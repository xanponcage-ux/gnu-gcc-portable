import json
import os
import time
import uuid
from typing import Any, Dict

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account

app = FastAPI(title="Tata Steel GenAI OpenAI-Compatible Bridge")

TARGET_AUDIENCE = os.getenv(
    "GENAI_TARGET_AUDIENCE",
    "https://genai-api-development-one-it-423929642383.asia-south1.run.app",
)
GATEWAY_URL = os.getenv(
    "GENAI_GATEWAY_URL",
    "https://tslgenaiapidev.corp.tatasteel.com/genai",
)
DEPLOYMENT_NAME = os.getenv("GENAI_MODEL", "gpt-4o-mini")
PROXY_URL = os.getenv("GENAI_PROXY", "http://127.0.0.1:13124")


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def make_session() -> AuthorizedSession:
    keyfile = required_env("GENAI_KEYFILE")
    creds = service_account.IDTokenCredentials.from_service_account_file(
        keyfile,
        target_audience=TARGET_AUDIENCE,
    )
    session = AuthorizedSession(creds)
    if PROXY_URL:
        session.proxies.update({"http": PROXY_URL, "https": PROXY_URL})
    return session


def gateway_payload(body: Dict[str, Any]) -> Dict[str, str]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        raise HTTPException(status_code=400, detail="messages must be a non-empty array")

    tools = body.get("tools") or []
    max_tokens = body.get("max_tokens") or body.get("max_completion_tokens") or 4000

    return {
        "deployment_name": DEPLOYMENT_NAME,
        "temperature": str(body.get("temperature", 0.1)),
        "adid": required_env("GENAI_ADID"),
        "apikey": required_env("GENAI_APIKEY"),
        "messages": json.dumps(messages),
        "tools": json.dumps(tools),
        "grounding": os.getenv("GENAI_GROUNDING", "0"),
        "max_tokens": str(max_tokens),
    }


def as_streaming_response(data: Dict[str, Any]):
    # The company gateway currently returns a complete OpenAI-style response.
    # Convert that one response into a minimal SSE stream for clients that ask
    # for stream=true (such as some OpenAI-compatible IDE clients).
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    model = data.get("model") or DEPLOYMENT_NAME
    response_id = data.get("id") or f"chatcmpl-{uuid.uuid4().hex}"
    created = data.get("created") or int(time.time())

    delta = {"role": message.get("role", "assistant")}
    if message.get("content") is not None:
        delta["content"] = message.get("content")
    if message.get("tool_calls") is not None:
        delta["tool_calls"] = message.get("tool_calls")

    chunk = {
        "id": response_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": choice.get("index", 0),
                "delta": delta,
                "finish_reason": choice.get("finish_reason"),
            }
        ],
    }

    def generate():
        yield "data: " + json.dumps(chunk) + "\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model": DEPLOYMENT_NAME,
        "gateway": GATEWAY_URL,
        "proxy_configured": bool(PROXY_URL),
    }


@app.get("/v1/models")
def models():
    return {
        "object": "list",
        "data": [
            {
                "id": DEPLOYMENT_NAME,
                "object": "model",
                "owned_by": "company-genai",
            }
        ],
    }


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    payload = gateway_payload(body)

    try:
        session = make_session()
        response = session.post(
            GATEWAY_URL,
            headers={},
            data=payload,
            files=[],
            timeout=180,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gateway connection/authentication failed: {exc}")

    if not response.ok:
        # Avoid echoing local credentials. The gateway response is still useful
        # for diagnosing auth/contract errors.
        detail = response.text[:3000]
        raise HTTPException(status_code=502, detail=f"Company GenAI HTTP {response.status_code}: {detail}")

    try:
        data = response.json()
    except Exception:
        raise HTTPException(status_code=502, detail="Company GenAI returned non-JSON data")

    if body.get("stream"):
        return as_streaming_response(data)
    return JSONResponse(content=data)
