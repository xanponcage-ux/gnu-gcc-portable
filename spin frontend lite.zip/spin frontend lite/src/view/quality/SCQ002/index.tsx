import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import { FormType } from "../../../view/auth/type";
import alertify from "../../../components/alert";
import { GetAuthorization } from "../../../utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import NextPlanIcon from "@mui/icons-material/NextPlan";
import WarningIcon from "@mui/icons-material/Warning";
import Draggable from "react-draggable";
import Paper, { PaperProps } from "@mui/material/Paper";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import { SCQ002Api } from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import ArchitectureIcon from "@mui/icons-material/Architecture";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, PopupObj, radio } from "./type";
import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "../../../context";
import { Collapse } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { isFloat } from "../../../utils";
import { MoveRowsModule } from "tabulator-tables";
import { getPickersCalendarHeaderUtilityClass } from "@mui/x-date-pickers/DateCalendar/pickersCalendarHeaderClasses";
import Auth from "../../../components/layout/dashboardLayout/auth";
import Upload from "../../chatbot/upload";
import aiGif from "../../../assets/images/ai_img.gif";

export default function SCQ002() {
  const [loading, setLoading] = React.useState(true);
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [btchData, setBtchData] = React.useState<Array<any>>([]);
  const [batchId, setBatchId] = React.useState<string>("");
  const [table2, setTable2] = React.useState<any>(null);
  const [tableData2, setTableData2] = React.useState<any>([]);
  const [reasonTable, setReasonTable] = React.useState<any>(null);
  const [reasonTableData, setReasonTableData] = React.useState<any>([]);
  const [radioOption, setRadioOption] =
    React.useState<string>("UPDATE REMARKS");

  ////

  const [isAdmin, setAdmin] = React.useState(false);
  const [isReadWriteAccess, setReadWriteAccess] = React.useState(true);
  const [plant, setPlant] = React.useState([]);
  const [selectedPlant, setSelectedPlant] = React.useState([]);
  const [selectedBatchId, setSelectedBatchId] = React.useState([]);
  const [selectedBatchStatus, setSelectedBatchStatus] = React.useState("HOLD");
  const [gridData, setGridData] = React.useState([]);
  const [rsnData, setRsnData] = React.useState([]);
  const [indexFind, setClickIndexModal] = React.useState(null);
  const [btchTableRef, setBtchTableRef] = React.useState(null);
  const [tableRef, setTableRef] = React.useState(null);
  const [gridTableRef, setGridTableRef] = React.useState(null);

  const [popUp, setPopUp] = React.useState<PopupObj>({ open: false, id: "" });
  const [popUp1, setPopUp1] = React.useState<PopupObj>({ open: false, id: "" });

  const [aiResp, setAiResp] = React.useState(""); // just the AI text
  const [analysis, setAnalysis] = React.useState(null);
  const [isAiEnabled, setIsAiEnabled] = React.useState(false);
  const [prevAiAnalysisFlag, setPrevAiAnalysisFlag] = React.useState(false);
  const [prevAiAnalysisList, setPrevAiAnalysisList] = React.useState<
    Array<{
      PLANT: string;
      BATCH_ID: string;
      SEQ_ID: number;
      CRT_BY?: string;
      CRT_DT?: string;
      AI_SUGG: string;
    }>
  >([]);

  const radioOptions: Array<radio> = [
    { label: "Display hold Batch", value: "HOLD" },
    { label: "Display Unhold Batch", value: "UPDATE REMARKS" },
    // { label: "Reduce Weight", value: "REDUCE_WT" },
  ];

  const HOLD: any = [
    {
      title: "Batch",
      field: "BATCHID",
      width: "100",
    },
    {
      title: "Batch Wt",
      field: "EOM_MS_GROSS_CAL",
      width: "100",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    // { title: "UOM", field: "EOM_UOM", width: "70" },
    { title: "Hold Cd", field: "HOLD_RSN", width: "150" },
    {
      title: "Hold Description",
      field: "HOLD_DESC",
      width: "300",
    },
    {
      title: "Operator Remarks",
      field: "OP_REMARKS",
      width: "250",
      editor: "input",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    { title: "MaterialNo", field: "MATERIAL_NO", width: "120" },
    { title: "Material Desc", field: "MATERIAL_DESC", width: "200" },
    { title: "Status", field: "EOM_CD_STATUS", width: "80" },
    { title: "Status Desc", field: "CD_DESC", width: "200" },
    {
      title: "Thick",
      field: "EOM_SEC1",
      width: "100",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Odia/Width",
      field: "EOM_SEC2",
      width: "120",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "EOM_LENGTH",
      width: "80",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    { title: "Customer Name", field: "ENC_CUST_NAME", width: "200" },
    { title: "Order", field: "EOM_ID_ORDER_CUS", width: "120" },
    { title: "Item", field: "EOM_ID_ORD_ITEM_CUS", width: "100" },
    { title: "Curr Proc", field: "EOM_CD_CURR_PROC", width: "100" },
    { title: "Next Proc", field: "EOM_CD_NEXT_PROC", width: "100" },
    { title: "TDC / Grade", field: "EOM_TDC_ACTL", width: "120" },
    { title: "Prod Code", field: "EOM_CD_PROD", width: "110" },
    { title: "Quality", field: "EOM_CD_QLTY_ACTL", width: "100" },
  ];
  const UPDATE_REMARKS = [
    { title: "Batch", field: "BATCHID" },
    {
      title: "Batch Wt",
      field: "EOM_MS_GROSS_CAL",
      // width: "100",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    // { title: "UOM", field: "EOM_UOM", width: "70" },
    { title: "Material No", field: "MATERIAL_NO" },
    { title: "Material Desc", field: "MATERIAL_DESC" },
    { title: "Status", field: "EOM_CD_STATUS" },
    { title: "Status Desc", field: "CD_DESC" },
    {
      title: "Thick",
      field: "EOM_SEC1",
      // width: "100",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Odia/Width",
      field: "EOM_SEC2",
      // width: "120",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "EOM_LENGTH",
      // width: "80",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    { title: "Customer Name", field: "ENC_CUST_NAME" },
    {
      title: "Order",
      field: "EOM_ID_ORDER_CUS",
      // width: "120",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "EOM_ID_ORD_ITEM_CUS",
      // width: "100",
      hozAlign: "right",
    },
    { title: "Curr Proc", field: "EOM_CD_CURR_PROC" },
    { title: "Next Proc", field: "EOM_CD_NEXT_PROC" },
    { title: "TDC / Grade", field: "EOM_TDC_ACTL" },
    { title: "Hold Rsn", field: "HOLD_RSN" },
    { title: "Hold Desc", field: "HOLD_DESC" },
    { title: "Operation Remarks", field: "OP_REMARKS" },
    { title: "Hold By", field: "HOLD_BY" },
    {
      title: "Hold Dt",
      field: "HOLD_DT",
      // width: "170",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          const d = new Date(value);
          // return date.toLocaleDateString('en-GB', {
          //     day: '2-digit', month: 'short', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric'
          // }).replace(/ /g, '-');

          return (
            ("0" + d.getDate()).slice(-2) +
            "-" +
            d.toString().substr(4, 3) +
            "-" +
            d.getFullYear() +
            " " +
            ("0" + d.getHours()).slice(-2) +
            ":" +
            ("0" + d.getMinutes()).slice(-2) +
            ":" +
            ("0" + d.getSeconds()).slice(-2)
          );
        }

        return value;
      },
    },
    { title: "Prod Code", field: "EOM_CD_PROD" },
    { title: "Quality", field: "EOM_CD_QLTY_ACTL" },
  ];

  const btchcolumn: Array<any> = [
    {
      formatter: "rowSelection",
      download: false,
      headerSort: false,
      frozen: true,
    },
    {
      title: "Batch",
      field: "BatchId",
      // width: "auto",
    },
    {
      title: "Hold Rsn",
      field: "HoldRsn",
      // width: "100",
    },
    {
      formatter: () => {
        return "<i class='fa-solid fa-square' style='color:#49a3f1'></i>";
      },
      width: 40,
      cellClick: function (e: any, cell: any) {
        const id = cell._cell.row.data.id;
        //;
        fetchData("getRsnData", undefined, undefined, undefined, id);
        setPopUp({ open: true, id: id });
      },
    },
    {
      title: "Suggestion (AI)",
      formatter: () => {
        // return "<i class='fa-solid fa-square' style='color:#ffa500'></i>";
        return `<img src="${aiGif}" style="width:24px;height:24px;cursor:pointer;" alt="AI" />`;
      },
      width: 100,
      cellClick: function (e: any, cell: any) {
        const id = cell._cell.row.data.id;
        setPopUp1({ open: true, id: id });
      },
    },
    { title: "Description", field: "Desc" },
    {
      title: "Operation Remarks",
      field: "OP_REMARKS",
      editor: "input",
      // width: "200",
      formatter: function (cell: any, formatterParams: any) {
        cell.getElement().style["border"] = "1.5px solid #748da6";
        var value = cell.getValue();
        if (value) {
          return value;
        }
        return value;
      },
    },
    { title: "Hold Date-Time", field: "holdDateTime" },
    { title: "Hold By", field: "userId" },
    { title: "Previous", field: "PREV" },
    { title: "Released By", field: "RLSBY" },
    { title: "Released Remarks", field: "RLSRMK" },
    { title: "Released Date-Time", field: "RLSTIME" },
  ];

  const rsnCol: any = [
    {
      title: "Reason Code",
      field: "CD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      cellClick: function (e: any, cell: any) {
        {
          handleClose(cell);
        }
      },
    },
    {
      title: "Reason",
      field: "CD_HOLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      cellClick: function (e: any, cell: any) {
        {
          handleClose(cell);
        }
      },
    },
  ];

  const procedureCall = (data: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ002Api(token, {
        route: "holdProcedure",
        data: data,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (data?.p_flag === "HOLD") {
            if (res?.data?.outBinds?.ls_out_flag[0] === "Y") {
              console.log(res.data);
              alertify.success(res?.data?.outBinds?.ls_out_flag);
              setTableData([]);
              setTableData2([]);
              fetchEpaData();
            } else {
              alertify.error(res?.data?.outBinds?.ls_out_flag);
              return;
            }
          } else if (data?.p_flag === "RMK_UPD") {
            if (res?.data?.outBinds?.ls_out_flag[0] === "Y") {
              alertify.success(res?.data?.outBinds?.ls_out_flag);
              setTableData([]);
              //console.log('ih')
            } else {
              console.log(res.data);
              alertify.error(res?.data?.outBinds?.ls_out_flag);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleSave = () => {
    var selectedRows = table2?.getSelectedRows();
    if (selectedRows === undefined || selectedRows?.length == 0) {
      alertify.error("No rows selected");
      return;
    }
    if (selectedRows[0]?._row.data?.HoldRsn === undefined) {
      alertify.error("Please select the hold rsn!");
      return;
    }
    let data = selectedRows.map((row: any) => {
      return row?._row?.data;
    });
    const bottomTableData = data[0];
    const topTabledata = table.getData()[0];
    let varData = {
      p_plant: selectedCode,
      p_batch: topTabledata?.BATCHID,
      p_rsn_hold_cd: bottomTableData?.HoldRsn,
      p_op_remarks: bottomTableData?.OP_REMARKS,
      p_status: topTabledata?.EOM_CD_STATUS,
      p_curr_proc: topTabledata?.EOM_CD_CURR_PROC,
      p_next_proc: topTabledata?.EOM_CD_NEXT_PROC,
      p_net_wt: topTabledata?.EOM_MS_GROSS_CAL,
      p_flag: "HOLD",
      p_user: user,
    };
    console.log(varData);
    procedureCall(varData);
  };

  React.useEffect(() => {
    fetchEpaData();
    getAIFeatureFlag();
  }, []);

  React.useEffect(() => {
    if (
      radioOption === "UPDATE REMARKS" &&
      table2 === null &&
      tableData2?.length > 0
    ) {
      setTable2(
        new Tabulator("#table6", {
          data: tableData2,
          columns: btchcolumn,
          // layout: "fitColumns",
          layout: "fitDataFill",
        })
      );
    } else if (tableData2?.length === 0) {
      setTable2(null);
    }
    if (table === null && tableData?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: tableData,
          columns: radioOption === "UPDATE REMARKS" ? UPDATE_REMARKS : HOLD,
          // layout: "fitColumns",
          layout: "fitDataFill",
        })
      );
    } else if (tableData?.length === 0) {
      setTable(null);
    }
  }, [tableData, tableData2]);

  React.useEffect(() => {
    console.log("hi");
    if (reasonTableData.length > 0) {
      setReasonTable(
        new Tabulator("#modalTable", {
          height: 400,
          data: reasonTableData,
          columns: rsnCol,
          layout: "fitDataFill",
        })
      );
    } else {
      setReasonTable(null);
    }
  }, [reasonTableData]);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ002Api(token, {
        route: "getPageData",
        plant: plant,
        status: radioOption,
        User: user,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log(res?.data);
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.PlanCode?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varData: Array<SelectType> = [];
              res?.data?.batch?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EOM_ID_BATCH?.toString(),
                    label: x?.EOM_ID_BATCH?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setBtchData(varData);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleClose = (cell: any) => {
    const rowId = popUp?.id;
    console.log(rowId);
    console.log(table, table2);
    table2?.updateRow(rowId, {
      HoldRsn: cell._cell?.row?.data?.CD_HOLD,
      Desc: cell._cell?.row?.data?.CD_DESC,
    });
    setPopUp({ open: false, id: "" });
    return;
  };

  const fetchData = async (
    route: any,
    plant?: any,
    batch?: any,
    status?: any,
    id?: any
  ) => {
    const d = new Date();
    var formattedDate =
      ("0" + d.getDate()).slice(-2) +
      "-" +
      d.toString().substr(4, 3) +
      "-" +
      d.getFullYear() +
      " " +
      ("0" + d.getHours()).slice(-2) +
      ":" +
      ("0" + d.getMinutes()).slice(-2) +
      ":" +
      ("0" + d.getSeconds()).slice(-2);

    if (route === "SCQ002getBatchInformation" && !selectedCode) {
      alertify.error("Please Select the plant");
      return;
    }
    if (route === "SCQ002getBatchInformation" && !batchId) {
      alertify.error("Please Select a Batch");
      return;
    }
    console.log(selectedCode, batchId, radioOption);
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ002Api(token, {
        route: route,
        plant: plant ? plant : selectedCode,
        batchId: batch ? batch : batchId,
        status: status ? status : radioOption,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (route === "batchChange") {
              if (res?.data?.batch?.length > 0) {
                const varData: Array<SelectType> = [];
                res?.data?.batch?.map((x: any, i: number) => (
                  <React.Fragment key={i}>
                    {varData?.push({
                      value: x?.EOM_ID_BATCH?.toString(),
                      label: x?.EOM_ID_BATCH?.toString(),
                      id: i,
                    })}
                  </React.Fragment>
                ));
                setBtchData(varData);
              }
            } else if (route === "SCQ002getBatchInformation") {
              console.log(res?.data);
              if (res.data.length > 0) {
                setTableData(res?.data);
                setTableData2([
                  {
                    BatchId: batchId,
                    OP_REMARKS: res.data["OP_REMARKS"],
                    Desc: "",
                    Holdrsn: "",
                    holdDateTime: formattedDate,
                    id: 0,
                    userId: user,
                  },
                  // ...[...Array(9)].map((it, i) => ({ id: i + 1 }))
                ]);
              }
            } else if (route === "getRsnData") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No Reason Data exists");
              }
              setReasonTableData(res.data);
              console.log("reasonTableData: ", reasonTableData);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setTableData([]);
    setTableData2([]);
    setReasonTableData([]);
    setBatchId("");
    setPrevAiAnalysisFlag(false);
  };

  const handleUpdate = () => {
    let data = table?.getData()[0];
    if (!data) {
      alertify.error("No data to Update");
      return;
    }
    const topTabledata = table.getData()[0];
    let varData = {
      p_plant: selectedCode,
      p_batch: topTabledata?.BATCHID,
      p_rsn_hold_cd: topTabledata?.HOLD_RSN,
      p_op_remarks: topTabledata?.OP_REMARKS,
      p_status: topTabledata?.EOM_CD_STATUS,
      p_curr_proc: topTabledata?.EOM_CD_CURR_PROC,
      p_next_proc: topTabledata?.EOM_CD_NEXT_PROC,
      p_net_wt: topTabledata?.EOM_MS_GROSS_CAL,
      p_flag: "RMK_UPD",
      p_user: user,
    };
    console.log(varData);
    procedureCall(varData);
  };

  const handleBatchIdChange = (e: string) => {
    setTableData([]);
    setTableData2([]);
    setBatchId(e);
    setPrevAiAnalysisFlag(false);
    setPrevAiAnalysisList([]);
  };

  const handleSearch = () => {
    fetchData("SCQ002getBatchInformation");
    // prevAiAnalysisExists();
    if (isAiEnabled) getPrevAiAnalysis();
  };

  // Implentation - Save AI Analysis

  const normalizeAiResp = (text: string) =>
    (text ?? "").replace(/\*\*/g, "").trim();

  React.useEffect(() => {
    let cancelled = false; // to avoid setting state after unmount

    const run = async () => {
      console.log("aiResp: ", aiResp);
      console.log("analysis: ", analysis);

      if (aiResp !== null && aiResp !== undefined && aiResp !== "") {
        try {
          let normAiResp = normalizeAiResp(aiResp);
          // console.log("normResp: ", normAiResp);
          await saveAiAnalysis(normAiResp);
        } catch (e) {
          // already handled inside saveAiAnalysis; optional
          console.error(e);
        }
      }
    };

    run();

    // Proper cleanup function (not a Promise)
    return () => {
      cancelled = true;
    };
  }, [aiResp, analysis]);

  const saveAiAnalysis = async (normAiResp: string) => {
    // console.log("Inside saveAiAnalysis");
    // console.log("normAiResp: ", normAiResp);
    setLoading(true);
    try {
      const token: TokenType = await GetAuthorization();

      const res = await SCQ002Api(token, {
        route: "saveAiAnalysis",
        plant: selectedCode ?? "",
        aiResp: normAiResp ?? "",
        userId: user,
        batchId: batchId,
        imgPath: analysis?.imageDets?.data?.remotePath ?? "",
      });

      if (res?.statusText && res.statusText !== "OK") {
        // alertify.error(res?.data?.err ? res.data.err : res?.toString());
        return;
      }

      console.log("saveAiAnalysis response:", res?.data);
      // Optionally show success toast
      // alertify.success("AI analysis saved");
    } catch (e: any) {
      alertify.error(
        e?.error?.message ? e.error.message : "Something went wrong!"
      );
    } finally {
      setLoading(false);
    }
  };

  const getAIFeatureFlag = async () => {
    setLoading(true);
    try {
      const token: TokenType = await GetAuthorization(); // await instead of .then

      const res = await SCQ002Api(token, {
        route: "isAiEnabled",
      });

      if (res?.statusText && res.statusText !== "OK") {
        // alertify.error(res?.data?.err ? res.data.err : res?.toString());
        return;
      }

      console.log("getAIFeatureFlag: ", res?.data);
      const flag = res?.data?.[0]?.FLAG;
      if (flag === "Y") setIsAiEnabled(true);
      else setIsAiEnabled(false);
    } catch (e: any) {
      alertify.error(
        e?.error?.message ? e.error.message : "Something went wrong!"
      );
    } finally {
      setLoading(false);
    }
  };

  const prevAiAnalysisExists = async () => {
    setLoading(true);
    try {
      const token: TokenType = await GetAuthorization(); // await instead of .then

      const res = await SCQ002Api(token, {
        route: "prevAiAnalysisExists",
        batchId: batchId ?? "",
        plant: selectedCode,
      });

      if (res?.statusText && res.statusText !== "OK") {
        alertify.error(res?.data?.err ? res.data.err : res?.toString());
        return;
      }

      console.log("prevAiAnalysisExists: ", res?.data);
      const flag = res?.data;
      if (flag === "Y") {
        setPrevAiAnalysisFlag(true);
        getPrevAiAnalysis();
      } else setPrevAiAnalysisFlag(false);
    } catch (e: any) {
      alertify.error(
        e?.error?.message ? e.error.message : "Something went wrong!"
      );
    } finally {
      setLoading(false);
    }
  };

  const getPrevAiAnalysis = async () => {
    setLoading(true);
    try {
      const token: TokenType = await GetAuthorization();

      const res = await SCQ002Api(token, {
        route: "getprevAiAnalysis",
        batchId: batchId,
      });

      if (res?.statusText && res.statusText !== "OK") {
        // alertify.error(res?.data?.err ? res.data.err : res?.toString());
        return;
      }

      // Ensure it's an array and sort DESC by SEQ_ID (API already does DESC; keep for safety)
      const list = Array.isArray(res?.data) ? [...res.data] : [];
      // list.sort((a, b) => (b.SEQ_ID ?? 0) - (a.SEQ_ID ?? 0));

      setPrevAiAnalysisList(list);
      setPrevAiAnalysisFlag(list.length > 0);
    } catch (e: any) {
      alertify.error(
        e?.error?.message ? e.error.message : "Something went wrong!"
      );
    } finally {
      setLoading(false);
    }
  };

  // Implementation of wt reduction feature
  // const [wtReduceTable, setWtReduceTable] = React.useState<any>(null);
  // const [wtReduceTableData, setWtReduceTableData] = React.useState<any>([]);

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={2} sx={{ pl: 1 }}>
            {/* ---------------------- Alert --------------------------- */}
            <Dialog
              open={popUp.open}
              onClose={() => {
                console.log("hurrey");
              }}
            >
              <DialogTitle>Reason Data</DialogTitle>
              <DialogContent>
                {loading ? <Loader /> : null}
                {reasonTableData?.length > 0 ? <div id="modalTable" /> : null}
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={() => {
                    setPopUp({ open: false, id: "" });
                  }}
                  color="primary"
                >
                  Close
                </Button>
              </DialogActions>
            </Dialog>
            <Dialog open={popUp1.open} onClose={() => {}}>
              <DialogTitle>Suggested Hold code (AI)</DialogTitle>
              <DialogContent>
                {isAiEnabled && (
                  <Upload
                    onAIResp={(resp: any) => {
                      // This fires whenever Upload gets AIResp
                      setAiResp(resp);
                    }}
                    onAnalysis={(payload: any) => {
                      // Complete result in case you need more than AIResp
                      setAnalysis(payload);
                    }}
                    batchId={batchId}
                  />
                )}
                {!isAiEnabled && <p>Feature is currently not available</p>}
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={() => {
                    setPopUp1({ open: false, id: "" });
                  }}
                  color="primary"
                >
                  Close
                </Button>
              </DialogActions>
            </Dialog>

            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid
                      container
                      spacing={2}
                      sx={{
                        gap: 1.5,
                      }}
                    >
                      <Grid item xs={2} sx={{ ml: 2 }}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            fetchEpaData(e);
                            setTableData([]);
                            setTableData2([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <SelectInput
                          label="Batch Id"
                          data={btchData}
                          id={"id2"}
                          value={batchId}
                          size={"small"}
                          onChange={handleBatchIdChange}
                        />
                      </Grid>

                      <Grid item xs={1}>
                        <ButtonElement
                          // onClick={() => fetchData("SCQ002getBatchInformation")}
                          onClick={() => handleSearch()}
                        >
                          Search
                        </ButtonElement>
                      </Grid>

                      <Grid item xs={6}>
                        <RadioInput
                          id={"radioOption"}
                          row={true}
                          value={radioOption}
                          data={radioOptions}
                          onChange={(e: string) => {
                            setTableData([]);
                            setTableData2([]);
                            setRadioOption(e);
                            fetchData("batchChange", undefined, undefined, e);
                          }}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Batch Information"
                headerContainer={
                  <Grid container>
                    {radioOption === "HOLD" && (
                      <Grid item>
                        <Tooltip title="Update Remarks">
                          <IconButton
                            onClick={() => handleUpdate()}
                            disabled={restricted !== "RL_RW"}
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid>
                    )}

                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel("Batch Information", tableData, table)
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>

                    {/* <Grid item>
                        <Tooltip title="Decision">
                          <IconButton
                            onClick={() =>
                              //console.log('HEL')
                              handleDecision()
                              //handleSave()
                            }
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid> */}
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            {tableData2?.length > 0 && radioOption === "UPDATE REMARKS" && (
              <Grid item xs={12}>
                <TableContainer
                  title={`QA Hold on Batch`}
                  headerContainer={
                    <Grid container>
                      <Grid item>
                        <Tooltip title="Decision">
                          <IconButton
                            onClick={() => handleSave()}
                            disabled={restricted !== "RL_RW"}
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid>
                    </Grid>
                  }
                >
                  {tableData2?.length > 0 && <div id="table6"></div>}
                  <br />
                  <p
                    color="black"
                    style={{
                      color: "black",
                      paddingLeft: "1rem",
                      marginTop: "-1rem",
                    }}
                  >
                    Showing 1 to {tableData2?.length} of {tableData2?.length}{" "}
                    entries
                  </p>
                </TableContainer>
              </Grid>
            )}

            {prevAiAnalysisFlag && (
              <Grid item xs={12}>
                <TableContainer title="Previous AI Analysis">
                  <div style={{ padding: "1rem", marginTop: "-0.5rem" }}>
                    {prevAiAnalysisList.map((row) => {
                      const key = `${row.BATCH_ID}-${row.SEQ_ID}`;
                      // Optional: format date for display
                      const dt = row.CRT_DT
                        ? new Date(row.CRT_DT).toLocaleString()
                        : "";

                      return (
                        <div
                          key={key}
                          style={{
                            marginBottom: "1rem",
                            padding: "0.75rem 0",
                            borderBottom: "1px dashed #ddd",
                          }}
                        >
                          {/* Header line with Serial (SEQ_ID) and metadata */}
                          <div
                            style={{
                              fontWeight: 600,
                              marginBottom: "0.25rem",
                              color: "#222",
                            }}
                          >
                            {/* “Serial No” requested: using SEQ_ID */}#
                            {row.SEQ_ID}
                            <span
                              style={{
                                fontWeight: 400,
                                color: "#555",
                                marginLeft: 8,
                              }}
                            >
                              ({row.PLANT} / {row.BATCH_ID}
                              {dt ? ` • ${dt}` : ""}
                              {row.CRT_BY ? ` • by ${row.CRT_BY}` : ""})
                            </span>
                          </div>

                          {/* Body — AI text with preserved line breaks */}
                          <pre
                            style={{
                              margin: 0,
                              color: "black",
                              whiteSpace: "pre-wrap",
                              wordWrap: "break-word",
                            }}
                          >
                            {row.AI_SUGG ?? ""}
                          </pre>
                        </div>
                      );
                    })}

                    {/* Show a fallback if list is empty for some reason */}
                    {prevAiAnalysisList.length === 0 && (
                      <p style={{ color: "#666", margin: 0 }}>
                        No previous AI analyses found.
                      </p>
                    )}
                  </div>
                </TableContainer>
              </Grid>
            )}

            {/* {prevAiAnalysisFlag && (
              <Grid item xs={12}>
                <TableContainer title={`OLD AI Analysis`}>
                  <p
                    color="black"
                    style={{
                      color: "black",
                      paddingLeft: "1rem",
                      marginTop: "-1rem",
                    }}
                  >
                    {prevAiAnalysisResult}
                  </p>
                </TableContainer>
              </Grid>
            )} */}
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
}
