import { Request, Response } from "express";
import SCQ002Model from "../models/SCQ002Model";
import { ResponceData } from "../utils";

export const SCQ002Api = async (req: Request, res: Response) => {
  try {
    const result1 = await SCQ002Model.prototype.SCQ002Model(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
