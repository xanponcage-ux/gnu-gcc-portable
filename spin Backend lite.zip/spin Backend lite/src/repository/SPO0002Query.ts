import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data.Plant) {
        return {
          batch: await ResponceData(
            await query(`
            select distinct EOM_ID_BATCH 
            from v_epa_prodn where eom_cd_status in ('VB','VF')
            AND EOM_CD_EPA = ${data.Plant}
            `)
          ),
          process: await ResponceData(
            await query(`
            select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
            FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
            `)
          ),
          status: await ResponceData(
            await query(`
            select CD_VALUE,CD_VALUE || ' - ' ||CD_DESC CD_DESC from V_CODES
            where CD_TYPE='E0001' and CD_VALUE in ('KB','KF','WB','WC','WF','WO','WL','WS','WT') order by 1
            `)
          ),
          ordTypeData: await ResponceData(
            await query(
              `SELECT DISTINCT ENC_ORDER_TYPE FROM V_END_CUST_ORD_EPA 
                WHERE ENC_CD_EPA=${data.Plant} and ENC_ST_ORDER='A' ORDER  BY 1`
            )
          ),
          custData: await ResponceData(
            await query(
              `SELECT DISTINCT ENC_CD_END_CUST,ENC_CD_END_CUST||' - '||ENC_CUST_NAME ENC_CUST_NAME 
                FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA=${data.Plant} AND  ENC_ST_ORDER='A' AND TRIM(ENC_CD_END_CUST) IS NOT NULL ORDER BY 1`
            )
          ),
          labelStatus: await ResponceData(
            await query(
              `select CD_VALUE STATUS from v_codes where cd_type = 'TK030'`
            )
          ),
        };
      } else {
        return getCommonPlantData();
      }
    } else if (data?.type === "coilData") {
      let QrygetCoils = `
        SELECT EOM_ID_BATCH,EOM_ID_PAR_COIL_NO, EOM_ID_FIRST_PAR, EOM_CD_PROD, EOM_LENGTH, EOM_CD_QLTY_ACTL, EOM_CD_SHIFT,
       round(EOM_MS_GROSS_ACTL,3) EOM_MS_GROSS_ACTL, EOM_MS_PIECE_ACTL, EOM_SEC1, EOM_SEC2, EOM_CD_ST_ACTL, 
       EOM_PASSED_PROC, EOM_NO_PIECES, EOM_TDC_ACTL, EOM_FL_SLEEVE, EOM_MS_SLEEVE,round(EOM_MS_GROSS_CAL,3) EOM_MS_GROSS_CAL,
       EOM_PASSED_PROC,EOM_PLANNED_PROC,EOM_MS_PIECE_CAL, EOM_IDIA, EOM_ODIA,EOM_NO_CAST,EOM_CD_SHIFT,
       TRIM(EOM_SCO_ORDER) EOM_SCO_ORDER,EOM_SCO_ITEM, EOM_ID_ORDER_CUS, EOM_ID_ORD_ITEM_CUS, EOM_CD_CURR_PROC, 
       EOM_CD_NEXT_PROC, EOM_CD_STATUS, EOM_CD_PREV_PROC, TO_char(EOM_TS_CREATION,'DD-MON-YYYY') EOM_TS_CREATION, EOM_FL_SEND_SAP, EOM_ID_OP_DECSN,EOM_SLIT_STATUS, 
       EOM_YIELD_STRENGTH,EOM_TENTATIVE_LENGTH, EOM_FINAL_JAC_GRD, EOM_UOM, EOM_ACTIVITY_TIME,NVL(EOM_cD_PACK,' ') STORAGE_LOC,
       CASE EOM_CD_STATUS WHEN 'WB' THEN ROUND(trunc(SYSDATE)-trunc(EOM_DT_PIECE_UPD))   ELSE 0  END AGE, 
       CASE WHEN EOM_CD_STATUS in ('WB','WS','WT','WL','WO','WD','WC','WF') THEN round(EOM_MS_GROSS_ACTL,3)  END GROSS_ACTL, 
       Case EOM_CD_STATUS When 'WB' THEN TO_CHAR(EOM_DT_PIECE_UPD)   ELSE ''  END EOM_DT_PIECE_UPD, 
       (Select DISTINCT ENC_ORDER_TYPE FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_ePA  And ENC_ID_ORDER = EOM_ID_ORDER_CUS And ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) Order_Type,
       (Select DISTINCT ENC_CUST_NAME FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_ePA  And ENC_ID_ORDER = EOM_ID_ORDER_CUS And ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) Customer_name,
       (Select DISTINCT ENC_SHIP_TO_PRTY_DESC FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_ePA  And ENC_ID_ORDER = EOM_ID_ORDER_CUS And ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) Party_Desc,
       --(SELECT DISTINCT IQL_GRADE_DESC  FROM V_QUALITY WHERE IQL_CD_QLTY = EOM_CD_QLTY_ACTL) Grade_Desc,  
       (Select DISTINCT ENC_MARK_CUST FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_ePA  And ENC_ID_ORDER = EOM_ID_ORDER_CUS And ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) Mark_Cust,
       (Select DISTINCT SUBSTR(REPLACE(ENC_MARK_CUST_NAME,CHR(10),' '),1,100) ENC_MARK_CUST_NAME FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_ePA  And ENC_ID_ORDER = EOM_ID_ORDER_CUS And ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) MkCustomer_Name, 
       (SELECT DISTINCT CD_DESC FROM V_CODES WHERE  CD_TYPE = 'E0001' AND  CD_VALUE = EOM_CD_STATUS) STATUS_DESC, 
        EOM_NO_PIECES EOM_NO_PIECES1,EOM_MS_PIECE_ACTL EOM_MS_PIECE_ACTL1, round(EOM_MS_GROSS_ACTL,3) EOM_MS_GROSS_ACTL1,
        EOM_NO_MATNR MATNR,(SELECT MAKTX FROM V_MAKT WHERE MANDT='600' AND MATNR= EOM_NO_MATNR) MATR_DESC
        ,(SELECT enc_no_matnr FROM v_end_cust_ord_epa
            WHERE enc_cd_epa = eom_cd_epa AND enc_id_order=eom_id_order_cus  
            AND enc_no_item = eom_id_ord_item_cus) FG_MAT_NO,
            ( SELECT maktx
                           FROM
                               v_makt
                           WHERE
                               mandt = '600'
                               AND matnr = (SELECT enc_no_matnr FROM v_end_cust_ord_epa
                                             WHERE enc_cd_epa = eom_cd_epa 
                                             AND enc_id_order=eom_id_order_cus  AND enc_no_item = eom_id_ord_item_cus
                                           )
                               AND ROWNUM = 1
                       ) FG_MATERIAL_DESC,
            --(SELECT IPD_PROD_DESC FROM V_PRODUCT WHERE IPD_STATUS ='A'
            --AND IPD_PROD_CD IN (SELECT ENC_CD_PROD FROM V_END_CUST_ORD_EPA
            --WHERE ENC_CD_EPA = EOM_CD_EPA AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM= EOM_ID_ORD_ITEM_CUS)) PROD_INFO,                        
           (SELECT PRODUCT_DESC FROM V_PRODUCT_DTLS WHERE STATUS ='A'
           AND PRODUCT_CD IN (SELECT ENC_CD_PROD FROM V_END_CUST_ORD_EPA
           WHERE ENC_CD_EPA = EOM_CD_EPA AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM= EOM_ID_ORD_ITEM_CUS)) PROD_INFO,
           (select enc_cd_grade from v_end_cust_ord_epa WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
              AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
              AND ENC_CD_EPA = EOM_CD_EPA) COIL_GRADE,
           (SELECT F_GET_SAPGRADE ('131',
                                  EOM_ID_ORDER_CUS,
                                  EOM_ID_ORD_ITEM_CUS
                                 )
             FROM DUAL) GRADE_DESC,
           (select RDC_SLIT_POS from v_sl_dautr_pdo where rdc_id_batch = eom_id_batch and rdc_cd_epa = eom_cd_epa) SLIT_POS,
           (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                       FROM v_tc_coil_test
                      WHERE tco_prod_no = eom_id_first_par
                        AND tco_cast_no = eom_no_cast
                        AND tco_test_para IN ('LYS', 'YS')
                        AND ROWNUM = 1) ys,
           (select ENC_MATNR_INFO from v_end_cust_ord_epa WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
              AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
              AND ENC_CD_EPA = EOM_CD_EPA) MAT_INFO,
           (SELECT SUBSTR(LONG_TEXT, 1, INSTR(LONG_TEXT, '(') - 1) FROM V_YMQMT_BIS_INFO WHERE WERKS = (SELECT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_ID_COIL = EOM_ID_FIRST_PAR)
            AND VORLNR = (SELECT ENC_NO_TDC FROM V_END_CUST_ORD_EPA WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
           AND ENC_CD_EPA = EOM_CD_EPA)) GRADE,
           (SELECT KURZTEXT FROM V_YMQMT_BIS_INFO WHERE WERKS = (SELECT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_ID_COIL = EOM_ID_FIRST_PAR)
            AND VORLNR = (SELECT ENC_NO_TDC FROM V_END_CUST_ORD_EPA WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
           AND ENC_CD_EPA = EOM_CD_EPA)) LIC_NO,
           (SELECT SORTFELD FROM V_YMQMT_BIS_INFO WHERE WERKS = (SELECT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_ID_COIL = EOM_ID_FIRST_PAR)
            AND VORLNR = (SELECT ENC_NO_TDC FROM V_END_CUST_ORD_EPA WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
           AND ENC_CD_EPA = EOM_CD_EPA)) CML_NO,
          (select APPLICATIONID from v_qci_appl_mst where plantcode = EOM_CD_EPA 
            and HSN_CODE = (SELECT distinct substr(STEUC,0,4) 
            FROM v_MARC WHERE mandt = '600' 
            AND WERKS = EOM_CD_EPA
           and matnr = (SELECT ENC_NO_MATNR FROM V_END_CUST_ORD_EPA
           WHERE ENC_CD_EPA = EOM_CD_EPA AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM= EOM_ID_ORD_ITEM_CUS))) APPL_ID
        FROM V_EPA_PRODN    
        WHERE EOM_CD_EPA = ${data.Plant}   
        AND EOM_CD_STATUS IN ('KB','KF','WB','WC','WF','WO','WL','WS','WT')
        AND EOM_CD_QLTY_ACTL  NOT IN ('SCRP')`;

      if (data?.Status && data?.Status?.length > 0) {
        QrygetCoils += ` And EOM_CD_STATUS =NVL('${data.Status}', EOM_CD_STATUS)`;
      }
      if (data?.batch && data?.batch?.length > 0) {
        QrygetCoils += ` And EOM_ID_BATCH =NVL('${data.batch}', EOM_ID_BATCH)`;
      }
      if (data?.mBatch && data?.mBatch?.length > 0) {
        QrygetCoils += ` And EOM_ID_FIRST_PAR =NVL('${data.mBatch}', EOM_ID_FIRST_PAR)`;
      }
      if (
        (data?.thickFrom && data?.thickFrom?.length > 0) ||
        (data?.thickFrom && data?.thickTo?.length > 0)
      ) {
        QrygetCoils += ` And EOM_SEC1 BETWEEN NVL('${data.thickFrom}',EOM_SEC1) AND NVL('${data.thickTo}',NVL('${data.thickFrom}',EOM_SEC1))`;
      }
      if (
        (data?.widthFrom && data?.widthFrom?.length > 0) ||
        (data?.widthFrom && data?.widthTo?.length > 0)
      ) {
        QrygetCoils += ` And EOM_SEC2 BETWEEN NVL('${data.widthFrom}',EOM_SEC2) AND NVL('${data.widthTo}',NVL('${data.widthFrom}',EOM_SEC2))`;
      }
      if (data?.ProdDtFrom && data?.ProdDtFrom?.length > 0) {
        QrygetCoils += ` And TRUNC(eom_ts_creation) BETWEEN NVL('${data.ProdDtFrom}',TRUNC(eom_ts_creation)) AND  NVL('${data.ProdDtTo}',NVL('${data.ProdDtFrom}',TRUNC(eom_ts_creation)))`;
      }
      if (data?.DisDtFrom && data?.DisDtFrom?.length > 0) {
        QrygetCoils += ` AND TRUNC(eom_dt_loading) BETWEEN NVL('${data.DisDtFrom}',TRUNC(eom_dt_loading)) AND  NVL('${data.DisDtTo}',NVL('${data.DisDtFrom}',TRUNC(eom_dt_loading))) `;
      }
      // if (data?.PkgDtTo && data?.PkgDtTo?.length > 0) {
      //       QrygetCoils += ` AND TRUNC(eom_ts_creation) BETWEEN NVL('${data.PkgDtFrom}',TRUNC(eom_ts_creation)) AND  NVL('${data.PkgDtTo}',NVL('${data.PkgDtFrom}',TRUNC(eom_ts_creation))) `
      // }
      QrygetCoils += ` ORDER BY EOM_TS_CREATION`;
      // console.log("QrygetCoils: ", QrygetCoils);
      return await query(QrygetCoils);
    } else if (data?.type === "saveLabelInfo") {
      return await saveLabelInfo(data);
    } else if (data?.type === "getLabelCount") {
      return await checkLabelCountFG(data);
    }
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const saveLabelInfo = async (data: any) => {
  try {
    // console.log("Inside saveLabelInfo");

    let labelCount = Number(await checkLabelCountFG(data));

    const userId = data?.user;
    const isAdmin = await checkAdmnIds(userId);
    // console.log("isAdmin-saveLabelInfo: ", isAdmin);
    if (labelCount > 0 && !isAdmin) {
      return "N-New Label cannot be generated.Label already generated.Contact Quality team";
    }
    // console.log("labelCount-saveLabelInfo: ", labelCount);

    let sql = `INSERT INTO V_LABEL_INFO (
        TLC_TIMESTAMP,
        TLC_CD_EPA,
        TLC_ID_BATCH,
        TLC_USER,
        TLC_LABEL_TYPE,
        TLC_BATCH_STATUS,
        TLC_FIRST_PAR,
        TLC_LABEL_CRT_ON,
        TLC_LABLE_CRT_BY,
        TLC_PROG_NM,
        TLC_SEQ
    ) VALUES (
        f_nannow_second_telgrm(SYSDATE),
        '${data?.plant}',
        '${data?.batchId}',
        '${data?.user}',
        'FG',
        '${data?.batchStatus}',
        '${data?.firstPar}',
        SYSDATE,
        '${data?.user}',
        'SPO0002',
        '${labelCount + 1}'
    )`;

    // console.log("sql-saveLabelInfo: ", sql);

    let result = await query(sql);
    // console.log("result: ", result);
    if (Number(result?.rowsAffected) > 0) {
      result = "Y-Label Details Saved";
    }
    return result;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const checkLabelCountFG = async (data: any) => {
  try {
    //console.log("Inside checkLabelCountFG");
    const chkCoilQry = ` select count(*) BATCH_COUNT from V_LABEL_INFO 
     where TLC_ID_BATCH = '${data?.batchId}'
     and TLC_CD_EPA = '${data?.plant}' and TLC_LABEL_TYPE = 'FG' `;
    //console.log("chkCoilQry: ", chkCoilQry);

    let chkCoilQryResult = await ResponceData(await query(chkCoilQry));
    //console.log("chkCoilQryResult: ", chkCoilQryResult);

    const labelCount = chkCoilQryResult?.[0]?.BATCH_COUNT;
    //console.log("labelCount-checkLabelCountFG: ", labelCount);

    return labelCount;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const checkAdmnIds = async (user: any) => {
  try {
    //console.log("Inside checkAdmnIds");
    const chkIdQry = ` select CD_VALUE AS ADMN_ID_FG from v_codes where cd_type = 'TK037' `;
    //console.log("chkIdQry: ", chkIdQry);

    let adminIdFGList = await ResponceData(await query(chkIdQry));
    adminIdFGList = adminIdFGList;
    //console.log("adminIdFGList: ", adminIdFGList, adminIdFGList?.[0]);

    const isAdmin = adminIdFGList.some((item: any) => item.ADMN_ID_FG === user);
    //console.log("isAdmin-checkAdmnIds: ", isAdmin);

    return isAdmin;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

// Not getting used in system
export const ConfirmPacking = async (data: any) => {
  try {
    if (data?.type === "confirmPacking") {
      const sql = `call SPOB002_CONF_TEMP_INS (
            P_PLANT => :P_PLANT,
            P_BATCHID=> :P_BATCHID,
            P_MCOIL => :P_MCOIL,
            P_PROC => :P_PROC,
            CUSTORD => :CUSTORD,
            CUSTITM => :CUSTITM,
            NXTPROC => :NXTPROC,
            PROD  => :PROD,
            QLTY => :QLTY,
            THICK  => :THICK,
            WIDTH => :WIDTH,
            P_LENGTH => :P_LENGTH,
            PIECE_ACTL    => :PIECE_ACTL,
            GROSS_ACTL => :GROSS_ACTL,
            P_NO_PCS => :P_NO_PCS,
            TDC => :TDC,
            USRID => :USRID,
            IDIA => :IDIA,
            ODIA => :ODIA,
            SHIFT => :SHIFT,
            PLANNED_PROC => :PLANNED_PROC,
            OPR_CMNT => :OPR_CMNT,
            ST_PRODN => :ST_PRODN,
            P_SCRAP_WT       => :P_SCRAP_WT,
            P_CAST_NO=> :P_CAST_NO,
            P_STATUS => :P_STATUS,
            ls_out_flag => :ls_out_flag
            )`;

      const binds = {
        P_PLANT: data.plant,
        P_BATCHID: data.row[0].EOM_ID_BATCH,
        P_MCOIL: data.row[0].EOM_ID_FIRST_PAR,
        P_PROC: data.row[0].EOM_CD_CURR_PROC,
        CUSTORD: data.row[0].EOM_ID_ORDER_CUS,
        CUSTITM: data.row[0].EOM_ID_ORD_ITEM_CUS,
        NXTPROC: data.row[0].EOM_CD_NEXT_PROC
          ? data.row[0].EOM_CD_NEXT_PROC
          : "",
        PROD: data.row[0].EOM_CD_PROD ? data.row[0].EOM_CD_PROD : "",
        QLTY: data.row[0].EOM_CD_QLTY_ACTL ? data.row[0].EOM_CD_QLTY_ACTL : "",
        THICK: data.row[0].EOM_SEC1 ? data.row[0].EOM_SEC1 : 0,
        WIDTH: data.row[0].EOM_SEC2 ? data.row[0].EOM_SEC2 : 0,
        P_LENGTH: data.row[0].EOM_LENGTH ? data.row[0].EOM_LENGTH : 0,
        PIECE_ACTL: data.row[0].EOM_MS_PIECE_ACTL
          ? data.row[0].EOM_MS_PIECE_ACTL
          : "", //data.MS_PIECE_ACTL, scrap mass is in MS_INPUT
        GROSS_ACTL: data.row[0].EOM_MS_GROSS_ACTL
          ? data.row[0].EOM_MS_GROSS_ACTL
          : "", //data.MS_GROSS_CAL,
        P_NO_PCS: data.row[0].EOM_NO_PIECES,
        TDC: data.row[0].EOM_TDC_ACTL,
        USRID: data.userid,
        IDIA: data.row[0].EOM_IDIA ? data.row[0].EOM_IDIA : 0,
        ODIA: data.row[0].EOM_ODIA ? data.row[0].EOM_ODIA : 0,
        SHIFT: data.row[0].EOM_CD_SHIFT ? data.row[0].EOM_CD_SHIFT : "",
        PLANNED_PROC: data.row[0].PLAN_PROC ? data.row[0].PLAN_PROC : "",
        OPR_CMNT: data.row[0].OPR_CMNT ? data.row[0].OPR_CMNT : "",
        ST_PRODN: data.row[0].ST_PRODN ? data.row[0].ST_PRODN : "",
        P_SCRAP_WT: data.row[0].EOM_MS_GROSS_ACTL, //data.MS_INPUT ? "",//{Scrap} this P_SCRAP_WT is being inserted in input mass in procedure thus piece_mass is being passed
        P_CAST_NO: data.row[0].EOM_NO_CAST ? data.row[0].EOM_NO_CAS : "",
        P_STATUS: data.row[0].EOM_CD_STATUS,
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      return await query(sql, binds);
    }
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const confirm = async (data: any) => {
  try {
    //Procedure is used for confirm packing
    //if (data?.type === 'confirmPacking') {
    const sql = `call SPOB002_CONF_PK (
            P_PLANT_ID => :P_PLANT_ID,
            P_BATCH=> :P_BATCH,
            P_USERID => :P_USERID,
            ls_out_flag => :ls_out_flag
            )`;
    const binds = {
      P_PLANT_ID: data.plant,
      P_BATCH: data.row[0].EOM_ID_BATCH,
      P_USERID: data.userid,
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    return await query(sql, binds);
    // }
  } catch (error: any) {
    throw new Error.InternalServerError(error.toString());
  }
};
