// const SPO0001Query = require("../repository/SPO0001Query");
import { getData, getProdData } from "../repository/SPO0001Query";

export default class SPO0001Model {
  getData(data: any) {
    return getData(data);
  }
  getProdData(data: any) {
    return getProdData(data);
  }
}
