import { Router } from "express";
import {
  // getData05,
  getEpaCode02,
  //getData06,
  //   getData07,
  // getTdcCode05,
  //   getOrderId07,
  getEpaCodeData08,
  getPlantData,
  callProcedure06,
  getData06,
  getEpaCode06,
} from "../controllers/commonController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const commonRoute = Router();

commonRoute
  .route("/common/getPlantData")
  .get(authenticationMiddleware.bearer, getPlantData);

commonRoute
  .route("/common/getEpaData")
  .get(authenticationMiddleware.bearer, getEpaCode02);
//commonRoute.route('/common/getData').post(authenticationMiddleware.bearer, getData02);
// commonRoute
//   .route("/common/getTdcData")
//   .post(authenticationMiddleware.bearer, getData05);
commonRoute
  .route("/common/getProdData")
  .post(authenticationMiddleware.bearer, getData06);
//commonRoute.route('/common/getData06').post(authenticationMiddleware.bearer, getData06);
// commonRoute
//   .route("/common/getOrderData")
//   .post(authenticationMiddleware.bearer, getData07);
//commonRoute.route('/common/getScoData').post(authenticationMiddleware.bearer, getData08);
// commonRoute
//   .route("/common/getTdcCode")
//   .get(authenticationMiddleware.bearer, getTdcCode05);
// commonRoute
//   .route("/common/getOrderId")
//   .get(authenticationMiddleware.bearer, getOrderId07);
commonRoute
  .route("/common/getEpaCode")
  .get(authenticationMiddleware.bearer, getEpaCodeData08);

commonRoute
  .route("/common/getData06")
  .post(authenticationMiddleware.bearer, getData06);
commonRoute
  .route("/common/getEpaCode06")
  .get(authenticationMiddleware.bearer, getEpaCode06);
commonRoute
  .route("/common/procedure06")
  .post(authenticationMiddleware.bearer, callProcedure06);
export default commonRoute;
