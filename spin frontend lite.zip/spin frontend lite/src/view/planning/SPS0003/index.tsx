import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  GetPlantDataApi,
  SPC0014GetData,
  SPC0014GetStatusData,
  SPS0003GetTableData,
  SPS0003CallPkgProc,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";
import { setTheme, useMaterialUIController } from "../../../context";

const P_SPS0003 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [motherBatch, setMotherBatch] = React.useState<string>("");
  const [status, setStatus] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");

  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);

  const actionList: Array<SelectType> = [
    { value: "I", label: "FG", id: 1 },
    { value: "S", label: "SCRAP", id: 2 },
    { value: "R", label: "REVERSAL", id: 2 },
  ];

  const [selectedAction, setSelectedAction] = React.useState<string>(
    actionList[0].value
  );

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
    getStatusData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    // if (!(selectedAction?.length > 0)) {
    //   alertify.error("Please select Action!");
    //   return;
    // }

    const data = {
      plant: selectedPlant,
      batchId: batchId ? batchId : "",
      motherBatch: motherBatch ? motherBatch : "",
      // action_cd: selectedAction ? selectedAction : "",
      // status: selectedStatus ? selectedStatus : "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0003GetTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          }
          if (res?.data?.length == 0) {
            setTableData(res.data);
            alertify.error("No Data Found!");
          } else if (res?.data) {
            setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleSaveBtn = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    let selectedRows = table?.getSelectedRows();

    if (selectedRows?.length === 0) {
      alertify.error("Please select row");
      return;
    }

    let packCdFlag = false;
    let selectedData: any[] = [];
    selectedRows.forEach((item) => {
      if (
        item?._row?.data?.PACK_CD == null ||
        item?._row?.data?.PACK_CD == ""
      ) {
        packCdFlag = true;
        return;
      }
      selectedData.push({
        batchId: item?._row?.data?.BATCH_ID,
        order: item?._row?.data?.ORD,
        item: item?._row?.data?.ITEM,
        packCd: item?._row?.data?.PACK_CD,
        user: user,
      });
    });

    if (packCdFlag) {
      alertify.error("Pack Code is mandatory");
      return;
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0003CallPkgProc(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            console.log("res?.data: ", res.data);
            if (res.data.substr(0, 1) === "Y") {
              alertify.success(res.data);
              // setTableData([]);
              getTableData();
              setLoading(false);
              return;
            } else {
              alertify.error(res.data);
              getTableData();
              setLoading(false);
              return;
            }
            // if (res?.data?.length == 0) {
            //   setTableData(res.data);
            //   alertify.error("No Data Found!");
            // } else if (res?.data) {
            //   setTableData(res.data);
            // }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getStatusData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0014GetStatusData(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData1: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.STATUS?.toString(),
                  label: x.STATUS?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            console.log("varData1: ", varData1);
            setStatus(varData1);
            setSelectedStatus(varData1[0]?.value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: tableCol,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const tableCol: Array<CulmnType> = [
    {
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pack Code",
      field: "PACK_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "input",
      editorParams: {
        // Add input validation
        elementAttributes: {
          maxlength: "4", // Limit input to 4 characters
          oninput: "this.value = this.value.toUpperCase()", // Convert to uppercase as user types
        },
      },
      validator: ["required", "maxLength:4", "minLength:4"],
      cellEdited: function (cell) {
        // Ensure the value is uppercase after editing
        let value = cell.getValue();
        if (value) {
          cell.setValue(value.toUpperCase());
        }
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "LEN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order",
      field: "ORD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "ODIA",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plan Proc",
      field: "PLAN_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "QLTY_CD",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Material",
      field: "MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Create Dt",
      field: "EOM_TS_CREATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleClearAll = () => {
    setBatchId("");
    setMotherBatch("");
    setSelectedAction("");
    setTableData([]);
    setSelectedStatus("");
  };

  const downloadExcel = () => {
    if (tableData?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "Packing WIP Screen" + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedPlant}
                            data={plant}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedPlant(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={1.8}>
                          <SelectInput
                            label="Action*"
                            data={actionList}
                            value={selectedAction}
                            onChange={(e: string) => {
                              setSelectedAction(e);
                              setTableData([]);
                            }}
                          />
                        </Grid> */}

                        <Grid item xs={2}>
                          <Input
                            id={"batchId"}
                            value={batchId}
                            label="Batch Id"
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <Input
                            id={"motherBatch"}
                            value={motherBatch}
                            label="Mother Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setMotherBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={1.2}>
                          <SelectInput
                            id={"status"}
                            value={selectedStatus}
                            data={status}
                            label="Status"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedStatus(e);
                              setTableData([]);
                            }}
                          />
                        </Grid> */}

                        {/* <Grid item xs={2}>
                          <DatePickerInput
                            label="Date From"
                            // id={x?.key}
                            value={dateFrom}
                            onChange={(e: string) => {
                              setDateFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Date To"
                            // id={x?.key}
                            value={dateTo}
                            onChange={(e: string) => {
                              setDateTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid> */}

                        <Grid item xs={1}>
                          <ButtonElement onClick={getTableData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <>
                  <Tooltip title="Download">
                    <IconButton onClick={downloadExcel}>
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Save">
                    <IconButton
                      // onClick={handleSaveBtn}
                      onClick={() => {
                        handleSaveBtn();
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <SaveIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0003;
