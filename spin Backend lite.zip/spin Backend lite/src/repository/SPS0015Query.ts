import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getScreenData = async (data: any) => {
  try {
    if (data.Plant) {
      return {
        // batch: await ResponceData(
        //   await query(`
        // select distinct EOM_ID_BATCH
        // from v_epa_prodn where eom_cd_status in ('VB','VF')
        // AND EOM_CD_EPA = ${data.Plant}
        // `)
        // ),
        // // select distinct(RSP_PDI) SCHID from V_SL_PDI_BUSI where RSP_CD_EPA =${data.Plant}
        // scheduleId: await ResponceData(
        //   await query(`
        // select distinct(PDS_PDI) from v_pr_data_ip_slt where PDS_CD_EPA = ${data.Plant}
        // `)
        // ),
        process: await ResponceData(
          await query(`
        select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
        FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} 
        AND EPL_CD_PROCESS != 'W'
        ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
        `)
        ),

        // status: await ResponceData(
        //   await query(`
        // select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
        //   WHERE CD_TYPE='TK005'
        // `)
        // ),
        // plannedPath: await ResponceData(
        //   await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
        //  FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} ORDER  BY 1`)
        // ),
      };
    } else {
      return getCommonPlantData();
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getSchdConfTabData = async (data: any) => {
  try {
    var Qrygetschs = "";
    if (data.data?.process == "S") {
      // Query is used only for Slit line process
      // Query for Draft Schedule

      //Replaced hardcoded yard, will now come from v_codes TK032
      Qrygetschs = `SELECT PDS_CD_EPA plant, 
          PDS_CURR_PROC CD_PROCESS,
          PDS_ID_COIL Coilid,
          PDS_PDI PDI_ID , 
          PDS_thick fgthick,
          PDS_width fgwidth,
          --PDS_QLTY_CD fg_qlty_cd , 
          --PDS_prod_cd fg_prod_cd , 
          PDS_CURR_PROC curr_proc,
          PDS_length fg_length,
          PDS_cast_no cast_no,
          --PDS_PLANNED_PROC paln_proc ,
          (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDS_PLANNED_PROC) paln_proc,
          PDS_SLIT_WIDTH slit_width ,
          PDS_NO_SLIT slits,
          PDS_OUT_TDC          SCH_TDC,
          PDS_NO_PART part ,
          PDS_ORDER order_id,PDS_ITEM_NO item,
          PDS_REC_CRT_BY crt_by,TO_CHAR(PDS_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
          , PDS_TDC TDC
          , NVL(PDS_PACK_CODE,' ') PACK_CD
          , PDS_OIL_TYPE  OIL_TYPE
          , PDS_COMBINATION COMBINATION           
          ,PDS_SCH_WT  SCH_WT
          ,PDS_PLAN_WT PLAN_WT
          ,PDS_MASS  INV_WT
          ,ENC_ORDER_EDGE ORD_EDGE
          ,PDS_SCHD_ID SCH_ID
          ,NVL(ENC_CUST_NAME,' ') cust_nm
          ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
          ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
          ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
          ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
          ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
          ,PDS_SETUP_CODE setup, PDS_GRADE_DESC GRADE_DEC, PDS_CD_STATUS CD_STATUS, PDS_THICK TNP_THICK, PDS_WIDTH INP_WIDTH
          ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
            WHERE EOM_ID_BATCH  = PDS_ID_COIL
            AND EOM_CD_ePA      = PDS_CD_EPA  ) CR_STATUS,
            (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys,
          (SELECT DISTINCT MAX(TRIM(REPLACE(CAD_DEF2_COMM, CHR(10),' '))) FROM V_COIL_CARD 
          WHERE CAD_ID_COIL = C.EOM_ID_FIRST_PAR AND (CAD_DEF2_COMM LIKE 'SLP%' OR CAD_DEF2_COMM LIKE '@SLP%') ) SLP_REMARKS,
         ENC_ROADDEST_DESC ROAD_DEST,
         ENC_RAILDEST_DESC RAIL_DEST,
         ENC_MIN_PIECE_WT PC_WT_MIN,
         ENC_MAX_PIECE_WT PC_WT_MAX,
         ENC_NO_DEPT_WO CUST_SEGMENT
          , NVL(PDS_IDIA,0) IDIA
          , NVL(PDS_ODIA,0) ODIA
          ,ENC_IDIA
          ,ENC_ODIA
          ,(select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE AND WTM_STATUS = 'A') width_tol
           ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks        
            from V_PR_DATA_IP_SLT A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
            where PDS_CD_EPA = EOM_CD_EPA
            AND PDS_ID_COIL = EOM_ID_BATCH
            AND PDS_CD_EPA = '${data.data?.plant}'
            AND PDS_CD_EPA = ENC_cD_EPA
            AND PDS_ORDER = ENC_ID_ORDER
            AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS ='WC'
            AND EOM_CD_YRD in (select cd_value from v_codes where cd_type = 'TK032') --('HJ', 'AB') --- this confirms that stock is in TSDPL Premise
            AND EOM_CD_STATUS LIKE '%C' `;

      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDS_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      // console.log("Qrygetschs Conf - S schd: ", Qrygetschs);

      return await ResponceData(await query(Qrygetschs));
    }
    if (
      data.data?.process == "N" ||
      data.data?.process == "T" ||
      data.data?.process == "E"
    ) {
      // Query is used only for CTL and Seggregation process
      Qrygetschs = `SELECT PDC_CD_EPA plant, 
      PDC_CURR_PROC CD_PROCESS,
      PDC_ID_COIL Coilid,
      PDC_PDI PDI_ID , 
      PDC_thick fgthick,
      PDC_width fgwidth,
      --PDC_QLTY_CD fg_qlty_cd , 
      --PDC_prod_cd fg_prod_cd , 
      PDC_CURR_PROC curr_proc,
      PDC_length fg_length,
      PDC_cast_no cast_no,
      --PDC_PLANNED_PROC paln_proc ,
      (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDC_PLANNED_PROC) paln_proc,
      PDC_PALLET_WIDTH slit_width ,
      PDC_NO_SHEETS slits,
      PDC_OUT_TDC          SCH_TDC,
      PDC_NO_PART part ,
      PDC_ORDER order_id,PDC_ITEM_NO item,
      PDC_REC_CRT_BY crt_by,TO_CHAR(PDC_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
      , PDC_TDC TDC
      , NVL(PDC_PACK_CODE,' ') PACK_CD
      , PDC_OIL_TYPE  OIL_TYPE
      , PDC_COMBINATION COMBINATION
      , NVL(PDC_IDIA,0) IDIA
      , NVL(PDC_ODIA,0) ODIA
      ,PDC_SCH_WT  SCH_WT
      ,PDC_PLAN_WT PLAN_WT
      ,PDC_MASS  INV_WT
      ,ENC_ORDER_EDGE ORD_EDGE
      ,PDC_SCHD_ID SCH_ID
      ,NVL(ENC_CUST_NAME,' ') cust_nm
      ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
      ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
      ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
      ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
      ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
      ,PDC_SETUP_CODE setup, PDC_GRADE_DESC GRADE_DEC, PDC_CD_STATUS CD_STATUS, PDC_THICK TNP_THICK, PDC_WIDTH INP_WIDTH
      ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
        WHERE EOM_ID_BATCH  = PDC_ID_COIL
        AND EOM_CD_ePA      = PDC_CD_EPA  ) CR_STATUS,
         (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys          
        from V_PR_DATA_IP_CTL A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
        where PDC_CD_EPA = EOM_CD_EPA
        AND PDC_ID_COIL = EOM_ID_BATCH
        AND PDC_CD_EPA = '${data.data?.plant}'
        AND PDC_CD_EPA = ENC_cD_EPA
        AND PDC_ORDER = ENC_ID_ORDER
        AND PDC_ITEM_NO = ENC_NO_ITEM  
        AND PDC_CD_STATUS ='WC'
        AND EOM_CD_STATUS LIKE '%C'`;

      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDC_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDC_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      // console.log("Qrygetschs Conf schd: ", Qrygetschs);

      return await ResponceData(await query(Qrygetschs));
    } else {
      return 1;
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getSchdRejTabData = async (data: any) => {
  try {
    var Qrygetschs = "";
    if (data.data?.process == "S") {
      // Query is used only for Slit line process
      Qrygetschs = `SELECT PDS_CD_EPA plant, 
          PDS_CURR_PROC CD_PROCESS,
          PDS_ID_COIL Coilid,
          PDS_PDI PDI_ID , 
          PDS_thick fgthick,
          PDS_width fgwidth,
          --PDS_QLTY_CD fg_qlty_cd , 
          --PDS_prod_cd fg_prod_cd , 
          PDS_CURR_PROC curr_proc,
          PDS_length fg_length,
          PDS_cast_no cast_no,
          --PDS_PLANNED_PROC paln_proc ,
          (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDS_PLANNED_PROC) paln_proc,
          PDS_SLIT_WIDTH slit_width ,
          PDS_NO_SLIT slits,
          PDS_OUT_TDC          SCH_TDC,
          PDS_NO_PART part ,
          PDS_ORDER order_id,PDS_ITEM_NO item,
          PDS_REC_CRT_BY crt_by,TO_CHAR(PDS_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
          , PDS_TDC TDC
          , NVL(PDS_PACK_CODE,' ') PACK_CD
          , PDS_OIL_TYPE  OIL_TYPE
          , PDS_COMBINATION COMBINATION           
          ,PDS_SCH_WT  SCH_WT
          ,PDS_PLAN_WT PLAN_WT
          ,PDS_MASS  INV_WT
          ,ENC_ORDER_EDGE ORD_EDGE
          ,PDS_SCHD_ID SCH_ID
          ,NVL(ENC_CUST_NAME,' ') cust_nm
          ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
          ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
          ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
          ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
          ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
          ,PDS_SETUP_CODE setup, PDS_GRADE_DESC GRADE_DEC, PDS_CD_STATUS CD_STATUS, PDS_THICK TNP_THICK, PDS_WIDTH INP_WIDTH
          ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
            WHERE EOM_ID_BATCH  = PDS_ID_COIL
            AND EOM_CD_ePA      = PDS_CD_EPA  ) CR_STATUS
          , NVL(PDS_IDIA,0) IDIA
          , NVL(PDS_ODIA,0) ODIA
          , ENC_IDIA
          , ENC_ODIA
          ,(select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE AND WTM_STATUS = 'A') width_tol,
            (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys
           ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks        
            from V_PR_DATA_IP_SLT A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
            where PDS_CD_EPA = EOM_CD_EPA
            AND PDS_ID_COIL = EOM_ID_BATCH
            AND PDS_CD_EPA = '${data.data?.plant}'
            AND PDS_CD_EPA = ENC_cD_EPA
            AND PDS_ORDER = ENC_ID_ORDER
            AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS ='WC'
            AND EOM_CD_YRD in (select cd_value from v_codes where cd_type = 'TK032') --'HJ' --- this confirms that stock is in TSDPL Premise
            AND EOM_CD_STATUS LIKE '%C'`;
      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDS_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      Qrygetschs += `
            UNION
            SELECT
                    PDS_CD_EPA           PLANT,
                    PDS_CURR_PROC        CD_PROCESS,
                    PDS_ID_COIL          COILID,
                    PDS_PDI              PDI_ID,
                    PDS_THICK            FGTHICK,
                    PDS_WIDTH            FGWIDTH,
                            --PDS_QLTY_CD fg_qlty_cd , 
                            --PDS_prod_cd fg_prod_cd , 
                    PDS_CURR_PROC        CURR_PROC,
                    PDS_LENGTH           FG_LENGTH,
                    PDS_CAST_NO          CAST_NO,
                    --PDS_PLANNED_PROC     PALN_PROC,
                    (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDS_PLANNED_PROC) paln_proc,
                    PDS_SLIT_WIDTH       SLIT_WIDTH,
                    PDS_NO_SLIT          SLITS,
                    PDS_OUT_TDC          SCH_TDC,
                    PDS_NO_PART          PART,
                    PDS_ORDER            ORDER_ID,
                    PDS_ITEM_NO          ITEM,
                    PDS_REC_CRT_BY       CRT_BY,
                    TO_CHAR(PDS_REC_CRT_DT,'dd-mm-yyyy hh24:MI:SS') CRT_NO,
                    PDS_TDC              TDC,
                    NVL(PDS_PACK_CODE,' ') PACK_CD,
                    PDS_OIL_TYPE         OIL_TYPE,
                    PDS_COMBINATION      COMBINATION,                     
                    PDS_SCH_WT           SCH_WT,
                    PDS_PLAN_WT          PLAN_WT,
                    PDS_MASS             INV_WT,
                    ENC_ORDER_EDGE       ORD_EDGE,
                    PDS_SCHD_ID          SCH_ID,
                    NVL(ENC_CUST_NAME,' ') cust_nm,
                    NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm,
                    (
                        SELECT
                            EIC_IDIA
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_IDIA,
                    (
                        SELECT
                            EIC_CD_EDGE
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_EDGE,
                    (
                        SELECT
                            EIC_MK_CUSTOMER
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_CUSTOMER,
                    (select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd,
                    PDS_SETUP_CODE       SETUP,
                    PDS_OUT_GRADE_DESC   GRADE_DEC,
                    PDS_CD_STATUS        CD_STATUS,
                    PDS_THICK            TNP_THICK,
                    PDS_WIDTH            INP_WIDTH,
                    (
                        SELECT
                            EOM_CD_STATUS
                        FROM
                            V_EPA_PRODN
                        WHERE
                            EOM_ID_BATCH = PDS_ID_COIL
                            AND EOM_CD_EPA = PDS_CD_EPA
                    ) CR_STATUS,
                    NVL(PDS_IDIA,0)             IDIA,
                    NVL(PDS_ODIA,0)             ODIA,
                    ENC_IDIA,
                    ENC_ODIA
                    ,(select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE AND WTM_STATUS = 'A') width_tol,
            (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys
           ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks        
                FROM
                    V_PR_DATA_IP_SLT A,
                    V_END_CUST_ORD_EPA,
                    V_EPA_PRODN C
                WHERE
                    PDS_CD_EPA = EOM_CD_EPA
                    AND PDS_ID_COIL = EOM_ID_BATCH
            AND PDS_CD_EPA = '${data.data?.plant}'
            AND PDS_CD_EPA = ENC_CD_EPA
            AND PDS_ORDER = ENC_ID_ORDER
            AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS ='WC'
            AND EOM_CD_STATUS ='VS'`;
      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDS_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      // console.log("Qrygetschs Rej schd: ", Qrygetschs);

      return await ResponceData(await query(Qrygetschs));
    }
    if (
      data.data?.process == "N" ||
      data.data?.process == "T" ||
      data.data?.process == "E"
    ) {
      // Query is used only for CTL and Seggregation process
      Qrygetschs = `SELECT PDC_CD_EPA plant, 
      PDC_CURR_PROC CD_PROCESS,
      PDC_ID_COIL Coilid,
      PDC_PDI PDI_ID , 
      PDC_thick fgthick,
      PDC_width fgwidth,
      --PDC_QLTY_CD fg_qlty_cd , 
      --PDC_prod_cd fg_prod_cd , 
      PDC_CURR_PROC curr_proc,
      PDC_length fg_length,
      PDC_cast_no cast_no,
      --PDC_PLANNED_PROC paln_proc ,
      (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDC_PLANNED_PROC) paln_proc,
      PDC_PALLET_WIDTH slit_width ,
      PDC_NO_SHEETS slits,
      PDC_OUT_TDC          SCH_TDC,
      PDC_NO_PART part ,
      PDC_ORDER order_id,PDC_ITEM_NO item,
      PDC_REC_CRT_BY crt_by,TO_CHAR(PDC_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
      , PDC_TDC TDC
      , NVL(PDC_PACK_CODE,' ') PACK_CD
      , PDC_OIL_TYPE  OIL_TYPE
      , PDC_COMBINATION COMBINATION
      , NVL(PDC_IDIA,0) IDIA
      , NVL(PDC_ODIA,0) ODIA
      ,PDC_SCH_WT  SCH_WT
      ,PDC_PLAN_WT PLAN_WT
      ,PDC_MASS  INV_WT
      ,ENC_ORDER_EDGE ORD_EDGE
      ,PDC_SCHD_ID SCH_ID
      ,NVL(ENC_CUST_NAME,' ') cust_nm
      ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
      ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
      ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
      ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
      ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
      ,PDC_SETUP_CODE setup, PDC_GRADE_DESC GRADE_DEC, PDC_CD_STATUS CD_STATUS, PDC_THICK TNP_THICK, PDC_WIDTH INP_WIDTH
      ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
        WHERE EOM_ID_BATCH  = PDC_ID_COIL
        AND EOM_CD_ePA      = PDC_CD_EPA  ) CR_STATUS,
         (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys
        from V_PR_DATA_IP_CTL A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
        where PDC_CD_EPA = EOM_CD_EPA
        AND PDC_ID_COIL = EOM_ID_BATCH
        AND PDC_CD_EPA = '${data.data?.plant}'
        AND PDC_CD_EPA = ENC_cD_EPA
        AND PDC_ORDER = ENC_ID_ORDER
        AND PDC_ITEM_NO = ENC_NO_ITEM  
        AND PDC_CD_STATUS ='WC'
        AND EOM_CD_STATUS LIKE '%C'`;

      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDC_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDC_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      return await ResponceData(await query(Qrygetschs));
    } else if (data.data?.process == "K") {
      Qrygetschs = `SELECT cid_cd_epa plant, cid_curr_proc cd_process, cid_id_coil coilid,
       cid_pdi pdi_id, cid_thick fgthick, cid_width fgwidth,
       cid_curr_proc curr_proc, cid_length fg_length, cid_cast_no cast_no,
       cid_planned_proc paln_proc, NULL slit_width, NULL slits,
       cid_out_tdc sch_tdc, NULL part, cid_order order_id, cid_item_no item,
       NULL crt_by, TO_CHAR (NULL, 'dd-mm-yyyy hh24:MI:SS') crt_no, NULL tdc,
       NVL (cid_pack_code, ' ') pack_cd, NULL oil_type, NULL combination,
       NVL (cid_idia, 0) idia, NVL (cid_odia, 0) odia, NULL sch_wt,
       NULL plan_wt, cid_mass inv_wt, enc_order_edge ord_edge,
       cid_schd_id sch_id, NVL(ENC_CUST_NAME,' ') cust_nm
          ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm,
       (SELECT eic_idia
          FROM v_input_coil
         WHERE eic_cd_epa = c.EOM_CD_EPA
           AND eic_id_coil = c.EOM_ID_FIRST_PAR) inp_idia,
       (SELECT eic_cd_edge
          FROM v_input_coil
         WHERE eic_cd_epa = c.EOM_CD_EPA
           AND eic_id_coil = c.EOM_ID_FIRST_PAR) inp_edge,
       (SELECT eic_mk_customer
          FROM v_input_coil
         WHERE eic_cd_epa = c.EOM_CD_EPA
           AND eic_id_coil = c.EOM_ID_FIRST_PAR) inp_customer,
      ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA
      and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd,
       NULL setup, cid_grade_desc grade_dec, cid_cd_status cd_status,
       cid_thick tnp_thick, cid_width inp_width,
       (SELECT eom_cd_status
          FROM v_epa_prodn
         WHERE eom_id_batch = cid_id_coil
           AND eom_cd_epa = cid_cd_epa) cr_status
          FROM v_pr_data_ip_cpl a, v_end_cust_ord_epa, v_epa_prodn c
         WHERE cid_cd_epa = eom_cd_epa
           AND cid_id_coil = eom_id_batch
           AND cid_cd_epa = '131'
           AND cid_cd_epa = enc_cd_epa
           AND cid_order = enc_id_order
           AND CID_CD_STATUS ='WC'
           AND EOM_CD_STATUS LIKE '%C' 
           AND cid_item_no = enc_no_item
          `;

      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND CID_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND CID_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }

      console.log("Qrygetschs: ", Qrygetschs);
      return await ResponceData(await query(Qrygetschs));
    } else {
      return 1;
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getOpenSchdTabData = async (data: any) => {
  try {
    var Qrygetschs = "";
    if (data.data?.process == "S") {
      // Query is used only for Slit line process
      // Query for Draft Schedule
      Qrygetschs = `SELECT PDS_CD_EPA plant, 
          PDS_CURR_PROC CD_PROCESS,
          PDS_ID_COIL Coilid,
          PDS_PDI PDI_ID , 
          PDS_thick fgthick,
          PDS_width fgwidth,
          --PDS_QLTY_CD fg_qlty_cd , 
          --PDS_prod_cd fg_prod_cd , 
          PDS_CURR_PROC curr_proc,
          PDS_length fg_length,
          PDS_cast_no cast_no,
          --PDS_PLANNED_PROC paln_proc ,
          (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDS_PLANNED_PROC) paln_proc,
          PDS_SLIT_WIDTH slit_width ,
          PDS_NO_SLIT slits,
          PDS_OUT_TDC          SCH_TDC,
          PDS_NO_PART part ,
          PDS_ORDER order_id,PDS_ITEM_NO item,
          PDS_REC_CRT_BY crt_by,TO_CHAR(PDS_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
          , PDS_TDC TDC
          , NVL(PDS_PACK_CODE,' ') PACK_CD
          , PDS_OIL_TYPE  OIL_TYPE
          , PDS_COMBINATION COMBINATION           
          ,PDS_SCH_WT  SCH_WT
          ,PDS_PLAN_WT PLAN_WT
          ,PDS_MASS  INV_WT
          ,ENC_ORDER_EDGE ORD_EDGE
          ,PDS_SCHD_ID SCH_ID
          ,PDS_REMARKS REMARKS
          ,NVL(ENC_CUST_NAME,' ') cust_nm
          ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
          ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
          ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
          ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
          ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
          ,PDS_SETUP_CODE setup, PDS_GRADE_DESC GRADE_DEC, PDS_CD_STATUS CD_STATUS, PDS_THICK TNP_THICK, PDS_WIDTH INP_WIDTH
          ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
            WHERE EOM_ID_BATCH  = PDS_ID_COIL
            AND EOM_CD_ePA      = PDS_CD_EPA  ) CR_STATUS
          ,(SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys,
          (SELECT DISTINCT MAX(TRIM(REPLACE(CAD_DEF2_COMM, CHR(10),' '))) FROM V_COIL_CARD 
          WHERE CAD_ID_COIL = C.EOM_ID_FIRST_PAR AND (CAD_DEF2_COMM LIKE 'SLP%' OR CAD_DEF2_COMM LIKE '@SLP%') ) SLP_REMARKS,         
         ENC_ROADDEST_DESC ROAD_DEST,
         ENC_RAILDEST_DESC RAIL_DEST,
         ENC_MIN_PIECE_WT PC_WT_MIN,
         ENC_MAX_PIECE_WT PC_WT_MAX,
         ENC_NO_DEPT_WO CUST_SEGMENT
          , NVL(PDS_IDIA,0) IDIA
          , NVL(PDS_ODIA,0) ODIA
          ,ENC_IDIA 
          ,ENC_ODIA
          ,(select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE AND WTM_STATUS = 'A') width_tol,
          (SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks
            from V_PR_DATA_IP_SLT A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
            where PDS_CD_EPA = EOM_CD_EPA
            AND PDS_ID_COIL = EOM_ID_BATCH
            AND PDS_CD_EPA = '${data.data?.plant}'
            AND PDS_CD_EPA = ENC_cD_EPA
            AND PDS_ORDER = ENC_ID_ORDER
            AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS  in ('WC','WS', 'WW', 'US', 'UP')
            AND EOM_CD_YRD in (select cd_value from v_codes where cd_type = 'TK032') --'HJ' --- this confirms that stock is in TSDPL Premise
            AND (EOM_CD_STATUS LIKE '%C' OR  EOM_CD_STATUS LIKE '%J') `;
      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDS_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      Qrygetschs += `
            UNION
            SELECT
                    PDS_CD_EPA           PLANT,
                    PDS_CURR_PROC        CD_PROCESS,
                    PDS_ID_COIL          COILID,
                    PDS_PDI              PDI_ID,
                    PDS_THICK            FGTHICK,
                    PDS_WIDTH            FGWIDTH,
                            --PDS_QLTY_CD fg_qlty_cd , 
                            --PDS_prod_cd fg_prod_cd , 
                    PDS_CURR_PROC        CURR_PROC,
                    PDS_LENGTH           FG_LENGTH,
                    PDS_CAST_NO          CAST_NO,
                    --PDS_PLANNED_PROC     PALN_PROC,
                    (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDS_PLANNED_PROC) paln_proc,
                    PDS_SLIT_WIDTH       SLIT_WIDTH,
                    PDS_NO_SLIT          SLITS,
                    PDS_OUT_TDC          SCH_TDC,
                    PDS_NO_PART          PART,
                    PDS_ORDER            ORDER_ID,
                    PDS_ITEM_NO          ITEM,
                    PDS_REC_CRT_BY       CRT_BY,
                    TO_CHAR(PDS_REC_CRT_DT,'dd-mm-yyyy hh24:MI:SS') CRT_NO,
                    PDS_TDC              TDC,
                    NVL(PDS_PACK_CODE,' ') PACK_CD,
                    PDS_OIL_TYPE         OIL_TYPE,
                    PDS_COMBINATION      COMBINATION,                      
                    PDS_SCH_WT           SCH_WT,
                    PDS_PLAN_WT          PLAN_WT,
                    PDS_MASS             INV_WT,
                    ENC_ORDER_EDGE       ORD_EDGE,
                    PDS_SCHD_ID          SCH_ID,
                    PDS_REMARKS REMARKS,
                    NVL(ENC_CUST_NAME,' ') cust_nm,
                    NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm,
                    (
                        SELECT
                            EIC_IDIA
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_IDIA,
                    (
                        SELECT
                            EIC_CD_EDGE
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_EDGE,
                    (
                        SELECT
                            EIC_MK_CUSTOMER
                        FROM
                            V_INPUT_COIL
                        WHERE
                            EIC_CD_EPA = c.EOM_CD_EPA
                            AND EIC_ID_COIL = c.EOM_ID_FIRST_PAR
                    ) INP_CUSTOMER,
                    (select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd,
                    PDS_SETUP_CODE       SETUP,
                    PDS_GRADE_DESC   GRADE_DEC,
                    PDS_CD_STATUS        CD_STATUS,
                    PDS_THICK            TNP_THICK,
                    PDS_WIDTH            INP_WIDTH,
                    (
                        SELECT
                            EOM_CD_STATUS
                        FROM
                            V_EPA_PRODN
                        WHERE
                            EOM_ID_BATCH = PDS_ID_COIL
                            AND EOM_CD_EPA = PDS_CD_EPA
                    ) CR_STATUS
          ,(SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys,
          (SELECT DISTINCT MAX(TRIM(REPLACE(CAD_DEF2_COMM, CHR(10),' '))) FROM V_COIL_CARD 
          WHERE CAD_ID_COIL = C.EOM_ID_FIRST_PAR AND (CAD_DEF2_COMM LIKE 'SLP%' OR CAD_DEF2_COMM LIKE '@SLP%') ) SLP_REMARKS,
         ENC_ROADDEST_DESC ROAD_DEST,
         ENC_RAILDEST_DESC RAIL_DEST,
         ENC_MIN_PIECE_WT PC_WT_MIN,
         ENC_MAX_PIECE_WT PC_WT_MAX,
         ENC_NO_DEPT_WO CUST_SEGMENT,
         NVL(PDS_IDIA,0) IDIA,
         NVL(PDS_ODIA,0) ODIA
        ,ENC_IDIA
        ,ENC_ODIA
        ,(select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE AND WTM_STATUS = 'A') width_tol
        ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks
                FROM
                    V_PR_DATA_IP_SLT A,
                    V_END_CUST_ORD_EPA,
                    V_EPA_PRODN C
                WHERE
                    PDS_CD_EPA = EOM_CD_EPA
                    AND PDS_ID_COIL = EOM_ID_BATCH
            AND PDS_CD_EPA = '${data.data?.plant}'
            AND PDS_CD_EPA = ENC_CD_EPA
            AND PDS_ORDER = ENC_ID_ORDER
            AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS in ('WC','WS')
            AND ( (EOM_CD_STATUS like '%C') OR (EOM_CD_STATUS like '%X') 
            OR (EOM_CD_STATUS IN ('VS', 'VI')))`;
      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDS_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TO_CHAR(TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD'),'DD-Mon-YY')
              BETWEEN NVL('${data.data.fromDt}',TO_CHAR(TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD'),'DD-Mon-YY')) 
              AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TO_CHAR(TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD'),'DD-Mon-YY')))`;
      }
      console.log("Qrygetschs open schd: ", Qrygetschs);
      return await ResponceData(await query(Qrygetschs));
    }
    if (
      data.data?.process == "N" ||
      data.data?.process == "T" ||
      data.data?.process == "E"
    ) {
      // Query is used only for CTL and Seggregation process
      Qrygetschs = `SELECT PDC_CD_EPA plant, 
      PDC_CURR_PROC CD_PROCESS,
      PDC_ID_COIL Coilid,
      PDC_PDI PDI_ID , 
      PDC_thick fgthick,
      PDC_width fgwidth,
      --PDC_QLTY_CD fg_qlty_cd , 
      --PDC_prod_cd fg_prod_cd , 
      PDC_CURR_PROC curr_proc,
      PDC_length fg_length,
      PDC_cast_no cast_no,
      --PDC_PLANNED_PROC paln_proc ,
      (select pph_desc from v_epa_proc_path where PPH_CD_PROC_PATH = PDC_PLANNED_PROC) paln_proc,
      PDC_PALLET_WIDTH slit_width ,
      PDC_NO_SHEETS slits,
      PDC_OUT_TDC          SCH_TDC,
      PDC_NO_PART part ,
      PDC_ORDER order_id,PDC_ITEM_NO item,
      PDC_REC_CRT_BY crt_by,TO_CHAR(PDC_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
      , PDC_TDC TDC
      , NVL(PDC_PACK_CODE,' ') PACK_CD
      , PDC_OIL_TYPE  OIL_TYPE
      , PDC_COMBINATION COMBINATION
      , NVL(PDC_IDIA,0) IDIA
      , NVL(PDC_ODIA,0) ODIA
      ,PDC_SCH_WT  SCH_WT
      ,PDC_PLAN_WT PLAN_WT
      ,PDC_MASS  INV_WT
      ,ENC_ORDER_EDGE ORD_EDGE
      ,PDC_SCHD_ID SCH_ID
      ,NVL(ENC_CUST_NAME,' ') cust_nm
      ,NVL(ENC_MARK_CUST_NAME,' ') mark_cust_nm
      ,(select eic_idia from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_idia
      ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_edge
      ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
      ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
      ,PDC_SETUP_CODE setup, PDC_GRADE_DESC GRADE_DEC, PDC_CD_STATUS CD_STATUS, PDC_THICK TNP_THICK, PDC_WIDTH INP_WIDTH
      ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
        WHERE EOM_ID_BATCH  = PDC_ID_COIL
        AND EOM_CD_ePA      = PDC_CD_EPA  ) CR_STATUS
      , (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('UTS')
                   AND ROWNUM = 1) uts,
          (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                  FROM v_tc_coil_test
                 WHERE tco_prod_no = eom_id_first_par
                   AND tco_cast_no = eom_no_cast
                   AND tco_test_para IN ('LYS', 'YS')
                   AND ROWNUM = 1) ys,
        PDC_SLP_REMARKS SLP_REMARKS,
        ENC_MIN_PIECE_WT PC_WT_MIN,
        ENC_MAX_PIECE_WT PC_WT_MAX,
        PDC_CUT_LENGTH PLAN_LENGTH,
        PDC_NO_SHEETS NO_SHEETS,
        PDC_NO_PACK NO_PACKET,
        (select wtm_width_tol from v_width_tol_master where wtm_mark_cust_cd = ENC_MARK_CUST 
           and wtm_ord_edge = ENC_ORDER_EDGE and wtm_cd_epa = EOM_CD_EPA AND WTM_STATUS = 'A') width_tol,
        (select LTM_CUT_LENGTH_TOL from v_length_tol_master where ltm_mark_cust_cd = ENC_MARK_CUST 
          and ltm_cd_epa = EOM_CD_EPA and ltm_status = 'A') cut_length_tol,
        (SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) addl_rls_remarks
        from V_PR_DATA_IP_CTL A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
        where PDC_CD_EPA = EOM_CD_EPA
        AND PDC_ID_COIL = EOM_ID_BATCH
        AND PDC_CD_EPA = '${data.data?.plant}'
        AND PDC_CD_EPA = ENC_cD_EPA
        AND PDC_ORDER = ENC_ID_ORDER
        AND PDC_ITEM_NO = ENC_NO_ITEM  
        AND PDC_CD_STATUS in ('WC','WS', 'WW', 'US', 'UP')
        AND ((EOM_CD_STATUS LIKE '%C') OR (EOM_CD_STATUS LIKE '%J')) `;

      if (data.data?.process && data.data?.process?.length > 0) {
        Qrygetschs += ` AND PDC_CURR_PROC = '${data.data.process}'`;
      }
      if (data.data?.coilId && data.data?.coilId?.length > 0) {
        Qrygetschs += ` AND PDC_ID_COIL = '${data.data.coilId}'`;
      }
      if (data.data?.fromDt && data.data?.fromDt?.length > 0) {
        Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      console.log("Qrygetschs-SPS0015-getOpenSchdTabData: ", Qrygetschs);
      return await ResponceData(await query(Qrygetschs));
    } else {
      return 1;
    }
  } catch (error: any) {
    console.log("error-SPS0015-getOpenSchdTabData: ", error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const rejectCoilPlan = async (data: any) => {
  try {
    let results: any = { N: [], Y: [] };
    for (let i = 0; i < data?.data?.length; i++) {
      var sql = `call TPLB0004(
        p_plant => :p_plant,
        p_coil_id => :p_coil_id,
        p_proc_line => :p_proc_line,
        ls_out_flag => :ls_out_flag
      )`;
      const binds = {
        p_plant: data?.data[i].plant ? data?.data[i].plant : "",
        p_coil_id: data?.data[i].coilId ? data?.data[i].coilId : "",
        p_proc_line: data?.data[i].pline ? data?.data[i].pline : "",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      let output = await query(sql, binds);
      if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "N") {
        results["N"].push(
          data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
        );
        //results['N'].push(data?.data?.[i].coilId)
      }
      if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "Y") {
        results["Y"].push(
          data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
        );
        //results['Y'].push(data?.data?.[i].coilId)
      }
    }

    return results;
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const saveCoilPlan = async (data: any) => {
  try {
    let results: any = { N: [], Y: [] };
    for (let i = 0; i < data?.data?.length; i++) {
      var sql = `call TPLB004A(
        p_plant => :p_plant,
        p_coil_id => :p_coil_id,
        p_proc_line => :p_proc_line,
        ls_out_flag => :ls_out_flag
      )`;
      const binds = {
        p_plant: data?.data[i].plant ? data?.data[i].plant : "",
        p_coil_id: data?.data[i].coilId ? data?.data[i].coilId : "",
        p_proc_line: data?.data[i].pline ? data?.data[i].pline : "",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      let output = await query(sql, binds);
      if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "N") {
        results["N"].push(
          data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
        );
        //results['N'].push(data?.data?.[i].coilId)
      }
      if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "Y") {
        results["Y"].push(
          data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
        );
        //results['Y'].push(data?.data?.[i].coilId)
      }
    }
    return results;
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};
