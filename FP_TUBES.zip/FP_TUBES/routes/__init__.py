from fastapi import APIRouter
from routes.checkDeffect import router as defectRouterSys
from routes.countTube import router as countRourerSys

api_router = APIRouter()

# Attach individual routers with custom URL path prefixes and tags
api_router.include_router(defectRouterSys, prefix="/check_defect")
api_router.include_router(countRourerSys, prefix="/get_tube_counts", tags=["get_tube_counts"])