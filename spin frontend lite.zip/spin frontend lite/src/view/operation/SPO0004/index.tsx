/* ------ MANNUAL RECORDING SCREEN INSIDE OPERATION --------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import {
  GetPlantDataApi,
  SPO0004GetTableDataApi,
  SPO0004GetMBatchDataApi,
  SPO0004saveData,
  SPS0005ScheduleID,
  SPO0004GetMotherTableData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import SaveIcon from "@mui/icons-material/Save";
import Loader from "../../../components/preloader";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { setTheme, useMaterialUIController } from "../../../context";
import { SelectType } from "../../../components/input/type";
import { DatePickerInput } from "../../../components/input";
import { InputChangeType } from "./type";
import { FormType } from "../../auth/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
// import { radio } from "../../../type";

import ClearAllIcon from "@mui/icons-material/ClearAll";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import GamepadIcon from "@mui/icons-material/Gamepad";
import SquareIcon from "@mui/icons-material/Square";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import FunctionsIcon from "@mui/icons-material/Functions";
import { PopupObj } from "./type";

import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPO0004 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);

  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<any>("");
  //   const [process, setProcess] = React.useState<Array<SelectType>>([]);
  //   const [selectedProc, setSelectedProc] = React.useState<any>("");
  //   const [selectedMBatch, setSelectedMBatch] = React.useState<any>("");
  const [radioOp, setRadioOp] = React.useState<string>("I");
  const [prodDtFrom, setProdDtFrom] = React.useState<any>("");
  const [prodDtTo, setProdDtTo] = React.useState<any>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [motherTable, setMotherTable] = React.useState<any>(null);
  const [motherTableData, setMotherTableData] = React.useState<any>([]);

  const [mBatchPopUp, setMBatchPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });
  const [mBatch, setMBatch] = React.useState<any>("");
  const [mBatchTable, setMBatchTable] = React.useState<any>(null);
  const [mBatchTableData, setMBatchTableData] = React.useState<any>([]);

  // const radioOptions: Array<radio> = [
  //   { label: "I", value: "1" },
  //   { label: "M", value: "2" },
  // ];

  const radioList = [
    { label: "INSERT", value: "I" },
    { label: "MODIFY", value: "M" },
  ];

  const procList = [
    { label: "E - SEGGREGATION", value: "E" },
    { label: "K - AUTO PKG", value: "K" },
  ];
  const [proc, setProc] = React.useState("");

  const [scheId, setScheId] = React.useState<string>("");
  const [saveDisable, setSaveDisable] = React.useState<boolean>(true);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Prod From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "Prod To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
    setTableData([]);
    setMotherTableData([]);
    setSaveDisable(true);
  }, []);

  React.useEffect(() => {
    if (mBatchTableData.length > 0) {
      setMBatchTable(
        new Tabulator("#mBatchTable", {
          height: "100%",
          data: mBatchTableData,
          columns: mBatchCol,
        })
      );
    } else {
      setMBatchTable(null);
    }
  }, [mBatchTableData]);

  const handleCloseMBatch = (cell: any) => {
    const rowId = mBatchPopUp?.data;
    setMBatch(cell._cell?.row?.data?.PDC_ID_COIL);

    setMBatchPopUp({ popUp: false, data: "" });
  };

  function checkSum() {
    var sumNetWt = 0;
    var rows = table.getRows();
    var scrapWt = 0;

    for (let i = 0; i < rows?.length; i++) {
      if (
        rows[i]?.getData().PDC_SCH_WT === "0" ||
        rows[i]?.getData().PDC_SCH_WT === ""
      ) {
        alertify.error(`Please enter valid Net Wt in row - ${i + 1}`);
        return;
      }
    }

    const schdWt = motherTable?.getRows()[0]?.getData().PDC_SCH_WT;

    rows.forEach(function (row) {
      var value = Number(row.getData().PDC_SCH_WT);
      sumNetWt += value;
    });

    scrapWt = schdWt - sumNetWt;
    scrapWt = Number(scrapWt.toFixed(3));

    if (sumNetWt > schdWt) {
      alertify.error("Sum of Net Wt cannot be greater then schd Wt");
      return;
    } else if (sumNetWt < schdWt) {
      alertify.confirm(
        `Alert! ${scrapWt} ton will go into Scrap? Do you want to continue?`,
        function () {
          setSaveDisable(false);
        },
        function () {}
      );
    } else {
      setSaveDisable(false);
    }
  }

  const deleteCell = async (cell: any) => {
    let filteredCoils = tableData?.filter(
      (item) => item.BATCH_ID !== cell._cell.row.data.BATCH_ID
    );
    setTableData([]);
    setTableData(filteredCoils);
    setSaveDisable(true);
  };

  const mBatchCol: any = [
    {
      title: "Mother Batch",
      field: "PDC_ID_COIL",
      cellClick: function (e: any, cell: any) {
        {
          handleCloseMBatch(cell);
        }
      },
    },
    {
      title: "Schedule Creation Data",
      field: "PDC_SCH_CRT_DT",
      cellClick: function (e: any, cell: any) {
        {
          handleCloseMBatch(cell);
        }
      },
    },
  ];

  React.useEffect(() => {
    if (tableData?.length > 0) {
      // setTable(
      let tableInstance = new Tabulator("#table1", {
        data: tableData,
        columns: tableCol,
        height: 250,
        layout: "fitDataFill",
      });

      tableInstance.on("cellEdited", (cell) => {
        if (cell.getField() === "PDC_SCH_WT") {
          setSaveDisable(true);
        }
      });

      setTable(tableInstance);
      // );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData]);

  const tableCol: any = [
    {
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },
    {
      field: "PDC_PDI",
      title: "Id Pdi",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "BATCH_ID",
      title: "Batch ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_CURR_PROC",
      title: "Proccess",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "PDC_THICK",
      title: "Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_WIDTH",
      title: "Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // editor: "input",
      // formatter: function (cell: any) {
      //   var value = cell.getValue();
      //   cell.getElement().style["background-color"] = "#748da6";
      //   cell.getElement().style["color"] = "#FFFFFF";
      //   return value;
      // },
    },
    {
      field: "PDC_CUT_LENGTH",
      title: "Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      // editor: "input",
      // formatter: function (cell: any) {
      //   var value = cell.getValue();
      //   cell.getElement().style["background-color"] = "#748da6";
      //   cell.getElement().style["color"] = "#FFFFFF";
      //   return value;
      // },
    },
    {
      field: "PDC_TDC",
      title: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_SCH_WT",
      title: "Net Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "input",
      formatter: function (cell: any) {
        var value = cell?.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      field: "EOM_NO_PIECES",
      title: "No of Pcs",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "input",
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      field: "PROD_CD",
      title: "Prod Cd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "QLTY_CD",
      title: "Qlty Cd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_IDIA",
      title: "Idia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_ODIA",
      title: "Odia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_ORDER",
      title: "Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_ITEM_NO",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_OIL_TYPE",
      title: "Oil Type",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_PACK_CODE",
      title: "Pack Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_NXT_PROC",
      title: "Next Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_PLANNED_PROC",
      title: "Planned Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "GRADE_DESC",
      title: "Grade Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "REMARKS",
      title: "Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "input",
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      field: "PDC_SCH_CRT_DT",
      title: "Schedule Created On",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_SCH_CRT_BY",
      title: "Schedule Created By",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_CD_EPA",
      title: "Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "",
      field: "",
      formatter: "buttonCross",
      cellClick: function (e: any, cell: any) {
        deleteCell(cell);
      },
    },
  ];

  React.useEffect(() => {
    if (motherTableData?.length > 0) {
      setMotherTable(
        new Tabulator("#Mtable", {
          data: motherTableData,
          columns: motherTableCol,
          height: "100%",
          layout: "fitDataFill",
        })
      );
    } else {
      setMotherTable(null);
    }
    return () => {
      motherTable?.destroy();
    };
  }, [motherTableData]);

  const motherTableCol: any = [
    {
      field: "PDC_THICK",
      title: "Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_WIDTH",
      title: "Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_CUT_LENGTH",
      title: "Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "PDC_TDC",
      title: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDC_PLAN_WT",
      title: "Input Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "PDC_SCH_WT",
      title: "Schd Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "PDC_CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  function formatDateToSysdate(value) {
    if (!value) return "";

    const date = new Date(value);
    const day = ("0" + date.getDate()).slice(-2);
    const month = ("0" + (date.getMonth() + 1)).slice(-2); // Months are 0-indexed
    const year = date.getFullYear();
    const hours = ("0" + date.getHours()).slice(-2);
    const minutes = ("0" + date.getMinutes()).slice(-2);
    const seconds = ("0" + date.getSeconds()).slice(-2);

    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  }

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!(proc?.length > 0)) {
      alertify.error("Please select Process!");
      return;
    }
    if (!(mBatch?.length > 0)) {
      alertify.error("Please select Mother Batch!");
      return;
    }

    if (prodDtFrom.length === 0 || prodDtTo.length === 0) {
      alertify.error("Please select Prod Date!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0004GetTableDataApi(token, {
        type: "tableData",
        plant: selectedPlant,
        mBatch: mBatch,
        prodDtFrom: formatDateToSysdate(prodDtFrom),
        prodDtTo: formatDateToSysdate(prodDtTo),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              // console.log(res.data);
              setTableData(res.data);
            } else {
              setTableData([]);
              alertify.error("No data found");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchMotherTableData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0004GetMotherTableData(token, {
        mBatch: mBatch,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              setMotherTableData(res.data);
            } else {
              setMotherTableData([]);
              // alertify.error("No data FOR");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchMBatchData = () => {
    setLoading(true);
    setMBatchPopUp({ popUp: true, data: "" });

    GetAuthorization().then((token: TokenType) => {
      SPO0004GetMBatchDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.PDC_ID_PARENT_BATCH?.toString(),
                  label: x?.PDC_SCH_CRT_DT?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setMBatchTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const saveData = async () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    if (tableData?.length === 0) {
      alertify.error("No Data exist to save");
      return;
    }

    let gridData = table?.getSelectedRows();

    if (gridData?.length === 0) {
      alertify.error("Please Select Row");
      return;
    }

    for (let i = 0; i < gridData?.length; i++) {
      var batchId = gridData[i].getData()?.BATCH_ID;
      var thick = gridData[i].getData()?.PDC_THICK;
      var width = gridData[i].getData()?.PDC_WIDTH;
      var length = gridData[i].getData()?.PDC_CUT_LENGTH;
      var order = gridData[i].getData()?.PDC_ORDER;
      var item = gridData[i].getData()?.PDC_ITEM_NO;
      var netWt = gridData[i].getData()?.PDC_SCH_WT;
      var noPcs = gridData[i].getData()?.EOM_NO_PIECES;
      var packCd = gridData[i].getData()?.PDC_PACK_CODE;

      if (batchId === "") {
        alertify.error("Batch Id is mandatory!");
        return;
      } else if (thick === "") {
        alertify.error("Thickness is mandatory!");
        return;
      } else if (width === "") {
        alertify.error("Width is mandatory!");
        return;
      } else if (length === "") {
        alertify.error("Length is mandatory!");
        return;
      } else if (order === "") {
        alertify.error("Order is mandatory!");
        return;
      } else if (item === "") {
        alertify.error("Item is mandatory!");
        return;
      } else if (netWt === "") {
        alertify.error("Net Wt is mandatory!");
        return;
      } else if (noPcs === "") {
        alertify.error("No Pcs is mandatory!");
        return;
      } else if (packCd === "") {
        alertify.error("Pack Cd is mandatory!");
        return;
      }
    }

    // SCRAP WT CALCULATION
    var sumNetWt = 0;
    const schdWt = motherTable?.getRows()[0]?.getData().PDC_SCH_WT;
    var rows = table.getRows();
    var scrapWt = 0;

    rows.forEach(function (row) {
      var value = Number(row.getData().PDC_SCH_WT);
      sumNetWt += value;
    });

    scrapWt = schdWt - sumNetWt;
    scrapWt = Number(scrapWt.toFixed(3));

    console.log("scrapWt: ", scrapWt);

    let data: Array<any> = [];
    for (let i = 0; i < gridData.length; i++) {
      data.push({
        batchId: gridData[i]?._row?.data?.BATCH_ID ?? "",
        idPdi: gridData[i]?._row?.data?.PDC_PDI ?? "",
        prodDtStart: formatDateToSysdate(prodDtFrom),
        prodDtEnd: formatDateToSysdate(prodDtTo),
        mBatch: mBatch,
        length: gridData[i]?._row?.data?.PDC_CUT_LENGTH ?? "",
        thick: gridData[i]?._row?.data?.PDC_THICK ?? "",
        width: gridData[i]?._row?.data?.PDC_WIDTH ?? "",
        netWt: gridData[i]?._row?.data?.PDC_SCH_WT ?? "",
        remarks: "",
        order: gridData[i]?._row?.data?.PDC_ORDER ?? "",
        item: gridData[i]?._row?.data?.PDC_ITEM_NO ?? "",
        tdc: gridData[i]?._row?.data?.PDC_TDC ?? "",
        gradeDesc: "",
        packCd: gridData[i]?._row?.data?.PDC_PACK_CODE ?? "",
        currProc: gridData[i]?._row?.data?.PDC_CURR_PROC ?? "",
        nextProc: gridData[i]?._row?.data?.PDC_NXT_PROC ?? "",
        planProc: gridData[i]?._row?.data?.PDC_PLANNED_PROC ?? "",
        user: user,
        noPcs: gridData[i]?._row?.data?.EOM_NO_PIECES ?? "",
      });

      // data.push({
      //   P_PLANT: gridData[i]?._row?.data?.PDC_CD_EPA ?? "",
      //   P_BATCHID: gridData[i]?._row?.data?.BATCH_ID ?? "",
      //   P_MCOIL: mBatch ?? "",
      //   P_PROC: gridData[i]?._row?.data?.PDC_CURR_PROC ?? "",
      //   CUSTORD: gridData[i]?._row?.data?.PDC_ORDER ?? "",
      //   CUSTITM: gridData[i]?._row?.data?.PDC_ITEM_NO ?? "",
      //   NXTPROC: gridData[i]?._row?.data?.PDC_NXT_PROC ?? "",
      //   PROD: gridData[i]?._row?.data?.PROD_CD ?? "",
      //   QLTY: gridData[i]?._row?.data?.QLTY_CD ?? "",
      //   THICK: gridData[i]?._row?.data?.PDC_THICK ?? "",
      //   WIDTH: gridData[i]?._row?.data?.PDC_WIDTH ?? "",
      //   P_LENGTH: gridData[i]?._row?.data?.PDC_CUT_LENGTH ?? "",
      //   PIECE_ACTL: gridData[i]?._row?.data?.PDC_SCH_WT ?? "",
      //   GROSS_ACTL: gridData[i]?._row?.data?.PDC_SCH_WT ?? "",
      //   P_NO_PCS: gridData[i]?._row?.data?.EOM_NO_PIECES ?? "",
      //   TDC: gridData[i]?._row?.data?.PDC_TDC ?? "",
      //   USRID: user,
      //   IDIA: gridData[i]?._row?.data?.PDC_IDIA ?? "",
      //   ODIA: gridData[i]?._row?.data?.PDC_ODIA ?? "",
      //   SHIFT: "",
      //   PLANNED_PROC: gridData[i]?._row?.data?.PDC_PLANNED_PROC ?? "",
      //   OPR_CMNT: gridData[i]?._row?.data?.EOM_OPER_COMMENT ?? "",
      //   ST_PRODN: formatDateToSysdate(prodDtTo),
      //   P_SCRAP_WT: scrapWt,
      //   P_CAST_NO: gridData[i]?._row?.data?.PDC_CAST_NO ?? "",
      //   P_STATUS: gridData[i]?._row?.data?.PDC_CD_STATUS ?? "",
      // });
    }

    data.push({
      batchId: "SCRAP",
      idPdi: gridData[0]?._row?.data?.PDC_PDI ?? "",
      prodDtStart: formatDateToSysdate(prodDtFrom),
      prodDtEnd: formatDateToSysdate(prodDtTo),
      mBatch: mBatch,
      length: null,
      thick: gridData[0]?._row?.data?.PDC_THICK ?? "",
      width: gridData[0]?._row?.data?.PDC_WIDTH ?? "",
      netWt: scrapWt,
      remarks: "",
      order: "",
      item: null,
      tdc: "",
      gradeDesc: "",
      packCd: "",
      currProc: "",
      nextProc: "",
      planProc: "",
      user: user,
      noPcs: "",
    });

    // try {
    //   setLoading(true);
    //   const token = await GetAuthorization();
    //   const res = await SPS0005ScheduleID(token);
    //   if (res.statusText !== "" && res.statusText !== "OK") {
    //     alertify.error(res?.data?.err ? res.data.err : res?.toString());
    //   } else {
    //     setScheId(res?.data[0]?.SCH_ID);
    //     data.map((row: any) => {
    //       row["p_schd_no"] = res?.data[0]?.SCH_ID;
    //     });
    //   }
    // } catch (error) {
    //   alertify.error(error, "Something went Wrong");
    // } finally {
    //   setLoading(false);
    // }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0004saveData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success("Schedule created successfully!");
            setTableData([]);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else {
            alertify.error("Schedule not created!");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const addRow = () => {
    let arr = [...tableData];

    let len = tableData?.length;

    let batch = tableData[len - 1].BATCH_ID;
    let lastCharacter = batch.slice(-1);
    let lastNumber = parseInt(lastCharacter);
    let incrementedNumber = lastNumber + 1;
    let incrementedString = incrementedNumber.toString();
    let newBatch = batch.slice(0, -1) + incrementedString;

    arr.push({
      PDC_PDI: tableData[0].PDC_PDI,
      BATCH_ID: newBatch,
      PDC_CURR_PROC: tableData[0].PDC_CURR_PROC,
      PDC_THICK: tableData[0].PDC_THICK,
      PDC_WIDTH: tableData[0].PDC_WIDTH,
      PDC_CUT_LENGTH: tableData[0].PDC_CUT_LENGTH,
      PDC_TDC: tableData[0].PDC_TDC,
      PDC_SCH_WT: "",
      EOM_NO_PIECES: "",
      PROD_CD: tableData[0].PROD_CD,
      QLTY_CD: tableData[0].QLTY_CD,
      PDC_IDIA: tableData[0].PDC_IDIA,
      PDC_ODIA: tableData[0].PDC_ODIA,
      PDC_ORDER: tableData[0].PDC_ORDER,
      PDC_ITEM_NO: tableData[0].PDC_ITEM_NO,
      PDC_OIL_TYPE: tableData[0].PDC_OIL_TYPE,
      PDC_PACK_CODE: tableData[0].PDC_PACK_CODE,
      PDC_NXT_PROC: tableData[0].PDC_NXT_PROC,
      PDC_PLANNED_PROC: tableData[0].PDC_PLANNED_PROC,
      GRADE_DESC: "",
      REMARKS: "",
      PDC_SCH_CRT_DT: tableData[0].PDC_SCH_CRT_DT,
      PDC_SCH_CRT_BY: tableData[0].PDC_SCH_CRT_BY,
      PDC_CD_EPA: tableData[0].PDC_CD_EPA,
    });
    setTableData(arr);
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPO0004 Mannual Recording" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setProc("");
    setMBatch("");
    setInputObj(varInput);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          {/* ----- Mother Batch Pop Up */}

          <Dialog
            open={mBatchPopUp.popUp}
            onClose={() => {
              console.log("Closed M Batch");
            }}
          >
            <DialogTitle>Mother Batch Data</DialogTitle>
            <DialogContent>
              {loading ? <Loader /> : null}
              {mBatchTableData?.length > 0 ? <div id="mBatchTable" /> : null}
            </DialogContent>
            <DialogActions>
              <Button
                onClick={() => {
                  setMBatchPopUp({ popUp: false, data: "" });
                }}
                color="primary"
              >
                Close
              </Button>
            </DialogActions>
          </Dialog>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={1.5}>
                        <label>Plant*</label>
                        <SelectInput
                          placeholder="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            //   fetchEpaData(e);
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <label>Process*</label>
                        <SelectInput
                          placeholder="Process*"
                          data={procList}
                          value={proc}
                          size={"small"}
                          onChange={(e: string) => setProc(e)}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <label>Mother Batch*</label>
                        <Input
                          placeholder="M Batch"
                          // data={mBatch}
                          value={mBatch}
                          size={"small"}
                          onChange={(e: string) => setMBatch("")}
                        />
                      </Grid>

                      <Grid item xs={0}>
                        <IconButton
                          onClick={() => {
                            fetchMBatchData();
                          }}
                          style={{
                            marginTop: "14px",
                          }}
                        >
                          <SquareIcon color="info" />
                        </IconButton>
                      </Grid>

                      <Grid item xs={1.7}>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <label>Prod Dt From</label>
                          <Input
                            //   label="Prod From"
                            type="datetime-local"
                            onChange={(date: any) => setProdDtFrom(date)}
                            value={prodDtFrom}
                            placeholder=""
                            // slotProps={{ textField: { size: "small" } }}
                          />
                        </LocalizationProvider>
                      </Grid>

                      <Grid item xs={1.7}>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <label>Prod Dt To</label>
                          <Input
                            //   label="Prod To"
                            type="datetime-local"
                            onChange={(date: any) => setProdDtTo(date)}
                            value={prodDtTo}
                            placeholder=""
                            // slotProps={{ textField: { size: "small" } }}
                          />
                        </LocalizationProvider>
                      </Grid>

                      {/* <Grid item xs={2}>
                        <RadioInput
                          id={"radioOption"}
                          row={true}
                          value={radioOp}
                          data={radioOptions}
                          onChange={(e: string) => {
                            setRadioOp(e);
                          }}
                        />
                      </Grid> */}

                      <Grid item xs={1.5}>
                        <label>Options</label>
                        <SelectInput
                          placeholder="--Select--"
                          data={radioList}
                          value={radioOp}
                          size={"small"}
                          onChange={(e: string) => setRadioOp(e)}
                        />
                      </Grid>

                      <Grid item xs={1}>
                        <label style={{ visibility: "hidden" }}>" "</label>
                        <ButtonElement
                          onClick={() => {
                            fetchTableData();
                            fetchMotherTableData();
                            setSaveDisable(true);
                          }}
                        >
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Mother Batch Details"
                headerContainer={<Grid container></Grid>}
              >
                <Box sx={{ width: "100%" }}>
                  {motherTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="Mtable"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          {/* Showing 1 to {motherTableData?.length} of{" "}
                          {motherTableData?.length} entries */}
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Daughter Batch Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Add">
                        <IconButton
                          // onClick={addRow}
                          onClick={() => {
                            addRow();
                            setSaveDisable(true);
                          }}
                          disabled={restricted !== "RL_RW"}
                        >
                          <LibraryAddIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    <Grid item>
                      <Tooltip title="Sum">
                        <IconButton
                          onClick={checkSum}
                          disabled={restricted !== "RL_RW"}
                        >
                          <FunctionsIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>

                    <Grid item>
                      <Tooltip title="Save">
                        <IconButton
                          onClick={saveData}
                          disabled={restricted !== "RL_RW" || saveDisable}
                        >
                          <SaveIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPO0004;
