import { dateInput, input } from "../../type";

export interface InputChangeType {
    key1: input,
    key2: input,
}
