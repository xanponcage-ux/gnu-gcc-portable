import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0007GetDataApi,
  SPC0007GetOrderIdApi,
  // SPC001GetPlantData
  GetPlantDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, InputChangeType } from "./type";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedOrderId, setSelectedOrderId] = React.useState<string>("");
  const [selectedItem, setSelectedItem] = React.useState<string>("");
  const [orderData, setOrderData] = React.useState<Array<SelectType>>([]);
  const [selectedEpaCode, setEpaCode] = React.useState<string>("");
  const [epaData, setEpaData] = React.useState<Array<SelectType>>([]);
  const [statusCodeData, setStatusCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [qltyData, setQltyData] = React.useState<Array<SelectType>>([]);
  const [orderStatusData, setOrderStatusData] = React.useState<
    Array<SelectType>
  >([]);
  const [customerData, setCustomerData] = React.useState<Array<SelectType>>([]);
  const [orderTypeData, setOrderTypeData] = React.useState<Array<SelectType>>(
    []
  );
  const [tdcData, setTdcData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Item",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "select",
        label: "Order Status",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Material No",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key3"),
    },
    key4: {
      config: {
        type: "select",
        label: "Customer",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "Tracking No",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "select",
        label: "Order Type",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    key9: {
      config: {
        type: "input",
        label: "TDC",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key9"),
    },
    key7: {
      config: {
        type: "input",
        label: "Prod Cd",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    },
    key8: {
      config: {
        type: "input",
        label: "Qlty Cd",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    },
    key10: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key10"),
    },
    key11: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key11"),
    },
    key12: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key12"),
    },
    key13: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key13"),
    },
    key14: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key14"),
    },
    key15: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key15"),
    },
    key16: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key16"),
    },
    key17: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key17"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const column: Array<CulmnType> = [
    {
      title: "Order No",
      field: "ORDERNO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ord Item",
      field: "ORDITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Dispatch Wk",
      field: "DISPATCH_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ord Type",
      field: "ORDTYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade",
      field: "GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(2);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick Min",
      field: "THICK_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Thick Max",
      field: "THICK_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Min",
      field: "WIDTH_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Max",
      field: "WIDTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length Min",
      field: "LENGTH_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length Max",
      field: "LENGTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "Ord Qnty",
      field: "ORD_QNTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Piece Wt Min",
      field: "PIECE_WT_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Piece Wt Max",
      field: "PIECE_WT_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Piece Wt Aim",
      field: "PIECE_WT_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Edge",
      field: "ORDER_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Post Treat",
      field: "POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Tracking No",
      field: "TRACKING_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mark Cust cd",
      field: "MARK_CUST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust NM",
      field: "MARK_CUST_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cust Code",
      field: "CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cust NM",
      field: "CUST_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship To P Desc",
      field: "SHIP_TO_P_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship To P cd",
      field: "SHIP_TO_P_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "ROAD DEST",
      field: "ENC_ROAD_DEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Road Desc",
      field: "ROAD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "RAIL DEST",
      field: "ENC_RAIL_DEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Rail Desc",
      field: "RAIL_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Ask Dt",
      field: "CUST_ASK_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Spec",
      field: "CUST_SPEC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Actual Thick",
      field: "ACTUAL_THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actual Width",
      field: "ACTUAL_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actual Length",
      field: "ACTUAL_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "FG Material",
      field: "FG_MATERIAL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Desc",
      field: "ORDER_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Release dt",
      field: "ORDER_RELEASE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ord Close Dt",
      field: "ORDER_CLOSE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Download Dt",
      field: "DOWNLOAD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant CD",
      field: "PLANTCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Creation dt",
      field: "ORDER_CREATION_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Delivary Dt",
      field: "DELIVARY_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Status",
      field: "ORDER_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Download Dt Latest",
      field: "DOWNLOAD_DT_LATEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Tolerance",
      field: "TOLERANCE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Spec Info",
      field: "ORDER_SPEC_INFO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ordr Crt By",
      field: "ORDR_CRT_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0007_" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  let arr_select = [
    [],
    orderStatusData,
    [],
    customerData,
    [],
    orderTypeData,
    tdcData,
    // prodData,
    qltyData,
  ];

  React.useEffect(() => {
    setLoading(true);
    fetchOrderIdData();
    fetchPlantData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: column,
          height: 400,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setEpaData(varData);
            setSelectedItem(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchOrderIdData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0007GetOrderIdApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData1: Array<SelectType> = [];
            res.data?.order?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.ENC_ID_ORDER?.toString(),
                  label: x.ENC_ID_ORDER?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setOrderData(varData1);
            const varData2: Array<SelectType> = [];
            res.data?.orderStatus?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData2.push({
                  value: x.ENC_ST_ORDER?.toString(),
                  label: x.ENC_ST_ORDER?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setOrderStatusData(varData2);
            const varData3: Array<SelectType> = [];
            res.data?.customer?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData3.push({
                  value: x.ENC_CD_END_CUST?.toString(),
                  label: x.ENC_CD_END_CUST?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setCustomerData(varData3);
            const varData4: Array<SelectType> = [];
            res.data?.orderType?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData4.push({
                  value: x.ENC_ID_ORDER?.toString(),
                  label: x.ENC_ID_ORDER?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setOrderTypeData(varData4);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const fetchData = () => {
    if (!(selectedItem?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      order: selectedOrderId,
      epa: selectedItem?.split(" - ")[0],
      // epa: '1175',
      orderItem: inputObj.key1.value,
      orderStatus: inputObj.key2.value,
      custCd: inputObj.key3.value,
      materialNo: inputObj.key4.value,
      trackingNo: inputObj.key5.value,
      orderType: inputObj.key6.value,
      prodCd: inputObj.key7.value,
      qltyCd: inputObj.key8.value,
      tdc: inputObj.key9.value,
      orderDateFr: DateFormat(inputObj.key10.value),
      orderDateTo: DateFormat(inputObj.key11.value),
      deliveryDateFr: DateFormat(inputObj.key12.value),
      deliveryDateTo: DateFormat(inputObj.key13.value),
      ThickFr: inputObj.key14.value,
      ThickTo: inputObj.key15.value,
      widthFr: inputObj.key16.value,
      widthTo: inputObj.key17.value,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0007GetDataApi(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length === 0) {
            alertify.error("No Data Found!");
            return;
          } else if (res?.data) {
            setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleClearAll = () => {
    setSelectedOrderId("");
    setTableData([]);
    setInputObj(varInput);
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedItem}
                            data={epaData}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedItem(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <SelectInput
                            id={"id"}
                            data={orderData}
                            value={selectedOrderId}
                            label="Order"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedOrderId(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        {formData?.map(
                          (x: FormType, i: number) =>
                            i < 7 && (
                              <React.Fragment key={i}>
                                <Grid item xs={i === 0 ? 0.5 : 1.2}>
                                  {x?.data?.config?.type === "select" ? (
                                    <SelectInput
                                      id={x?.key}
                                      data={arr_select[i]}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  ) : (
                                    <Input
                                      id={x?.key}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e.toUpperCase());
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  )}
                                </Grid>
                              </React.Fragment>
                            )
                        )}
                        <Grid item xs={2}>
                          <Box component="span">
                            {" "}
                            Order Date
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 9 &&
                                  i < 11 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={2}>
                          <Box component="span">
                            {" "}
                            Delivery Date
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 11 &&
                                  i < 13 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={1.5}>
                          <Box component="span">
                            {" "}
                            Thickness
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 13 &&
                                  i < 15 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <Input
                                        id={x?.key}
                                        value={x?.data?.value}
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={1.5}>
                          <Box component="span">
                            {" "}
                            Width
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 15 &&
                                  i < 17 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <Input
                                        id={x?.key}
                                        value={x?.data?.value}
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={1.5}>
                          <Box component="span">
                            {" "}
                            Code
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 7 &&
                                  i < 9 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <Input
                                        id={x?.key}
                                        value={x?.data?.value}
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={2} sx={{ mt: 3 }}>
                          <ButtonElement onClick={fetchData}>
                            Search
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
