import { Router } from "express";
import {
  deleteCoil,
  getData01,
  getEpaData01,
  saveTableData,
  tabAccess,
} from "../controllers/SPCG001Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPCG001Route = Router();

SPCG001Route.route("/SPCG001/getData").post(
  authenticationMiddleware.bearer,
  getData01
);
SPCG001Route.route("/SPCG001/getEpaData").get(
  authenticationMiddleware.bearer,
  getEpaData01
);
SPCG001Route.route("/SPCG001/saveTableData").post(
  authenticationMiddleware.bearer,
  saveTableData
);
SPCG001Route.route("/SPCG001/tabAccess").get(
  authenticationMiddleware.bearer,
  tabAccess
);
SPCG001Route.route("/SPCG001/deleteCoil").post(
  authenticationMiddleware.bearer,
  deleteCoil
);
export default SPCG001Route;
