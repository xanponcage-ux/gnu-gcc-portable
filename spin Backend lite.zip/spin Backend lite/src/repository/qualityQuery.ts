import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

// export const getData01 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code,
//     };
//     let sql: any = `SELECT * FROM v_coil_hold_rls WHERE CHR_CD_EPA = :code`;

//     if (data.process && data.process?.length > 0) {
//       sql += ` AND CHR_CD_PROCESS = :process`;
//       binds["process"] = data?.process;
//     }
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

export const getEpaCodeData01 = async () => {
  try {
    const sql = `SELECT
    DISTINCT EPL_CD_EPA
   FROM
       V_EPA_PROC_LINE`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

// export const getFetchData = async (data: any) => {
//   try {
//     let statusSql: any = `SELECT CD_VALUE FROM V_CODES
//                           WHERE CD_TYPE='TK001'
//                           ORDER BY 1`;
//     return {
//       Status: await ResponceData(await query(statusSql)),
//       PlanCode: await ResponceData(await getCommonPlantData()),
//     };
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ001getBatchInformation = async (data: any) => {
//   try {
//     let sql: any = `SELECT EOM_ID_BATCH,EOM_CD_EPA,EOM_CD_PROD,EOM_CD_QLTY_AIM,EOM_MS_GROSS_ACTL,EOM_SEC1,EOM_CD_QLTY_ACTL,EOM_TDC_AIM,
//                                 EOM_SEC2,EOM_MS_PIECE_ACTL,EOM_TDC_ACTL,EOM_LENGTH,EOM_MS_GROSS_CAL,EOM_CD_CURR_PROC,
//                                 EOM_CD_STATUS,EOM_CD_NEXT_PROC,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS, EOM_OPER_COMMENT
//                                 FROM V_EPA_PRODN
//                           WHERE EOM_CD_EPA= '${data?.plant}' `;
//     if (data?.status && data?.status?.length > 0) {
//       sql += ` AND EOM_CD_STATUS LIKE NVL('${data?.status}',EOM_CD_STATUS) `;
//     }
//     if (data?.batch && data?.batch?.length > 0) {
//       sql += ` AND EOM_ID_BATCH = ${data?.batch} `;
//     }
//     if (data?.coilId && data?.coilId?.length > 0) {
//       sql += ` AND (EOM_ID_PAR_COIL_NO=${data?.coilId} OR EOM_ID_FIRST_PAR=${data?.coilId})`;
//     }
//     return await ResponceData(await query(sql));
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ001SaveData = async (data: any) => {
//   try {
//     let sql: any = `call TSKEPADBA.TRMQ0004(
//             p_plant => :p_plant,
//             p_batch => :p_batch,
//             p_curr_proc =>:p_curr_proc,
//             p_rsn_cd=>: p_rsn_cd,
//             p_rsn_cat=>:p_rsn_cat,
//             p_rsn_desc=>:p_rsn_desc,
//             p_scr_qty=>: p_scr_qty,
//             ln_rsn=>:ln_rsn,
//             ls_out_flag => :ls_out_flag
//           )`;

//     const binds = {
//       p_plant: data?.p_plant,
//       p_batch: data?.p_batch,
//       p_curr_proc: data?.p_curr_proc,
//       p_rsn_cd: data?.p_rsn_cd,
//       p_rsn_cat: data?.p_rsn_cat,
//       p_rsn_desc: data?.p_rsn_desc,
//       p_scr_qty: data?.p_scr_qty,
//       ln_rsn: data?.ln_rsn,
//       ls_out_flag: {
//         type: oracledb.STRING,
//         dir: oracledb.BIND_OUT,
//         maxSize: 500,
//       },
//     };
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ001ColumnData = async (data: any) => {
//   try {
//     // console.log(data);
//     let Column1: any = await ResponceData(await query(``));
//     let Column2: any = await ResponceData(await query(``));
//     let Column3: any = await ResponceData(await query(``));
//     return { Column1: Column1, Column2: Column2, Column3: Column3 };
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ001GetPopUpData = async (data: any) => {
//   try {
//     if (data?.type === "Seconds Tdc") {
//       // return await ResponceData(await query(`
//       // SELECT DISTINCT ESP_TDC_DOWNGRADE,ESP_NO_MATNR SECOND_MAT, (SELECT MAKTX FROM V_MAKT WHERE MANDT='600' AND MATNR=ESP_NO_MATNR) SECOND_MAT_DESC
//       // FROM V_EPA_sECONDS_PRIME_TDC
//       // WHERE ESP_CD_EPA='131'
//       // AND ESP_TDC_PRIME= '${data?.PrimeTdc}'`))
//       return await ResponceData(
//         await query(`SELECT DISTINCT ESP_TDC_DOWNGRADE,LTRIM(ESP_NO_MATNR,'0') SECOND_MAT
//       FROM V_EPA_sECONDS_PRIME_TDC
//       WHERE ESP_CD_EPA='131'
//       AND ESP_TDC_PRIME= '${data?.PrimeTdc}'
//       ORDER BY 1,2`)
//       );
//     } else if (data?.type === "Seconds Tdc Reason Data") {
//       let reason_category = await ResponceData(
//         // await query(
//         //   `SELECT DISTINCT ESR_RSN_CAT FROM V_SCRP_SEC_RSN WHERE ESR_CD_EPA='131' AND ESR_STATUS='A' `
//         // )
//         await query(
//           `SELECT DISTINCT ESR_RSN_CAT, ESR_RSN_YIELD FROM V_SCRP_SEC_RSN WHERE ESR_CD_EPA='131' AND ESR_STATUS='A' ORDER BY ESR_RSN_YIELD`
//         )
//       );
//       return { REASON_CATEGORY: reason_category };
//     } else if (data?.type === "Downgrade") {
//     } else if (data?.type == "getRemarks") {
//       return await ResponceData(
//         await query(`SELECT CD_DESC FROM V_CODES WHERE CD_TYPE = 'TK016'`)
//       );
//     } else if (data?.type == "getHoldNo") {
//       return await ResponceData(
//         await query(`SELECT   TO_CHAR (ch.chr_ts_hold, 'DD-MM-YYYY HH24:MI:SS') AS chr_ts_hold,
//         ch.chr_cd_rsn_hold, vh.cd_desc
//    FROM v_coil_hold_rls ch JOIN v_epa_hold_rsn vh
//         ON ch.chr_cd_rsn_hold = vh.cd_hold
//   WHERE ch.chr_id_coil = '${data?.BatchNo}'
// ORDER BY cd_hold`)
//       );
//     }
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const getRsnCodeData = async (data: any) => {
//   try {
//     let binds = {
//       rsnCat: data?.rsnCat,
//     };

//     let reason_desp = await ResponceData(
//       await query(
//         `SELECT DISTINCT ESR_RSN_CAT,ESR_RSN_CD,ESR_RSN_DESC FROM V_SCRP_SEC_RSN
//          WHERE ESR_CD_EPA='131'
//          AND ESR_STATUS='A'
//          AND ESR_RSN_CAT = '${data?.rsnCat}'
//          ORDER BY 1 `
//       )
//     );
//     return { REASON_DESP: reason_desp };
//   } catch (error) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ001Procedure = async (inputData: any) => {
//   try {
//     let data = inputData?.data;
//     let sql: any = `call TSKEPADBA.TRMQ0005(
//             p_plant => :p_plant,
//             P_RADIO_VALUE => :p_radio_value,
//             p_batch => :p_batch,
//             p_status => :p_status,
//             p_curr_proc =>:p_curr_proc,
//             p_next_proc =>:p_next_proc ,
//             p_cust_ord =>:p_cust_ord,
//             p_cust_item =>:p_cust_item,
//             p_sec_qlty => :p_sec_qlty,
//             p_sec_tdc => :p_sec_tdc,
//             p_proc=>:p_proc,
//             p_rsn_cd=>:p_rsn_cd,
//             p_rsn_cat=>:p_rsn_cat,
//             p_rsn_desc=>:p_rsn_desc,
//             p_gross_cal=>:p_gross_cal,
//             p_tdc=>:p_tdc,
//             p_sec_no_matnr=>:p_sec_no_matnr,
//             p_qlty_actl=>:p_qlty_actl,
//             p_param_cust=>:p_param_cust,
//             p_rls_remarks=>:p_rls_remarks,
//             p_rls_hold_code=>:p_rls_hold_code,
//             ls_out_flag => :ls_out_flag
//           )`;

//     const binds = {
//       p_plant: data?.p_plant,
//       P_RADIO_VALUE: data?.p_radio_value,
//       p_batch: data?.p_batch,
//       p_status: data?.p_status,
//       p_curr_proc: data?.p_curr_proc,
//       p_next_proc: data?.p_next_proc,
//       p_cust_ord: data?.p_cust_ord,
//       p_cust_item: data?.p_cust_item,
//       p_sec_qlty: data?.p_sec_qlty,
//       p_sec_tdc: data?.p_sec_tdc,
//       p_proc: data?.p_proc,
//       p_rsn_cd: data?.p_rsn_cd,
//       p_rsn_cat: data?.p_rsn_cat,
//       p_rsn_desc: data?.p_rsn_desc,
//       p_gross_cal: data?.p_gross_cal,
//       p_tdc: data?.p_tdc,
//       p_sec_no_matnr: data?.p_sec_no_matnr,
//       p_qlty_actl: data?.p_qlty_actl,
//       p_param_cust: data?.p_param_cust,
//       p_rls_remarks: data?.p_rls_remarks,
//       p_rls_hold_code: data?.p_rls_hold_code,
//       ls_out_flag: {
//         type: oracledb.STRING,
//         dir: oracledb.BIND_OUT,
//         maxSize: 500,
//       },
//     };

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

/*--------------------------- APIS FOR SCQ002 PAGE ---------------------------------------------*/

// export const SCQ002getPlantData = async (data: any) => {
//   try {
//     return {
//       PlanCode: await ResponceData(await getCommonPlantData()),
//     };
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ002getBatchData = async (data: any) => {
//   try {
//     let sql = `SELECT DISTINCT EOM_ID_BATCH,EOM_CD_STATUS
//     FROM V_EPA_PRODN
//     WHERE EOM_CD_EPA='${data?.plant}'
//     AND EOM_CD_QLTY_ACTL<>'SCRP'
    
//   `;
//     if (data?.status === "UPDATE REMARKS") {
//       sql += `AND (EOM_CD_STATUS LIKE '%B' OR EOM_CD_STATUS LIKE '%F')`;
//     }
//     if (data?.status === "HOLD") {
//       sql += ` AND (EOM_CD_STATUS LIKE '%D' OR EOM_CD_STATUS LIKE '%Q')`;
//     }
//     sql += ` ORDER BY 1`;
//     let batchesResults = { batch: await ResponceData(await query(sql)) };
//     return batchesResults;
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ002getTableData = async (data: any) => {
//   try {
//     let sql = ``;
//     if (data?.status === "HOLD") {
//       sql = `SELECT DISTINCT CHR_TS_HOLD HOLD_DT,EOM_UOM,CHR_CD_RSN_HOLD Hold_Rsn,(SELECT CD_DESC FROM V_EPA_HOLD_RSN 
//             WHERE CD_HOLD =CHR_CD_RSN_HOLD 
//             AND CD_COMP='1000' AND ROWNUM=1)HOLD_DESC, CHR_ID_OP_HOLD Hold_By
//             ,eom_cd_prod,eom_cd_qlty_actl,eom_sec1,eom_sec2,eom_length,eom_tdc_actl,eom_ms_piece_actl,eom_ms_gross_cal,
//             nvl(eom_ms_scrap/1000,0) EOM_MS_SCRAP,eom_cd_status,  eom_cd_curr_proc,eom_cd_next_proc,eom_id_order_cus,
//             eom_id_ord_item_cus,enc_cust_name,
//             (select cd_desc from v_codes where eom_cd_status=cd_value and cd_type='E0001') cd_desc 
//             ,NVL(LTRIM(EOM_NO_MATNR,'0'),LTRIM(ENC_NO_MATNR,'0')) MATERIAL_NO,(SELECT MAKTX FROM 
//             V_MAKT WHERE MANDT='600' AND MATNR=NVL(EOM_NO_MATNR,ENC_NO_MATNR) AND ROWNUM=1)MATERIAL_DESC
//             ,CHR_ID_COIL BATCHID,CHR_CD_RSN_HOLD Holdrsn,CHR_OPR_REMARKS OP_REMARKS
//             FROM v_epa_prodn, v_end_cust_ord_epa,v_coil_hold_rls
//             WHERE eom_id_order_cus = enc_id_order(+) 
//             and eom_id_ord_item_cus=enc_no_item(+) 
//             and eom_id_batch = chr_id_coil(+) 
//             and eom_cd_epa=chr_cd_epa(+)      
//             and eom_id_batch= :BatchId
//             and eom_cd_epa= :plant
//             order by CHR_TS_HOLD desc`;
//     }

//     if (data?.status === "UPDATE REMARKS") {
//       sql = `
//       SELECT eom_id_batch BATCHID,EOM_UOM,eom_cd_prod,eom_cd_qlty_actl,eom_sec1,eom_sec2,eom_length,
//       eom_tdc_actl,eom_ms_piece_actl,eom_ms_gross_cal,nvl(eom_ms_scrap/1000,0) EOM_MS_SCRAP,eom_cd_status,  
//       eom_cd_curr_proc,eom_cd_next_proc,eom_id_order_cus,eom_id_ord_item_cus,enc_cust_name,
//       (select cd_desc from v_codes where eom_cd_status=cd_value and cd_type='E0001') cd_desc 
//       ,NVL(LTRIM(EOM_NO_MATNR,'0'),LTRIM(ENC_NO_MATNR,'0')) MATERIAL_NO,
//       (SELECT MAKTX FROM V_MAKT WHERE MANDT='600' AND MATNR=NVL(EOM_NO_MATNR,ENC_NO_MATNR) 
//       AND ROWNUM=1)MATERIAL_DESC,'' CHR_OPR_REMARKS
//       FROM v_epa_prodn, v_end_cust_ord_epa
//       WHERE eom_id_order_cus = enc_id_order(+) 
//       and eom_id_ord_item_cus=enc_no_item(+)  
//       and eom_id_batch= :BatchId
//       and eom_cd_epa= :plant
//       AND (EOM_CD_STATUS LIKE '%B' OR EOM_CD_STATUS LIKE '%F')
//       AND EOM_CD_QLTY_ACTL<>'SCRP'
//       ORDER BY EOM_TS_CREATION`;
//     }

//     let binds = {
//       plant: data?.plant ? data.plant : "",
//       BatchId: data?.batchId ? data?.batchId : "",
//     };
//     return await ResponceData(await query(sql, binds));
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ002getRsnData = async (data: any) => {
//   try {
//     let sql: any = `SELECT distinct CD_DESC,CD_HOLD FROM  V_EPA_HOLD_RSN order by   CD_HOLD`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ002Procedure = async (data: any) => {
//   try {
//     let sql: any = `call TSKEPADBA.TRMQ0006(
//             p_plant                =>:p_plant,
//             p_batch                =>:p_batch,
//             p_rsn_hold_cd          =>:p_rsn_hold_cd,  
//             p_op_remarks           =>:p_op_remarks,  
//             p_status               =>:p_status,
//             p_curr_proc            =>:p_curr_proc,
//             p_next_proc            =>:p_next_proc,
//             p_net_wt               =>:p_net_wt,  
//             p_flag                 =>:p_flag,     
//             p_user                 =>:p_user,          
//             ls_out_flag            =>:ls_out_flag
//           )`;

//     const binds = {
//       p_plant: data?.p_plant ? data?.p_plant : "",
//       p_batch: data?.p_batch ? data?.p_batch : "",
//       p_rsn_hold_cd: data?.p_rsn_hold_cd ? data?.p_rsn_hold_cd : "",
//       p_op_remarks: data?.p_op_remarks ? data?.p_op_remarks : "",
//       p_status: data?.p_status ? data?.p_status : "",
//       p_curr_proc: data?.p_curr_proc ? data?.p_curr_proc : "",
//       p_next_proc: data?.p_next_proc ? data?.p_next_proc : "",
//       p_net_wt: data?.p_net_wt ? data?.p_net_wt : "",
//       p_flag: data?.p_flag ? data?.p_flag : "",
//       p_user: data?.p_user,
//       ls_out_flag: {
//         type: oracledb.STRING,
//         dir: oracledb.BIND_OUT,
//         maxSize: 500,
//       },
//     };
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

// export const SCQ002updateHoldRemarks = async (data: any) => {
//   try {
//     let ehrOpRemarks = "";
//     // let opRemarks = `SELECT EHR_PREV_OP_REMARKS, EHR_OP_REMARKS FROM V_EPA_MATL_HOLD_RLS,V_CODES WHERE CD_TYPE = 'EPA459' AND EHR_CD_EPA = CD_VALUE AND EHR_CD_EPA =:PLANT AND EHR_ID_BATCH =:BATCH_ID`;
//     let opRemarks = `SELECT CHR_OPR_REMARKS FROM V_COIL_HOLD_RLS, V_CODES WHERE CD_TYPE = 'EPA459' AND CHR_CD_EPA = CD_VALUE AND CHR_CD_EPA =:PLANT AND CHR_ID_COIL =:BATCH_ID`;

//     let remBinds = {
//       PLANT: data?.Plant,
//       BATCH_ID: data?.Batch_id,
//     };
//     let resOrmx = await ResponceData(await query(opRemarks, remBinds));
//     if (resOrmx.length > 0) {
//       ehrOpRemarks = resOrmx[0]?.EHR_PREV_OP_REMARKS;
//     }
//     const sql = `UPDATE V_COIL_HOLD_RLS SET chr_opr_remarks =:opr_remarks WHERE chr_cd_epa =:plant AND chr_id_coil =:batch_id`;

//     let binds = {
//       Plant: data?.Plant ? data?.Plant : "",
//       Batch_id: data?.Batch_id ? data?.Batch_id : "",
//       opr_remarks: data?.OprRemaks ? data?.OprRemaks : "",
//       prev_opr_remarks: ehrOpRemarks,
//       userid: data?.userid,
//     };
//     return await ResponceData(await query(sql, binds));
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };
