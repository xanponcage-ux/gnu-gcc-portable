import { Request, Response } from "express";
import DashboardModel from "../models/DashboardModel";
import { ResponceData } from "../utils";

export const piechart1 = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await DashboardModel.prototype.piechart1();
    console.log('Controller piechart2',varData)
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const piechart2 = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await DashboardModel.prototype.piechart2();
    console.log('Controller piechart2',varData)
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const linegraph1 = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await DashboardModel.prototype.linegraph1();
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const linegraph2 = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await DashboardModel.prototype.linegraph2();
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};


