// const SPC0012Query = require("../repository/SPC0012Query");
import { getOrderProgData } from "../repository/SPC0012Query";

export default class SPC0012Model {
  getOrderProgData(data: any) {
    return getOrderProgData(data);
  }
}
