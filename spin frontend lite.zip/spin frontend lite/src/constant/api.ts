interface ApiType {
  [key: string]: {
    Login: string;
    Logout: string;
    RefreshTokenUrl: string;
    AuthCheck: string;
    GenaratePasscode: string;
    SPC0002GetData: string;
    SPC0005GetData: string;
    SPC0006GetData: string;
    SPC0006GetEpaCode: string;
    SPC0007GetData: string;
    SPC0008GetData: string;
    SPQ001GetData: string;
    SPC0002GetEpaData: string;
    SPC0005GetTdcData: string;
    SPC0007GetOrderId: string;
    SPQ001GetEpaData: string;
    SPC001GetPlantData: string;

    C1FGS001GetEpaData: string;
    C1FGS001GetFilterData: string;
    SPS0005ConfirmData: string;
    SPS0005UpdateCoilStatus: string;
    SPS0005Scheduling: string;
    SPS0005GetOrderData: string;
    SPS0010IndentingApi: string;
    SPS0005ScheduleApi: string;
    SPS0005Tolerance: string;
    SCQ001Api: string;
    SCQ001GetFilterDataApi: string;
    SCQ001GetDataApi: string;
    SCQ001SaveDataApi: string;
    SPS0015Api: string;
    SPC0001GetInvData: string;
    SPC0001GetInvMonData: string;
    SPO0001GetData: string;
    SPO0001GetProdData: string;

     piechart1: string; // Added the  endpoint
     piechart2: string; // Added the  endpoint
    //DIPATCH
    SPO0002GetData: string;
    SPO0002ConfirmApi: string;

    SCQ002Api: string;
    SCQ002UploadImageToSftp: string;

    SPC0003GetData: string;
    SPC0003getPackCodeList: string;
    SPC0003GetPackSeq: string;
    SPC0003Procedure: string;

    SPC0004GetData: string;
    // --
    SPC0015GetData: string;
    // --
    SPC0008GetOrderData: string;
    SPC0006ProcedureCall: string;
    SPO0003Api: string;
    SPO0005Api: string;

    SPS0020Api: string;
    SPC0010GetData: string;
    SPC0010GetDispatchData: string;
    SPC0010GetInvMonData: string;
    SPS0025Api: string;
    SPS0025BatchApi: string;
    SPS0025TableApi: string;
    // SPS0004WipSchedulling: string;
    SPS0009GetYieldData: string;
    // SPC0009GetPlantData: string;
    GetPlantData: string;
    SPO0004GetTableData: string;
    SPO0004GetMBatchData: string;
    SPO0004saveData: string;
    SPO0004GetMotherTableData: string;
    SPC0011GetData: string;
    SPC0011GetTableData: string;
    SPO0005GetData: string;
    SPO0005GetTableData: string;
    SPO0005DeletePDI: string;

    //OPRATION
    SCO0006Action: string;
    SPO0008GetTroubleType: string;
    SPO0008GetData: string;
    SPO0008UpdData: string;
    SPO0008SaveModalData: string;
    SPO0008SaveTableData: string;
    SPO0008InsertTableData: string;

    SPC0012GetOrderData: string;
    getAuthData: string;
    SCQ001DiversionRes: string;

    //INTRANSIT REPORT - SPCG001 PG APIS
    SPCG001SaveTableData: string;
    SPCG001TabAccess: string;
    SPCG001GetData: string;
    SPCG001GetEpaData: string;
    SPCG001DeleteCoil: string;

    SPS0004BatchTableData: string;
    SPS0004OrderTableData: string;
    SPS0004BatchDlinkTableData: string;
    SPS0004SaveData: string;
    SPS0004GetChemChk: string;

    SPO0003getHoldRsn: string;
    SPO0003getSlitPos: string;
    SPS0005DiversionRes: string;

    SPC0013getCastDetails: string;
    SPC0013getCoilDetails: string;
    SPC0013getFittingDetails: string;

    SPC0014GetData: string;
    SPC0014GetStatusData: string;

    SPC0016GetData: string;
    SPC0016GetStatusData: string;

    SPC0017GetData: string;
    SPC0017GetStatusData: string;

    SPC0021GetScDwnData: string;

    //WIP Label Generation
    SPO0007GetData: string;

    QPexecQueryScreenAccess: string;
    QPexecQuery: string;
    QPconfirmExecQuery: string;
    QPtestConnection: string;

    //WIP PACKING SCHD
    SPS0003GetTableData: string;
    SPS0003CallPkgProc: string;
  };
}
const API: ApiType = {
  local: {
    Login: "api/users/login",
    Logout: "api/users/logout",
    RefreshTokenUrl: "api/users/refresh_token",
    AuthCheck: "api/users/authCheck",
    GenaratePasscode: "api/users/genaratePasscode",
    // SPC0002GetData: "api/maintainmaster/getData",
    SPC0002GetData: "api/SPC0002/getData",

    // SPC0005GetData: "api/common/getTdcData",
    // SPC0005GetTdcData: "api/common/getTdcCode",
    SPC0005GetData: "api/SPC0005/getTdcData",
    SPC0005GetTdcData: "api/SPC0005/getTdcCode",

    // SPC0006GetData: "api/maintainmaster/getData06",
    // SPC0006GetEpaCode: "api/maintainmaster/getEpaCode06",
    SPC0006GetData: "api/SPC0006/getData06",
    SPC0006GetEpaCode: "api/SPC0006/getEpaCode06",
    // SPC0007GetData: "api/common/getOrderData",
    SPC0007GetData: "api/SPC0007/getOrderData",
    // SPC0008GetData: "api/report/getScoData",
    SPC0008GetData: "api/SPC0008/getScoData",
    // SPQ001GetData: "api/quality/getData",
    SPQ001GetData: "api/SPQ001/getData",
    SPC0002GetEpaData: "api/maintainmaster/getEpaData",

    // SPC0007GetOrderId: "api/common/getOrderId",
    SPC0007GetOrderId: "api/SPC0007/getOrderId",
    SPQ001GetEpaData: "api/quality/getEpaData",
    // SPC001GetPlantData: "api/maintainmaster/getPlantData",
    SPC001GetPlantData: "api/common/getPlantData",

    //INTRANSIT REPORT - SPCG001 PG APIS
    // SPCG001GetData: "api/gateEntry/getData",
    // SPCG001GetEpaData: "api/gateEntry/getEpaData",
    SPCG001GetData: "api/SPCG001/getData",
    SPCG001GetEpaData: "api/SPCG001/getEpaData",
    SPCG001SaveTableData: "api/SPCG001/saveTableData",
    SPCG001TabAccess: "api/SPCG001/tabAccess",
    SPCG001DeleteCoil: "api/SPCG001/deleteCoil",

    C1FGS001GetEpaData: "api/operation/getData",

    // SPS0005Scheduling: "api/planning/scheduling",
    // SPS0005GetOrderData: "/api/planning/orderData",
    // SPS0005ScheduleApi: "/api/planning/scheduleID",

    SPS0005Scheduling: "api/SPS0005/scheduling",
    SPS0005GetOrderData: "/api/SPS0005/orderData",
    SPS0005ScheduleApi: "/api/SPS0005/scheduleID",
    SPS0005Tolerance: "/api/SPS0005/getToleranceLimit",

    C1FGS001GetFilterData: "api/operation/getFilterData",
    SPS0005ConfirmData: "api/planning/confirmData",
    SPS0005UpdateCoilStatus: "api/planning/updateCoilStatus",

    // SPS0010IndentingApi: "/api/planning/indenting",
    SPS0010IndentingApi: "/api/SPS0010/indenting",

    // SCQ001Api: "api/quality/SCQ001",
    SCQ001Api: "api/SCQ001/SCQ001Api",
    SCQ001GetFilterDataApi: "api/SCQ001/SCQ001GetFilterDataApi",
    SCQ001GetDataApi: "api/SCQ001/SCQ001GetDataApi",
    SCQ001SaveDataApi: "api/SCQ001/SCQ001SaveDataApi",
    SPS0015Api: "/api/SPS0015/scheduleDeletion",
    // SPC0001GetInvData: "api/report/getInvData",
    // SPC0001GetInvMonData: "api/report/getInvMonData",
    SPC0001GetInvData: "api/SPC0001/getInvData",
    SPC0001GetInvMonData: "api/SPC0001/getInvMonData",
    // SCQ002Api: "api/quality/SCQ002",
    SCQ002Api: "api/SCQ002/SCQ002Api",
    SCQ002UploadImageToSftp: "api/SCQ002/uploadImageToSftp",

    // SPO0001GetData: "api/operation/getData",
    // SPO0001GetProdData: "api/operation/getProdData",
    
    SPO0001GetData: "api/SPO0001/getData",
    SPO0001GetProdData: "api/SPO0001/getProdData",

        // DASHBOARD
     piechart1: "api/Dashboard/piechart1", // Define the path for  API
     piechart2: "api/Dashboard/piechart2", // Define the path for  API

    //OPRATION
    SCO0006Action: "api/SCO006/action",
    SPO0008GetTroubleType: "api/SPO0008/getTroubleType",
    SPO0008GetData: "api/SPO0008/getData",
    SPO0008UpdData: "api/SPO0008/saveData",
    SPO0008SaveModalData: "api/SPO0008/saveModalData",
    SPO0008SaveTableData: "api/SPO0008/saveTableData",
    SPO0008InsertTableData: "api/SPO0008/insertTableData",

    //#### Dispatch
    // SPO0002GetData: "api/dispatch/getData",
    // SPO0002ConfirmApi: "api/dispatch/confirmPacking",
    SPO0002GetData: "api/SPO0002/getData",
    SPO0002ConfirmApi: "api/SPO0002/confirmPacking",

    // SPC0003GetData: "api/maintainmaster/getcodingData",
    SPC0003GetData: "api/SPC0003/getcodingData",
    SPC0003getPackCodeList: "api/SPC0003/getPackCdList",
    SPC0003GetPackSeq: "api/SPC0003/getPackSeq",
    // SPC0003Procedure: "api/maintainmaster/savePackingOiling",
    SPC0003Procedure: "api/SPC0003/savePackingOiling",

    // SPC0004GetData: "api/maintainmaster/getcoding_02_Data",
    SPC0004GetData: "api/SPC0004/getcoding_02_Data",

    // SPC0008GetOrderData: "api/report/getOrder08",
    SPC0008GetOrderData: "api/SPC0008/getOrder08",
    // SPC0006ProcedureCall: "api/maintainmaster/procedure06",
    SPC0006ProcedureCall: "api/SPC0006/procedure06",

    // SPO0003Api: "api/operation/SPO0003Api",
    SPO0003Api: "api/SPO0003/SPO0003Api",
    SPO0005Api: "api/SPO0005/SPO0005Api",

    // SPS0020Api: "/api/report/SPS0020Api",
    SPS0020Api: "/api/SPS0020/SPS0020Api",

    // SPC0010GetData: "api/report/getData",
    // SPC0010GetDispatchData: "api/report/getDispatchData",
    SPC0010GetData: "api/SPC0010/getData",
    SPC0010GetDispatchData: "api/SPC0010/getDispatchData",

    SPC0010GetInvMonData: "api/report/getInvMonData",

    // SPS0025Api: "/api/report/SPS0025Api",
    // SPS0025BatchApi: "/api/report/SPS0025BatchApi",
    // SPS0025TableApi: "/api/report/SPS0025TableApi",
    SPS0025Api: "/api/SPS0025/SPS0025Api",
    SPS0025BatchApi: "/api/SPS0025/SPS0025BatchApi",
    SPS0025TableApi: "/api/SPS0025/SPS0025TableApi",

    // SPS0004WipSchedulling: "/api/SPS0004/WipScheduling",
    SPS0009GetYieldData: "api/SPC0009/getYieldData",
    // SPC0009GetPlantData: "api/SPC0009/getPlantData",
    GetPlantData: "api/common/getPlantData",
    SPO0004GetTableData: "api/SPO0004/getTableData",
    SPO0004GetMBatchData: "api/SPO0004/getMBatchList",
    SPO0004saveData: "api/SPO0004/saveDataTemp",
    SPO0004GetMotherTableData: "api/SPO0004/getMotherTableData",

    SPC0011GetData: "api/SPC0011/getData",
    SPC0011GetTableData: "api/SPC0011/getTableData",
    SPO0005GetData: "api/SPO0005/getData",
    SPO0005GetTableData: "api/SPO0005/getTableData",
    SPO0005DeletePDI: "api/SPO0005/callDeleteProcedure",
    SPC0012GetOrderData: "api/SPC0012/getOrdProgData",
    getAuthData: "api/users/screenAuth",
    SCQ001DiversionRes: "api/SCQ001/SCQ001DiversionRes",

    SPS0004BatchTableData: "api/SPS0004/getBatchData",
    SPS0004BatchDlinkTableData: "api/SPS0004/getBatchDLinkData",
    SPS0004OrderTableData: "api/SPS0004/getFittingOrderData",
    SPS0004SaveData: "api/SPS0004/saveData",
    SPS0004GetChemChk: "api/SPS0004/getChemChk",

    SPO0003getHoldRsn: "api/SPO0003/getHoldRsn",
    SPO0003getSlitPos: "api/SPO0003/getSlitPos",
    SPS0005DiversionRes: "api/SPS0005/getDiversionRes",

    // SPC0013 - TEST RESULT ENQUIRY SCREEN

    SPC0013getCastDetails: "api/SPC0013/getCastDetails",
    SPC0013getCoilDetails: "api/SPC0013/getCoilDetails",
    SPC0013getFittingDetails: "api/SPC0013/getFittingDetails",

    SPC0014GetData: "api/SPC0014/getData",
    SPC0014GetStatusData: "api/SPC0014/getStatusData",

    SPC0015GetData: "api/SPC0015/getData",

    SPC0016GetData: "api/SPC0016/getData",
    SPC0016GetStatusData: "api/SPC0016/getStatusData",

    SPC0017GetData: "api/SPC0017/getData",
    SPC0017GetStatusData: "api/SPC0017/getStatusData",

    SPC0021GetScDwnData: "api/SPC0021/getScDwnData",

    SPO0007GetData: "api/SPO0007/getData",

    // Query Page
    QPexecQueryScreenAccess: "api/queryPg/execQueryScreenAccess",
    QPexecQuery: "api/queryPg/execQuery",
    QPconfirmExecQuery: "api/queryPg/confirmExecQuery",
    QPtestConnection: "api/queryPg/testConnection",

    //PACKING WIP SCHD
    SPS0003GetTableData: "api/SPS0003/getBatchData",
    SPS0003CallPkgProc: "api/SPS0003/callPkgProc",
  },
  dev: {
    Login: "api/users/login",
    Logout: "api/users/logout",
    RefreshTokenUrl: "api/users/refresh_token",
    AuthCheck: "api/users/authCheck",
    GenaratePasscode: "api/users/genaratePasscode",
    SPC0002GetData: "api/SPC0002/getData",
    SPC0005GetData: "api/SPC0005/getTdcData",
    SPC0005GetTdcData: "api/SPC0005/getTdcCode",
    SPC0006GetData: "api/SPC0006/getData06",
    SPC0006GetEpaCode: "api/SPC0006/getEpaCode06",
    SPC0007GetData: "api/SPC0007/getOrderData",
    SPC0008GetData: "api/SPC0008/getScoData",
    SPQ001GetData: "api/SPQ001/getData",
    SPC0002GetEpaData: "api/maintainmaster/getEpaData",
    SPC0007GetOrderId: "api/SPC0007/getOrderId",
    SPQ001GetEpaData: "api/quality/getEpaData",
    SPC001GetPlantData: "api/common/getPlantData",

    //GATE ENTRY
    SPCG001GetData: "api/SPCG001/getData",
    SPCG001GetEpaData: "api/SPCG001/getEpaData",
    SPCG001SaveTableData: "api/SPCG001/saveTableData",
    SPCG001TabAccess: "api/SPCG001/tabAccess",
    SPCG001DeleteCoil: "api/SPCG001/deleteCoil",

    C1FGS001GetEpaData: "api/operation/getData",

    SPS0005Scheduling: "api/SPS0005/scheduling",
    SPS0005GetOrderData: "/api/SPS0005/orderData",
    SPS0005ScheduleApi: "/api/SPS0005/scheduleID",
    SPS0005Tolerance: "/api/SPS0005/getToleranceLimit",

    C1FGS001GetFilterData: "api/operation/getFilterData",
    SPS0005ConfirmData: "api/planning/confirmData",
    SPS0005UpdateCoilStatus: "api/planning/updateCoilStatus",
    SPS0010IndentingApi: "/api/SPS0010/indenting",
    SCQ001Api: "api/SCQ001/SCQ001Api",
    SCQ001GetFilterDataApi: "api/SCQ001/SCQ001GetFilterDataApi",
    SCQ001GetDataApi: "api/SCQ001/SCQ001GetDataApi",
    SCQ001SaveDataApi: "api/SCQ001/SCQ001SaveDataApi",

    SPS0015Api: "/api/SPS0015/scheduleDeletion",
    SPC0001GetInvData: "api/SPC0001/getInvData",
    SPC0001GetInvMonData: "api/SPC0001/getInvMonData",
    //Operation API
    SPO0001GetData: "api/SPO0001/getData",
    SPO0001GetProdData: "api/SPO0001/getProdData",

        // DASHBOARD
     piechart1: "api/Dashboard/piechart1", // Define the path for  API
     piechart2: "api/Dashboard/piechart2", // Define the path for  API

    //Dispatch API
    SPO0002GetData: "api/SPO0002/getData",
    SPO0002ConfirmApi: "api/SPO0002/confirmPacking",

    SCQ002Api: "api/SCQ002/SCQ002Api",
    SCQ002UploadImageToSftp: "api/SCQ002/uploadImageToSftp",

    SPC0003GetData: "api/SPC0003/getcodingData",
    SPC0003getPackCodeList: "api/SPC0003/getPackCdList",
    SPC0003GetPackSeq: "api/SPC0003/getPackSeq",
    SPC0003Procedure: "api/SPC0003/savePackingOiling",

    SPC0004GetData: "api/SPC0004/getcoding_02_Data",
    SPC0008GetOrderData: "api/SPC0008/getOrder08",
    SPC0006ProcedureCall: "api/SPC0006/procedure06",

    SPO0003Api: "api/SPO0003/SPO0003Api",
    SPO0005Api: "api/SPO0005/SPO0005Api",
    SPS0020Api: "/api/SPS0020/SPS0020Api",

    SPC0010GetData: "api/SPC0010/getData",
    SPC0010GetDispatchData: "api/SPC0010/getDispatchData",

    SPC0010GetInvMonData: "api/report/getInvMonData",

    SPS0025Api: "/api/SPS0025/SPS0025Api",
    SPS0025BatchApi: "/api/SPS0025/SPS0025BatchApi",
    SPS0025TableApi: "/api/SPS0025/SPS0025TableApi",

    SPS0009GetYieldData: "api/SPC0009/getYieldData",
    GetPlantData: "api/common/getPlantData",
    SPO0004GetTableData: "api/SPO0004/getTableData",
    SPO0004GetMBatchData: "api/SPO0004/getMBatchList",
    SPO0004saveData: "api/SPO0004/saveDataTemp",
    SPO0004GetMotherTableData: "api/SPO0004/getMotherTableData",

    SPC0011GetData: "api/SPC0011/getData",
    SPC0011GetTableData: "api/SPC0011/getTableData",
    SPO0005GetData: "api/SPO0005/getData",
    SPO0005GetTableData: "api/SPO0005/getTableData",
    SPO0005DeletePDI: "api/SPO0005/callDeleteProcedure",

    //OPRATION
    SCO0006Action: "api/SCO006/action",
    SPO0008GetTroubleType: "api/SPO0008/getTroubleType",
    SPO0008GetData: "api/SPO0008/getData",
    SPO0008UpdData: "api/SPO0008/saveData",
    SPO0008SaveModalData: "api/SPO0008/saveModalData",
    SPO0008SaveTableData: "api/SPO0008/saveTableData",
    SPO0008InsertTableData: "api/SPO0008/insertTableData",

    SPC0012GetOrderData: "api/SPC0012/getOrdProgData",
    getAuthData: "api/users/screenAuth",
    SCQ001DiversionRes: "api/SCQ001/SCQ001DiversionRes",

    SPS0004BatchTableData: "api/SPS0004/getBatchData",
    SPS0004BatchDlinkTableData: "api/SPS0004/getBatchDLinkData",
    SPS0004OrderTableData: "api/SPS0004/getFittingOrderData",
    SPS0004SaveData: "api/SPS0004/saveData",
    SPS0004GetChemChk: "api/SPS0004/getChemChk",

    SPO0003getHoldRsn: "api/SPO0003/getHoldRsn",
    SPO0003getSlitPos: "api/SPO0003/getSlitPos",
    SPS0005DiversionRes: "api/SPS0005/getDiversionRes",

    // SPC0013 - TEST RESULT ENQUIRY SCREEN

    SPC0013getCastDetails: "api/SPC0013/getCastDetails",
    SPC0013getCoilDetails: "api/SPC0013/getCoilDetails",
    SPC0013getFittingDetails: "api/SPC0013/getFittingDetails",

    SPC0014GetData: "api/SPC0014/getData",
    SPC0014GetStatusData: "api/SPC0014/getStatusData",
    SPC0015GetData: "api/SPC0015/getData",
    SPC0016GetData: "api/SPC0016/getData",
    SPC0016GetStatusData: "api/SPC0016/getStatusData",
    SPC0017GetData: "api/SPC0017/getData",
    SPC0017GetStatusData: "api/SPC0017/getStatusData",
    SPC0021GetScDwnData: "api/SPC0021/getScDwnData",
    SPO0007GetData: "api/SPO0007/getData",

    // Query Page
    QPexecQueryScreenAccess: "api/queryPg/execQueryScreenAccess",
    QPexecQuery: "api/queryPg/execQuery",
    QPconfirmExecQuery: "api/queryPg/confirmExecQuery",
    QPtestConnection: "api/queryPg/testConnection",

    //PACKING WIP SCHD
    SPS0003GetTableData: "api/SPS0003/getBatchData",
    SPS0003CallPkgProc: "api/SPS0003/callPkgProc",
  },
  qa: {
    Login: "api/users/login",
    Logout: "api/users/logout",
    RefreshTokenUrl: "api/users/refresh_token",
    AuthCheck: "api/users/authCheck",
    GenaratePasscode: "api/users/genaratePasscode",
    SPC0002GetData: "api/SPC0002/getData",

    SPC0005GetData: "api/SPC0005/getTdcData",
    SPC0005GetTdcData: "api/SPC0005/getTdcCode",
    SPC0006GetData: "api/SPC0006/getData06",
    SPC0006GetEpaCode: "api/SPC0006/getEpaCode06",
    SPC0007GetData: "api/SPC0007/getOrderData",
    SPC0008GetData: "api/SPC0008/getScoData",
    SPC0002GetEpaData: "api/maintainmaster/getEpaData",
    SPC0007GetOrderId: "api/SPC0007/getOrderId",
    SPQ001GetData: "api/SPQ001/getData",
    SPQ001GetEpaData: "api/quality/getEpaData",
    SPC001GetPlantData: "api/common/getPlantData",

    //INTRANSIT REPORT - SPCG001 PG APIS

    SPCG001GetData: "api/SPCG001/getData",
    SPCG001GetEpaData: "api/SPCG001/getEpaData",
    SPCG001SaveTableData: "api/SPCG001/saveTableData",
    SPCG001TabAccess: "api/SPCG001/tabAccess",
    SPCG001DeleteCoil: "api/SPCG001/deleteCoil",

    C1FGS001GetEpaData: "api/operation/getData",

    SPS0005Scheduling: "api/SPS0005/scheduling",
    SPS0005GetOrderData: "/api/SPS0005/orderData",
    SPS0005ScheduleApi: "/api/SPS0005/scheduleID",
    SPS0005Tolerance: "/api/SPS0005/getToleranceLimit",

    C1FGS001GetFilterData: "api/operation/getFilterData",
    SPS0005ConfirmData: "api/planning/confirmData",
    SPS0005UpdateCoilStatus: "api/planning/updateCoilStatus",
    SPS0010IndentingApi: "/api/SPS0010/indenting",
    SCQ001Api: "api/SCQ001/SCQ001Api",
    SCQ001GetFilterDataApi: "api/SCQ001/SCQ001GetFilterDataApi",
    SCQ001GetDataApi: "api/SCQ001/SCQ001GetDataApi",
    SCQ001SaveDataApi: "api/SCQ001/SCQ001SaveDataApi",

    SPS0015Api: "/api/SPS0015/scheduleDeletion",
    SPC0001GetInvData: "api/SPC0001/getInvData",
    SPC0001GetInvMonData: "api/SPC0001/getInvMonData",
    //Operation API
    SPO0001GetData: "api/SPO0001/getData",
    SPO0001GetProdData: "api/SPO0001/getProdData",

        // DASHBOARD
     piechart1: "api/Dashboard/piechart1", // Define the path for  API
     piechart2: "api/Dashboard/piechart2", // Define the path for  API

    //DIPATCH
    SPO0002GetData: "api/SPO0002/getData",
    SPO0002ConfirmApi: "api/SPO0002/confirmPacking",

    SCQ002Api: "api/SCQ002/SCQ002Api",
    SCQ002UploadImageToSftp: "api/SCQ002/uploadImageToSftp",

    SPC0003GetData: "api/SPC0003/getcodingData",
    SPC0003getPackCodeList: "api/SPC0003/getPackCdList",
    SPC0003GetPackSeq: "api/SPC0003/getPackSeq",
    SPC0003Procedure: "api/SPC0003/savePackingOiling",

    SPC0004GetData: "api/SPC0004/getcoding_02_Data",

    SPC0008GetOrderData: "api/SPC0008/getOrder08",
    SPC0006ProcedureCall: "api/SPC0006/procedure06",

    SPO0003Api: "api/SPO0003/SPO0003Api",
    SPO0005Api: "api/SPO0005/SPO0005Api",
    SPS0020Api: "/api/SPS0020/SPS0020Api",

    SPC0010GetData: "api/SPC0010/getData",
    SPC0010GetDispatchData: "api/SPC0010/getDispatchData",

    SPC0010GetInvMonData: "api/report/getInvMonData",

    SPS0025Api: "/api/SPS0025/SPS0025Api",
    SPS0025BatchApi: "/api/SPS0025/SPS0025BatchApi",
    SPS0025TableApi: "/api/SPS0025/SPS0025TableApi",

    SPS0009GetYieldData: "api/SPC0009/getYieldData",
    GetPlantData: "api/common/getPlantData",

    // SPO0004 Apis
    SPO0004GetTableData: "api/SPO0004/getTableData",
    SPO0004GetMBatchData: "api/SPO0004/getMBatchList",
    SPO0004saveData: "api/SPO0004/saveDataTemp",
    SPO0004GetMotherTableData: "api/SPO0004/getMotherTableData",

    SPC0011GetData: "api/SPC0011/getData",
    SPC0011GetTableData: "api/SPC0011/getTableData",
    SPO0005GetData: "api/SPO0005/getData",
    SPO0005GetTableData: "api/SPO0005/getTableData",
    SPO0005DeletePDI: "api/SPO0005/callDeleteProcedure",

    //OPRATION
    SCO0006Action: "api/SCO006/action",
    SPO0008GetTroubleType: "api/SPO0008/getTroubleType",
    SPO0008GetData: "api/SPO0008/getData",
    SPO0008UpdData: "api/SPO0008/saveData",
    SPO0008SaveModalData: "api/SPO0008/saveModalData",
    SPO0008SaveTableData: "api/SPO0008/saveTableData",
    SPO0008InsertTableData: "api/SPO0008/insertTableData",

    SPC0012GetOrderData: "api/SPC0012/getOrdProgData",
    getAuthData: "api/users/screenAuth",
    SCQ001DiversionRes: "api/SCQ001/SCQ001DiversionRes",

    SPS0004BatchTableData: "api/SPS0004/getBatchData",
    SPS0004BatchDlinkTableData: "api/SPS0004/getBatchDLinkData",
    SPS0004OrderTableData: "api/SPS0004/getFittingOrderData",
    SPS0004SaveData: "api/SPS0004/saveData",
    SPS0004GetChemChk: "api/SPS0004/getChemChk",

    SPO0003getHoldRsn: "api/SPO0003/getHoldRsn",
    SPO0003getSlitPos: "api/SPO0003/getSlitPos",
    SPS0005DiversionRes: "api/SPS0005/getDiversionRes",

    // SPC0013 - TEST RESULT ENQUIRY SCREEN

    SPC0013getCastDetails: "api/SPC0013/getCastDetails",
    SPC0013getCoilDetails: "api/SPC0013/getCoilDetails",
    SPC0013getFittingDetails: "api/SPC0013/getFittingDetails",

    SPC0014GetData: "api/SPC0014/getData",
    SPC0014GetStatusData: "api/SPC0014/getStatusData",
    SPC0015GetData: "api/SPC0015/getData",
    SPC0016GetData: "api/SPC0016/getData",
    SPC0016GetStatusData: "api/SPC0016/getStatusData",
    SPC0017GetData: "api/SPC0017/getData",
    SPC0017GetStatusData: "api/SPC0017/getStatusData",
    SPC0021GetScDwnData: "api/SPC0021/getScDwnData",
    SPO0007GetData: "api/SPO0007/getData",

    // Query Page
    QPexecQueryScreenAccess: "api/queryPg/execQueryScreenAccess",
    QPexecQuery: "api/queryPg/execQuery",
    QPconfirmExecQuery: "api/queryPg/confirmExecQuery",
    QPtestConnection: "api/queryPg/testConnection",

    //PACKING WIP SCHD
    SPS0003GetTableData: "api/SPS0003/getBatchData",
    SPS0003CallPkgProc: "api/SPS0003/callPkgProc",
  },
  prd: {
    Login: "api/users/login",
    Logout: "api/users/logout",
    RefreshTokenUrl: "api/users/refresh_token",
    AuthCheck: "api/users/authCheck",
    GenaratePasscode: "api/users/genaratePasscode",
    SPC0002GetData: "api/SPC0002/getData",
    SPC0005GetData: "api/SPC0005/getTdcData",
    SPC0005GetTdcData: "api/SPC0005/getTdcCode",
    SPC0006GetData: "api/SPC0006/getData06",
    SPC0006GetEpaCode: "api/SPC0006/getEpaCode06",
    SPC0007GetData: "api/SPC0007/getOrderData",
    SPC0008GetData: "api/SPC0008/getScoData",
    SPQ001GetData: "api/SPQ001/getData",
    SPC0002GetEpaData: "api/maintainmaster/getEpaData",
    SPC0007GetOrderId: "api/SPC0007/getOrderId",
    SPQ001GetEpaData: "api/quality/getEpaData",
    SPC001GetPlantData: "api/common/getPlantData",

    //INTRANSIT REPORT - SPCG001 PG APIS
    SPCG001GetData: "api/SPCG001/getData",
    SPCG001GetEpaData: "api/SPCG001/getEpaData",
    SPCG001SaveTableData: "api/SPCG001/saveTableData",
    SPCG001TabAccess: "api/SPCG001/tabAccess",
    SPCG001DeleteCoil: "api/SPCG001/deleteCoil",

    C1FGS001GetEpaData: "api/operation/getData",

    SPS0005Scheduling: "api/SPS0005/scheduling",
    SPS0005GetOrderData: "/api/SPS0005/orderData",
    SPS0005ScheduleApi: "/api/SPS0005/scheduleID",
    SPS0005Tolerance: "/api/SPS0005/getToleranceLimit",

    C1FGS001GetFilterData: "api/operation/getFilterData",
    SPS0005ConfirmData: "api/planning/confirmData",
    SPS0005UpdateCoilStatus: "api/planning/updateCoilStatus",
    SPS0010IndentingApi: "/api/SPS0010/indenting",
    SCQ001Api: "api/SCQ001/SCQ001Api",
    SCQ001GetFilterDataApi: "api/SCQ001/SCQ001GetFilterDataApi",
    SCQ001GetDataApi: "api/SCQ001/SCQ001GetDataApi",
    SCQ001SaveDataApi: "api/SCQ001/SCQ001SaveDataApi",
    SPS0015Api: "/api/SPS0015/scheduleDeletion",
    SPC0001GetInvData: "api/SPC0001/getInvData",
    SPC0001GetInvMonData: "api/SPC0001/getInvMonData",

    SCQ002Api: "api/SCQ002/SCQ002Api",
    SCQ002UploadImageToSftp: "api/SCQ002/uploadImageToSftp",

    SPO0001GetData: "api/SPO0001/getData",
    SPO0001GetProdData: "api/SPO0001/getProdData",
    // DASHBOARD
     piechart1: "api/Dashboard/piechart1", // Define the path for API
     piechart2: "api/Dashboard/piechart2", // Define the path for  API

    //OPRATION
    SCO0006Action: "api/SCO006/action",
    SPO0008GetTroubleType: "api/SPO0008/getTroubleType",
    SPO0008GetData: "api/SPO0008/getData",
    SPO0008UpdData: "api/SPO0008/saveData",
    SPO0008SaveModalData: "api/SPO0008/saveModalData",
    SPO0008SaveTableData: "api/SPO0008/saveTableData",
    SPO0008InsertTableData: "api/SPO0008/insertTableData",

    SPO0002GetData: "api/SPO0002/getData",
    SPO0002ConfirmApi: "api/SPO0002/confirmPacking",
    SPC0003GetData: "api/SPC0003/getcodingData",
    SPC0003getPackCodeList: "api/SPC0003/getPackCdList",
    SPC0003GetPackSeq: "api/SPC0003/getPackSeq",
    SPC0003Procedure: "api/SPC0003/savePackingOiling",
    SPC0004GetData: "api/SPC0004/getcoding_02_Data",
    SPC0008GetOrderData: "api/SPC0008/getOrder08",
    SPC0006ProcedureCall: "api/SPC0006/procedure06",
    SPO0003Api: "api/SPO0003/SPO0003Api",
    SPO0005Api: "api/SPO0005/SPO0005Api",
    SPS0020Api: "/api/SPS0020/SPS0020Api",
    SPC0010GetData: "api/SPC0010/getData",
    SPC0010GetDispatchData: "api/SPC0010/getDispatchData",

    SPC0010GetInvMonData: "api/report/getInvMonData",
    SPS0025Api: "/api/SPS0025/SPS0025Api",
    SPS0025BatchApi: "/api/SPS0025/SPS0025BatchApi",
    SPS0025TableApi: "/api/SPS0025/SPS0025TableApi",

    SPS0009GetYieldData: "api/SPC0009/getYieldData",
    GetPlantData: "api/common/getPlantData",
    SPO0004GetTableData: "api/SPO0004/getTableData",
    SPO0004GetMBatchData: "api/SPO0004/getMBatchList",
    SPO0004saveData: "api/SPO0004/saveDataTemp",
    SPO0004GetMotherTableData: "api/SPO0004/getMotherTableData",

    SPC0011GetData: "api/SPC0011/getData",
    SPC0011GetTableData: "api/SPC0011/getTableData",
    SPO0005GetData: "api/SPO0005/getData",
    SPO0005GetTableData: "api/SPO0005/getTableData",
    SPO0005DeletePDI: "api/SPO0005/callDeleteProcedure",
    SPC0012GetOrderData: "api/SPC0012/getOrdProgData",
    getAuthData: "api/users/screenAuth",
    SCQ001DiversionRes: "api/SCQ001/SCQ001DiversionRes",

    SPS0004BatchTableData: "api/SPS0004/getBatchData",
    SPS0004BatchDlinkTableData: "api/SPS0004/getBatchDLinkData",
    SPS0004OrderTableData: "api/SPS0004/getFittingOrderData",
    SPS0004SaveData: "api/SPS0004/saveData",
    SPS0004GetChemChk: "api/SPS0004/getChemChk",

    SPO0003getHoldRsn: "api/SPO0003/getHoldRsn",
    SPO0003getSlitPos: "api/SPO0003/getSlitPos",
    SPS0005DiversionRes: "api/SPS0005/getDiversionRes",

    // SPC0013 - TEST RESULT ENQUIRY SCREEN

    SPC0013getCastDetails: "api/SPC0013/getCastDetails",
    SPC0013getCoilDetails: "api/SPC0013/getCoilDetails",
    SPC0013getFittingDetails: "api/SPC0013/getFittingDetails",

    SPC0014GetData: "api/SPC0014/getData",
    SPC0014GetStatusData: "api/SPC0014/getStatusData",
    SPC0015GetData: "api/SPC0015/getData",
    SPC0016GetData: "api/SPC0016/getData",
    SPC0016GetStatusData: "api/SPC0016/getStatusData",
    SPC0017GetData: "api/SPC0017/getData",
    SPC0017GetStatusData: "api/SPC0017/getStatusData",
    SPC0021GetScDwnData: "api/SPC0021/getScDwnData",

    SPO0007GetData: "api/SPO0007/getData",

    // Query Page
    QPexecQueryScreenAccess: "api/queryPg/execQueryScreenAccess",
    QPexecQuery: "api/queryPg/execQuery",
    QPconfirmExecQuery: "api/queryPg/confirmExecQuery",
    QPtestConnection: "api/queryPg/testConnection",

    //PACKING WIP SCHD
    SPS0003GetTableData: "api/SPS0003/getBatchData",
    SPS0003CallPkgProc: "api/SPS0003/callPkgProc",
  },
};
export default API;
