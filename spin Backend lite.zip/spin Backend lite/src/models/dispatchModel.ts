const DispatchQuery = require("../repository/dispatchQuery");

export default class DispatchModel {  
    // getData(data: any) {
    //     return DispatchQuery.getData(data);
    // }
    // ConfirmPacking(data: any) {
    //     return DispatchQuery.ConfirmPacking(data);
    // }
    // confirm(data: any) {
    //     return DispatchQuery.confirm(data);
    // }
}