// const SPS0005Query = require("../repository/SPS0005Query");
import {
  scheduling,
  deleteScheduling,
  getOrderData,
  scheduleID,
  getToleranceLimit,
  getDiversionRes,
} from "../repository/SPS0005Query";

export default class SPS0005Model {
  deleteScheduling(data: any) {
    return deleteScheduling(data);
  }
  scheduling(data: any) {
    return scheduling(data);
  }
  getOrderData(data: any) {
    return getOrderData(data);
  }
  scheduleID() {
    return scheduleID();
  }
  getToleranceLimit() {
    return getToleranceLimit();
  }
  getDiversionRes(data: any) {
    return getDiversionRes(data);
  }
}
