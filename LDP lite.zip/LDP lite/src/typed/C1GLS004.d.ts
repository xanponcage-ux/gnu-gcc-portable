interface C1GLS004ProcedureHr {
    p_fromdt: string
    p_todt: string
    p_grade: string
    p_nbt_type_cgl: string
    p_prod_type: string
    p_decision_type: string
}