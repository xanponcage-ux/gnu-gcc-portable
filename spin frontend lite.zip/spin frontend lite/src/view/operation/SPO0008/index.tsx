import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip, Typography } from "@mui/material";
import { reactFormatter, ReactTabulator } from "react-tabulator";

import {
  GetPlantDataApi,
  SPC0011GetDataApi,
  SPC0011GetTableDataApi,
  SPO0008GetTroubleType,
  SPO0008GetData,
  SPO0008UpdData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { setTheme, useMaterialUIController } from "../../../context";
import { SelectType } from "../../../components/input/type";
import { DatePickerInput } from "../../../components/input";
// import { InputChangeType } from "./type";
import { InputChangeType } from "../SPO0008/type";
import { FormType } from "../../auth/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import Auth from "../../../components/layout/dashboardLayout/auth";
import "bootstrap-daterangepicker/daterangepicker.css";
import DateRangePicker from "react-bootstrap-daterangepicker";
import moment from "moment";
import "moment/locale/en-gb.js";
import SaveModel from "./SaveModal";

const SPO0008 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<any>("");
  const [process, setProcess] = React.useState<Array<SelectType>>([]);
  const [selectedProc, setSelectedProc] = React.useState<any>("");
  const [status, setStatus] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<any>("");
  const [batch, setBatch] = React.useState<any>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [troubleDesc, setTroubleDesc] = React.useState({});
  const [noOfDelay, setNoOfDelay] = React.useState("");
  const [DelayInHrs, setDelayInHrs] = React.useState("");
  const [workingHrs, setWorkingHrs] = React.useState("");
  const [mttr, setMttr] = React.useState("");
  const [milUtil, setMilUtil] = React.useState("");
  const [mtbf, setMtbf] = React.useState("");

  const [delay, setDelay] = React.useState([]);
  const [equip, setEquip] = React.useState([]);
  const [fac, setFac] = React.useState([]);
  const [showModal, setShowModal] = React.useState(false);
  const [modalData, setModalData] = React.useState([]);
  const [deleteData, setDeleteData] = React.useState([]);
  const [reason, setReason] = React.useState([]);
  const [eqpCode, seteqpCode] = React.useState([]);
  const [agcCode, setAgcCode] = React.useState([]);

  //DELAY MANAGEMENT STATES
  const [state1, setState1] = React.useState({
    start: moment(), //.subtract(29, 'days'),
    end: moment(),
  });
  var dataTableRef = React.createRef();
  const { start, end } = state1;
  const label = start.format("DD-MMM-YY") + " | " + end.format("DD-MMM-YY");

  const Shift = [
    { label: "All", value: "All" },
    { label: "A", value: "A" },
    { label: "B", value: "B" },
    { label: "C", value: "C" },
  ];
  const defaultvalues = {
    dateFrom: new Date("01-01-2019"),
    dateTo: new Date("01-31-2019"),
    selectBy: "",
    selectShift: "All",
    selectAction: "",
    troubleType: "",
    EqpCD: "",
    FaqCD: "",
  };

  const [filter, setFilter] = React.useState(defaultvalues);
  const [troubleType, setTroubleType] = React.useState<Array<SelectType>>([]);
  const [selectedTroubleType, setSelectedTroubleType] = React.useState<any>("");

  // const [troubleType, setTroubleType] = React.useState({});
  // const [troubleType, setTroubleType] = React.useState({});

  //   const varInput: InputChangeType = {
  //     key1: {
  //       config: {
  //         type: "input",
  //         label: "Schd From",
  //       },
  //       value: "",
  //       onChange: (e: any) => onInputChange(e?.toString(), "key1"),
  //     },
  //     key2: {
  //       config: {
  //         type: "input",
  //         label: "Schd To",
  //       },
  //       value: "",
  //       onChange: (e: any) => onInputChange(e?.toString(), "key2"),
  //     },
  //   };

  //   const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  //   let formData: Array<FormType> = [];
  //   for (const i in inputObj) {
  //     formData.push({
  //       key: i.toString(),
  //       data: inputObj[i as keyof InputChangeType],
  //     });
  //   }

  //   const onInputChange = (value: string, obj: string) => {
  //     setInputObj((prevState: InputChangeType) => ({
  //       ...prevState,
  //       [obj]: {
  //         ...inputObj[obj as keyof InputChangeType],
  //         value: value?.toString(),
  //       },
  //     }));
  //   };
  const [restricted, setRestricted] = React.useState(null);

  React.useEffect(() => {
    fetchEpaData();
    getTroubleType();
  }, []);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0011GetDataApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlant(varData);
              setSelectedPlant(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcess(varprocessData);

              const varStatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varStatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_VALUE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatus(varStatusData);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getTroubleType = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0008GetTroubleType(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data: ", res.data);
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.TRBLTYPE?.toString(),
                  label: x?.TRBLDESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setTroubleType(varData);
            console.log("troubleType: ", troubleType);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // const getTroubleType = async (newToken = true) => {
  //   if (newToken) {
  //     const rsp = await getAuthorization();
  //   }
  //   var defaultOptions = {
  //     headers: {
  //       Authorization: "Bearer " + localStorage.getItem("tcm_accessToken"),
  //     },
  //   };
  //   setLoading(true);

  //   var url = "api/c1fps008/get-Trouble-Type";

  //   axiosAPI
  //     .post(url, {}, defaultOptions)
  //     .then(({ data, status }) => {
  //       var items = [];

  //       data?.troubleData.map((row) => {
  //         var obj = new Object();

  //         var rowSplit = row.split(":");

  //         obj.label = rowSplit[0];

  //         obj.value = rowSplit[1];

  //         items.push(obj);
  //       });
  //       setTroubleType(items);
  //     })
  //     .finally(() => {
  //       setLoading(false);
  //     });
  // };

  const downloadExcel = () => {
    if (delay.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPO0008_Delay_details" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  // const getSearchData = () => {
  //   setLoading(true);
  //   GetAuthorization().then((token: TokenType) => {
  //     let data = {
  //       ...filter,
  //       dateFrom: start.format("DD-MMM-YYYY"),
  //       dateTo: end.format("DD-MMM-YYYY"),
  //       troubleType: troubleType,
  //     };
  //     SPO0008GetData(token, data)
  //       .then((res) => {
  //         if (res.statusText !== "" && res.statusText !== "OK") {
  //           alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //         } else if (res?.data) {
  //           console.log("res.data: ", res.data);
  //           ({
  //             data: {
  //               delayData,
  //               eqpData,
  //               facData,
  //               totalDelay,
  //               totalRows,
  //               workHrs,
  //               spnMttr,
  //               milUtility,
  //               spnMtbf,
  //               reasonData,
  //               eqpCodeData,
  //               agencyList,
  //             },
  //             status,
  //           }) => {
  //             // setDelay(delayData);

  //             // setEquip(eqpData);

  //             // setFac(facData);
  //             setDelayInHrs(Number(totalDelay).toFixed(2));
  //             setNoOfDelay(totalRows);
  //             setWorkingHrs(workHrs);
  //             setMttr(spnMttr);
  //             setMilUtil(Number(milUtility).toFixed(2));
  //             setMtbf(Number(spnMtbf).toFixed(2));

  //             // var items = [];
  //             // reasonData.map((row) => {
  //             //   //var obj = new Object();
  //             //   var [value] = row.split("-");

  //             //   // obj.label = rowSplit[0];
  //             //   // obj.value = rowSplit[0];

  //             //   items.push({ label: row, value }); //moment(item, "DD");
  //             // });
  //             // setReason(items);

  //             // var items1 = eqpCodeData.map((row) => {
  //             //   var [value] = row.split("-");
  //             //   return { label: row, value };
  //             // });
  //             // seteqpCode(items1);

  //             // setAgcCode(agencyList ?? []);
  //           };
  //         }
  //       })
  //       .catch((e: any) => {
  //         console.log("e", e);
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something Went wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };

  // const optionsAuto = {
  //   height: 400,
  //   autoColumns: true,
  //   //pagination: "local",
  //   //paginationSize: 12,
  //   layout: "fitDataFill",
  //   // downloadDataFormatter: (data) => data,
  //   // downloadReady: (fileContents, blob) => blob,
  //   // responsiveLayout:"collapse",
  //   // responsiveLayoutCollapseStartOpen:false,
  // };

  const searchField = {
    headerFilter: "input",
    headerFilterPlaceholder: "search...",
  };

  function SaveButton({ restricted }) {
    const isDisabled = restricted !== "RL_RW";

    return (
      <i
        className="fa fa-save"
        aria-hidden="true"
        style={{
          color: isDisabled ? "#ccc" : "#000",
          cursor: isDisabled ? "not-allowed" : "pointer",
          pointerEvents: isDisabled ? "none" : "auto",
        }}
      ></i>
    );
  }

  // function SaveButton() {
  //   // if (restricted !== "RL_RW") {
  //   return <i className="fa fa-save" aria-hidden="true"></i>;
  //   // }
  // }

  function DelButton({ restricted }) {
    const isDisabled = restricted !== "RL_RW";

    return (
      <i
        className="fas fa-trash"
        aria-hidden="true"
        style={{
          color: isDisabled ? "#ccc" : "#000",
          cursor: isDisabled ? "not-allowed" : "pointer",
          pointerEvents: isDisabled ? "none" : "auto",
        }}
      ></i>
    );
  }

  // function DelButton() {
  //   return <i className="fas fa-trash"></i>;
  // }

  function UpdateDataButton({ restricted }) {
    const isDisabled = restricted !== "RL_RW";

    return (
      <i
        className="fa fa-clone fa-1x"
        aria-hidden="true"
        style={{
          color: isDisabled ? "#ccc" : "#000",
          cursor: isDisabled ? "not-allowed" : "pointer",
          pointerEvents: isDisabled ? "none" : "auto",
        }}
      ></i>
    );
  }

  // function UpdateDataButton() {
  //   return (
  //     <i
  //       className="fa fa-clone fa-1x"
  //       aria-hidden="true"
  //       // onClick={() => saveData(cellData)}
  //     ></i>
  //   );
  // }

  const dataCol: any = [
    {
      title: "Update",
      formatter: reactFormatter(<SaveButton restricted={restricted} />),
      hozAlign: "center",
      cellClick: function (e, cell) {
        {
          if (restricted == "RL_RW") {
            showSaveInfo(cell);
          }
        }
      },
      download: false,
      headerSort: false,
      width: "50",
    },
    {
      title: "Delete",
      formatter: reactFormatter(<DelButton restricted={restricted} />),
      hozAlign: "center",
      cellClick: function (e, cell) {
        if (restricted === "RL_RW") {
          // showDelInfo(cell);
        }
      },
      download: false,
      headerSort: false,
      width: "50",
    },
    {
      title: "Break",
      formatter: reactFormatter(<UpdateDataButton restricted={restricted} />),
      hozAlign: "center",
      cellClick: function (e, cell) {
        if (restricted === "RL_RW") {
          showUpdateInfo(cell);
        }
      },
      download: false,
      headerSort: false,
      width: "50",
      resize: false,
    },
    { title: "Outage Date", field: "OUTAGE_DT", ...searchField },
    { title: "Process", field: "FAO_CD_PROCESS", ...searchField },

    { title: "Shift", field: "FAO_CD_SH_OUTAGE", ...searchField },
    {
      title: "Start Date",
      field: "FAO_TM_STOP_ST",
      ...searchField,
      // formatter: function (cell) {
      //   var value = cell.getValue();
      //   value = value ? moment(value).format("DD/MM/YYYY hh:mm:ss A") : "";
      //   return value;
      // },
    },
    {
      title: "End Date",
      field: "FAO_TM_STOP_EN",
      ...searchField,
      // formatter: function (cell) {
      //   var value = cell.getValue();
      //   value = value ? moment(value).format("DD/MM/YYYY hh:mm:ss A") : "";
      //   return value;
      // },
    },
    {
      title: "Duration(Mins)",
      field: "DURATION",
      ...searchField,
      formatter: "money",
    },
    {
      title: "Reason",
      field: "FAO_CD_OUTAGE",
      ...searchField,
      formatter: function (cell) {
        var value = cell.getValue();
        cell.getElement().style["background-color"] = "#d3d3d3";
        return value;
      },
      cellEdited: function (cell: any) {
        if (cell?.isEdited()) {
          cell.getRow().getElement().style.backgroundColor = "#c8f205";
          cell._cell.row.updateData({
            DESCP:
              reason.find((i: any) => i.value == cell.getValue())?.label ?? "",
          });
        }
      },
      editor: "select",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: reason,
      },
    },
    { title: "Reason Description", field: "DESCP", ...searchField },
    {
      title: "Remarks",
      field: "FAO_REMARKS",
      ...searchField,
      editor: "input",
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["background-color"] = "#d3d3d3";
        return value;
      },
      cellEdited: function (cell: any) {
        if (cell.isEdited()) {
          cell.getRow().getElement().style.backgroundColor = "#c8f205";
        }
      },
    },
    // { title: "Coil Id", field: "FAO_ID_COIL", ...searchField },
    {
      title: "Equip Code",
      field: "FAO_CD_EQP_MAST",
      ...searchField,
      editor: "select",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: eqpCode,
      },
      formatter: function (cell) {
        var value = cell.getValue();
        cell.getElement().style["background-color"] = "#d3d3d3";
        return value;
      },
      cellEdited: function (cell) {
        if (cell.isEdited()) {
          cell.getRow().getElement().style.backgroundColor = "#c8f205";
          cell._cell.row.updateData({
            equip_description:
              eqpCode.find((i: any) => i.value == cell.getValue())?.label ?? "",
          });
        }
      },
    },
    {
      title: "Equip Desc",
      field: "equip_description",
      ...searchField,
    },
    {
      title: "Agency Code",
      field: "FAO_CD_FAC_MAST",
      ...searchField,
      editor: "select",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: agcCode,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["background-color"] = "#d3d3d3";
        return value;
      },
      cellEdited: function (cell: any) {
        if (cell.isEdited()) {
          cell.getRow().getElement().style.backgroundColor = "#c8f205";
          cell._cell.row.updateData({
            agency_description:
              agcCode.find((i: any) => i.value == cell.getValue())?.label ?? "",
          });
        }
      },
    },
    {
      title: "Agency Desc",
      field: "agency_description",
      ...searchField,
    },
    {
      title: "Creation Time",
      field: "FAO_TS_REC_CREATE",
      ...searchField,
      // formatter: function (cell) {
      //   var value = cell.getValue();
      //   value = value ? moment(value).format("DD/MM/YYYY hh:mm:ss A") : "";
      //   return value;
      // },
    },
    {
      title: "Modified Time",
      field: "FAO_DT_PIECE_UPD",
      ...searchField,
      formatter: function (cell) {
        var value = cell.getValue();
        var dateValue = value
          ? moment(value).format("MM/DD/YYYY hh:mm:ss A")
          : null;
        value = dateValue;
        return value;
      },
    },
    { title: "User", field: "FAO_ID_OPERATOR", ...searchField },
  ];

  React.useEffect(() => {
    if (delay?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: delay,
          columns: dataCol,
          height: 340,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [delay]);

  const showSaveInfo = async (cell: any, newToken = true) => {
    setLoading(true);
    console.log("selectedProc: ", selectedProc);
    if (selectedProc === "" || selectedProc === null) {
      alertify.error("Select Process!");
      setLoading(false);
      return;
    }
    GetAuthorization().then((token: TokenType) => {
      const cellData: any = cell._cell.row.data;

      SPO0008UpdData(token, {
        remarks: cellData.FAO_REMARKS,
        reason: cellData.FAO_CD_OUTAGE,
        stDate: cellData.FAO_TM_STOP_ST,
        outageDt: cellData.OUTAGE_DT,
        p_line: selectedProc,
        eqpMast: cellData.FAO_CD_EQP_MAST,
        faqMast: cellData.FAO_CD_FAC_MAST,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            alertify.success("Data Updated Successfully");
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
    // if (newToken) {
    //   const rsp = await getAuthorization();
    // }
    // var defaultOptions = {
    //   headers: {
    //     Authorization: "Bearer " + localStorage.getItem("tcm_accessToken"),
    //   },
    // };
    // setLoading(true);

    // var url = "api/c1fps008/save-data";
    // const cellData = cell._cell.row.data;
    // axiosAPI
    //   .post(
    //     url,
    //     {
    //       remarks: cellData.FAO_REMARKS,
    //       reason: cellData.FAO_CD_OUTAGE,
    //       stDate: cellData.FAO_TM_STOP_ST,
    //       outageDt: cellData.OUTAGE_DT,
    //       p_line: filter.selectBy,
    //       eqpMast: cellData.FAO_CD_EQP_MAST,
    //       faqMast: cellData.FAO_CD_FAC_MAST,
    //     },
    //     defaultOptions
    //   )
    //   .then(({ data: { reasonData, updRsn }, status }) => {
    //     alertify.success("Data Updated Successfully");
    //   })

    //   .finally(() => {
    //     setLoading(false);
    //   });
  };

  const showUpdateInfo = async (cell: any) => {
    setModalData(cell._cell.row.data);
    setShowModal(true);
  };

  const getSearchData = () => {
    setLoading(true);
    if (selectedProc === "" || selectedProc === null) {
      alertify.error("Select Process!");
      setLoading(false);
      return;
    }
    GetAuthorization().then((token: TokenType) => {
      let data = {
        ...filter,
        dateFrom: start.format("DD-MMM-YYYY"),
        dateTo: end.format("DD-MMM-YYYY"),
        troubleType: selectedTroubleType,
        process: selectedProc,
      };
      SPO0008GetData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data: ", res.data);
            const {
              delayData,
              eqpData,
              facData,
              totalDelay,
              totalRows,
              workHrs,
              spnMttr,
              milUtility,
              spnMtbf,
              reasonData,
              eqpCodeData,
              agencyList,
            } = res.data;

            // Now you can use the destructured variables
            setDelayInHrs(Number(totalDelay).toFixed(2));
            setNoOfDelay(totalRows);
            setWorkingHrs(workHrs);
            setMttr(spnMttr);
            setMilUtil(Number(milUtility).toFixed(2));
            setMtbf(Number(spnMtbf).toFixed(2));

            // Uncomment and use these if needed
            setDelay(delayData);
            setEquip(eqpData);
            setFac(facData);

            // Example of how to handle reasonData and eqpCodeData
            const reasonItems = reasonData.map((row: any) => {
              const [value] = row.split("-");
              return { label: row, value };
            });
            setReason(reasonItems);

            const eqpCodeItems = eqpCodeData.map((row: any) => {
              const [value] = row.split("-");
              return { label: row, value };
            });
            seteqpCode(eqpCodeItems);

            setAgcCode(agencyList ?? []);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setSelectedProc("");
    setSelectedStatus("");
    setBatch("");
    setTableData("");
    handleClearDelayData();
    setState1({ start: moment(), end: moment() });
    // setInputObj(varInput);
  };

  const handleClearDelayData = () => {
    setDelay([]);
    setNoOfDelay("");
    setDelayInHrs("");
    setWorkingHrs("");
    setMilUtil("");
    setMttr("");
    setMtbf("");
  };

  const handleCallbackCplDtRange = (start, end) => {
    setState1({ start, end });
    handleClearDelayData();
  };

  // const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2.5} style={{ flexWrap: "wrap" }}>
                      {" "}
                      {/* Added flexWrap for responsiveness */}
                      <Grid item xs={12} sm={6} md={2}>
                        {" "}
                        {/* Adjust xs, sm, md as needed */}
                        <SelectInput
                          label="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            fetchEpaData(e);
                            setTableData("");
                            handleClearDelayData();
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <SelectInput
                          label="Process"
                          data={process}
                          value={selectedProc}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProc(e);
                            setTableData("");
                            handleClearDelayData();
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2.5}>
                        <label>Date Range</label>
                        <DateRangePicker
                          initialSettings={{
                            startDate: start.toDate(),
                            endDate: end.toDate(),
                            showDropdowns: true,
                            ranges: {
                              Today: [moment().toDate(), moment().toDate()],
                              Yesterday: [
                                moment().subtract(1, "days").toDate(),
                                moment().subtract(1, "days").toDate(),
                              ],
                              "Last 7 Days": [
                                moment().subtract(6, "days").toDate(),
                                moment().toDate(),
                              ],
                              "Last 30 Days": [
                                moment().subtract(29, "days").toDate(),
                                moment().toDate(),
                              ],
                              "This Month": [
                                moment().startOf("month").toDate(),
                                moment().endOf("month").toDate(),
                              ],
                              "Last Month": [
                                moment()
                                  .subtract(1, "month")
                                  .startOf("month")
                                  .toDate(),
                                moment()
                                  .subtract(1, "month")
                                  .endOf("month")
                                  .toDate(),
                              ],
                              "All Time": [
                                moment().subtract(20, "years"),
                                moment(),
                              ],
                            },
                          }}
                          onCallback={handleCallbackCplDtRange}
                        >
                          <div
                            id="reportrange"
                            className="col-4"
                            style={{
                              background: "#fff",
                              cursor: "pointer",
                              padding: "0px 10px",
                              border: "1px solid #ccc",
                              width: "100%",
                            }}
                          >
                            <i className="fa fa-calendar"></i>&nbsp;
                            <span>{label}</span>
                          </div>
                        </DateRangePicker>
                      </Grid>
                      <Grid item xs={12} sm={6} md={1.5}>
                        <SelectInput
                          label="Shift"
                          data={Shift}
                          value={filter?.selectShift}
                          size={"small"}
                          onChange={(e: string) => {
                            setFilter({ ...filter, selectShift: e });
                            handleClearDelayData();
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <SelectInput
                          label="Trouble Type*"
                          data={troubleType}
                          value={selectedTroubleType}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedTroubleType(e);
                            handleClearDelayData();
                          }}
                        />
                      </Grid>
                      {/* <Grid item xs={12} sm={6} md={2}>
                        <label>Trouble Desc</label>
                        <br />
                        <ButtonElement>
                          {troubleDesc?.value ?? "Choose"}
                        </ButtonElement>
                      </Grid> */}
                      {/* <Grid item xs={12} sm={6} md={2}>
                        <SelectInput
                          label="Trouble Type*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            fetchEpaData(e);
                            setTableData("");
                          }}
                        />
                      </Grid> */}
                      <Grid item xs={12} sm={6} md={1}>
                        <ButtonElement
                          onClick={() => {
                            getSearchData();
                          }}
                        >
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>

                <Grid margin={"1rem"}></Grid>

                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2.5} style={{ flexWrap: "wrap" }}>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="No Of Delays"
                          value={noOfDelay}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="Delay in Hrs"
                          value={DelayInHrs}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="Working Hrs"
                          value={workingHrs}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="Mill Utility"
                          value={milUtil}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="MTTR"
                          value={mttr}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={6} md={2}>
                        <Input
                          label="MTBF"
                          value={mtbf}
                          size={"small"}
                          readOnly={true}
                          onChange={(e: string) => {
                            // setSelectedPlant(e);
                            // fetchEpaData(e);
                            // setTableData("");
                          }}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {delay?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <Typography
                          variant="body2"
                          color="black"
                          style={{ paddingLeft: "1rem", marginTop: "-1rem" }}
                        >
                          {/* Showing 1 to {delay?.length} of {delay?.length}{" "}
                          entries */}
                        </Typography>
                      </Grid>
                    </Grid>
                  )}
                </Box>

                {/* <ReactTabulator
                  ref={(ref: any) => {
                    dataTableRef = ref;
                  }}
                  columns={dataCol}
                  data={delay}
                  options={optionsAuto}
                />
                <p
                  color="black"
                  style={{
                    color: "black",
                    paddingLeft: "1rem",
                  }}
                >
                  Showing 1 to {delay.length} of {delay.length} entries
                </p> */}

                {/* <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <Typography
                          variant="body2"
                          color="black"
                          style={{ paddingLeft: "1rem", marginTop: "-1rem" }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </Typography>
                      </Grid>
                    </Grid>
                  )}
                </Box> */}
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>

        {showModal && (
          <SaveModel
            closeModal={setShowModal}
            refreshTable={getSearchData}
            data={modalData}
            // selectData={setSaveSelectData}
            filterData={filter}
          />
        )}
      </Auth>
    </DashboardLayout>
  );
};

export default SPO0008;
