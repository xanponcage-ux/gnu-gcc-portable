import { Router } from "express";
import {
  SCQ001Api,
  SCQ001GetFilterData,
  SCQ001GetData,
  SCQ001SaveData,
  SCQ001DiversionRes,
} from "../controllers/SCQ001Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SCQ001Route = Router();

SCQ001Route.route("/SCQ001/SCQ001GetFilterDataApi").post(
  authenticationMiddleware.bearer,
  SCQ001GetFilterData
);
SCQ001Route.route("/SCQ001/SCQ001GetDataApi").post(
  authenticationMiddleware.bearer,
  SCQ001GetData
);
SCQ001Route.route("/SCQ001/SCQ001SaveDataApi").post(
  authenticationMiddleware.bearer,
  SCQ001SaveData
);
SCQ001Route.route("/SCQ001/SCQ001Api").post(
  authenticationMiddleware.bearer,
  SCQ001Api
);
SCQ001Route.route("/SCQ001/SCQ001DiversionRes").post(
  authenticationMiddleware.bearer,
  SCQ001DiversionRes
);
export default SCQ001Route;
