import { Router } from "express";
import {
  // getPlantData,
  getYieldData,
} from "../controllers/SPC0009Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0009Route = Router();

// SPC0009Route.route("/SPC0009/getPlantData").get(
//   authenticationMiddleware.bearer,
//   getPlantData
// );

SPC0009Route.route("/SPC0009/getYieldData").post(
  authenticationMiddleware.bearer,
  getYieldData
);
export default SPC0009Route;
