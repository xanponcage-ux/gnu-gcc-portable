import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getTableData = async (data: any) => {
  try {
    if (data.type === "tableData") {
      if (data.plant) {
        let sql = `SELECT 
        (SELECT SUBSTR(F_GET_FGBATCH('${data?.mBatch}',TO_DATE('${data?.prodDtTo}', 'DD-MM-YYYY HH24:MI:SS') ,'E',1),3,13)  
                FROM DUAL) Batch_id,
                c.pdc_cd_epa, c.pdc_id_coil, c.pdc_curr_proc, c.pdc_order,
       c.pdc_item_no, c.pdc_tdc, c.pdc_thick, c.pdc_width, c.pdc_length, c.pdc_cut_length,
       c.pdc_pdi, 
       c.pdc_idia, c.pdc_odia,
       c.pdc_oil_type, c.PDC_PACK_CODE,
       TO_CHAR (c.pdc_sch_crt_dt, 'DD-MM-YYYY HH24:MI:SS') pdc_sch_crt_dt,
       c.pdc_sch_crt_by, c.pdc_cd_status, 
       c.pdc_nxt_proc, c.pdc_planned_proc, c.pdc_cast_no,
       c.pdc_cd_status, C.PDC_SCH_WT,
       p.eom_cd_prod prod_cd, p.eom_cd_qlty_actl qlty_cd,
       p.eom_no_pieces
  FROM v_pr_data_ip_ctl c JOIN v_epa_prodn p ON c.pdc_id_coil = p.eom_id_batch
 WHERE c.pdc_cd_epa = '131' AND c.pdc_curr_proc = 'E'
       AND c.pdc_cd_status = 'WS'`;

        if (data?.mBatch && data?.mBatch?.length > 0) {
          sql += ` and pdc_id_coil like nvl('${data.mBatch}',pdc_id_coil)`;
        }

        // if (
        //   data?.prodDtFrom &&
        //   data?.prodDtFrom?.length !== ""
        //   //   data.prodDtTo &&
        //   //   data.prodDtTo?.length !== null
        // ) {
        //   if (data?.prodDtTo == "") {
        //     console.log("---->", data.prodDateTo);
        //     data.prodDtTo = data.prodDtFrom;
        //   }
        //   console.log("++++>", data.prodDtTo);
        //   sql += `AND c.pdc_sch_crt_dt BETWEEN TO_DATE('${data.prodDtFrom}', 'DD-MM-YYYY HH24:MI:SS')
        //                     AND TO_DATE('${data.prodDtTo}', 'DD-MM-YYYY HH24:MI:SS')`;
        // }
        console.log("sql: ", sql);
        return await query(sql);
      }
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getMBatchList = async () => {
  try {
    //     const QryMCoilList = `SELECT   pdc_id_coil,
    //          TO_CHAR (pdc_sch_crt_dt, 'DD-MM-YYYY HH24:MI:SS') AS pdc_sch_crt_dt
    //     FROM v_pr_data_ip_ctl
    //    WHERE pdc_curr_proc = 'E'
    // ORDER BY pdc_sch_crt_dt DESC  `;

    const QryMCoilList = `SELECT pdc_id_coil,
             TO_CHAR (pdc_sch_crt_dt, 'DD-MM-YYYY HH24:MI:SS') AS pdc_sch_crt_dt
        FROM v_epa_prodn, v_pr_data_ip_ctl
       WHERE eom_cd_status = 'EC'
         AND pdc_curr_proc = 'E'
         AND pdc_cd_status = 'WS'
         AND pdc_id_coil = eom_id_batch
    ORDER BY pdc_sch_crt_dt DESC `;

    return await query(QryMCoilList);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerError(JSON.stringify(error));
  }
};

// export const saveDataTemp = async (data: any) => {
//   try {
//     let countY = 0;
//     let len = data?.length;

//     let dtQry: any = `SELECT F_TATADATE(TO_DATE('${data[0]?.ST_PRODN}','DD-MM-YYYY HH24:MI:SS')) AS shiftDate FROM DUAL`;

//     let result = await query(dtQry);
//     // console.log("dtQry: ", dtQry);
//     // console.log("result: ", result);
//     var dtRes = await ResponceData(result);
//     console.log("dtRes: ", dtRes);

//     const shift = dtRes[0]?.SHIFTDATE?.substr(0, 1);
//     const prodnDt = dtRes[0]?.SHIFTDATE?.substr(1, 11);

//     let dltQry: any = `DELETE FROM V_PRODUCTION_TEMP
//             WHERE TPT_CD_EPA ='${data[0]?.P_PLANT}'
//             AND TPT_ID_FIRST_PAR = '${data[0]?.P_MCOIL}'  --- MOTHER BATCH ID'`;

//     await query(dltQry);

//     for (let i = 0; i < len; i++) {
//       let qry1: any = `call TOPRB002(
//         P_PLANT   => : P_PLANT,
//         P_BATCHID   => :P_BATCHID ,
//         P_MCOIL   => :P_MCOIL ,
//         P_PROC   => :P_PROC ,
//         CUSTORD   => :CUSTORD ,
//         CUSTITM   => :CUSTITM ,
//         NXTPROC   => :NXTPROC ,
//         PROD   => :PROD ,
//         QLTY   => :QLTY ,
//         THICK   => :THICK ,
//         WIDTH   => :WIDTH ,
//         P_LENGTH   => :P_LENGTH ,
//         PIECE_ACTL   => :PIECE_ACTL ,
//         GROSS_ACTL   => :GROSS_ACTL ,
//         P_NO_PCS   => :P_NO_PCS ,
//         TDC   => :TDC ,
//         USRID   => :USRID ,
//         IDIA   => :IDIA ,
//         ODIA   => :ODIA ,
//         SHIFT   => :SHIFT ,
//         PLANNED_PROC   => :PLANNED_PROC ,
//         OPR_CMNT   => :OPR_CMNT ,
//         ST_PRODN   => :ST_PRODN ,
//         P_SCRAP_WT   => :P_SCRAP_WT ,
//         P_CAST_NO   => :P_CAST_NO ,
//         P_STATUS   => :P_STATUS ,
//         LS_OUT_FLAG   => :LS_OUT_FLAG
//         )`;

//       const binds = {
//         P_PLANT: data[i]?.P_PLANT ? data[i]?.P_PLANT : "",
//         P_BATCHID: data[i]?.P_BATCHID ? data[i]?.P_BATCHID : "",
//         P_MCOIL: data[i]?.P_MCOIL ? data[i]?.P_MCOIL : "",
//         P_PROC: data[i]?.P_PROC ? data[i]?.P_PROC : "",
//         CUSTORD: data[i]?.CUSTORD ?? "",
//         CUSTITM: data[i]?.CUSTITM ?? "",
//         NXTPROC: data[i]?.NXTPROC ? data[i]?.NXTPROC : "",
//         PROD: data[i]?.PROD ? data[i]?.PROD : "",
//         QLTY: data[i]?.QLTY ? data[i]?.QLTY : "",
//         THICK: data[i]?.THICK ?? "",
//         WIDTH: data[i]?.WIDTH ?? "",
//         P_LENGTH: data[i]?.P_LENGTH ?? "",
//         PIECE_ACTL: data[i]?.PIECE_ACTL ? data[i]?.PIECE_ACTL : "",
//         GROSS_ACTL: data[i]?.GROSS_ACTL ? data[i]?.GROSS_ACTL : "",
//         P_NO_PCS: data[i]?.P_NO_PCS ?? "",
//         TDC: data[i]?.TDC ? data[i]?.TDC : "",
//         USRID: data[i]?.USRID ? data[i]?.USRID : "",
//         IDIA: data[i]?.IDIA ?? "",
//         ODIA: data[i]?.ODIA ?? "",
//         SHIFT: shift,
//         PLANNED_PROC: data[i]?.PLANNED_PROC ? data[i]?.PLANNED_PROC : "",
//         OPR_CMNT: data[i]?.OPR_CMNT ? data[i]?.OPR_CMNT : "",
//         ST_PRODN: prodnDt,
//         P_SCRAP_WT: 0,
//         P_CAST_NO: data[i]?.P_CAST_NO ? data[i]?.P_CAST_NO : "",
//         P_STATUS: data[i]?.P_STATUS ? data[i]?.P_STATUS : "",
//         P_PAGE_ID: "SPO0004",
//         LS_OUT_FLAG: {
//           type: oracledb.STRING,
//           dir: oracledb.BIND_OUT,
//           maxSize: 500,
//         },
//       };

//       const result1 = await query(qry1, binds);

//       if (result1?.outBinds?.LS_OUT_FLAG?.substr(0, 1) === "Y") {
//         countY += 1;
//       }
//     }

//     if (countY === len) {
//       let qry2 = `call TOPRB003(
//       p_plant   => :p_plant,
//       p_mother_batch   => :p_mother_batch,
//       p_user   => :p_user,
//       ls_out_flag   => :ls_out_flag
//       )`;

//       const binds = {
//         p_plant: data[0]?.P_PLANT ? data[0]?.P_PLANT : "",
//         p_mother_batch: data[0]?.P_MCOIL ? data[0]?.P_MCOIL : "",
//         p_user: data[0]?.USRID ? data[0]?.USRID : "",
//         ls_out_flag: {
//           type: oracledb.STRING,
//           dir: oracledb.BIND_OUT,
//           maxSize: 500,
//         },
//       };

//       const result = await query(qry2, binds);
//       return result;
//     }
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };

export const saveDataTemp = async (data: any) => {
  try {
    let countY = 0;
    let len = data?.length;

    for (let i = 0; i < len; i++) {
      let qry1: any = `
          Insert into V_SEG_DAUTR_COIL
       (SEG_ID_SOR_APPL, SEG_ID_DESTN_APPL, SEG_ID_MESSAGE, SEG_RESERVED_1, SEG_RESERVED_2,
        SEG_ID_BATCH, SEG_ID_PDI, SEG_BATCH_START, SEG_BATCH_END, SEG_ID_COIL,
        SEG_CUT_LENGTH, SEG_THICK, SEG_WIDTH, SEG_LENGTH, SEG_PACK_NET_WT,
        SEG_REMARKS, SEG_ORDER, SEG_ITEM_NO, SEG_FG_TDC, SEG_GRADE_DESC,
        SEG_PACK_CODE, SEG_CURR_PROC, SEG_NXT_PROC, SEG_PLANNED_PROC, SEG_REC_CRT_DT,
        SEG_REC_CRT_BY, SEG_PROD_ACT_PIECE)
     Values
       ('SPIN', 'SPIN', f_nannow_second_telgrm(SYSDATE), 'N', 'N',
        '${data[i]?.batchId}', ${data[i]?.idPdi}, TO_DATE('${data[i]?.prodDtStart}', 'DD/MM/YYYY HH24:MI:SS'), TO_DATE('${data[i]?.prodDtEnd}', 'DD/MM/YYYY HH24:MI:SS'), '${data[i]?.mBatch}',
        ${data[i]?.length}, ${data[i]?.thick}, ${data[i]?.width}, ${data[i]?.length}, ${data[i]?.netWt},
        '${data[i]?.remarks}', '${data[i]?.order}', ${data[i]?.item}, '${data[i]?.tdc}', '${data[i]?.gradeDesc}',
        '${data[i]?.packCd}', '${data[i]?.currProc}', '${data[i].nextProc}', '${data[i]?.planProc}', sysdate,
        '${data[i]?.user}', '${data[i]?.noPcs}')`;
      console.log(`${i}: `, qry1);
      await query(qry1);
    }

    let qryChkCount: any = `SELECT count(1) as count FROM V_SEG_DAUTR_COIL where seg_id_coil = '${data[0]?.mBatch}' 
        and SEG_RESERVED_1 = 'N'
        and SEG_ID_BATCH != 'SCRAP'`;

    let result = await ResponceData(await query(qryChkCount));

    countY = result[0]?.COUNT;
    const finLength = len - 1;

    if (countY === finLength) {
      let qry: any = `call tbkb0031 (
         ls_id_coil  => :ls_id_coil,         
         ls_out_flag  => :ls_out_flag  
      )`;

      const binds = {
        ls_id_coil: data[0]?.mBatch ? data[0]?.mBatch : "",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      const result = await query(qry, binds);
      return result;
    } else {
      let upQry: any = `UPDATE V_SEG_DAUTR_COIL SET SEG_RESERVED_1 = 'E' WHERE SEG_ID_COIL = '${data[0]?.mBatch}'`;
      await query(upQry);
      console.log("OOPPSSS");
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getMotherTableData = async (data: any) => {
  try {
    let sql = `select PDC_THICK, PDC_WIDTH, PDC_LENGTH, PDC_TDC, PDC_CAST_NO, PDC_CUT_LENGTH,
    PDC_PLAN_WT, PDC_SCH_WT FROM V_PR_DATA_IP_CTL  WHERE PDC_ID_COIL = '${data?.mBatch}'`;

    console.log("sql: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};
