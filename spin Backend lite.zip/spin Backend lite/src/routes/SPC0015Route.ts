import { Router } from "express";
import { SPC0015getData } from "../controllers/SPC0015Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0015Route = Router();

SPC0015Route.route("/SPC0015/getData").post(
  authenticationMiddleware.bearer,
  SPC0015getData
);

export default SPC0015Route;