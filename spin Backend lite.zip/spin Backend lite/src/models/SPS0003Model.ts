import * as repo from "../repository/SPS0003Query";

export default class SPS0025Model {
  getBatchData(data: any) {
    return repo.getBatchData(data);
  }
  callPkgProc(data: any) {
    return repo.callPkgProc(data);
  }
}
