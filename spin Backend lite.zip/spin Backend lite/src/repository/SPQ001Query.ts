import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData01 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code,
    };

    let sql: any = `SELECT chr_cd_epa, chr_cd_process, TO_CHAR (chr_ts_hold, 'DD-MM-YYYY HH24:MI:SS') as chr_ts_hold, chr_cd_rsn_hold,
       (select CD_DESC from V_EPA_HOLD_RSN where CD_HOLD = chr_cd_rsn_hold) rsn_hold_desc,
       chr_id_op_hold, chr_id_op_release, chr_remarks, TO_CHAR (chr_ts_release, 'DD-MM-YYYY HH24:MI:SS') as chr_ts_release,
       chr_id_coil, chr_cd_prev_status, TO_CHAR (chr_ts_create_db, 'DD-MM-YYYY HH24:MI:SS') as chr_ts_create_db, TO_CHAR (chr_ts_update_db, 'DD-MM-YYYY HH24:MI:SS') as chr_ts_update_db,
       TO_CHAR (chr_dt_piece_upd, 'DD-MM-YYYY HH24:MI:SS') as chr_dt_piece_upd, chr_archival_ind, chr_cd_fnl_decsn, chr_hold_wt,
       chr_rls_wt, chr_opr_remarks, chr_rls_remarks, chr_rls_remarks1
  FROM v_coil_hold_rls
 WHERE chr_cd_epa =  :code `;

    if (data.process && data.process?.length > 0) {
      sql += ` AND CHR_CD_PROCESS = :process`;
      binds["process"] = data?.process;
    }

    if (data?.batchId && data?.batchId?.length > 0) {
      sql += ` AND chr_id_coil = :batchId`;
      binds["batchId"] = data?.batchId;
    }

    if (data?.holdDtFrom && data?.holdDtTo) {
      sql += ` AND TRUNC(chr_ts_hold) BETWEEN TO_DATE('${data?.holdDtFrom}', 'DD-MON-YYYY') AND TO_DATE('${data?.holdDtTo}', 'DD-MON-YYYY')  `;
    } else if (data?.holdDtFrom) {
      sql += ` AND TRUNC(chr_ts_hold) >= TO_DATE('${data?.holdDtFrom}', 'DD-MON-YYYY')`;
    } else if (data?.holdDtTo) {
      sql += ` AND TRUNC(chr_ts_hold) <= TO_DATE('${data?.holdDtTo}', 'DD-MON-YYYY')`;
    }

    if (data?.rlsDtFrom && data?.rlsDtTo) {
      sql += ` AND TRUNC(chr_ts_release) BETWEEN TO_DATE('${data?.rlsDtFrom}', 'DD-MON-YYYY') AND TO_DATE('${data?.rlsDtTo}', 'DD-MON-YYYY')  `;
    } else if (data?.rlsDtFrom) {
      sql += ` AND TRUNC(chr_ts_release) >= TO_DATE('${data?.rlsDtFrom}', 'DD-MON-YYYY')`;
    } else if (data?.rlsDtTo) {
      sql += ` AND TRUNC(chr_ts_hold) <= TO_DATE('${data?.rlsDtTo}', 'DD-MON-YYYY')`;
    }
    console.log("sql: ", sql);
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
