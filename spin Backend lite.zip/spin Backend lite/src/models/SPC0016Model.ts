import { getData, getStatusData } from "../repository/SPC0016Query";

export default class SPC0016Model {
  async getData(data: any) {
    return getData(data);
  }
  async getStatusData(data: any) {
    return getStatusData(data);
  }
}
