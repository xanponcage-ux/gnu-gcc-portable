import { Router } from "express";
import { getData01 } from "../controllers/SPQ001Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPQ001Route = Router();

SPQ001Route.route("/SPQ001/getData").post(
  authenticationMiddleware.bearer,
  getData01
);

export default SPQ001Route;
