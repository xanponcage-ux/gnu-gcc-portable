import {
  getCastDetails,
  getCoilDetails,
  getFittingDetails,
} from "../repository/SPC0013Query";

export default class SPC0013Model {
  getCastDetails(data: any) {
    return getCastDetails(data);
  }

  getCoilDetails(data: any) {
    return getCoilDetails(data);
  }

  getFittingDetails(data: any) {
    return getFittingDetails(data);
  }
}
