import * as React from "react";
import AxiosApi from "src/apiConfig/axiosAPI";
import SERVER from "src/constant/serverConnection";
import env from "src/constant/env";
import Loader from "src/components/preloader";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import MuiLink from "@mui/material/Link";
import PasswordIcon from "@mui/icons-material/Password";
import LockOpenIcon from "@mui/icons-material/LockOpen";
import { Input, RadioInput, SelectInput } from "src/components/input";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
// import MDBox from "components/MDBox";
// import MDTypography from "components/MDTypography";
// import MDButton from "components/MDButton";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Grid from "@mui/material/Grid";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import CloseIcon from "@mui/icons-material/Close";
import TataIcon from "src/assets/images/Tata_White.png";
import PowerSettingsNewIcon from "@mui/icons-material/PowerSettingsNew";
import TurnSlightRight from "@mui/icons-material/TurnSlightRight";

import { NavbarProps, RouteProps, RouteNestedProps } from "../type";
import { authRoutes } from "src/routes";
import { useNavigate } from "react-router-dom";
import { useTheme } from "@mui/material/styles";
import { useMaterialUIController, setTheme, setUser } from "src/context";
import { UISwitch, UIAccordion, UIBox } from "./style";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {
  AccordionDetails,
  AccordionSummary,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { csTheme } from "src/theme/type";
import { AuthCheck, LogoutApi } from "src/apiConfig/insideAuthApi";
import {
  DateFormat,
  GetAuthorization,
  getFromStorage,
  openInNewTab,
} from "src/utils";
import { TokenType } from "src/type";
import alertify from "src/components/alert";
import InsertLinkIcon from "@mui/icons-material/InsertLink";

function Navbar(props: NavbarProps) {
  const csTheme: csTheme = useTheme();
  const navigate = useNavigate();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);
  const [anchorElNav, setAnchorElNav] = React.useState<Boolean>(true);
  const [loader, setLoader] = React.useState(true);
  const [isAuth, setIsAuth] = React.useState(false);
  const [pageName, setPageName] = React.useState("");
  const [open, setOpen] = React.useState<boolean>(false);
  const [oldPassword, setOldPassword] = React.useState<any>("");
  const [newPassword, setNewPassword] = React.useState<any>("");
  const [confirmPassword, setConfirmPassword] = React.useState<any>("");
  const [anchorElUser, setAnchorElUser] = React.useState<
    Array<null> | Array<HTMLElement>
  >([]);
  const [weak, setWeak] = React.useState<string>("");
  const handleOpenNavMenu = () => {
    setAnchorElNav(true);
  };

  const regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[#$!%*?&])[A-Za-z\d#$!%*?&]{8,}$/;

  const handleOpenUserMenu = (
    event: React.MouseEvent<HTMLElement>,
    i: number
  ) => {
    const varAnch: Array<null> | Array<HTMLElement> = { ...anchorElUser };
    varAnch[i] = event.currentTarget;
    setAnchorElUser(varAnch);
  };

  const PwordChangeFunc = () => {
    setOpen(true);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(false);
  };

  const handleCloseUserMenu = (i: number, path?: string) => {
    const varAnch: Array<null> | Array<HTMLElement> = { ...anchorElUser };
    varAnch[i] = null;
    setAnchorElUser(varAnch);
    if (path) {
      navigate(path);
    }
  };

  const logout = () => {
    GetAuthorization().then((token: TokenType) => {
      LogoutApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            sessionStorage.clear();
            localStorage.clear();
            if (res?.data?.message) {
              alertify.success(res?.data?.message);
            }
            setUser(dispatch, {
              user: "",
              token: {
                accessToken: "",
                refreshToken: "",
              },
            });
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
          sessionStorage.clear();
          setUser(dispatch, {
            user: "",
            token: {
              accessToken: "",
              refreshToken: "",
            },
          });
        });
    });
  };

  const MenuUi = (
    routeObj: Array<RouteProps>,
    anc: Array<null> | Array<HTMLElement>,
    ancIndex: number,
    closeMenu: Function,
    openMenu: Function,
    cRoute: string
  ) => {
    return (
      <Menu
        sx={{
          mt: "45px",
          "& .MuiMenu-paper": {
            width: "350px",
            ul: {
              padding: 0,
            },
          },
        }}
        id={`menu-appbar-${ancIndex}`}
        anchorEl={anc[ancIndex]}
        anchorOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        keepMounted
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        // open={Boolean(anc[ancIndex])}
        // onClose={(e) => closeMenu(ancIndex)}
      >
        {routeObj?.map((y, j) => sideMenuList(y, [y?.path], cRoute, false))}
      </Menu>
    );
  };

  const pushInArray = (array: Array<string>, path: string) => {
    const varPath = [...array];
    if (path?.length > 0) {
      varPath.push(path);
    }
    return varPath;
  };

  // const getStyle = (label) => {
  //   if (label === "Dashboard") {
  //       return { backgroundColor: "#f5a623", color: "#ffffff" };
  //   }
  //   if (label === "Planning and Scheduling") {
  //     return { backgroundColor: "#dc5354", color: "#ffffff" };
  //   }
  //   if (label === "Operation") {
  //     return { backgroundColor: "#198754", color: "#ffffff" };
  //   }
  //   if (label === "Quality Management") {
  //     return { backgroundColor: "#423A8e", color: "#ffffff" };
  //   }
  //   if (label === "Gate Entry") {
  //     return { backgroundColor: "#fd3995", color: "#ffffff" };
  //   }
  //   if (label === "Dispatch") {
  //     return { backgroundColor: "#00cccd", color: "#ffffff" };
  //   }
  //   if (label === "Report") {
  //     return { backgroundColor: "#9fcc2e", color: "#ffffff" };
  //   }
  //   if (label === "Common") {
  //     return { backgroundColor: "#ab47bc", color: "#ffffff" };
  //   }
  //   if (label === "Maintain Master") {
  //     return { backgroundColor: "#D8BFD8", color: "#ffffff" };
  //   }
  //   return {};
  //   };

  const sideMenuList = (
    x: RouteNestedProps,
    path: Array<string>,
    menu: boolean | string,
    defaultExpanded: boolean
  ) => (
    x?.label &&
      x?.path &&
      window.location.hash.lastIndexOf(x.path) + x.path.length ===
        window.location.hash.length &&
      x.label !== pageName &&
      ((document.title = "SPIN - " + x.label), setPageName(x.label)),
    (
      <div style={{ position: "relative" }} key={x.path}>
        <UIAccordion
          key={x.label}
          className={anchorElNav || menu ? "open" : "close"}
          defaultExpanded={defaultExpanded}
        >
          <AccordionSummary
            // style={{
            //     backgroundColor: "red",
            //     color:"#ffffff"
            // }
            //}
            //style={getStyle(x.label)}
            expandIcon={
              x.children && x.path && (anchorElNav || menu) ? (
                <ExpandMoreIcon />
              ) : null
            }
            aria-controls="panel-content"
            id={x?.label}
            onClick={() => {
              if (!x.children && x.path) {
                navigate(x.path);
              }
            }}
          >
            {x?.icon ? (
              <ListItemIcon
                sx={{ width: anchorElNav || menu ? "auto" : "100%" }}
              >
                {x.icon}
              </ListItemIcon>
            ) : null}
            {anchorElNav || menu ? (
              <Typography sx={{ display: "flex", fontSize: "12px" }}>
                {x?.label}
              </Typography>
            ) : null}
          </AccordionSummary>
          {x?.children ? (
            <AccordionDetails sx={{ paddingLeft: menu ? "1px" : "inherit" }}>
              {x?.children?.map((y: RouteNestedProps, i: number) =>
                y?.children ? (
                  <React.Fragment key={i}>
                    {sideMenuList(
                      y,
                      pushInArray(path, y?.path ? y?.path : ""),
                      menu,
                      defaultExpanded &&
                        window.location.hash?.indexOf(
                          y?.label?.substring(0, y?.label?.indexOf(" ")) ?? ""
                        ) > 1
                    )}
                  </React.Fragment>
                ) : (
                  <ListItem
                    key={i}
                    disablePadding
                    style={{
                      backgroundColor: "LightSteelBlue",
                      //,color: "#dc5354"
                    }}
                  >
                    <ListItemButton
                      onClick={() => {
                        if (!y.children && y.path) {
                          if (typeof menu === "string" && menu?.length > 0) {
                            navigate(
                              path
                                ? pushInArray(
                                    [menu].concat([...path]),
                                    y?.path
                                  ).join("/")
                                : y.path
                            );
                          } else {
                            navigate(
                              path
                                ? pushInArray(path, y?.path).join("/")
                                : y.path
                            );
                          }
                        }
                      }}
                    >
                      {y?.icon ? (
                        <ListItemIcon
                          sx={{
                            width: anchorElNav || menu ? "auto" : "100%",
                          }}
                        >
                          {y.icon}
                        </ListItemIcon>
                      ) : null}
                      {anchorElNav || menu ? (
                        //   <ListItemText
                        //     sx={{
                        //       width: anchorElNav || menu ? "auto" : "100%",
                        //     }}
                        //     primary={y?.label}
                        //   />
                        // ) : null}
                        <Typography
                          sx={{
                            display: "flex",
                            fontSize: "11px",
                            fontFamily: "Verdana",
                          }}
                        >
                          {y?.label}
                        </Typography>
                      ) : null}
                    </ListItemButton>
                    {!y.children && y.path && anchorElNav && (
                      <span
                        style={{
                          position: "absolute",
                          top: "50%",
                          right: "10px",
                          transform: "translateY(-45%)",
                          padding: "2px",
                          cursor: "pointer",
                        }}
                        onClick={() => {
                          if (!y.children && y.path) {
                            if (typeof menu === "string" && menu?.length > 0) {
                              openInNewTab(
                                path
                                  ? pushInArray(
                                      [menu].concat([...path]),
                                      y?.path
                                    ).join("/")
                                  : y.path
                              );
                            } else {
                              openInNewTab(
                                path && !path.includes(y?.path)
                                  ? pushInArray(path, y?.path).join("/")
                                  : y.path
                              );
                            }
                          }
                        }}
                      >
                        <TurnSlightRight fontSize="small" />
                      </span>
                    )}
                  </ListItem>
                )
              )}
            </AccordionDetails>
          ) : null}
        </UIAccordion>
        {!x.children && x.path && anchorElNav && (
          <span
            style={{
              position: "absolute",
              top: "50%",
              right: "20px",
              transform: "translateY(-45%)",
              padding: "10px",
              cursor: "pointer",
            }}
            onClick={() => {
              if (!x.children && x.path) {
                if (typeof menu === "string" && menu?.length > 0) {
                  openInNewTab(
                    path
                      ? pushInArray([menu].concat([...path]), x?.path).join("/")
                      : x.path
                  );
                } else {
                  openInNewTab(
                    path && !path.includes(x?.path)
                      ? pushInArray(path, x?.path).join("/")
                      : x.path
                  );
                }
              }
            }}
          >
            {/* <TurnSlightRight fontSize="large" /> */}
          </span>
        )}
      </div>
    )
  );

  const getWeek = async () => {
    setWeak(await getFromStorage("weak"));
  };

  React.useEffect(() => {
    getWeek();
    const page = window.location.hash.substring(
      window.location.hash?.lastIndexOf("/") + 1,
      window.location.hash?.length
    );
    setIsAuth(true);
    setLoader(false);
    // GetAuthorization().then((token) => {
    //   AuthCheck(token, { page: page })
    //     .then((res) => {
    //       if (res.statusText !== "" && res.statusText !== "OK") {
    //         alertify.error(res?.data?.err ? res.data.err : res?.toString());
    //       } else if (
    //         res.data?.LS_OUT_ERR_FLAG &&
    //         res.data?.LS_OUT_ERR_FLAG !== "Y"
    //       ) {
    //         alertify.success(`Permission Type: ${res?.data?.LS_OUT_ROLE}`);
    //         setIsAuth(true);
    //       } else {
    //         alertify.error(
    //           res?.data?.LS_OUT_MSG_FLAG
    //             ? res?.data?.LS_OUT_MSG_FLAG
    //             : res.data?.LS_OUT_MSG_FLAG?.toString()
    //         );
    //       }
    //     })
    //     .catch((e) => {
    //       setIsAuth(false);
    //       alertify.error(e?.error?.message ? e.error.message : e?.toString());
    //     })
    //     .finally(() => {
    //       setLoader(false);
    //     });
    // });
  }, []);

  const handleChange = () => {
    //setOpen(false);
    //e.preventDefault();
    var old = oldPassword;
    var newP = newPassword;
    var conP = confirmPassword;
    var OldPassword = old.replaceAll(" ", "");
    var NewPassword = newP.replaceAll(" ", "");
    var ConfirmPassword = conP.replaceAll(" ", "");
    if (
      !OldPassword ||
      !NewPassword ||
      !ConfirmPassword ||
      OldPassword.length == 0 ||
      NewPassword.length == 0 ||
      ConfirmPassword == 0
    ) {
      alertify.error("Please provide Old,New,Confirm Password ");
      return;
    }
    if (confirmPassword !== newPassword) {
      alertify.error("Password does not match. Enter same password");
      setNewPassword("");
      setConfirmPassword("");
      return;
    }
    if (!regex.test(newPassword)) {
      alertify.error("New Password doesn't meet required constraints");
      setNewPassword("");
      setConfirmPassword("");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token) => {
      var defaultOptions = {
        headers: {
          Authorization: "Bearer " + token.accessToken,
        },
      };

      var url = SERVER[env.server].baseURL + "api/users/changePassword";

      var data = {
        user: user,
        newpass: NewPassword,
        oldpass: OldPassword,
      };
      AxiosApi.post(url, data, defaultOptions)
        .then((response: any) => {
          if (response.statusText != "" && response.statusText != "OK") {
          } else {
            if (response.data) {
              if (response.data.changed === 0) {
                if (response.data.offset === "ORA-28003") {
                  alertify.error(
                    "Password verification for specified password failed"
                  );
                  return;
                } else if (response.data.offset === "ORA-20006") {
                  alertify.error(
                    "Password should contain at least one digit, one character and one punctuation"
                  );
                } else if (response.data.offset === "ORA-28007") {
                  alertify.error("Error: the password cannot be reused");
                } else if (response.data.offset === "ORA-28008") {
                  alertify.error("Invalid old password");
                }
                setOldPassword("");
                setNewPassword("");
                setConfirmPassword("");
              } else if (response.data.changed === 1) {
                alertify.success(
                  "Password changed successfully, please login again"
                );
                sessionStorage.clear();
                localStorage.clear();
                setUser(dispatch, {
                  user: "",
                  token: {
                    accessToken: "",
                    refreshToken: "",
                  },
                });
                //history("/signin");
              }
            } else {
              alertify.error("Invalid Request !!!");
            }
          }
        })
        .catch((error: any) => {
          console.log("error nav bar", error);
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleRedirect = () => {
    window.open("https://tslapps.tatasteel.co.in/EPAMOBTSK/", "_blank");
  };

  return (
    <Box>
      <AppBar
        position="static"
        sx={{ backgroundColor: csTheme?.palette.primary.main }}
      >
        <Container maxWidth="small">
          <Toolbar disableGutters style={{ minHeight: "40px", height: "10px" }}>
            <img
              src={TataIcon}
              alt="logo"
              style={{ marginLeft: "-10px", maxWidth: "40px", display: "flex" }}
            />
            <Box
              sx={
                anchorElNav
                  ? {
                      display: {
                        xs: "flex",
                        md: "flex",
                        marginLeft: "210px",
                        minHeight: "18px",
                      },
                    }
                  : {
                      display: {
                        xs: "flex",
                        md: "flex",
                        marginLeft: "11px",
                        minHeight: "18px",
                      },
                    }
              }
            >
              {anchorElNav ? (
                <IconButton
                  size="small"
                  onClick={handleCloseNavMenu}
                  color="inherit"
                >
                  <MenuIcon />{" "}
                </IconButton>
              ) : (
                <IconButton
                  size="small"
                  onClick={handleOpenNavMenu}
                  color="inherit"
                >
                  <MenuIcon />
                </IconButton>
              )}
            </Box>
            <Box
              sx={{
                flexGrow: 1,
                display: { xs: "none", md: "flex", marginLeft: "10px" },
              }}
            >
              {authRoutes?.map((x: RouteNestedProps, i) =>
                x.label &&
                x?.label !== "hide" &&
                x.path &&
                window.location.hash.includes(x.path) ? (
                  <React.Fragment key={i}>
                    <Box sx={{ flexGrow: 0 }}>
                      <Button
                        key={i}
                        onMouseEnter={(e) => handleOpenUserMenu(e, i + 1)}
                        sx={{ color: "white", display: "block" }}
                        // onClick={() => (x?.path ? navigate(x.path) : null)}
                      >
                        {x.label + "  =>  " + pageName}
                      </Button>
                      {x?.children
                        ? MenuUi(
                            x?.children,
                            anchorElUser,
                            i + 1,
                            handleCloseUserMenu,
                            handleOpenUserMenu,
                            x.path
                          )
                        : null}
                    </Box>
                  </React.Fragment>
                ) : null
              )}
            </Box>

            <Grid item>
              <Tooltip title="Yield Approval System">
                <IconButton onClick={handleRedirect}>
                  <InsertLinkIcon sx={{ color: "#ffffff" }} />
                </IconButton>
              </Tooltip>
            </Grid>

            <Box sx={{ mr: 2 }}>
              <Typography
                sx={{
                  textAlign: "center",
                  width: "100%",
                  color: csTheme.palette.background.default,
                  ml: 1,
                }}
              >
                {DateFormat(new Date()?.toString(), true)}
              </Typography>
            </Box>
            <Box sx={{ mr: 4 }}>
              <Typography
                sx={{
                  textAlign: "center",
                  width: "100%",
                  color: csTheme.palette.background.default,
                  ml: 1,
                }}
              >
                {weak}
              </Typography>
            </Box>
            <Box sx={{ flexGrow: 0 }}>
              {/* <Tooltip title={theme === "light" ? "Dark Theme" : "Light Theme"}>
                <IconButton
                  onClick={(e) =>
                    setTheme(dispatch, theme === "light" ? "dark" : "light")
                  }
                >
                  <UISwitch checked={theme === "light"} />
                </IconButton>
              </Tooltip> */}
              <Tooltip title="user">
                <IconButton
                  // onClick={(e) => handleOpenUserMenu(e, 0)}
                  sx={{ p: 0 }}
                >
                  <Avatar
                    alt="Remy Sharp"
                    src={`https://intranet.corp.tatasteel.com/GIH001.ashx?pf=YY&cid=${user}`}
                  />
                  <Typography
                    sx={{
                      textAlign: "center",
                      width: "100%",
                      color: csTheme.palette.background.default,
                      ml: 1,
                    }}
                  >
                    {user}
                  </Typography>
                </IconButton>
              </Tooltip>
              <>
                {/* <MuiLink
              style={{ cursor: "pointer" }}
              onClick={PwordChangeFunc}
              variant="button"
              color="secondary"
            >
              <MDBox
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                <PasswordIcon color="primary" />
                <MDTypography
                  fontWeight="regular"
                  fontSize="small"
                  textTransform="capitalize"
                  variant="h6"
                  color={"dark"}
                  noWrap
                  style={{ marginLeft: "0.1rem" }}
                >
                  Change Password
                </MDTypography>
                </MDBox>
                </MuiLink>  */}
                <Tooltip title="Change Password">
                  <IconButton onClick={(e) => setOpen(true)} sx={{ p: 0 }}>
                    <LockOpenIcon sx={{ color: "#ffffff", ml: 1 }} />
                  </IconButton>
                </Tooltip>
              </>
              <IconButton onClick={logout}>
                <PowerSettingsNewIcon
                  style={{
                    color: csTheme.palette.background.default,
                    marginLeft: 10,
                  }}
                />
              </IconButton>
              {/* <Menu
                sx={{ mt: "45px", transformOrigin: 0 }}
                id="menu-appbar"
                anchorEl={anchorElUser[0]}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser[0])}
                onClose={(e) => handleCloseUserMenu(0)}
              >
                <MenuItem>
                  <Typography sx={{ textAlign: "center", width: "100%" }}>
                    {user}
                  </Typography>
                </MenuItem>
                <MenuItem onClick={logout}>
                  <PowerSettingsNewIcon />
                  <Typography textAlign="center" sx={{ ml: 1 }}>
                    Logout
                  </Typography>
                </MenuItem>
              </Menu> */}
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <Grid container spacing={0}>
        <Dialog
          // style={{
          //   paddingLeft: "150px",
          //   paddingBottom: "40px",
          //   width: "1000px",
          // }}
          sx={{ ".MuiPaper-root": { backgroundColor: "white" } }}
          open={open}
          maxWidth="md"
          fullWidth={true}
          //PaperComponent={PaperComponent}
          onClose={() => setOpen(false)}
          aria-labelledby="draggable-dialog-title"
        >
          <DialogTitle
            style={{ cursor: "move", fontWeight: "bold" }}
            id="alert-dialog-title"
          >
            Reset Password
          </DialogTitle>
          <DialogContent sx={{ backgroundColor: "white" }}>
            <Grid item xs={12}>
              {loading ? <Loader /> : null}
            </Grid>
            <Typography sx={{ alignContent: "center", mt: "10px" }}>
              Password should differ by at least 3 characters. Select a password
              which has is atleast 8 characters long and contains atleast one
              alphabet, one numeric digit and one special character (#$!%*?&)
            </Typography>
            <br />
            <Grid
              container
              spacing={0}
              sx={{
                backgroundColor: "white",
                gap: 3,
              }}
            >
              <Grid item xs={6}>
                <Input
                  style={{ margin: "dense" }}
                  id="oldPass"
                  value={oldPassword}
                  sideLabel="Old Password"
                  type="password"
                  onChange={(e: any) => {
                    setOldPassword(e);
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <Input
                  id="newPass"
                  sideLabel="New Password"
                  value={newPassword}
                  type="password"
                  onChange={(e: any) => {
                    setNewPassword(e);
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <Input
                  id="confirmPass"
                  sideLabel="Confirm Password"
                  value={confirmPassword}
                  type="password"
                  onChange={(e: any) => {
                    setConfirmPassword(e);
                  }}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ backgroundColor: "white" }}>
            <Button
              variant="contained"
              onClick={() => setOpen(false)}
              color="primary"
            >
              close
            </Button>
            <Button
              onClick={(e: any) => {
                handleChange();
              }}
              color="primary"
              variant="contained"
            >
              ok
            </Button>
          </DialogActions>
        </Dialog>
        <Grid item xs={12}>
          <div style={{ display: "flex" }}>
            <div
              className="rScroll"
              style={{
                width: anchorElNav ? "380px" : "100px",
                backgroundColor: csTheme?.palette.primary.main,
                height: "calc(120vh - 41px)",
                overflow: "hidden",
                overflowY: "scroll",
              }}
            >
              <UIBox sx={{ width: "100%" }} role="presentation">
                <List sx={{ pt: 0 }}>
                  {authRoutes?.map((x: RouteNestedProps, i) =>
                    x?.label && x?.label !== "hide" && x?.path ? (
                      <React.Fragment key={i}>
                        {sideMenuList(
                          x,
                          [x?.path],
                          false,
                          window.location.hash?.indexOf(
                            x?.label?.substring(
                              0,
                              x?.label?.indexOf(" ") > 0
                                ? x?.label?.indexOf(" ")
                                : x?.label?.length
                            )
                          ) > 1
                        )}
                      </React.Fragment>
                    ) : null
                  )}
                </List>
              </UIBox>
            </div>
            <div
              className="rScroll"
              style={{
                height: "calc(120vh - 41px)",
                overflow: "hidden",
                overflowY: "scroll",
                width: "100%",
                backgroundColor: csTheme?.palette.background.default,
              }}
            >
              {loader ? <Loader /> : null}
              {isAuth ? (
                props.children
              ) : (
                <h3
                  style={{
                    color: csTheme?.palette.text.error,
                    textAlign: "center",
                  }}
                >
                  Page is not Authorised!
                </h3>
              )}
            </div>
          </div>
        </Grid>
      </Grid>
    </Box>
  );
}
export default Navbar;
