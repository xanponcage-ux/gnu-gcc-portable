import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

// export const getPlantData = async () => {
//   try {
//     return getCommonPlantData();
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

export const getYieldData = async (data: any) => {
  try {
    let binds: any = {
      plantCD: data?.plant,
    };
    let sql: any = `SELECT TO_CHAR(TYT_CRT_DT, 'YYYY-MM') YEAR_MONTH,       TYT_ID_REQ APPROVAL_NO,       TO_CHAR(TYT_CRT_DT, 'DD-MON-YYYY') APPROVAL_RAISED_ON,   
                    TYT_CD_EPA PLANT,       TYT_ID_BATCH MC_BATCH,       EIC_SEC1 MC_THK,       EIC_SEC2 MC_WIDTH,   
                    EIC_TDC_ACTL MC_TDC,       ROUND(EIC_MS_GROSS_CAL,2) MC_QTY,       (SELECT listagg(BATCH_SIZE, ', ')
                    WITHIN GROUP (ORDER BY 1) B_SIZE from (SELECT to_char(ENC_SEC1_MAX || 'X' || ENC_SEC2_MAX) BATCH_SIZE 
                    FROM V_YIELD_DTLS A, V_END_CUST_ORD_EPA B         WHERE SUBSTR(A.TYD_ID_REQ, 1, 4) = B.ENC_CD_ePA 
                    AND A.TYD_ID_ORDER = B.ENC_ID_ORDER           AND A.TYD_NO_ITEM = B.ENC_NO_ITEM        
                    AND A.TYD_ID_REQ = tyt_id_req)) FG_SIZE,       ROUND(TYT_SCH_QTY,2) FG_TONN_PLAN,       TYT_REQ_TYP,   
                    ROUND(TYT_CAL_YIELD,2) TYT_CAL_YIELD,       ROUND(TYT_ACP_YIELD,2) TYT_ACP_YIELD,   
                    TYT_REQ_STATUS APPROVAL_TYPE,       (SELECT listagg(MARK_CUST_NAME, ', ') WITHIN GROUP (ORDER BY 1)
                    MARK_CUST_NAME from (SELECT distinct TO_cHAR(ENC_MARK_CUST_NAME) MARK_CUST_NAME      
                    FROM V_EPA_PRODN C, V_END_CUST_ORD_EPA D         WHERE C.EOM_CD_EPA = D.ENC_CD_EPA     
                    AND C.EOM_ID_ORDER_CUS = D.ENC_ID_ORDER           AND C.EOM_ID_ORD_ITEM_CUS = D.ENC_NO_ITEM     
                    AND EOM_CD_EPA = A.TYT_CD_EPA           AND EOM_ID_FIRST_PAR = A.TYT_ID_BATCH      
                    AND ENC_NO_TDC NOT IN               ((SELECT DISTINCT ESP_TDC_DOWNGRADE          
                    FROM V_EPA_SECONDS_PRIME_TDC                  WHERE ESP_CD_EPA = C.EOM_CD_EPA)))) FG_CUSTOMER,
                    ROUND(((100 - TYT_CAL_YIELD) / 100) * TYT_SCH_QTY,2) OFFCUT_TONN,   
                    ROUND((TYT_ACP_YIELD - TYT_CAL_YIELD),2) YIELD_LOSS,    
                    (SELECT (ROUND((SUM(TCY_PLNGDEF_SEC_WT) / NULLIF(SUM(TCY_ISSUEPROD_WT),0)) * 100, 2))          FROM V_COIL_YIELD  
                    WHERE TCY_BATCH_ID = A.TYT_ID_BATCH           AND TCY_CD_EPA = A.TYT_CD_ePA) ACTUAL_LOSS,  
                    (SELECT TYA_CRT_ID || ' - ' || TYA_RSN_DESC          FROM V_YIELD_APPROVAL_ACT     
                    WHERE TYA_ID_REQ = A.TYT_ID_REQ           AND TYA_REQ_STATUS IN ('AA', 'RT', 'RJ')    
                    AND TYA_CRT_DATE IN               (SELECT MAX(TYA_CRT_DATE)                  FROM V_YIELD_APPROVAL_ACT    
                    WHERE TYA_ID_REQ = A.TYT_ID_REQ                   AND TYA_REQ_STATUS IN ('AA', 'RT', 'RJ'))) SPC_MANAGER_REM,  
                    (SELECT TYA_CRT_ID || ' - ' || TYA_RSN_DESC          FROM V_YIELD_APPROVAL_ACT         WHERE TYA_ID_REQ = A.TYT_ID_REQ    
                    AND TYA_REQ_STATUS IN ('AP', 'AT')           AND TYA_CRT_DATE IN               (SELECT MAX(TYA_CRT_DATE)     
                    FROM V_YIELD_APPROVAL_ACT                 WHERE TYA_ID_REQ = A.TYT_ID_REQ        
                    AND TYA_REQ_STATUS IN ('AP', 'AT'))) APPROVING_AUTH_REM,       (SELECT TO_CHAR(TYA_CRT_DATE, 'DD-MON-YYYY')   
                    FROM V_YIELD_APPROVAL_ACT         WHERE TYA_ID_REQ = A.TYT_ID_REQ           AND TYA_REQ_STATUS IN ('AP', 'AT')     
                    AND TYA_CRT_DATE IN               (SELECT MAX(TYA_CRT_DATE)                  FROM V_YIELD_APPROVAL_ACT       
                    WHERE TYA_ID_REQ = A.TYT_ID_REQ                   AND TYA_REQ_STATUS IN ('AP', 'AT'))) APPROVING_AUTH_APP_DT 
                    FROM V_YIELD_APPROVAL_TRANS A, V_INPUT_COIL B WHERE A.TYT_CD_EPA = B.EIC_CD_EPA   AND A.TYT_ID_BATCH = B.EIC_ID_COIL
                    AND TYT_CD_EPA=NVL(:plantCD,TYT_CD_EPA) 
                    --AND tyt_id_req = NVL(:reqID,tyt_id_req) 
                    AND TYT_ACT_STATUS IN ('A','I') `;

    if (data?.dateFr && data?.dateTo) {
      sql += `AND TRUNC (a.tyt_crt_dt) BETWEEN TO_DATE (:frmdt, 'DD-MON-YY') AND TO_DATE (:todt, 'DD-MON-YY')`;
      binds.frmdt = data?.dateFr;
      binds.todt = data?.dateTo;
    }
    sql += `ORDER BY TYT_CD_EPA,TYT_CRT_DT`;
    // console.log("---->", sql);
    return await query(sql, binds);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error);
  }
};
