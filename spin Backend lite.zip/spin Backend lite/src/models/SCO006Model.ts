const SCO006Query = require("../repository/SCO006Query");
import {
  getFetchData,
  SCO006getBatchInformation,
  SCO006GetPopUpData,
  SCO006SaveData,
  getProcess,
  SCO006SaveForm,
  getScrapData,
} from "../repository/SCO006Query";

export default class SCO006Model {
  SCO006Model(data: any) {
    if (data?.route === "SCO006getfetchData") {
      return getFetchData(data);
    } else if (data?.route === "SCO0006getBatchInformation") {
      return SCO006getBatchInformation(data);
    } else if (data?.route === "getPopupData") {
      return SCO006GetPopUpData(data);
    } else if (data?.route === "saveData") {
      return SCO006SaveData(data);
    } else if (data?.route === "saveForm") {
      return SCO006SaveForm(data);
    } else if (data?.route === "getProcess") {
      return getProcess(data);
    } else if (data?.route === "getScrapData") {
      return getScrapData(data);
    }
  }
}
