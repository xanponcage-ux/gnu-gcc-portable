import { Router } from "express";
import { getData, getStatusData } from "../controllers/SPC0014Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0014Route = Router();

SPC0014Route.route("/SPC0014/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPC0014Route.route("/SPC0014/getStatusData").get(
  authenticationMiddleware.bearer,
  getStatusData
);

export default SPC0014Route;
