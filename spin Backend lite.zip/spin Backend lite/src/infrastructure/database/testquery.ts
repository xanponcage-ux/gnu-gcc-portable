import oracledb from "oracledb";
import { getValue } from "express-ctx";

const getConnection = async () => {
  var connection = await oracledb.getConnection();
  return connection;
};

const testExecuteQuery = (query: string, parameters = {}) => {
  return new Promise<any>(async (resolve, reject) => {
    let adid = getValue("userad");
    let conn = await oracledb.getConnection(
      {
        user: getValue("userad"),
        password: getValue("userps"),
        connectString: getValue("userdb"),
      },
      function (err: any, conn: any) {
        try {
          conn.execute(query, parameters, (errors: any, results: any) => {
            if (errors) {
              reject(errors);
            } else {
              resolve(results);
            }
          });
        } catch {
          (error: any) => {
            console.log(error, "error block ran");
          };
        } finally {
          if (err) {
            reject(err);
          }
        }
      }
    );
  });
};

export default testExecuteQuery;
