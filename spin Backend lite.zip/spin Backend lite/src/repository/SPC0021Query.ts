import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";

export const getData = async (data: any) => {
  try {
    let binds: any = {};
    let sql: any = `SELECT   TIMESTAMP timedt, werks plant, lgort LOCATION, charg fg_batch,
         matnr fg_material, fg_qty net_wt, moth_batch parent_batch,
         moth_matnr parent_material, status status, error_cd err_remarks,
         l_sco_no, l_sco_item_no, passed_proc, pack_cd, oil_type,
         sco_order sco_order, sco_item sco_item, budat budat, pcode fg_pcode,
         qcode fg_qcode, sec1 fg_thk, sec2 fg_width, LENGTH fg_length,
         no_pcs no_of_pcs, cast_no cast_no, idia, odia, tdcno fg_tdc,
         scrp_matnr, cust_order, cust_item, source_plant, stage_cd,
         action_cd rec_type, pi_status, ack_timestamp pi_ack_time,
         final_timestamp final_time, pi_source_pgm, prc1, prc2, prc3, prc4, prc5,
         prc6, prc7, prc8, prc9, prc10
         FROM ymsdt_sco_grn
         WHERE mandt = '600' 
         AND STATUS NOT IN ('X', 'L')`;

    if (data.batchId && data.batchId?.length > 0) {
      sql += ` and charg='${data?.batchId}'`;
    }
    if (data.motherBatch && data.motherBatch?.length > 0) {
      sql += ` and moth_batch='${data?.motherBatch}'`;
    }
    if (data.action_cd && data.action_cd?.length > 0) {
      sql += ` and action_cd='${data?.action_cd}'`;
      // action_cd = 'S' --'I'      -- FG , S= SCRAP , REVERSAL -R
    }
    if (data.status && data.status?.length > 0) {
      sql += ` and status='${data?.status}'`;
    }

    // if (data?.dateFrom && data?.dateTo) {
    //   sql += `and TO_DATE(SUBSTR(timestamp, 1, 10), 'YYYY-MM-DD')
    //   BETWEEN TO_DATE('${data?.dateFrom}', 'YYYY-MM-DD') AND TO_DATE('${data?.dateTo}', 'YYYY-MM-DD')  `;
    //   binds.dateFrom = data?.dateFrom;
    //   binds.dateTo = data?.dateTo;
    // }

    sql += ` ORDER BY TIMESTAMP desc, moth_batch `;
    console.log("sql: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getStatusData = async (data: any) => {
  try {
    let sql: any = ` SELECT DISTINCT STATUS FROM YMSDT_SCO_GRN WHERE STATUS NOT IN ('X', 'L') `;

    // console.log("sql: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getScDwnData = async (data: any) => {
  try {
    // console.log("wdwdw");
    let binds: any = {};

    let sql: any = ` select distinct EBS_ID_BATCH BATCH_ID, EBS_MS_SCRAP SCRAP_WT
                        ,EBS_CD_RSN_SCRAP RSN_CODE,ESR_RSN_DESC RSN_DESC,ESR_RSN_CAT RSN_CAT,EBS_ID_PARENT_BATCH PARENT_BATCH,EBS_FIRST_PAR COIL_ID
                        ,EOM_SEC1 COIL_THK
                        ,EOM_SEC2 COIL_WIDTH
                        ,EOM_TDC_ACTL COIL_TDC
                        , EBS_ID_OP_SCRAP SCRAPPED_BY
                        ,to_char(EBS_DT_SCRAP,'DD-MM-YYYY HH24:MI:SS')  EBS_DT_SCRAP,DECODE(EBS_REC_STATUS,'Y','Posted To Sap','Not Posted to SAP') Posting_Status
                        from v_epa_batch_scrap , V_SCRP_SEC_RSN ,V_EPA_PRODN
                        where  TRIM(EBS_CD_RSN_SCRAP) = ESR_RSN_CD
                        AND EBS_CD_ePA = EOM_CD_ePA
                        AND EBS_FIRST_PAR = EOM_ID_BATCH
                        --AND TRUNC(EBS_DT_SCRAP) >= '${data?.prodDtFrm}' AND  TRUNC(EBS_DT_SCRAP)  <= '${data?.prodDtTo}'
                        `;

    if (data.plant && data.plant?.length > 0) {
      sql += ` and EBS_CD_ePA='${data?.plant}'`;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` and EBS_ID_BATCH='${data?.batchId}'`;
    }
    if (data.motherBatch && data.motherBatch?.length > 0) {
      sql += ` and EBS_FIRST_PAR='${data?.motherBatch}'`;
    }
    if (data.action_cd && data.action_cd?.length > 0) {
      sql += ` and ebs_ind='${data?.action_cd}'`;
      // A -- Scrap, B -- Downgrade
    }

    if (data?.prodDtFrm && data?.prodDtTo) {
      sql += `and TRUNC(EBS_DT_SCRAP)
                BETWEEN TO_DATE('${data?.prodDtFrm}', 'YYYY-MM-DD') AND TO_DATE('${data?.prodDtTo}', 'YYYY-MM-DD')  `;
    } else if (data?.prodDtFrm) {
      sql += ` and TRUNC(EBS_DT_SCRAP)
                    >= TO_DATE('${data?.prodDtFrm}', 'YYYY-MM-DD') `;
    } else if (data?.prodDtTo) {
      sql += ` and TRUNC(EBS_DT_SCRAP)
                    <= TO_DATE('${data?.prodDtTo}', 'YYYY-MM-DD') `;
    }

    sql += `ORDER BY EBS_FIRST_PAR,EBS_DT_SCRAP `;

    console.log("sql", sql);

    const res = await query(sql);

    if (!res || res.length === 0) {
      return { message: "No Data Found!" };
    }

    return res;
  } catch (error: any) {
    console.log(error);

    throw new Error.InternalServerErrorMsg(error);
  }
};
