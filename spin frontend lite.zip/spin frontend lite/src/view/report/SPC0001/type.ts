import { dateInput, input } from "../../type";

export interface InputChangeType {
    key1: input,
    key2: input,
    key3: input,
    key4: input,
    key5: input,
    key6: input,
    key7: input,
    key8: input,
    key9: input,
    key10: input,
    key11: input,   
}
export interface TableType {
    EGP_CD_EPA: string;
    ENC_ID_ORDER: string;
    ENC_CD_END_CUST: string;
    ENC_ORDER_TYPE: string;
    ENC_ST_ORDER: string;
}