/** 
  All of the routes for the Material Kit 2 React React are added here,
  You can add a new route, customize the routes and delete the routes here.

  Once you add a new route on this file it will be visible automatically on
  the Navbar.

  For adding a new route you can follow the existing routes in the routes array.
  1. The `name` key is used for the name of the route on the Navbar.
  2. The `icon` key is used for the icon of the route on the Navbar.
  3. The `collapse` key is used for making a collapsible item on the Navbar that contains other routes
  inside (nested routes), you need to pass the nested routes inside an array as a value for the `collapse` key.
  4. The `route` key is used to store the route location which is used for the react router.
  5. The `href` key is used to store the external links location.
  6. The `component` key is used to store the component of its route.
  7. The `dropdown` key is used to define that the item should open a dropdown for its collapse items .
  8. The `description` key is used to define the description of
          a route under its name.
  9. The `columns` key is used to define that how the content should look inside the dropdown menu as columns,
          you can set the columns amount based on this key.
  10. The `rowsPerColumn` key is used to define that how many rows should be in a column.
*/
import React from "react";
import { Navigate, RouterProvider, createHashRouter } from "react-router-dom";

// Pages
import LoginScreen from "./view/auth";

// icon list
import HomeIcon from "@mui/icons-material/Home";
import EmojiObjects from "@mui/icons-material/EmojiObjects";
import SettingsInputCompositeIcon from "@mui/icons-material/SettingsInputComposite";
import Equalizer from "@mui/icons-material/Equalizer";
import EmojiTransportationIcon from "@mui/icons-material/EmojiTransportation";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import routes from "./constant/route";
import { Typography } from "@mui/material";
import { useMaterialUIController, setUser } from "./context";
import { getFromStorage } from "./utils";
// import pages from Pickling line

// REPORTS
const R_SPC0001 = React.lazy(() => import("./view/report/SPC0001"));
const R_SPC0007 = React.lazy(() => import("./view/report/SPC0007"));
const R_SPC0008 = React.lazy(() => import("./view/report/SPC0008"));
const R_SPC0009 = React.lazy(() => import("./view/report/SPC0009"));
const R_SPC0010 = React.lazy(() => import("./view/report/SPC0010"));
const R_SPC0011 = React.lazy(() => import("./view/report/SPC0011"));
const R_SPC0012 = React.lazy(() => import("./view/report/SPC0012"));
const R_SPC0014 = React.lazy(() => import("./view/report/SPC0014"));
const R_SPC0016 = React.lazy(() => import("./view/report/SPC0016"));
const R_SPC0017 = React.lazy(() => import("./view/report/SPC0017"));
const R_SPS0020 = React.lazy(() => import("./view/report/SPS0020"));
const R_SPC0021 = React.lazy(() => import("./view/report/SPC0021"));
const R_SPS0025 = React.lazy(() => import("./view/report/SPS0025"));

//PLANNING
const P_SPS0004 = React.lazy(() => import("./view/planning/SPS0004"));
const P_SPS0005 = React.lazy(() => import("./view/planning/SPS0005"));
const P_SPS0010 = React.lazy(() => import("./view/planning/SPS0010"));
const P_SPS0015 = React.lazy(() => import("./view/planning/SPS0015"));
const P_SPS0003 = React.lazy(() => import("./view/planning/SPS0003"));

//QUALITY
const Q_SPQ001 = React.lazy(() => import("./view/quality/SPQ001"));
const Q_SCQ001 = React.lazy(() => import("./view/quality/SCQ001"));
const Q_SCQ002 = React.lazy(() => import("./view/quality/SCQ002"));

//OPERATION
const O_SPO0001 = React.lazy(() => import("./view/operation/SPO0001"));
const O_SPO0003 = React.lazy(() => import("./view/operation/SPO0003"));
const O_SPO0004 = React.lazy(() => import("./view/operation/SPO0004"));
const O_SPO0005 = React.lazy(() => import("./view/operation/SPO0005"));
const O_SPO0006 = React.lazy(() => import("./view/operation/SCO0006"));
const O_SPO0007 = React.lazy(() => import("./view/operation/SPO0007"));
const O_SPO0008 = React.lazy(() => import("./view/operation/SPO0008"));

//MAINTAIN MASTER
const M_SPC0002 = React.lazy(() => import("./view/maintainMasterData/SPC0002"));
const M_SPC0003 = React.lazy(() => import("./view/maintainMasterData/SPC0003"));
const M_SPC0004 = React.lazy(() => import("./view/maintainMasterData/SPC0004"));
const M_SPC0006 = React.lazy(() => import("./view/maintainMasterData/SPC0006"));
const M_SPC0015 = React.lazy(() => import("./view/maintainMasterData/SPC0015"));

//COMMON
const C_SPC0005 = React.lazy(() => import("./view/common/SPC0005"));
const C_SPC0013 = React.lazy(() => import("./view/common/SPC0013"));

const Dashboard = React.lazy(() => import("./view/dashboard"));
const G_SPCG001 = React.lazy(() => import("./view/gateEntry/SPCG001"));
const O_SPO0002 = React.lazy(() => import("./view/dispatch/SPO0002"));

const Query_Pg = React.lazy(() => import("./view/common/QueryPage/queryPg"));

const noOuthRoutes = [
  {
    path: routes.login,
    element: <LoginScreen />,
    // loader: ,
    icon: <HomeIcon />,
  },
  {
    path: "*",
    element: <Navigate to={routes.login} replace />,
  },
];

export const authRoutes = [
  {
    path: routes.login,
    element: <LoginScreen />,
    // loader: ,
  },
  //DASHBOARD
  {
    path: routes.dashboard,
    label: "Dashboard",
    element: <Dashboard />,
    icon: (
      <HomeIcon
        sx={{
          m: "auto",
          color: "primary.main", // Use theme color
          transition: "transform 0.2s",
          "&:hover": {
            transform: "scale(1.5)", // Simple hover effect
          },
        }}
        aria-label="Dashboard"
      />
    ),
  },
  {
    path: routes.queryPage,
    label: "hide",
    element: <Query_Pg />,
    icon: (
      <HomeIcon
        sx={{
          m: "auto",
          color: "primary.main", // Use theme color
          transition: "transform 0.2s",
          "&:hover": {
            transform: "scale(1.5)", // Simple hover effect
          },
        }}
        aria-label="Dashboard"
      />
    ),
  },
  // PLANNING MODULE
  {
    path: routes.PlanningAndSchedSubModule,
    label: "Planning and Scheduling",
    //icon: <EmojiObjects sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}} />,
    icon: (
      <EmojiObjects
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.schedulingScreen,
        label: "RM Schedule Creation",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            P01
          </Typography>
        ),
        element: <P_SPS0005 />,
      },
      {
        path: routes.scheduleRejection,
        label: "RM Schedule Confirmation/Rejection",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            P02
          </Typography>
        ),
        element: <P_SPS0015 />,
      },
      {
        path: routes.indentCoil,
        label: "Indent Coil",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            P03
          </Typography>
        ),
        element: <P_SPS0010 />,
      },
      // WIP process currectly not required.
      {
        path: routes.WIPSchedullingScreen,
        label: "Linking/D Linking",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            P04
          </Typography>
        ),
        element: <P_SPS0004 />,
      },
      {
        path: routes.packingWIPScreen,
        label: "Packing WIP Schd",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            P05
          </Typography>
        ),
        element: <P_SPS0003 />,
      },
    ],
  },
  //OPERATION MODULE
  {
    path: routes.OperationSubModule,
    label: "Operation",
    icon: (
      <SettingsInputCompositeIcon
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.ProductionReport,
        label: "Production Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O01
          </Typography>
        ),
        element: <O_SPO0001 />,
      },
      {
        path: routes.PdiEnquiry,
        label: "PDI Enquiry",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O02
          </Typography>
        ),
        element: <R_SPC0011 />,
      },
      {
        path: routes.daugtherCoil,
        label: "Backup Screen",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O03
          </Typography>
        ),
        element: <O_SPO0003 />,
      },
      {
        path: routes.MannualRecording,
        label: "Mannual Recording",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O04
          </Typography>
        ),
        element: <O_SPO0004 />,
      },
      {
        path: routes.ProductionRejection,
        label: "PDI Deletion",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O05
          </Typography>
        ),
        element: <O_SPO0005 />,
      },
      {
        path: routes.ScrapScreen,
        label: "Scrap Posting",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O06
          </Typography>
        ),
        element: <O_SPO0006 />,
      },
      {
        path: routes.WipLabel,
        label: "WIP Label Generation",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O07
          </Typography>
        ),
        element: <O_SPO0007 />,
      },
      {
        path: routes.delayManagement,
        label: "Delay Management",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O08
          </Typography>
        ),
        element: <O_SPO0008 />,
      },

      // {
      //   path: routes.ConfirmPacking,
      //   label: "Confirm Packing",
      //   icon: <Typography sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}}>O02</Typography>,
      //   element: <O_SPO0002 />,
      // },

      // {
      //   path: routes.ProductionRejection,
      //   label: "PDI Rejection",
      //   icon: <Typography sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}}>O05</Typography>,
      //   element: <O_SPO0005 />,
      // },
    ],
  },
  // QUALITY MODULE
  {
    path: routes.QualitySubModule,
    label: "Quality Management",
    icon: (
      <Equalizer
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      // {
      //   path: routes.holdReport,
      //   label: "Hold/Rease Report",
      //   icon: <Typography sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}}>Q01</Typography>,
      //   element: <Q_SPQ001 />,
      // },
      {
        path: routes.defectlogging,
        label: "QM  Decision",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            Q02
          </Typography>
        ),
        element: <Q_SCQ001 />,
      },
      {
        path: routes.holdLog,
        label: "Hold Batch",
        element: <Q_SCQ002 />,
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            Q03
          </Typography>
        ),
      },
    ],
  },
  // {
  //   path: routes.GateEntrySubModule,
  //   label: "Gate Entry",
  //   icon: <EmojiTransportationIcon sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}} />,
  //   children: [
  //     {
  //       path: routes.RMInformation,
  //       label: "RM Information",
  //       icon: <Typography sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}}>G01</Typography>,
  //       element: <G_SPCG001 />,
  //     },
  //   ],
  // },

  //DISPATCH MODULE
  {
    path: routes.DispatchSubModule,
    label: "Dispatch",
    icon: (
      <LocalShippingIcon
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.ConfirmPacking,
        label: "Confirm Packing",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            O02
          </Typography>
        ),
        element: <O_SPO0002 />,
      },
    ],
  },
  //REPORT MODULE
  {
    path: routes.Report,
    label: "Report",
    icon: (
      <BusinessCenterIcon
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.InventoryInformation,
        label: "Inventory Information",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R01
          </Typography>
        ),
        element: <R_SPC0001 />,
      },
      {
        path: routes.orderBook,
        label: "Order Book",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R02
          </Typography>
        ),
        element: <R_SPC0007 />,
      },
      {
        path: routes.scoOrderBook,
        label: "SCO Order Book",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R03
          </Typography>
        ),
        element: <R_SPC0008 />,
      },
      {
        path: routes.yieldReport,
        label: "Yield Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R04
          </Typography>
        ),
        element: <R_SPS0020 />,
      },
      {
        path: routes.AuditReport,
        label: "Audit Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R05
          </Typography>
        ),
        element: <R_SPS0025 />,
      },
      {
        path: routes.dispatchReport,
        label: "Dispatch Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R06
          </Typography>
        ),
        element: <R_SPC0010 />,
      },
      {
        path: routes.YieldApprovalReport,
        label: "Yield Approval Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R07
          </Typography>
        ),
        element: <R_SPC0009 />,
      },
      // {
      //   path: routes.PdiEnquiry,
      //   label: "PDI Enquiry",
      //   icon: <Typography sx={{ m: "auto", color: "primary.main", transition: "transform 0.2s", '&:hover': { transform: 'scale(1.5)', }}}>R11</Typography>,
      //   element: <R_SPC0011 />,
      // },
      {
        path: routes.holdReport,
        label: "Hold/Release Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R08
          </Typography>
        ),
        element: <Q_SPQ001 />,
      },
      {
        path: routes.orderProgReport,
        label: "Order Progress Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R09
          </Typography>
        ),
        element: <R_SPC0012 />,
      },
      {
        path: routes.RMInformation,
        label: "Intransit Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R10
          </Typography>
        ),
        element: <G_SPCG001 />,
      },
      {
        path: routes.errorReport,
        label: "Error Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R11
          </Typography>
        ),
        element: <R_SPC0014 />,
      },
      {
        path: routes.Scrap_downgradeReasonReport,
        label: "Scrap/Downgrade Reason Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R14
          </Typography>
        ),
        element: <R_SPC0021 />,
      },

      {
        path: routes.reworkReport,
        label: "Rework/Replan Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R12
          </Typography>
        ),
        element: <R_SPC0016 />,
      },

      {
        path: routes.QaReport,
        label: "QA Report",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            R13
          </Typography>
        ),
        element: <R_SPC0017 />,
      },
    ],
  },
  //COMMON MODULE
  {
    path: routes.CommonSubModule,
    label: "Common",
    icon: (
      <BusinessCenterIcon
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.masterTdcSpecLine,
        label: "TDC Spec Limit",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            C01
          </Typography>
        ),
        element: <C_SPC0005 />,
      },
      {
        path: routes.testResultEnq,
        label: "Test Result Enquiry",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            C02
          </Typography>
        ),
        element: <C_SPC0013 />,
      },
    ],
  },
  //MAINTAIN MASTER
  {
    path: routes.MaintainMaster,
    label: "Maintain Master",
    icon: (
      <BusinessCenterIcon
        sx={{
          m: "auto",
          color: "primary.main",
          transition: "transform 0.2s",
          "&:hover": { transform: "scale(1.5)" },
        }}
      />
    ),
    children: [
      {
        path: routes.ProcessLine,
        label: "Process Line",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            M02
          </Typography>
        ),
        element: <M_SPC0002 />,
      },
      {
        path: routes.OilingScreen,
        label: "Oiling and Packing",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            M03
          </Typography>
        ),
        element: <M_SPC0003 />,
      },
      {
        path: routes.Yield_Approve_Master,
        label: "Yield Approver & Yield Master",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            M04
          </Typography>
        ),
        element: <M_SPC0004 />,
      },
      {
        path: routes.prodEnquiry,
        label: "Downgrade/Diverted Enquiry",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            M05
          </Typography>
        ),
        element: <M_SPC0006 />,
      },

      {
        path: routes.Subrange_Master,
        label: "Activity Details",
        icon: (
          <Typography
            sx={{
              m: "auto",
              color: "primary.main",
              transition: "transform 0.2s",
              "&:hover": { transform: "scale(1.5)" },
            }}
          >
            M06
          </Typography>
        ),
        element: <M_SPC0015 />,
      },
    ],
  },
  {
    path: "*",
    // element: <Navigate to={routes.dashboard} replace />,
    element: <Navigate to={routes.login} replace />,
  },
];

export const Routes = () => {
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;

  React.useEffect(() => {
    const fetchData = async () => {
      const token = await getFromStorage("token");
      const varUser: string = await getFromStorage("user");

      if (varUser && token.accessToken && token.refreshToken) {
        setUser(dispatch, {
          user: varUser,
          token: {
            accessToken: token.accessToken,
            refreshToken: token.refreshToken,
          },
        });
      } else {
        setUser(dispatch, {
          user: "",
          token: {
            accessToken: "",
            refreshToken: "",
          },
        });
        sessionStorage.clear();
      }
    };
    fetchData();
  }, []);

  // React.useEffect(() => {
  //   // @ts-ignore
  //   const initialValue = document.body.style.zoom;
  //   if (user?.length) {
  //     // @ts-ignore
  //     document.body.style.zoom = "100%";
  //   } else {
  //     // @ts-ignore
  //     document.body.style.zoom = "100%";
  //   }
  //   return () => {
  //     // Restore default value
  //     // @ts-ignore
  //     document.body.style.zoom = initialValue;
  //   };
  // }, [user]);

  return user !== null ? (
    <RouterProvider
      router={createHashRouter(
        user?.length > 0 ? [...authRoutes, ...noOuthRoutes] : noOuthRoutes
      )}
    />
  ) : (
    <Typography>Loading</Typography>
  );
};
