import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  GetPlantDataApi,
  SPC0012GetOrderDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0012 = () => {
  const csTheme: csTheme = useTheme();
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [order, setOrder] = React.useState<string>("");
  const [item, setItem] = React.useState<string>("");
  const [ordTable, setOrdTable] = React.useState<any>(null);
  const [ordTableData, setOrdTableData] = React.useState<any>([]);

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchOrdProgData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      order: order,
      item: item,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0012GetOrderDataApi(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            setOrdTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (ordTableData?.length > 0) {
      setOrdTable(
        new Tabulator("#table", {
          data: ordTableData,
          columns: ordCol,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setOrdTable(null);
    }
  }, [ordTableData]);

  const ordCol: Array<CulmnType> = [
    {
      title: "Order",
      field: "ENC_ID_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ENC_NO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Type",
      field: "ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "ENC_CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Idia",
      field: "ENC_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Qlty Cd",
      field: "ENC_CD_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "TDC",
      field: "ENC_NO_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Dispatch Wk",
      field: "DISP_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Ord Qty(mt)",
      field: "ORD_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Ord Tol",
      field: "ORD_TOL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "Ord Qty With Tolerance",
      field: "ORD_QTY_WITH_TOLERANCE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Dispatched",
      field: "DISPTCHED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Dispbl",
      field: "DISPBL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "FG Ready",
      field: "FG_READY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "WIP",
      field: "WIP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Hold",
      field: "HOLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "BTR",
      field: "BTR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Mat No",
      field: "ENC_NO_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Post Treatment",
      field: "ENC_POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ord Desc",
      field: "ORD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick min",
      field: "ENC_SEC1_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Thick max",
      field: "ENC_SEC1_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width min",
      field: "ENC_SEC2_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Max",
      field: "ENC_SEC2_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length Min",
      field: "ENC_LENGTH_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length Max",
      field: "ENC_LENGTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "Grade Cd",
      field: "ENC_CD_GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Ord Crt Dt",
      field: "ORD_CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "St Order",
      field: "ENC_ST_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Name",
      field: "ENC_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship to party",
      field: "SHIP_TO_PARTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Odia",
      field: "ENC_ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "Road Dest Desc",
      field: "ENC_ROADDEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail Dest Desc",
      field: "ENC_RAILDEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Last Download",
      field: "ORD_LAST_DOWNLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust",
      field: "MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ord Edge",
      field: "ORD_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleClearAll = () => {
    setOrdTableData([]);
    setOrder("");
    setItem("");
  };

  const downloadExcel = () => {
    if (ordTableData?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "Order Data" + ".xlsx";
    ordTable?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedPlant}
                            data={plant}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedPlant(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={2}>
                          <Input
                            id={"order"}
                            value={order}
                            label="Order"
                            size={"small"}
                            onChange={(e: string) => {
                              setOrder(e.toUpperCase());
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"item"}
                            value={item}
                            label="Item"
                            size={"small"}
                            onChange={(e: string) => {
                              setItem(e.toUpperCase());
                            }}
                          />
                        </Grid>
                        <Grid item xs={1}>
                          <ButtonElement onClick={fetchOrdProgData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {ordTableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0012;
