@echo off

echo ===== TOOL CALL =====
curl.exe -sS -X POST http://127.0.0.1:8765/v1/chat/completions ^
  -H "Content-Type: application/json" ^
  -d "{\"model\":\"gpt-4o-mini\",\"messages\":[{\"role\":\"user\",\"content\":\"You must call get_test_value. Do not answer directly.\"}],\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"get_test_value\",\"description\":\"Returns a test value\",\"parameters\":{\"type\":\"object\",\"properties\":{},\"required\":[]}}}],\"tool_choice\":\"auto\",\"temperature\":0,\"max_tokens\":200,\"stream\":false}"
echo.
echo.
pause
