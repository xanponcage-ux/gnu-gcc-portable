import { Request, Response } from "express";
import SPS0015Model from "../models/SPS0015Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import OracleDB from "oracledb";

// export const getData01 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if (req.body.data === 0) {
//       result1 = await SPS0015Model.prototype.getVCoilData01(req.body);
//     }
//     if (req.body.data === 1) {
//       result2 = await SPS0015Model.prototype.getData01(req.body);
//     }
//     varData = {
//       ...{ procLine: await ResponceData(result1) },
//       ...{ procPath: await ResponceData(result2) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };

export const scheduleDeletion = async (req: Request, res: Response) => {
  try {
    const results = await ResponceData(
      await SPS0015Model.prototype.scheduleDeletion(req.body)
    );
    return res.status(200).json(results);
  } 
  catch (error: any) {
    return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
  }
};
