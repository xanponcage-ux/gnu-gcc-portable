import * as repo from "../repository/queryPgQuery";

export default class SPO0007Model {
  execQueryScreenAccess(req: any) {
    return repo.execQueryScreenAccess(req);
  }

  execQuery(req: any) {
    return repo.execQuery(req);
  }

  confirmExecQuery(req: any) {
    return repo.confirmExecQuery(req);
  }

  testConnection() {
    return repo.testConnection();
  }
}
