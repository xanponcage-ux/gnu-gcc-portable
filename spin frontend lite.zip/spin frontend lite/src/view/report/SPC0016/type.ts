export interface SPC0016DataType {
    BATCH_ID: string;
    STATUS: string;
    NET_WT: number;
    HOLD_DATE_TIME: string;
    HOLD_CD: string;
    HOLD_DESC: string;
    HOLD_DT: string;
    HOLD_BY: string;
    HOLD_REM_BY_OPR: string;
    RELEASE_DT: string;
    RELEASE_BY: string;
    RELEASE_REMARK: string;
    EOM_TDC_ACTL: string;
    THICK: number;
    WIDTH: number;
    PROD_CD: string;
    QLTY_CD: string;
    PARENT_BATCH: string;
    MOTHER_BATCH: string;
    CHR_RLS_REMARKS: string;
  }