import { Request, Response } from "express";
import SPCG001Model from "../models/SPCG001Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData01 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    let result3;
    let result4;

    if (req.body.data === 0) {
      result1 = await SPCG001Model.prototype.getData01(req.body); //Intransit details
    }
    if (req.body.data === 1) {
      result3 = await SPCG001Model.prototype.getData03(req.body); //Rec Raw mat report
    }
    if (req.body.data === 2) {
      result2 = await SPCG001Model.prototype.getData02(req.body); //Rec raw material
    }
    if (req.body.data === 3) {
      result4 = await SPCG001Model.prototype.getData04(req.body); //Return raw material
    }
    varData = {
      ...{ intransitData: await ResponceData(result1) },
      ...{ recData: await ResponceData(result2) },
      ...{ recRepData: await ResponceData(result3) },
      ...{ returnRawMat: await ResponceData(result4) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getEpaData01 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPCG001Model.prototype.getStatusCodeData01();
    const result2 = await SPCG001Model.prototype.getInvoiceData01();
    const result3 = await SPCG001Model.prototype.getMaterialData01();
    const result4 = await SPCG001Model.prototype.getProdData01();
    const result5 = await SPCG001Model.prototype.getQltyData01();
    const result6 = await SPCG001Model.prototype.getTdcData01();
    const result7 = await SPCG001Model.prototype.getYardValue();

    const varData = {
      statusCode: await ResponceData(result1),
      invoice: await ResponceData(result2),
      material: await ResponceData(result3),
      prod: await ResponceData(result4),
      qlty: await ResponceData(result5),
      tdc: await ResponceData(result6),
      yardValue: await ResponceData(result7),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const saveTableData = async (req: Request, res: Response) => {
  try {
    let batchIds = req?.body?.batchId;
    let yardLs = req?.body?.yard;
    let result;
    for (let i = 0; i < batchIds?.length; i++) {
      let batchId = batchIds[i];
      let yard = yardLs[i];
      result = await SPCG001Model.prototype.saveTableData(batchId, yard);
    }
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const tabAccess = async (req: Request, res: Response) => {
  try {
    const result = await ResponceData(await SPCG001Model.prototype.tabAccess());
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const deleteCoil = async (req: Request, res: Response) => {
  try {
    let batchIds = req?.body?.batchId;
    let plantCd = req?.body?.plantCd;
    let result;
    for (let i = 0; i < batchIds?.length; i++) {
      let batchId = batchIds[i];
      result = await ResponceData(
        await SPCG001Model.prototype.deleteCoil(batchId, plantCd)
      );
    }
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
