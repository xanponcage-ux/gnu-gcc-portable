import { Request, Response } from "express";
import SPS0004Model from "../models/SPS0004Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import OracleDB from "oracledb";

export const getBatchData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPS0004Model.prototype.getBatchData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getBatchDLinkData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPS0004Model.prototype.getBatchDLinkData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getFittingOrderData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPS0004Model.prototype.getFittingOrderData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const saveData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPS0004Model.prototype.saveData(req.body);
    const result = result1?.outBinds?.ls_out_flag;
    return res.status(200).json(await ResponceData(result, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getChemChk = async (req: Request, res: Response) => {
  try {
    const result = await SPS0004Model.prototype.getChemChk(req.body);
    const finRes = await ResponceData(result, true);
    return res.status(200).json(finRes);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
