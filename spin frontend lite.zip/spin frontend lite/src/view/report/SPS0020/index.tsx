import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization } from "../../../utils";
import { TableType, InputChangeType } from "./type";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import { SPS0020Api } from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { PopupObj, option, popuptype } from "./type";
import { setTheme, useMaterialUIController } from "../../../context";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

import * as XLSX_NS from "xlsx-js-style";

const XLSX: any = (XLSX_NS as any).default ?? XLSX_NS;
(window as any).XLSX = XLSX;

const P_SPS0020 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;

  const [table1, setTable1] = React.useState<any>(null);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedCode, setSelectedCode] = React.useState<any>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [tableData1, setTableData1] = React.useState<any>([]);
  const [deletePop, setDeletePop] = React.useState<popuptype>({
    isPopUp: false,
    data: "",
  });

  const [selectedSourcePlant, setSelectedSourcePlant] =
    React.useState<string>("");
  const [selectedReportType, setSelectedReportType] = React.useState("");
  const [selectedProcess, setSelectedProcess] = React.useState<any>("");
  const [value, setValue] = React.useState<number>(0);
  const [plannedPath, setPlannedPath] = React.useState<string>("");
  const [scheduleDetailsData, setScheduleDetailsData] = React.useState<
    Array<SelectType>
  >([]);
  const [radioOptions, setRadioOption] = React.useState<string>("1");

  const now = new Date();
  const [selectedYear, setSelectedYear] = React.useState<string>(
    String(now.getFullYear())
  );
  const [selectedMonth, setSelectedMonth] = React.useState<string>(
    String(now.getMonth() + 1).padStart(2, "0")
  );
  let year = new Date().getFullYear();
  year = year - 2;
  let yearData: Array<SelectType> = [];
  for (let i = 0; i <= 4; i++) {
    let obj = {
      label: (year + i).toString(),
      value: (year + i).toString(),
      id: i,
    };
    yearData.push(obj);
  }
  const monthData = [
    { label: "Jan", value: "01" },
    { label: "Feb", value: "02" },
    { label: "Mar", value: "03" },
    { label: "Apr", value: "04" },
    { label: "May", value: "05" },
    { label: "Jun", value: "06" },
    { label: "Jul", value: "07" },
    { label: "Aug", value: "08" },
    { label: "Sep", value: "09" },
    { label: "Oct", value: "10" },
    { label: "Nov", value: "11" },
    { label: "Dec", value: "12" },
  ];
  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Material No",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "TDC",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Prod Cd",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key3"),
    },
    key4: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    key7: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    },
    key8: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    },
    key9: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key9"),
    },
    key10: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key10"),
    },
    key11: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key11"),
    },
  };
  const [reportData, setReportData] = React.useState<Array<SelectType>>([]);
  const [sourceplantData, setsourceplantData] = React.useState<
    Array<SelectType>
  >([]);

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const column: any = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      field: "PLANT_NAME",
      title: "Plant Name",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Issue For Production(T)(A)",
      field: "ISSUE_FOR_PRODUCTION",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Prime(B)",
      field: "PRIME",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Downgraded(C)",
      field: "SECONDS",
      hozAlign: "right",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
        // return `<span style = "color :blue">${value}</span>`;
      },
      //Date - 30.01.2026, This is removed for now, if needed this can be incorporated in future
      // cellClick: function (cell: any) {
      //   //console.log(cell.getData())
      //   callClickDownloadApi("secondsData");
      // },
    },
    {
      title: "Scrap",
      field: "SCRAP",
      hozAlign: "right",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
        // return `<span style = "color :blue">${value}</span>`;
      },
      //Date - 30.01.2026, This is removed for now if needed this can be incorporated in future
      // cellClick: function (cell: any) {
      //   //console.log(cell.getData())
      //   callClickDownloadApi("scrapData");
      // },
    },
    {
      title: "Prime Yield% (B/A)*100",
      field: "PRIME_YIELD",
      hozAlign: "right",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
      //Date - 30.01.2026, This is removed for now if needed this can be incorporated in future
      // cellClick: function (cell: any) {
      //   console.log(cell.getData());
      //   callClickDownloadApi("scrapData");
      // },
    },
    {
      title: "Gross Yield% ((B+C)/A)*100",
      field: "GROSS_YIELD",
      hozAlign: "right",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
  ];

  const replaceNulls = (rows: any[]) =>
    rows.map((row) => {
      const cleaned: any = {};
      Object.keys(row).forEach((k) => {
        const v = row[k];
        cleaned[k] = v === null || v === undefined ? "" : v;
      });
      return cleaned;
    });

  const getFileStamp = () => {
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(
      d.getDate()
    )}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
  };

  const yldTableCol: any = [
    { title: "Month", field: "Month", headerFilter: "input" },
    { title: "Plant", field: "Plant", headerFilter: "input" },
    {
      title: "CR Mother Coil ID",
      field: "CRMotherCoilID",
      headerFilter: "input",
    },
    { title: "Mother Coil TDC", field: "MotherCoilTDC", headerFilter: "input" },
    {
      title: "Thickness",
      field: "Thickness",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "M C Width",
      field: "MCWidth",
      headerFilter: "input",
      hozAlign: "right",
    },
    { title: "Combination", field: "Combination", headerFilter: "input" },
    {
      title: "M C Width Actual",
      field: "MCWidthActual",
      headerFilter: "input",
      hozAlign: "right",
    },
    { title: "M Coil Edge", field: "MCoilEdge", headerFilter: "input" },
    {
      title: "Mother Coil Grade",
      field: "MotherCoilGrade",
      headerFilter: "input",
    },
    {
      title: "Mother Coil Prod Cd",
      field: "MotherCoilProdCode",
      headerFilter: "input",
    },
    {
      title: "Mother Coil Catg.",
      field: "MotherCoilCategory",
      headerFilter: "input",
    },
    {
      title: "Mother Coil Mark Cust",
      field: "MotherCoilMarkCust",
      headerFilter: "input",
    },

    {
      title: "Mother Coil Weight (T)",
      field: "MotherCoilWeight(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Mother Coil Consumed Wt (T)",
      field: "MotherCoilConsumedWt(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "WIP Tonnage (T)",
      field: "WIPTonnage(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Hold Tonnage (T)",
      field: "HoldTonnage(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Segregation Tonnage (T)",
      field: "SegregationTonnage(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Rework/Replan Tonnage (T)",
      field: "Rework/ReplanTonnage(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "Total Issued For Production (T)",
      field: "TotalIssuedForProduction(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Total Prime Tonnage (T)",
      field: "TotalPrimeTonnage(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Total Prime-2 Qty (T)",
      field: "TotalPrime-2Qty(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Total Scrap Qty (T)",
      field: "TotalScrapQty(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "Prime Yield (%)",
      field: "PrimeYield(%)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Gross Yield (%)",
      field: "GrossYield(%)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "Total RM Defect Downgraded to Prime-2 (T)",
      field: "RMDefectDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Total EPA Defect Downgraded to Prime-2 (T)",
      field: "EPADefectDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Total Nominal Defect Downgraded to Prime-2 (T)",
      field: "NominalDefectDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Planning Downgraded to Prime-2 (T)",
      field: "PlanningDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Marketing Downgraded to Prime-2 (T)",
      field: "MarketingDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "CSD Downgraded to Prime-2 (T)",
      field: "CSDDowngradedtoPrime-2(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "RM Defect Scrap - End Cut (T)",
      field: "RMDefectScrap-EndCut(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "EPA Defect Scrap - End Cut (T)",
      field: "EPADefectScrap-EndCut(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Nominal Defect Scrap - End Cut (T)",
      field: "NominalDefectScrap-EndCut(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Planning Defect Scrap - End Cut (T)",
      field: "PlanningDefectScrap-EndCut(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "RM Defect Scrap - Trim Loss (T)",
      field: "RMDefectScrap-TrimLoss(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "EPA Defect Scrap - Trim Loss (T)",
      field: "EPADefectScrap-TrimLoss(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Nominal Defect Scrap - Trim Loss (T)",
      field: "NominalDefectScrap-TrimLoss(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Planning Defect Scrap - Trim Loss (T)",
      field: "PlanningDefectScrap-TrimLoss(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "RM Defect Scrap - Pup Coil (T)",
      field: "RMDefectScrap-PupCoil(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "EPA Defect Scrap - Pup Coil (T)",
      field: "EPADefectScrap-PupCoil(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "Nominal Defect Scrap - Pup Coil (T)",
      field: "NominalDefectScrap-PupCoil(T)",
      headerFilter: "input",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Planning Defect Scrap - Pup Coil (T)",
      field: "PlanningDefectScrap-PupCoil(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "Marketing Scrap (T)",
      field: "MarketingScrap(T)",
      headerFilter: "input",
      hozAlign: "right",
    },
    {
      title: "CSD Defect Scrap (T)",
      field: "CSDDefectScrap(T)",
      headerFilter: "input",
      hozAlign: "right",
    },

    {
      title: "Salvaging remarks",
      field: "SalvagingRemarks",
      headerFilter: "input",
    },
    { title: "Cast no", field: "CastNo", headerFilter: "input" },
    { title: "CR Source plant", field: "CRSourcePlant", headerFilter: "input" },
    {
      title: "Source Plant passed process",
      field: "SourcePlantPassedProcess",
      headerFilter: "input",
    },

    { title: "UOM", field: "UOM", headerFilter: "input", visible: false },
    {
      title: "Created By",
      field: "CreatedBy",
      headerFilter: "input",
      visible: false,
    },
    {
      title: "Created On",
      field: "CreatedOn",
      headerFilter: "input",
      visible: false,
    },
    {
      title: "Updated By",
      field: "UpdatedBy",
      headerFilter: "input",
      visible: false,
    },
    {
      title: "Updated On",
      field: "UpdatedOn",
      headerFilter: "input",
      visible: false,
    },
    {
      title: "Company Code",
      field: "CompanyCode",
      headerFilter: "input",
      visible: false,
    },
    {
      title: "WIP WT A",
      field: "WIPWTA",
      headerFilter: "input",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "FG Size",
      field: "FGSize",
      headerFilter: "input",
      visible: false,
    },
  ];

  // const column1: any = [
  //   {
  //     title: "Month",
  //     field: "MONTH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil ID",
  //     field: "MOTHER_COIL_ID",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Plant",
  //     field: "PLANT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Company",
  //     field: "COMPANY",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil TDC",
  //     field: "MOTHER_COIL_TDC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Thickness",
  //     field: "THICKNESS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Width",
  //     field: "WIDTH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Combination",
  //     field: "COMBINATION",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Grade",
  //     field: "MOTHER_COIL_GRADE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Prod Cd",
  //     field: "MOTHER_COIL_PROD_CD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Catg",
  //     field: "MOTHER_COIL_CATG",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Mark Cust",
  //     field: "MOTHER_COIL_MARK_CUST",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Weight",
  //     field: "MOTHER_COIL_WEIGHT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Coil Consumed Wt",
  //     field: "MOTHER_COIL_CONSUMED_WT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Input Tonnage",
  //     field: "INPUT_TONNAGE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Issue For Production",
  //     field: "ISSUE_FOR_PRODUCTION",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Prime Tonnage",
  //     field: "PRIME_TONNAGE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Seconds Tonnage",
  //     field: "SECONDS_TONNAGE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Scrap Tonnage",
  //     field: "SCRAP_TONNAGE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "RM Defect Sec",
  //     field: "RM_DEFECT_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "EPA Defect Sec",
  //     field: "EPA_DEFECT_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Nominal Sec",
  //     field: "NOMINAL_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Planning Sec",
  //     field: "PLANNING_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Marketing Sec",
  //     field: "MARKETING_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "CSD Defect",
  //     field: "CSD_DEFECT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Unacc Sec",
  //     field: "UNACC_SEC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "RM Defect Scrap",
  //     field: "RM_DEFECT_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "EPA Defect Scrap",
  //     field: "EPA_DEFECT_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Nominal Scrap",
  //     field: "NOMINAL_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Planning Scrap",
  //     field: "PLANNING_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Marketing Scrap",
  //     field: "MARKETING_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "CSD Defect Scrap",
  //     field: "CSD_DEFECT_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Unacc Scrap",
  //     field: "UNACC_SCRAP",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Prime Yield",
  //     field: "PRIME_YIELD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Gross Yield",
  //     field: "GROSS_YIELD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Salvaging Remarks",
  //     field: "SALVAGING_REMARKS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Source Plant",
  //     field: "SOURCE_PLANT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Source Plant Desc",
  //     field: "SOURCE_PLANT_DESC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  // ];

  const secondcolumns: any = [
    {
      title: "Batch ID",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Thickness",
      field: "FG_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Width",
      field: "FG_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG TDC",
      field: "FG_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Prod CD",
      field: "FG_PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "MC TDC",
      field: "MC_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "MC Prod CD",
      field: "MC_PRODCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "MC Thickness",
      field: "MC_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "MC Width",
      field: "MC_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "MC Customer",
      field: "MC_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Source Plant",
      field: "SOURCE_PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Product Type",
      field: "PRODUCT_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SSY RSN CAT",
      field: "SSY_RSN_CAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "RSN Description",
      field: "RSN_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TON",
      field: "TON",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const scrapcolumns: any = [
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Fg Thk",
      field: "FG_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Fg Width",
      field: "FG_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Fg Tdc",
      field: "FG_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Fg Prod Cd",
      field: "FG_PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mc Tdc",
      field: "MC_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mc Prodcd",
      field: "MC_PRODCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mc Thk",
      field: "MC_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mc Width",
      field: "MC_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mc Customer",
      field: "MC_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Source Plant",
      field: "SOURCE_PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Product Type",
      field: "PRODUCT_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ssy Rsn Cat",
      field: "SSY_RSN_CAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rsn Desc",
      field: "RSN_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Tonn",
      field: "TONN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  React.useEffect(() => {
    SPS0020ApiCall("pageData");
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: tableData,
          columns: column,
          maxHeight: 200,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData]);

  let formData: Array<FormType> = [];

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const SPS0020ApiCall = (type: string, plant?: string, data?: any) => {
    setLoading(true);
    // console.log("selectedCode: ", selectedCode);
    console.log(data);
    GetAuthorization().then((token: TokenType) => {
      SPS0020Api(token, {
        type: type,
        plant: plant ? plant : "",
        data: data,
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (type === "pageData") {
              if (res?.data?.plant.length === 0) {
                alertify.error("No Plant Data found");
              }
              const varData: Array<SelectType> = [];
              res?.data?.plant?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0]?.value);

              //Commented on 04.02.26, Cause report type dd is not needed for now
              // const varData1: Array<SelectType> = [];
              // res?.data?.report?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varData1?.push({
              //       value: x?.CD_VALUE?.toString(),
              //       label: x?.CD_DESC?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setReportData(varData1);
              // setSelectedReportType(varData1[0]?.value);

              const varData3: Array<SelectType> = [];
              res?.data?.sourcePlant?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData3?.push({
                    value: x?.SRC_PLANT?.toString(),
                    label: x?.SRC_PLANT?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setsourceplantData(varData3);
              //setSelectedSourcePlant(varData3[0]?.value)
            } else if (type === "sourcePlant") {
              const varData3: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData3?.push({
                    value: x?.SRC_PLANT?.toString(),
                    label: x?.SRC_PLANT?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setsourceplantData(varData3);
              //setSelectedSourcePlant(varData3[0].value)
            } else if (type === "getTableData") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                setTableData(res.data);
              }
            } else if (type === "yieldWiseData") {
              if (res?.data?.length === 0) {
                alertify.error("No data Found for downloading");
                return;
              } else {
                const cleanedData = replaceNulls(res.data);

                const tempTable = new Tabulator("#table2", {
                  data: cleanedData,
                  columns: yldTableCol,
                  height: 250,
                  layout: "fitDataFill",
                });
                tempTable?.on("tableBuilt", function () {
                  const fileName = `Coil_Wise_Yield ${getFileStamp()}.xlsx`;
                  // console.log("fileName: ", fileName);
                  // tempTable.download("xlsx", "Coil Wise Yield Details.xlsx", {
                  tempTable.download("xlsx", fileName, {
                    sheetName: "Sheet1",
                    documentProcessing: function (workbook: any) {
                      const sheetName = workbook.SheetNames[0];
                      const ws = workbook.Sheets[sheetName];

                      if (!ws || !ws["!ref"]) return workbook;

                      const range = XLSX.utils.decode_range(ws["!ref"]);
                      const startCol = range.s.c;
                      const endCol = range.e.c;

                      // -------------------------------------------------------
                      // 1) Shift sheet DOWN by 1 row to create group header row
                      // -------------------------------------------------------
                      for (let R = range.e.r; R >= range.s.r; R--) {
                        for (let C = startCol; C <= endCol; C++) {
                          const oldAddr = XLSX.utils.encode_cell({
                            r: R,
                            c: C,
                          });
                          const newAddr = XLSX.utils.encode_cell({
                            r: R + 1,
                            c: C,
                          });

                          if (ws[oldAddr]) {
                            ws[newAddr] = ws[oldAddr];
                            delete ws[oldAddr];
                          }
                        }
                      }

                      ws["!ref"] = XLSX.utils.encode_range({
                        s: { r: 0, c: startCol },
                        e: { r: range.e.r + 1, c: endCol },
                      });

                      const groupRow = 0; // NEW row for group headers
                      const headerRow = 1; // original header row moved down

                      // -------------------------------------------------------
                      // 2) Build header text -> column index map (from row 1)
                      // -------------------------------------------------------
                      const headerMap: Record<string, number> = {};
                      for (let C = startCol; C <= endCol; C++) {
                        const addr = XLSX.utils.encode_cell({
                          r: headerRow,
                          c: C,
                        });
                        const v = (ws[addr]?.v ?? "").toString().trim();
                        if (v) headerMap[v] = C;
                      }
                      const col = (title: string) => headerMap[title];

                      // -------------------------------------------------------
                      // 3) Define groups by header titles (exact text from export)
                      // -------------------------------------------------------
                      const groups = [
                        {
                          title: "Downgrade",
                          from: "Total RM Defect Downgraded to Prime-2 (T)",
                          to: "CSD Downgraded to Prime-2 (T)",
                          color: "4DB6AC", // deep blue (different from header row)
                        },
                        {
                          title: "Scrap - End Cut (T)",
                          from: "RM Defect Scrap - End Cut (T)",
                          to: "Planning Defect Scrap - End Cut (T)",
                          color: "38761D", // green
                        },
                        {
                          title: "Scrap - Trim Loss (T)",
                          from: "RM Defect Scrap - Trim Loss (T)",
                          to: "Planning Defect Scrap - Trim Loss (T)",
                          color: "C65911", // orange
                        },
                        {
                          title: "Scrap - Pup Coil (T)",
                          from: "RM Defect Scrap - Pup Coil (T)",
                          to: "Planning Defect Scrap - Pup Coil (T)",
                          color: "7F7F7F", // grey
                        },
                        {
                          title: "Other Scrap (T)",
                          from: "Marketing Scrap (T)",
                          to: "CSD Defect Scrap (T)",
                          color: "00695C", // navy
                        },
                      ];

                      // -------------------------------------------------------
                      // Helpers for styling
                      // -------------------------------------------------------
                      const thinBorder = {
                        style: "thin",
                        color: { rgb: "D9D9D9" },
                      };
                      const thickBorder = {
                        style: "medium",
                        color: { rgb: "000000" },
                      };

                      const setCell = (
                        r: number,
                        c: number,
                        value?: string
                      ) => {
                        const addr = XLSX.utils.encode_cell({ r, c });
                        if (!ws[addr]) ws[addr] = { t: "s", v: "" };
                        if (value !== undefined) {
                          ws[addr].t = "s";
                          ws[addr].v = value;
                        }
                        return ws[addr];
                      };

                      const applyStyle = (cell: any, style: any) => {
                        cell.s = { ...(cell.s || {}), ...style };
                      };

                      // -------------------------------------------------------
                      // 4) Style the COLUMN HEADER row (row 1) -> uniform dark header
                      // -------------------------------------------------------
                      const headerStyle = {
                        font: { bold: true, color: { rgb: "FFFFFF" } },
                        fill: {
                          patternType: "solid",
                          fgColor: { rgb: "1F4E79" },
                        }, // your main header blue
                        alignment: {
                          horizontal: "center",
                          vertical: "center",
                          wrapText: true,
                        },
                        border: {
                          top: thinBorder,
                          bottom: thinBorder,
                          left: thinBorder,
                          right: thinBorder,
                        },
                      };

                      for (let C = startCol; C <= endCol; C++) {
                        const cell = setCell(headerRow, C);
                        applyStyle(cell, headerStyle);
                      }

                      // -------------------------------------------------------
                      // 5) Put light background in GROUP row (row 0) everywhere
                      //    so groups are clearly visible
                      // -------------------------------------------------------
                      const groupBaseStyle = {
                        font: { bold: true, color: { rgb: "000000" } },
                        fill: {
                          patternType: "solid",
                          fgColor: { rgb: "EDEDED" },
                        }, // light grey
                        alignment: {
                          horizontal: "center",
                          vertical: "center",
                          wrapText: true,
                        },
                        border: {
                          top: thinBorder,
                          bottom: thinBorder,
                          left: thinBorder,
                          right: thinBorder,
                        },
                      };

                      for (let C = startCol; C <= endCol; C++) {
                        const cell = setCell(groupRow, C, "");
                        applyStyle(cell, groupBaseStyle);
                      }

                      // -------------------------------------------------------
                      // 6) Create merges + apply distinct color per group + thick borders
                      // -------------------------------------------------------
                      ws["!merges"] = ws["!merges"] || [];

                      groups.forEach((g) => {
                        const c1 = col(g.from);
                        const c2 = col(g.to);

                        if (c1 === undefined || c2 === undefined) return;

                        // Set group title (only first cell; merged across)
                        const first = setCell(groupRow, c1, g.title);

                        // Merge across group span
                        ws["!merges"].push({
                          s: { r: groupRow, c: c1 },
                          e: { r: groupRow, c: c2 },
                        });

                        // Group row style (distinct fill)
                        const groupStyle = {
                          font: { bold: true, color: { rgb: "FFFFFF" } },
                          fill: {
                            patternType: "solid",
                            fgColor: { rgb: g.color },
                          },
                          alignment: {
                            horizontal: "center",
                            vertical: "center",
                            wrapText: true,
                          },
                          border: {
                            top: thickBorder,
                            bottom: thickBorder,
                            left: thickBorder,
                            right: thickBorder,
                          },
                        };
                        applyStyle(first, groupStyle);

                        // Add THICK boundary lines at start/end of group on HEADER row too
                        // Start boundary
                        const headerStart = setCell(headerRow, c1);
                        headerStart.s = headerStart.s || {};
                        headerStart.s.border = headerStart.s.border || {};
                        headerStart.s.border.left = thickBorder;

                        // End boundary
                        const headerEnd = setCell(headerRow, c2);
                        headerEnd.s = headerEnd.s || {};
                        headerEnd.s.border = headerEnd.s.border || {};
                        headerEnd.s.border.right = thickBorder;
                      });

                      // Freeze both group row + header row
                      ws["!freeze"] = { xSplit: 0, ySplit: 2 };

                      return workbook;
                    },
                  });
                });

                // var tempTable = new Tabulator("#table2", {
                //   data: res.data,
                //   columns: yldTableCol, //column1,
                //   height: 250,
                //   layout: "fitDataFill",
                // });
                // tempTable?.on("tableBuilt", function () {
                //   console.log("Hi");
                //   tempTable.download("xlsx", "Coil Wise Yield Details.xlsx", {
                //     sheetName: "Sheet1",
                //   });
                // });
              }
            }
          }
        })
        .catch((e: any) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  //Date - 30.01.26, Keeping this code here, right now it is not used but can be activated in future
  const callClickDownloadApi = (type?: any, data?: any) => {
    //console.log('sec')
    setLoading(true);
    GetAuthorization()
      .then((token: TokenType) => {
        SPS0020Api(token, {
          type: type,
          data: {
            year: selectedYear,
            month: selectedMonth,
            plant: selectedCode,
            sourceplant: selectedSourcePlant,
          },
        }).then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (type === "secondsData") {
            console.log(res.data);
            if (res.data.length === 0) {
              alertify.error("No Downgrade Data Found!");
              return;
            } else {
              var tempTable = new Tabulator("#table2", {
                data: res.data,
                columns: secondcolumns,
                height: 250,
                layout: "fitDataFill",
              });
              tempTable?.on("tableBuilt", function () {
                tempTable.download("xlsx", "Seconds Details.xlsx", {
                  sheetName: "Sheet1",
                });
              });
            }
          } else if (type === "scrapData") {
            console.log(res.data);
            if (res.data.length === 0) {
              alertify.error("No Scrap Data Found!");
              return;
            } else {
              var tempTable = new Tabulator("#table2", {
                data: res.data,
                columns: scrapcolumns,
                height: 250,
                layout: "fitDataFill",
              });
              tempTable?.on("tableBuilt", function () {
                tempTable.download("xlsx", "Scrap Details.xlsx", {
                  sheetName: "Sheet1",
                });
              });
            }
          }
        });
      })
      .catch((e) => {
        alertify.error(e?.error?.message ? e.error.message : e?.toString());
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedCode("");
    setTableData([]);
    setSelectedReportType("");
    setSelectedSourcePlant("");
    setSelectedYear("");
    setSelectedMonth("");
  };

  const handleSearch = () => {
    if (!selectedCode) {
      alertify.error("Please Select Plant");
      return;
    }
    if (!selectedYear) {
      alertify.error("Please Select Year");
      return;
    }
    if (!selectedMonth) {
      alertify.error("Please Select Month");
      return;
    }
    SPS0020ApiCall("getTableData", selectedCode, {
      reportType: selectedReportType,
      sourcePlant: selectedSourcePlant,
      year: selectedYear,
      month: selectedMonth,
    });
  };

  const handleDownload = () => {
    if (!selectedCode) {
      alertify.error("Please Select Plant");
      return;
    }
    if (!selectedYear) {
      alertify.error("Please Select Year");
      return;
    }
    if (!selectedMonth) {
      alertify.error("Please Select Month");
      return;
    }
    SPS0020ApiCall("yieldWiseData", selectedCode, {
      sourcePlant: selectedSourcePlant,
      year: selectedYear,
      month: selectedMonth,
    });
  };

  const handleRadioChange = (e: any) => {
    setRadioOption(e);
    if (e === "2") {
      alertify.error("No Yearly Data Exists");
      return;
    }
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            {/* <Grid item xs={8}>
                        {deletePop.isPopUp && (
                            <div>
                                <Dialog
                                    open={deletePop.isPopUp}
                                    onClose={() => {
                                        console.log("hurrey");
                                    }}
                                >
                                    <DialogTitle>
                                        <WarningIcon color="warning" />
                                        Warning
                                    </DialogTitle>
                                    <DialogContent>
                                        <p>Are you sure want to delete the Schedules?</p>
                                    </DialogContent>
                                    <DialogActions>
                                        <Button
                                            onClick={() => {
                                                // SPS0020ApiCall();
                                            }}
                                            color="primary"
                                        >
                                            YES
                                        </Button>
                                        <Button
                                            onClick={() => {
                                                setDeletePop({ isPopUp: false, data: "" });
                                            }}
                                        >
                                            NO
                                        </Button>
                                    </DialogActions>
                                </Dialog>
                            </div>
                        )}
                    </Grid> */}
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid
                  container
                  spacing={1}
                  sx={{
                    p: 2,
                    backgroundColor: csTheme?.palette.background.paper,
                    borderRadius: 2,
                    gap: 1.5,
                  }}
                >
                  <Grid item xs={2}>
                    <SelectInput
                      label="Plant*"
                      data={plantCodeData}
                      id={"id"}
                      value={selectedCode}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedCode(e);
                        SPS0020ApiCall("sourcePlant", e);
                        setTableData([]);
                      }}
                    />
                  </Grid>
                  {/* <Grid item xs={2.5}>
                    <SelectInput
                      label="Report type"
                      data={reportData}
                      value={selectedReportType}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedReportType(e);
                        setTableData([]);
                      }}
                    />
                  </Grid> */}

                  <Grid item xs={2.5}>
                    <SelectInput
                      label="Source Plant"
                      data={sourceplantData}
                      value={selectedSourcePlant}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedSourcePlant(e);
                        setTableData([]);
                      }}
                    />
                  </Grid>

                  <Grid item xs={1}>
                    <ButtonElement
                      sx={{ width: "100%" }}
                      onClick={() => handleSearch()}
                    >
                      Search
                    </ButtonElement>
                  </Grid>

                  <Grid item xs={3}>
                    <ButtonElement
                      sx={{ width: "100%" }}
                      onClick={() => handleDownload()}
                    >
                      Coil Wise Yield Details
                      {/* Download Yield Wise Coil Details */}
                    </ButtonElement>
                  </Grid>

                  <Grid item xs={2}>
                    <RadioInput
                      row
                      value={radioOptions}
                      data={[
                        { label: "Monthly", value: "1" },
                        { label: "Yearly", value: "2" },
                      ]}
                      onChange={(e: string) => {
                        handleRadioChange(e);
                        setTableData([]);
                      }}
                    />
                  </Grid>

                  <Grid item xs={1.3}>
                    <SelectInput
                      data={yearData}
                      id={"year"}
                      value={selectedYear}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedYear(e);
                        setTableData([]);
                        console.log(e);
                      }}
                    />
                  </Grid>

                  <Grid item xs={1.3}>
                    <SelectInput
                      data={monthData}
                      id={"month"}
                      value={selectedMonth}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedMonth(e);
                        setTableData([]);
                        console.log(e);
                      }}
                    />
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Table Details"
                headerContainer={
                  <Tooltip title="Download">
                    <IconButton
                      onClick={() => {
                        downloadExcel("Yield Report", tableData, table);
                      }}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            {
              <Grid sx={{ display: "None" }}>
                <div id="table2"></div>
              </Grid>
            }
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0020;
