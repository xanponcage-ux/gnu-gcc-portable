import { Router } from "express";
import // getData,
//   getProdData,
//   SPO0003Api,
"../controllers/operationController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const operationRoute = Router();
// operationRoute
//   .route("/operation/getData")
//   .post(authenticationMiddleware.bearer, getData);
// operationRoute
//   .route("/operation/getProdData")
//   .post(authenticationMiddleware.bearer, getProdData);
// operationRoute
//   .route("/operation/SPO0003Api")
//   .post(authenticationMiddleware.bearer, SPO0003Api);

export default operationRoute;
