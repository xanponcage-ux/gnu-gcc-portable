// const SPC0006Query = require("../repository/SPC0006Query");
import * as SPC0006Query from "../repository/SPC0006Query";

export default class SPC0006Model {
  getSECONDSTdc06(data: any) {
    return SPC0006Query.getSECONDSTdc06(data);
  }
  getTdcMap06(data: any) {
    return SPC0006Query.getTdcMap06(data);
  }
  getActTdc06() {
    return SPC0006Query.getActTdc06();
  }
  getEpaPlant06() {
    return SPC0006Query.getEpaPlant06();
  }
  getTdcsec06() {
    return SPC0006Query.getTdcsec06();
  }
  callProcedure06(data: any) {
    return SPC0006Query.callProcedure06(data);
  }
}
