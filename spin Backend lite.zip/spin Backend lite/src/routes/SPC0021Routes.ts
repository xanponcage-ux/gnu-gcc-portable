import { Router } from "express";
import { getData, getStatusData, getScDwnData } from "../controllers/SPC0021Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0021Route = Router();

SPC0021Route.route("/SPC0021/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPC0021Route.route("/SPC0021/getStatusData").get(
  authenticationMiddleware.bearer,
  getStatusData
);

SPC0021Route.route("/SPC0021/getScDwnData").post(
    authenticationMiddleware.bearer,
    getScDwnData
);

export default SPC0021Route;
