CODEGENIE -> CONTINUE BRIDGE
============================

What this does
--------------
Continue talks OpenAI Chat Completions JSON to:

  http://127.0.0.1:8765/v1/chat/completions

The bridge converts that request to the multipart/form-data contract used by the
working internal CodeGenie API:

  https://asia-south1-tsl-generative-ai.cloudfunctions.net/code_genie_api_calls

No llama.cpp, local Qwen, Google service-account JSON, browser token, or tracking
endpoint is required.

The CodeGenie endpoint has already been verified to:
  - return an OpenAI-style chat.completion response
  - return choices[0].message.tool_calls
  - use finish_reason="tool_calls"

Files
-----
codegenie_bridge.py             OpenAI-compatible adapter
RUN_BRIDGE.cmd                  Starts it; edit ADID + API key here
TEST_CHAT.cmd                   Checks ordinary chat through the adapter
TEST_TOOLS.cmd                  Checks function/tool calls through the adapter
continue-config-snippet.yaml    Model block for Continue config.yaml

Setup
-----
1. Open RUN_BRIDGE.cmd in Notepad.
2. Replace only:
     YOUR_ADID
     YOUR_CODEGENIE_API_KEY
3. Save it.
4. Double-click RUN_BRIDGE.cmd or run it from CMD.
5. Leave that window running.
6. In a second CMD run TEST_CHAT.cmd.
7. Then run TEST_TOOLS.cmd.

Expected chat result
--------------------
The response should contain BRIDGE_CHAT_OK.

Expected tool result
--------------------
The response should contain:
  "finish_reason":"tool_calls"
and a tool call named get_test_value.

Continue
--------
Add the model block in continue-config-snippet.yaml to your Continue config.yaml,
reload the Continue config, then select "CodeGenie Cloud" and Agent mode.

First Agent test
----------------
Use a tiny non-editing task first:
  Find package.json in this workspace, read it, and tell me its workspace-relative path.

Then test an edit in a throwaway file before using it on production code.

Important
---------
The API key is intentionally NOT stored in this ZIP. Put it only into your local
RUN_BRIDGE.cmd or, preferably, a protected environment variable once testing is
complete.

The tracking endpoint code_genie_tracking_qa is not called by this bridge.
