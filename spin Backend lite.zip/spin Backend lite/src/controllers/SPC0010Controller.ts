import { Request, Response } from "express";
import SPC0010Model from "../models/SPC0010Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0010Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const getDispatchData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0010Model.prototype.getDispatchData(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
