// const SPC0008Query = require("../repository/SPC0008Query");
import * as SPC0008Query from "../repository/SPC0008Query";

export default class SPC0008Model {
  getData08(data: any) {
    return SPC0008Query.getData08(data);
  }
  getEpa08() {
    return SPC0008Query.getEpa08();
  }
  getOrderData08() {
    return SPC0008Query.getOrderData08();
  }
  getNoEnd08() {
    return SPC0008Query.getNoEnd08();
  }
  getNoInp08() {
    return SPC0008Query.getNoInp08();
  }
}
