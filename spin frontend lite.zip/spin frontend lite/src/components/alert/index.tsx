import './alertifyjs.css';
// @ts-ignore
import alertify  from "alertifyjs";
import "./style.css";

// const customAlert = (time?:number)=>{
//     alertify.defaults.notifier.delay = (time)?time:8;
//     return alertify;
// }
// export default customAlert;



alertify.defaults.notifier.delay=8;

export default alertify;

