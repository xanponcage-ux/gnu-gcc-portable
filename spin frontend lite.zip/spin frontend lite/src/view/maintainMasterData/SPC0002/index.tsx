import React from "react";
import DashboardLayout from "src/components/layout/dashboardLayout";
import Tabulator from "src/components/table";
import TableContainer from "src/components/tableContainer";
import { Input, RadioInput, SelectInput } from "src/components/input";
import { CulmnType } from "src/type";
import alertify from "src/components/alert";
import { GetAuthorization } from "src/utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0002GetDataApi,
  // SPC001GetPlantData,
  GetPlantDataApi,
} from "src/apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "src/components/preloader";
import { SelectType } from "src/components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "src/theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "src/components/input";
import ButtonElement from "src/components/button";
import { TokenType } from "src/type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const M_SPC0002 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [value, setValue] = React.useState<number>(0);

  const column: Array<CulmnType> = [
    {
      title: "Plant ",
      field: "EPL_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    }, //1
    {
      title: "Plant Name",
      field: "EPL_EPA_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    }, //2
    {
      title: "Process",
      field: "EPL_CD_PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    }, //3
    {
      title: "Process Name",
      field: "EPL_PROC_LINE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
    }, //4
    {
      title: "Proc Seq",
      field: "EPL_NO_PROC_SEQ",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Activity NM",
      field: "EPL_ACTIVITY_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Production Type",
      field: "EPL_PRODUCTION_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];
  const pathColumn: Array<CulmnType> = [
    {
      title: "Plant",
      field: "PPH_CD_EPA",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Proc Path Code",
      field: "PPH_CD_PROC_PATH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Desc",
      field: "PPH_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Proc Path No",
      field: "PPH_NO_PROC_PATH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setSelectedCode("");
    setSelectedProcess("");
    fetchEpaData();
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: value === 0 ? column : pathColumn,
          height: 600,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const fetchEpaData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantCodeData(varData);
            setSelectedCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const fetchData = (data: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0002GetDataApi(token, {
        data: data,
        process: selectedProcess,
        code: selectedCode?.split(" - ")[0],
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0) {
              setTableData(res.data?.procLine);
            } else {
              setTableData(res.data?.procPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }

    var date = new Date();
    const fileName =
      value === 0
        ? "SPC0002_Process_line" + ".xlsx"
        : "SPC0002_Process_Path" + ".xlsx";
    // var fileName = "SPC0002_Process_line" + ".xlsx";

    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setTableData([]);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={10}>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <SelectInput
                        label="Plant*"
                        data={plantCodeData}
                        id={"id"}
                        value={selectedCode}
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedCode(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <Input
                        id={"process"}
                        value={selectedProcess}
                        label="Process"
                        size={"small"}
                        onChange={(e: string) => {
                          if (e.length <= 1) setSelectedProcess(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <ButtonElement onClick={() => fetchData(value)}>
                        Search
                      </ButtonElement>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Process Line" />
                    <Tab label="Process Path" />
                  </Tabs>
                </Box>
                {value === 0 && tableData?.length > 0 && <div id="table"></div>}
                {value === 1 && tableData?.length > 0 && <div id="table"></div>}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default M_SPC0002;
