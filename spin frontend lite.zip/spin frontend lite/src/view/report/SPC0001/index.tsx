import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  GetPlantDataApi,
  // SPC001GetPlantData,
  SPC0001GetInvData,
  SPC0001GetInvMonData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, InputChangeType } from "./type";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0001 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedMaterialNo, setSelectedMaterialNo] =
    React.useState<string>("");
  const [selectedItem, setSelectedItem] = React.useState<string>("");

  const [selectedEpaCode, setEpaCode] = React.useState<string>("");
  const [epaData, setEpaData] = React.useState<Array<SelectType>>([]);
  const [statusCodeData, setStatusCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [qltyData, setQltyData] = React.useState<Array<SelectType>>([]);
  const [orderStatusData, setOrderStatusData] = React.useState<
    Array<SelectType>
  >([]);
  const [customerData, setCustomerData] = React.useState<Array<SelectType>>([]);
  const [orderTypeData, setOrderTypeData] = React.useState<Array<SelectType>>(
    []
  );
  const [tdcData, setTdcData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedBatch, setSelectedBatch] = React.useState<string>("");
  const [selectedMBatch, setSelectedMBatch] = React.useState<string>("");
  const [parentBatch, setParentBatch] = React.useState<string>("");
  const [yearMon, setYearMon] = React.useState<string>("");
  const [status, setStatus] = React.useState<string>("");

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Matr No",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString()?.toUpperCase(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "TDC",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString()?.toUpperCase(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Prod Cd",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString()?.toUpperCase(), "key3"),
    },
    key4: {
      config: {
        type: "input",
        label: "Prod Dt From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "Prod Dt To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    key7: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    },
    key8: {
      config: {
        type: "input",
        label: "Thick From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    },
    key9: {
      config: {
        type: "input",
        label: "Thick To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key9"),
    },
    key10: {
      config: {
        type: "input",
        label: "Width From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key10"),
    },
    key11: {
      config: {
        type: "input",
        label: "Width To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key11"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const prdFormList: Array<SelectType> = [
    { value: "RM", label: "RM", id: 1 },
    { value: "WIP", label: "WIP", id: 2 },
    { value: "FG", label: "FG", id: 3 },
    { value: "HOLD", label: "HOLD", id: 4 },
  ];

  const [prodForm, setProdForm] = React.useState<string>("");

  const column: Array<CulmnType> = [
    {
      title: "Batch Creation Dt",
      field: "PRODN_ARRIVAL_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "STATUS_DESC",
      title: "Status Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Send To SAP",
      field: "SEND_TO_SAP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        let status = cell?._cell?.row?.data?.STATUS;
        if (status === "WB" && value === "N") {
          cell.getElement().style["background-color"] = "red";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
    },
    {
      title: "Process Flag",
      field: "PROCESS_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Addl Rls Remarks",
      field: "RELEASE_REMARKS1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Type",
      field: "ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Code",
      field: "PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC Grade Desc",
      field: "GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Code",
      field: "QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Actual TDC",
      field: "ACTUAL_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Net Wt",
      field: "NET_WT_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Gross Wt",
      field: "GROSS_WT_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Coil Idia",
      field: "COIL_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Odia",
      field: "COIL_ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Idia",
      field: "ORDER_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Odia",
      field: "ORDER_ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Edge",
      field: "ORD_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Post Treat",
      field: "ORDER_POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Actl Post Treat",
      field: "POST_TREAT_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "No Pieces",
      field: "NO_PIECES",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Scrap Wt",
      field: "SCRAP_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: false,
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Batch Age Days",
      field: "AGE_DAYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value && Number(value) > 30 && Number(value) <= 60) {
          cell.getElement().style["background-color"] = "yellow";
        } else if (value && Number(value) > 60) {
          cell.getElement().style["background-color"] = "red";
        }
        return value;
      },
    },
    {
      title: "Mother Wt",
      field: "MOTHER_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Parent Batch",
      field: "PARENT_CHARG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_CHARG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch Age",
      field: "MOTHER_CHARG_AGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Prev Proc",
      field: "PREV_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Curr Proc",
      field: "CURR_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Next Proc",
      field: "NEXT_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Planned Proc",
      field: "PLAN_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Passed Proc",
      field: "PASSED_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PRODUCT_FORM",
      title: "Product Form",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Order",
      field: "CUSTOMER_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Cd",
      field: "MK_CUST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mark Cust Name",
      field: "MK_CUST_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Code",
      field: "CUSTOMER_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Name",
      field: "CUSTOMER_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Intend Cust Code",
      field: "INDENT_CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Intend Cust Name",
      field: "INTEND_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Order Aim",
      field: "CUST_ORD_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Item Aim",
      field: "CUST_ITEM_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mill Order Mother Batch",
      field: "MILL_ORD_MOTH_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mill Item Mother Batch",
      field: "MILL_ITEM_MOTH_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship to Party CD",
      field: "SHIP_TO_PARTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ship to Party Desc",
      field: "SHIP_TO_PARTY_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Fret Indicator",
      field: "FRT_IND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Road Destination",
      field: "ROAD_DESTN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Road Dest Description",
      field: "ROAD_DEST_DESCRIPTION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail Destination",
      field: "RAIL_DESTN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail Dest Description",
      field: "RAIL_DESTN_DESCRIPTION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Tracking No",
      field: "TRACKING_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Yard",
      field: "YARD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc X",
      field: "LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Y",
      field: "LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Z",
      field: "LOC_Z",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Operator ID",
      field: "OPERATOR_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Salvaging Remarks",
      field: "SALVAGING_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Operator Remarks",
      field: "OPERATOR_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Code Reason",
      field: "HOLD_CODE_REASON",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Operator Remarks",
      field: "HOLD_OPERATOR_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release Remarks",
      field: "RELEASE_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "QA Person Id",
      field: "QA_PERSON_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch AIM TDC",
      field: "MOTHER_BATCH_AIM_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch TDC",
      field: "MOTHER_BATCH_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch Prod CD",
      field: "MOTHER_BATCH_PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Source Plant",
      field: "SOURCE_PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "LYS/YS",
      field: "LYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG Material No",
      field: "FG_MATERIAL_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Material Desc",
      field: "FG_MAT_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Raw Material No",
      field: "RAW_MATRL_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mother Charg Desc",
      field: "MOTHER_CHARG_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SCO Order",
      field: "SCO_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "SCO Item",
      field: "SCO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "SPC",
      field: "SPC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "SPC Name",
      field: "SPC_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice No",
      field: "INVOICE_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice Date",
      field: "INVOICE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Delivery No.",
      field: "DELIVERY_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Delivery Item",
      field: "DELIVERY_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Indent Age",
      field: "AGE_INDENT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Age in Same Status",
      field: "STATUS_AGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Transition Slab",
      field: "EIC_TRANSITION_SLAB",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Inv Loss",
      field: "INV_LOSS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0001 Inventory Information" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  let arr_select = [
    [],
    orderStatusData,
    [],
    customerData,
    [],
    orderTypeData,
    tdcData,
    // prodData,
    qltyData,
  ];
  // Page Load
  React.useEffect(() => {
    setLoading(true);
    //fetchOrderIdData();
    fetchPlantData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: column,
          height: 400,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setEpaData(varData);
            setSelectedItem(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // const fetchOrderIdData = () => {
  //   setLoading(true);
  //   GetAuthorization().then((token: TokenType) => {
  //     SPC0001GetOrderIdApi(token)
  //       .then((res) => {
  //         if (res.statusText !== "" && res.statusText !== "OK") {
  //           alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //         } else if (res?.data) {
  //           const varData1: Array<SelectType> = [];
  //           res.data?.order?.map((x: TableType, i: number) => (
  //             <React.Fragment key={i}>
  //               {varData1.push({
  //                 value: x.ENC_ID_ORDER?.toString(),
  //                 label: x.ENC_ID_ORDER?.toString(),
  //                 id: i,
  //               })}
  //             </React.Fragment>
  //           ));
  //           setOrderData(varData1);
  //           const varData2: Array<SelectType> = [];
  //           res.data?.orderStatus?.map((x: TableType, i: number) => (
  //             <React.Fragment key={i}>
  //               {varData2.push({
  //                 value: x.ENC_ST_ORDER?.toString(),
  //                 label: x.ENC_ST_ORDER?.toString(),
  //                 id: i,
  //               })}
  //             </React.Fragment>
  //           ));
  //           setOrderStatusData(varData2);
  //           const varData3: Array<SelectType> = [];
  //           res.data?.customer?.map((x: TableType, i: number) => (
  //             <React.Fragment key={i}>
  //               {varData3.push({
  //                 value: x.ENC_CD_END_CUST?.toString(),
  //                 label: x.ENC_CD_END_CUST?.toString(),
  //                 id: i,
  //               })}
  //             </React.Fragment>
  //           ));
  //           setCustomerData(varData3);
  //           const varData4: Array<SelectType> = [];
  //           res.data?.orderType?.map((x: TableType, i: number) => (
  //             <React.Fragment key={i}>
  //               {varData4.push({
  //                 value: x.ENC_ID_ORDER?.toString(),
  //                 label: x.ENC_ID_ORDER?.toString(),
  //                 id: i,
  //               })}
  //             </React.Fragment>
  //           ));
  //           setOrderTypeData(varData4);
  //         }
  //       })
  //       .catch((e) => {
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something Wents wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };
  const fetchData = () => {
    if (!(selectedItem?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      epa: selectedItem?.split(" - ")[0],
      process: selectedProcess,
      status: status,
      batch: selectedBatch,
      parentBatch: parentBatch,
      mBatch: selectedMBatch,
      materialNo: inputObj.key1.value,
      tdc: inputObj.key2.value,
      prodCd: inputObj.key3.value,
      //qltyCd: inputObj.key8.value,
      productionDateFr: DateFormat(inputObj.key4.value),
      productionDateTo: DateFormat(inputObj.key5.value),
      deliveryDateFr: DateFormat(inputObj.key6.value),
      deliveryDateTo: DateFormat(inputObj.key7.value),
      ThickFr: inputObj.key8.value,
      ThickTo: inputObj.key9.value,
      widthFr: inputObj.key10.value,
      widthTo: inputObj.key11.value,
      prodForm: prodForm,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0001GetInvData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setTableData(res.data);
          } else {
            setTableData([]);
            alertify.error("No data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchMonData = () => {
    if (!(selectedItem?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      epa: selectedItem?.split(" - ")[0],
    };
    setLoading(true);
    GetAuthorization().then((token: any) => {
      SPC0001GetInvMonData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setTableData(res.data);
          } else {
            setTableData([]);
            alertify.error("No data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleClearAll = () => {
    setSelectedMaterialNo("");
    setTableData([]);
    setInputObj(varInput);
    setStatus("");
    setSelectedProcess("");
    setSelectedBatch("");
    setParentBatch("");
    setSelectedMBatch("");
    setProdForm("");
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedItem}
                            data={epaData}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedItem(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"process"}
                            value={selectedProcess}
                            label="Process"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedProcess(e.toUpperCase().slice(0, 1));
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"Status"}
                            value={status}
                            label="Status"
                            size={"small"}
                            onChange={(e: string) => {
                              setStatus(e.toUpperCase().slice(0, 2));
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"Batch"}
                            value={selectedBatch}
                            label="Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"parentBatch"}
                            value={parentBatch}
                            label="Parent Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setParentBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <Input
                            id={"MBatch"}
                            value={selectedMBatch}
                            label="MBatch"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedMBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={1.5}>
                        <Input
                          id={"MaterialNo"}
                          value={selectedMaterialNo}
                          label="MaterialNo"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedMaterialNo(e);
                          }}
                        />
                      </Grid> */}
                        {formData?.map(
                          (x: FormType, i: number) =>
                            i < 3 && (
                              <React.Fragment key={i}>
                                <Grid item xs={i === 0 ? 1.4 : 1.2}>
                                  {x?.data?.config?.type === "select" ? (
                                    <SelectInput
                                      id={x?.key}
                                      data={arr_select[i]}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  ) : (
                                    <Input
                                      id={x?.key}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  )}
                                </Grid>
                              </React.Fragment>
                            )
                        )}

                        <Grid item xs={2}>
                          <SelectInput
                            id={"prodForm"}
                            value={prodForm}
                            data={prdFormList}
                            label="Product Form"
                            size={"small"}
                            onChange={(e: string) => {
                              setProdForm(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={3.5}>
                          <Box component="span">
                            {" "}
                            {/* Production Date */}
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 3 &&
                                  i < 5 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        // onChange={x?.data?.onChange}
                                        onChange={(e: string) => {
                                          if (x?.data?.onChange) {
                                            x.data.onChange(e);
                                          }
                                          setTableData([]);
                                        }}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        {/* <Grid item xs={3}>
                        <Box component="span">
                          {" "}
                          Dispatch Date
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 5 &&
                                i < 7 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid> */}
                        <Grid item xs={3}>
                          <Box component="span">
                            {" "}
                            {/* Thickness */}
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 7 &&
                                  i < 9 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <Input
                                        id={x?.key}
                                        value={x?.data?.value}
                                        {...x?.data?.config}
                                        // onChange={x?.data?.onChange}
                                        onChange={(e: string) => {
                                          if (x?.data?.onChange) {
                                            x.data.onChange(e);
                                          }
                                          setTableData([]);
                                        }}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={3}>
                          <Box component="span">
                            {" "}
                            {/* Width */}
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 9 &&
                                  i < 11 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <Input
                                        id={x?.key}
                                        value={x?.data?.value}
                                        {...x?.data?.config}
                                        // onChange={x?.data?.onChange}
                                        onChange={(e: string) => {
                                          if (x?.data?.onChange) {
                                            x.data.onChange(e);
                                          }
                                          setTableData([]);
                                        }}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>

                        <Grid item xs={1.5}>
                          <ButtonElement onClick={fetchData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                        <Grid item xs={2}>
                          <ButtonElement onClick={fetchMonData}>
                            Stk on 1st
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0001;
