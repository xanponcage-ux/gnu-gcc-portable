import { Request, Response } from "express";
import SPO0001Model from "../models/SPO0001Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0001Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getProdData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0001Model.prototype.getProdData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
