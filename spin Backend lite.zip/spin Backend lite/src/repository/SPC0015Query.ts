import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";

export const getSubrangeMaster = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT 
      SSM_CD_EPA PLANT, 
      SSM_SUBRANGE_CD SUBRANGE_CD, 
      SSM_SUBRANGE_DESC SUBRANGE_DESC, 
      SSM_CD_STATUS STATUS,
      SSM_CRT_DT CREATE_DT, 
      SSM_CRT_BY CREATED_BY, 
      SSM_UPD_DT UPDATE_DT, 
      SSM_UPD_BY UPDATED_BY 
    FROM V_SUBRNG_MAST
    WHERE SSM_CD_EPA = :code`;
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getPackageSubrange = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT 
      SPM_CD_EPA PLANT, 
      SPM_PKG_SUBRAN_CD SUBRANGE_CD, 
      SPM_PKG_SUBRAN_DESC SUBRANGE_DESC, 
    
      SPM_STATUS STATUS, 
      SPM_CRT_USER CREATE_USER, 
      SPM_CRT_DT CREATE_DT, 
      SPM_UPD_USER UPDATE_USER, 
      SPM_UPD_DT UPDATE_DT 
    FROM V_SUBRNG_PKG_MAST
    WHERE SPM_CD_EPA = :code`;
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getProcessSubrange = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT 
      ERT_CD_EPA PLANT, 
      ERT_PROC_CD PROC_CD, 
      ERT_SUBPROC_CD SUBPROC_CD, 
      ERT_SUBRAN_CD SUBRANGE_CD, 
      ERT_SUBRAN_DESC SUBRANGE_DESC,
      ERT_SEC2_MIN WIDTH_MIN, 
      ERT_SEC2_MAX WIDTH_MAX, 
      ERT_STATUS STATUS, 
      ERT_CRT_USER CREATE_USER, 
      ERT_CRT_DT CREATE_DT,
      ERT_UPD_USER UPDATE_USER, 
      ERT_UPD_DT UPDATE_DT 
    FROM V_SUBRNG_PROC_MAST
    WHERE ERT_CD_EPA = :code`;
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
