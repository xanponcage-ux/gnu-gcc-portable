import API from 'src/constant/api';
import AxiosApi from './axiosAPI';
import ENV from 'src/constant/env';
import { LoginData } from './type';

export const LoginApi = (data: LoginData) => {
    return AxiosApi(
        {
            method: 'POST',
            url: API[ENV.server].Login,
            data: data
        }
    )
}
export const GenaratePasscodeApi = (data: LoginData) => {
    return AxiosApi(
        {
            method: 'POST',
            url: API[ENV.server].GenaratePasscode,
            data: data
        }
    )
}
