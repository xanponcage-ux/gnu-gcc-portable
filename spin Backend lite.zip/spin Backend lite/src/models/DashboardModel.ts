import { piechart1,piechart2,linegraph1,linegraph2 } from "../repository/DashboardQuery";

export default class DashboardModel {
  piechart1() {
    return piechart1();
  }
  piechart2() {
    return piechart2();
  }
  linegraph1() {
    return linegraph1();
  }
  linegraph2() {
    return linegraph2();
  }
}
