// const SPO0003Query = require("../repository/SPO0003Query");
import * as repo from "../repository/SPO0003Query";

export default class SPO0003Model {
  SPO0003Modal(data: any) {
    return repo.SPO0003Query(data);
  }
  getHoldRsn(data: any) {
    return repo.getHoldRsn();
  }
  getSlitPos(data: any) {
    return repo.getSlitPos();
  }
}
