import { Router } from "express";
import // getData01,
// getEpaData01,
"../controllers/gateEntryController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const gateEntryRoute = Router();

// gateEntryRoute.route('/gateEntry/getData').post(authenticationMiddleware.bearer, getData01);
// gateEntryRoute.route('/gateEntry/getEpaData').get(authenticationMiddleware.bearer, getEpaData01);
export default gateEntryRoute;
