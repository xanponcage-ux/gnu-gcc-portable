// const SPO0002Query = require("../repository/SPO0002Query");
import * as repo from "../repository/SPO0002Query";

export default class SPO0002Model {
  getData(data: any) {
    return repo.getData(data);
  }
  ConfirmPacking(data: any) {
    return repo.ConfirmPacking(data);
  }
  confirm(data: any) {
    return repo.confirm(data);
  }
}
