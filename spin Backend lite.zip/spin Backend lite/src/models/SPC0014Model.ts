import { getData, getStatusData } from "../repository/SPC0014Query";

export default class SPC0014Model {
  getData(data: any) {
    return getData(data);
  }
  getStatusData(data: any) {
    return getStatusData(data);
  }
}
