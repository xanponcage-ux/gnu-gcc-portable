import { Request, Response } from "express";
import SPC0016Model from "../models/SPC0016Model";
import { ResponceData } from "../utils";

export const getData = async (req: Request, res: Response) => {
  try {
    console.log("Controller recieved:", req.body);
    const result1 = await SPC0016Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getStatusData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0016Model.prototype.getStatusData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
