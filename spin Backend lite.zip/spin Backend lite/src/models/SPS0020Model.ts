// const SPS0020Query = require("../repository/SPS0020Query");

import * as SPS0020Query from "../repository/SPS0020Query";

export default class SPS0020Model {
  getPlantCode(data: any) {
    return SPS0020Query.getPlantCode();
  }
  getReportType(data: any) {
    return SPS0020Query.getReportType();
  }
  getSourcePlant(data: any) {
    return SPS0020Query.getSourcePlant(data);
  }
  getTableData(data: any) {
    return SPS0020Query.getTableData(data);
  }
  getyieldwisedata(data: any) {
    return SPS0020Query.getyieldwisedata(data);
  }
  getSecondsData(data: any) {
    return SPS0020Query.getSecondsData(data);
  }
  getScrapData(data: any) {
    return SPS0020Query.getScrapData(data);
  }
}
