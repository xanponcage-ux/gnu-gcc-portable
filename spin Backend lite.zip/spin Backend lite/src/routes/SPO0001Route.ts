import { Router } from "express";
import { getData, getProdData } from "../controllers/SPO0001Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPO0001Route = Router();

SPO0001Route.route("/SPO0001/getData").post(
  authenticationMiddleware.bearer,
  getData
);
SPO0001Route.route("/SPO0001/getProdData").post(
  authenticationMiddleware.bearer,
  getProdData
);

export default SPO0001Route;
