import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  GetPlantDataApi,
  SPC0014GetData,
  SPC0014GetStatusData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0014 = () => {
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [motherBatch, setMotherBatch] = React.useState<string>("");
  const [status, setStatus] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");

  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);

  const actionList: Array<SelectType> = [
    { value: "I", label: "FG", id: 1 },
    { value: "S", label: "SCRAP", id: 2 },
    { value: "R", label: "REVERSAL", id: 2 },
  ];

  const [selectedAction, setSelectedAction] = React.useState<string>(
    actionList[0].value
  );

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
    getStatusData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    if (!(selectedAction?.length > 0)) {
      alertify.error("Please select Action!");
      return;
    }

    const data = {
      plant: selectedPlant,
      batchId: batchId ? batchId : "",
      motherBatch: motherBatch ? motherBatch : "",
      action_cd: selectedAction ? selectedAction : "",
      status: selectedStatus ? selectedStatus : "",
      // dateFrom: DateFormat(dateFrom) ? DateFormat(dateFrom) : "",
      // dateTo: DateFormat(dateTo) ? DateFormat(dateTo) : "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0014GetData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          }
          if (res?.data?.length == 0) {
            setTableData(res.data);
            alertify.error("No Data Found!");
          } else if (res?.data) {
            setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getStatusData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0014GetStatusData(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData1: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.STATUS?.toString(),
                  label: x.STATUS?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            console.log("varData1: ", varData1);
            setStatus(varData1);
            setSelectedStatus(varData1[0]?.value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: tableCol,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const tableCol: Array<CulmnType> = [
    {
      title: "Timestamp",
      field: "TIMEDT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Batch",
      field: "FG_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Material",
      field: "FG_MATERIAL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Gross Wt",
      field: "GRS_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Scrap Wt",
      field: "SCR_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Parent Material",
      field: "PARENT_MATERIAL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Error Cd",
      field: "ERR_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "L Sco No",
      field: "L_SCO_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "L Sco Item No",
      field: "L_SCO_ITEM_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sco Order",
      field: "SCO_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sco Item",
      field: "SCO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Passed Proc",
      field: "PASSED_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Budat",
      field: "BUDAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG PCode",
      field: "FG_PCODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG QCode",
      field: "FG_QCODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG Thick",
      field: "FG_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "FG Width",
      field: "FG_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "FG Length",
      field: "FG_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "No of Pcs",
      field: "NO_OF_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG Tdc",
      field: "FG_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Scrp Matnr",
      field: "SCRP_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cust Order",
      field: "CUST_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cust Item",
      field: "CUST_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Stage Cd",
      field: "STAGE_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Rec Type",
      field: "REC_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Pi Status",
      field: "PI_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Pi Ack Time",
      field: "PI_ACK_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Final Time",
      field: "FINAL_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Pi Source Pgm",
      field: "PI_SOURCE_PGM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Location",
      field: "LOCATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Source Plant",
      field: "SOURCE_PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Pack Cd",
      field: "PACK_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Oil Type",
      field: "OIL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "CS Indicator",
      field: "CS_INDICATOR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SCO RATE",
      field: "SCO_RATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PI IB MESSAGE ID",
      field: "PI_IB_MESSAGE_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PI OB MESSAGE ID",
      field: "PI_OB_MESSAGE_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "CREATION TIMESTAMP",
      field: "CREATION_TIMESTAMP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PICK TIMESTAMP",
      field: "PICK_TIMESTAMP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC1",
      field: "PRC1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC2",
      field: "PRC2",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC3",
      field: "PRC3",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC4",
      field: "PRC4",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC5",
      field: "PRC5",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC6",
      field: "PRC6",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC7",
      field: "PRC7",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC8",
      field: "PRC8",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC9",
      field: "PRC9",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PRC10",
      field: "PRC10",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleClearAll = () => {
    setBatchId("");
    setMotherBatch("");
    setSelectedAction("");
    setTableData([]);
    setSelectedStatus("");
  };

  const downloadExcel = () => {
    if (tableData?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "Error Report" + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedPlant}
                            data={plant}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedPlant(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1.8}>
                          <SelectInput
                            label="Action*"
                            data={actionList}
                            value={selectedAction}
                            onChange={(e: string) => {
                              setSelectedAction(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <Input
                            id={"batchId"}
                            value={batchId}
                            label="Batch Id"
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <Input
                            id={"motherBatch"}
                            value={motherBatch}
                            label="Mother Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setMotherBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1.2}>
                          <SelectInput
                            id={"status"}
                            value={selectedStatus}
                            data={status}
                            label="Status"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedStatus(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={2}>
                          <DatePickerInput
                            label="Date From"
                            // id={x?.key}
                            value={dateFrom}
                            onChange={(e: string) => {
                              setDateFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Date To"
                            // id={x?.key}
                            value={dateTo}
                            onChange={(e: string) => {
                              setDateTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid> */}

                        <Grid item xs={1}>
                          <ButtonElement onClick={getTableData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0014;
