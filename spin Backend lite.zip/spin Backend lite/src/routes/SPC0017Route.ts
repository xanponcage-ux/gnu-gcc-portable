import { Router } from "express";
import { getData, getStatusData } from "../controllers/SPC0017Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0017Route = Router();

SPC0017Route.route("/SPC0017/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPC0017Route.route("/SPC0017/getStatusData").get(
  authenticationMiddleware.bearer,
  getStatusData
);

export default SPC0017Route;
