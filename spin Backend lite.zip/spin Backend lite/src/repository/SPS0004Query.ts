import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getBatchData = async (data: any) => {
  try {
    let qry: any = `SELECT 
              EOM_ID_BATCH AS BATCH_ID,
              EOM_SEC1 AS THICK, 
              EOM_SEC2 AS WIDTH,
              EOM_LENGTH AS LENGTH,
              EOM_TDC_ACTL AS TDC,
              EOM_MS_PIECE_ACTL AS NET_QTY, 
              EOM_MS_GROSS_ACTL AS GROSS_QTY,
              EOM_CD_PROD AS PROD_CD,
              EOM_CD_QLTY_ACTL AS QLTY_CD,
              EOM_CD_PACK AS PACKING_CD,
              EOM_CD_OIL AS OILING_CD,
              EOM_CD_STATUS AS STATUS,
              EOM_IDIA AS IDIA,
              EOM_ODIA AS ODIA,
              EOM_ID_PAR_COIL_NO AS PARENT_BATCH,
              EOM_ID_FIRST_PAR AS MOTHER_BATCH,
              EOM_ID_ORD_CUS_AIM,
              EOM_ID_ITM_CUS_AIM,
              EOM_CD_EPA AS PLANT,
              (SELECT EIC_POST_TREAT_ACTL FROM V_INPUT_COIL WHERE EIC_ID_COIL = EOM_ID_FIRST_PAR) MCOIL_POST_TREAT,
              EOM_NO_MATNR MAT_NO,
              EOM_PASSED_PROC PASS_PROC
              FROM V_EPA_PRODN 
              WHERE EOM_CD_STATUS = 'WF'
              AND EOM_CD_EPA = '${data?.plant}'`;

    if (data?.mBatch && data?.mBatch?.length > 0) {
      qry += ` and EOM_ID_FIRST_PAR = '${data?.mBatch}'`;
    }

    if (data?.tdc && data?.tdc?.length > 0) {
      qry += ` and EOM_TDC_ACTL = '${data?.tdc}'`;
    }

    if (data?.prodCd && data?.prodCd?.length > 0) {
      qry += ` and EOM_CD_PROD = '${data?.prodCd}'`;
    }

    if (data?.thick && data?.thick?.length > 0) {
      qry += ` and EOM_SEC1 = '${data?.thick}'`;
    }

    if (data?.width && data?.width?.length > 0) {
      qry += ` and EOM_SEC2 = '${data?.width}'`;
    }

    return await query(qry);
  } catch (error: any) {
    console.log("SPS0004-getBatchData-error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getBatchDLinkData = async (data: any) => {
  try {
    let qry: any = ` SELECT 
    EOM_ID_BATCH AS BATCH_ID,
    EOM_SEC1 AS THICK, 
    EOM_SEC2 AS WIDTH,
    EOM_TDC_ACTL AS TDC,
    EOM_MS_PIECE_ACTL AS NET_QTY, 
    EOM_MS_GROSS_ACTL AS GROSS_QTY,
    EOM_CD_PROD AS PROD_CD,
    EOM_CD_QLTY_ACTL AS QLTY_CD,
    EOM_CD_PACK AS PACKING_CD,
    EOM_CD_OIL AS OILING_CD,
    EOM_CD_STATUS AS STATUS,
    EOM_IDIA AS IDIA,
    EOM_ODIA AS ODIA,
    EOM_ID_PAR_COIL_NO AS PARENT_BATCH,
    EOM_ID_FIRST_PAR AS MOTHER_BATCH,
    EOM_ID_ORD_CUS_AIM,
    EOM_ID_ITM_CUS_AIM,
    EOM_CD_EPA AS PLANT,
    b.ENC_ID_ORDER,
    b.ENC_NO_ITEM,
    b.ENC_MARK_CUST,
    b.ENC_MARK_CUST_NAME,
    b.ENC_NO_MATNR,
    (SELECT MAKTG FROM V_MAKT WHERE MATNR = ENC_NO_MATNR ) FG_MAT_DESC
    FROM 
        V_EPA_PRODN a 
    JOIN 
        V_END_CUST_ORD_EPA b 
    ON 
        a.EOM_ID_ORDER_CUS = b.ENC_ID_ORDER and
        a.EOM_ID_ORD_ITEM_CUS = b.ENC_NO_ITEM
    WHERE 
        EOM_CD_EPA = '${data.plant}'
        AND EOM_CD_STATUS = 'WB'`;

    if (data?.mBatch && data?.mBatch?.length > 0) {
      qry += ` and EOM_ID_FIRST_PAR = '${data?.mBatch}'`;
    }

    if (data?.tdc && data?.tdc?.length > 0) {
      qry += ` and EOM_TDC_ACTL = '${data?.tdc}'`;
    }

    if (data?.prodCd && data?.prodCd?.length > 0) {
      qry += ` and EOM_CD_PROD = '${data?.prodCd}'`;
    }

    if (data?.thick && data?.thick?.length > 0) {
      qry += ` and EOM_SEC1 = '${data?.thick}'`;
    }

    if (data?.width && data?.width?.length > 0) {
      qry += ` and EOM_SEC2 = '${data?.width}'`;
    }

    return await query(qry);
  } catch (error: any) {
    console.log("SPS0004-getBatchDLinkData-error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getFittingOrderData = async (data: any) => {
  try {
    const pass_proc = data?.pass_proc || "";
    console.log("pass_proc: ", pass_proc);
    let qry: any = `SELECT ENC_ID_ORDER, ENC_NO_ITEM, ENC_ORDER_TYPE,
                    ENC_SEC1_MAX, ENC_SEC1_MIN, ENC_SEC2_MAX, ENC_SEC2_MIN,
                    ENC_NO_TDC, ENC_CD_PROD, ENC_CD_QLTY, 
                    ENC_MARK_CUST_NAME, ENC_CD_SHIP_TO_PRTY, ENC_FRT_IND, 
                    ENC_ORDER_EDGE, ENC_DT_ORD_CREATE, ENC_DESPATCH_WK, ENC_ODIA, ENC_POST_TREAT
                    --EOM_ID_BATCH, EOM_SEC1, EOM_SEC2, EOM_TDC_ACTL, EOM_ODIA
                    FROM V_END_CUST_ORD_EPA                    
                    WHERE '${data.thick}' >= ENC_SEC1_MIN
                    AND '${data.thick}' <= ENC_SEC1_MAX
                    AND '${data.width}' >= ENC_SEC2_MIN
                    AND '${data.width}' <= ENC_SEC2_MAX  
                    AND ENC_NO_TDC = '${data.tdc}'
                    AND ENC_IDIA = '${data.idia}' `;
    // AND ENC_NO_MATNR = '${data?.mat_no}' `; //Matnr added on 22.05.26, mat check removed on 15.06.26

    // Length check added on 15.06.26, for ctl batches
    if (
      pass_proc?.includes("N") ||
      pass_proc?.includes("T") ||
      pass_proc?.includes("E")
    ) {
      qry += `AND ${data.length} >= ENC_LENGTH_MIN
              AND ${data.length} <= ENC_LENGTH_MAX
  `;
    }

    console.log("SPS0004-getFittingOrderData-qry: ", qry);

    return await query(qry);
  } catch (error: any) {
    console.log("SPS0004-getFittingOrderData-error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const saveData = async (data: any) => {
  try {
    if (data?.tabValue === 1) {
      //For D linking
      let sql: any = `call TDSB0008(
        ls_batchid => :ls_batchid,
        ls_ord => :ls_ord,
        ln_item => :ln_item,
        ls_user => :ls_user,
        ls_out_flag => :ls_out_flag 
        )`;

      const binds = {
        ls_batchid: data?.batchId ? data?.batchId : "",
        ls_ord: data?.ordId ? data?.ordId : "",
        ln_item: data?.item ? data?.item : "",
        ls_user: data?.user ? data?.user : "",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      const result = await query(sql, binds);
      return result;
    } else if (data.tabValue === 0) {
      //For Linking
      let sql: any = `call TDSB0007(
        ls_batchid => :ls_batchid,
        ls_ord => :ls_ord,
        ln_item => :ln_item,
        ls_user => :ls_user,
        ls_out_flag => :ls_out_flag 
        )`;

      const binds = {
        ls_batchid: data?.batchId ? data?.batchId : "",
        ls_ord: data?.ordId ? data?.ordId : "",
        ln_item: data?.item ? data?.item : "",
        ls_user: data?.user ? data?.user : "",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      const result = await query(sql, binds);
      return result;
      // return await query(sql, binds);
    }
  } catch (error: any) {
    console.log("SPS0004-saveData-error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getChemChk = async (data: any) => {
  try {
    let qry: any = `select F_CHEM_CHK('${data?.plant}','${data?.batchId}','${data?.tdc}') as fm_chk FROM DUAL`;

    const res = await query(qry);
    return res;
  } catch (error: any) {
    console.log("SPS0004-getChemChk-error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
