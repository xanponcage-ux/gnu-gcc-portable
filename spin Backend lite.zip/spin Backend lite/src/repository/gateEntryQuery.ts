import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";

// export const getData01 = async (data: any) => {
//   try {
//     let binds: any = {
//       epaCode: data?.code
//     }
//     let sql:any = `SELECT NVL(EIC_ID_COIL, '') "Coil Id", NVL(EIC_NO_INVOICE, 0) "Invoice No", TO_CHAR(EIC_DT_INVOICE,'DD-MON-YYYY')"Invoice Date"

//     ,NVL(EIC_NO_DELIVERY, 0) "Delivary No",NVL(EIC_CD_PROD, '') "Prod Cd",NVL(EIC_CD_QLTY_ACTL, '') "Qlty Cd",NVL('', ' ') "Grade_Desc",NVL(EIC_SEC1, 0) "Thick", NVL(EIC_SEC2, 0) "Width",NVL(EIC_TDC_ACTL, '') "TDC"
    
//     ,NVL(EIC_NO_MATNR, 0) "Material no",NVL(EIC_NO_CAST, '') "Cast_No"
    
//     ,NVL(EIC_CD_EDGE, '') "Edge",NVL(EIC_MS_PIECE_ACTL, 0) "Invoice Weight" ,(EIC_MS_PIECE_ACTL-nvl(EIC_MS_SCRAP,0)) "Residual Weight",NVL(EIC_ID_LOC_X, 0) EIC_ID_LOC_X, NVL(EIC_ID_LOC_Y, 0) EIC_ID_LOC_Y,NVL(EIC_ID_POS, 0) EIC_ID_POS,NVL(EIC_CD_YRD, 0) EIC_CD_YRD
    
//     ,NVL(EIC_REMARKS, ' ') EIC_REMARKS,NVL(EIC_MS_PIECE_ACTL, 0) "SPC Wt", NVL(EIC_CD_STATUS, '') EIC_CD_STATUS, NVL(EIC_CD_EPA, '') EIC_CD_EPA , NVL(EIC_ID_OP_SCRAP, '') "Operator ID", NVL(EIC_MARK_CUST, '') "Customer Code"
    
//     --,(select NAME1 from v_kna1 where mandt='600' AND KUNNR = LPAD(EIC_MARK_CUST ,10,'0') AND ROWNUM=1) "CustNM"
    
//     ,NVL('', 0) "CustNM"
    
//     ,NVL('', ' ') "Salvaging Remarks"
    
//     ,NVL(EIC_PASSED_PROC, '') "Mill Passed Process"
    
//     ,round((sysdate-EIC_DT_INVOICE)) "Invoice Age"
    
//     ,round((sysdate-nvl(EIC_DT_LOADING,sysdate))) "Age at SPC", TO_CHAR(EIC_DT_LOADING, 'DD-MON-YYYY') "Arrival Dt"
    
//     ,ROUND(nvl(EIC_DT_LOADING,sysdate)-nvl(EIC_DT_INVOICE,sysdate)) "Transit Lead Time(Days)"
    
//     ,(select  round((sysdate-nvl(min(EOM_TS_CREATION), sysdate)))  from v_epa_prodn where eom_cd_epa =EIC_CD_EPA and eom_id_first_par=EIC_ID_COIL and eom_id_batch <> eom_id_first_par) "Processing Date"
    
//     FROM V_INPUT_COIL
    
//     WHERE EIC_CD_EPA=:epaCode`
//   if(data.process && data.process?.length > 0) {
//     sql += ` AND EIC_CD_STATUS = :process`
//     binds['process'] = data?.process;
//   }
//   if(data.tdc && data.tdc?.length > 0) {
//     sql += ` AND EIC_TDC_ACTL = :tdc`
//     binds['tdc'] = data?.tdc;
//   }
//   if(data.batchId && data.batchId?.length > 0) {
//     sql += ` AND EIC_ID_COIL = :batchId`
//     binds['batchId'] = data?.batchId;
//   }
//   if(data.invoiceNo && data.invoiceNo?.length > 0) {
//     sql += ` AND EIC_NO_INVOICE = :invoiceNo`
//     binds['invoiceNo'] = data?.invoiceNo;
//   }
//   if(data.materialNo && data.materialNo?.length > 0) {
//     sql += ` AND EIC_NO_MATNR = :materialNo`
//     binds['materialNo'] = data?.materialNo;
//   }
//   if(data.prodCode && data.prodCode?.length > 0) {
//     sql += ` AND EIC_CD_PROD = :prodCode`
//     binds['prodCode'] = data?.prodCode;
//   }
//   if(data.qltyCode && data.qltyCode?.length > 0) {
//     sql += ` AND EIC_CD_QLTY_ACTL = :qltyCode`
//     binds['qltyCode'] = data?.qltyCode;
//   }
//   if (data?.invoiceDateFr) {
//     sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')` 
//     binds.invoiceDateFr = data?.invoiceDateFr;
//     binds.invoiceDateTo = data?.invoiceDateTo;
//   }
//   if (data?.receivingDateFr) {
//     sql += ` AND EIC_DT_LOADING BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')` 
//     binds.receivingDateFr = data?.receivingDateFr;
//     binds.receivingDateTo = data?.receivingDateTo;
//   }
//   // if (data?.processDateFr) {
//   //   sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:processDateFr,'01-JAN-1900') AND NVL(:processDateTo,'31-DEC-9999')` 
//   //   binds.processDateFr = data?.processDateFr;
//   //   binds.processDateTo = data?.processDateTo;
//   // }
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getStatusCodeData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_CD_STATUS
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getInvoiceData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_NO_INVOICE
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getMaterialData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_NO_MATNR
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getProdData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_CD_PROD
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getQltyData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_CD_QLTY_ACTL
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getTdcData01 = async () => {
//   try {
//     const sql: any = `SELECT
//     DISTINCT EIC_TDC_ACTL
//   FROM
//     V_INPUT_COIL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };