// const SCQ002Query = require("../repository/SCQ002Query");
import * as repo from "../repository/SCQ002Query";

export default class SCQ002Model {
  SCQ002Model(data: any) {
    if (data?.route === "getPageData") {
      if (!data?.plant) {
        return repo.SCQ002getPlantData(data);
      } else {
        return repo.SCQ002getBatchData(data);
      }
    } else if (data?.route === "batchChange") {
      return repo.SCQ002getBatchData(data);
    } else if (data?.route === "SCQ002getBatchInformation") {
      return repo.SCQ002getTableData(data);
    } else if (data?.route === "getRsnData") {
      return repo.SCQ002getRsnData(data);
    } else if (data?.route === "holdProcedure") {
      return repo.SCQ002Procedure(data?.data);
    } else if (data?.route === "updateHoldRemarks") {
      return repo.SCQ002updateHoldRemarks(data);
    } else if (data?.route === "wtReduce") {
      return repo.getHoldBatchForWtRed(data);
    } else if (data?.route === "saveAiAnalysis") {
      return repo.saveAiHoldAnalysis(data);
    } else if (data?.route === "isAiEnabled") {
      return repo.aiFeatureEnable(data);
    } else if (data?.route === "getprevAiAnalysis") {
      return repo.getPrevAiAnalysis(data);
    } else if (data?.route === "prevAiAnalysisExists") {
      return repo.prevAiAnalysisExists(data);
    }
  }
}
