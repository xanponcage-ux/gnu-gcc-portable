import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  GetPlantDataApi,
  SPC0016GetData,
  SPC0016GetStatusData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0016 = () => {
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [motherBatch, setMotherBatch] = React.useState<string>("");
  const [status, setStatus] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [remarks, setRemarks] = React.useState<string>("");

  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);

  const actionList = [
    { value: "REWORK", label: "REWORK", id: 1 },
    { value: "REPLAN", label: "REPLAN", id: 2 },
  ];

  const [selectedAction, setSelectedAction] = React.useState<string>(
    actionList[0].value
  );

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
    // getStatusData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  // TableData (with no alert on empty table)
  //   const getTableData = () => {
  //     if (!(selectedPlant?.length > 0)) {
  //       alertify.error("Please select Plant!");
  //       return;
  //     }

  //     if (!(selectedAction?.length > 0)) {
  //       alertify.error("Please select Action!");
  //       return;
  //     }

  //     const data = {
  //       plant: selectedPlant,
  //       batchId: batchId ? batchId : "",
  //       motherBatch: motherBatch ? motherBatch : "",
  //       action_cd: selectedAction ? selectedAction : "",
  //       // status: selectedStatus ? selectedStatus : "",
  //     };
  //     setLoading(true);
  // //     GetAuthorization().then((token: TokenType) => {
  // //       SPC0016GetData(token, data)
  // //         .then((res) => {
  // //           if (res.statusText !== "" && res.statusText !== "OK") {
  // //             alertify.error(res?.data?.err ? res.data.err : res?.toString());
  // //           } else if (res?.data) {
  // //             // Filter data based on selected action
  // //             const filteredData = res.data.filter((row: any) =>
  // //               row.CHR_RLS_REMARKS?.toLowerCase() === selectedAction.toLowerCase()
  // //             );
  // //             setTableData(filteredData);
  // //           }
  // //         })
  // //         .catch((e) => {
  // //           alertify.error(
  // //             e?.error?.message ? e.error.message : "Something Wents wrong!"
  // //           );
  // //         })
  // //         .finally(() => {
  // //           setLoading(false);
  // //         });
  // //     });
  // //   };

  // GetAuthorization().then((token: TokenType) => {
  //     SPC0016GetData(token, data)
  //       .then((res) => {
  //         console.log("Raw API Response:", res); // Debug log
  //         if (res.data) {
  //           console.log("Setting table data:", res.data); // Debug log
  //           setTableData(res.data);
  //           // Ensure Tabulator is reinitializing with new data
  //           if (table) {
  //             table.setData(res.data);
  //           }
  //         }
  //       })
  //       .catch((e) => {
  //         console.error("API Error:", e);
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something went wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };

  const getTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    if (!(selectedAction?.length > 0)) {
      alertify.error("Please select Action!");
      return;
    }

    const data = {
      plant: selectedPlant,
      batchId: batchId ? batchId : "",
      motherBatch: motherBatch ? motherBatch : "",
      action_cd: selectedAction ? selectedAction : "",
      // status: selectedStatus ? selectedStatus : "",
    };
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      SPC0016GetData(token, data)
        .then((res) => {
          console.log("Raw API Response:", res); // Debug log
          if (res.data) {
            console.log("Setting table data:", res.data); // Debug log

            if (res.data.length === 0) {
              alertify.error("No data to display");
            }

            setTableData(res.data);
            // Ensure Tabulator is reinitializing with new data
            if (table) {
              table.setData(res.data);
            }
          }
        })
        .catch((e) => {
          console.error("API Error:", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  // const getStatusData = () => {
  //   setLoading(true);
  //   GetAuthorization().then((token: TokenType) => {
  //     SPC0016GetStatusData(token)
  //       .then((res) => {
  //         if (res.statusText !== "" && res.statusText !== "OK") {
  //           alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //         } else if (res?.data) {
  //           const varData1: Array<SelectType> = [];
  //           res.data?.map((x: any, i: number) => (
  //             <React.Fragment key={i}>
  //               {varData1.push({
  //                 value: x.STATUS?.toString(),
  //                 label: x.STATUS?.toString(),
  //                 id: i,
  //               })}
  //             </React.Fragment>
  //           ));
  //           console.log("varData1: ", varData1);
  //           setStatus(varData1);
  //           setSelectedStatus(varData1[0]?.value);
  //         }
  //       })
  //       .catch((e) => {
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something Wents wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: tableCol,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const tableCol: Array<CulmnType> = [
    {
      title: "Batch ID",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Net Weight",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const value = cell?.getValue();
        return value ? value.toFixed(3) : value;
      },
    },
    {
      title: "Hold Date & Time",
      field: "HOLD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Code",
      field: "HOLD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Description",
      field: "HOLD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold By",
      field: "HOLD_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Remarks",
      field: "HOLD_REM_BY_OPR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Addl Rls Remarks",
      field: "ADL_RLS_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release Date & Time",
      field: "RELEASE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release By",
      field: "RELEASE_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release Remarks",
      field: "RELEASE_REMARK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC Actual",
      field: "EOM_TDC_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thickness",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const value = cell?.getValue();
        return value ? value.toFixed(3) : value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const value = cell?.getValue();
        return value ? value.toFixed(3) : value;
      },
    },
    {
      title: "Product Code",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Quality Code",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleClearAll = () => {
    setBatchId("");
    setMotherBatch("");
    setSelectedAction("");
    setTableData([]);
    setSelectedStatus("");
  };

  const downloadExcel = () => {
    if (tableData?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "Rework-Replan Report" + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedPlant}
                            data={plant}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedPlant(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2.5}>
                          <SelectInput
                            label="Action*"
                            data={actionList}
                            value={selectedAction}
                            onChange={(e: string) => {
                              setSelectedAction(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <Input
                            id={"batchId"}
                            value={batchId}
                            label="Batch Id"
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <Input
                            id={"motherBatch"}
                            value={motherBatch}
                            label="Mother Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setMotherBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={1.2}>
                          <SelectInput
                            id={"status"}
                            value={selectedStatus}
                            data={status}
                            label="Status"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedStatus(e);
                              setTableData([]);
                            }}
                          />
                        </Grid> */}

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Date From"
                            // id={x?.key}
                            value={dateFrom}
                            onChange={(e: string) => {
                              setDateFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Date To"
                            // id={x?.key}
                            value={dateTo}
                            onChange={(e: string) => {
                              setDateTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1}>
                          <ButtonElement onClick={getTableData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0016;
