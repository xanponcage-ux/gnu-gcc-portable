import { Request, Response } from "express";
import SPO0003Model from "../models/SPO0003Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const SPO0003Api = async (req: Request, res: Response) => {
  try {
    const result1 = await SPO0003Model.prototype.SPO0003Modal(req.body);
    return res.status(200).json(result1);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getHoldRsn = async (req: Request, res: Response) => {
  try {
    const result1 = await SPO0003Model.prototype.getHoldRsn(req.body);
    const finRes = await ResponceData(result1, true);
    return res.status(200).json(finRes);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getSlitPos = async (req: Request, res: Response) => {
  try {
    const result1 = await SPO0003Model.prototype.getSlitPos(req.body);
    const finRes = await ResponceData(result1, true);
    return res.status(200).json(finRes);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
