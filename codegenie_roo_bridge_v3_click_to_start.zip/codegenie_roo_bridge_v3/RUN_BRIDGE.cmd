@echo off
call "%~dp0START_CODEGENIE_BRIDGE.cmd"
