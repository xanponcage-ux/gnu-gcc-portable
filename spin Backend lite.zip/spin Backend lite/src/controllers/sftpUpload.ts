import { Request, Response } from "express";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import SftpClient from "ssh2-sftp-client";
import fs from "fs";
import path from "path";
import { GetIp } from "../utils";

function getEnvironment(): "local" | "dev" | "uat" | "prd" {
  const ipVal = GetIp();

  if (ipVal === "176.0.15.164") return "dev";
  if (ipVal === "176.0.15.247") return "uat";
  if (ipVal === "10.152.98.222") return "prd";

  return "local";
}

function getSftpConfig() {
  const envVal = getEnvironment();

  if (envVal === "prd") {
    return {
      host: "10.136.135.53",
      port: 22,
      username: "spcisprd",
      privateKey: fs.readFileSync("/home/unxadml3/sppinkeys/Spinpvtkey"),
    };
  }

  // local / dev / uat
  return {
    host: "10.136.135.53",
    port: 22,
    username: "spcis",
    privateKey: fs.readFileSync(
      path.resolve(__dirname, "../utils/PrivateKey/id_ras-pkcs1")
    ),
  };
}

function getRemoteDir() {
  const env = getEnvironment();

  return env === "prd"
    ? "/home/spcisprd/sppinprdfiles"
    : "/home/spcis/sppin_files";
}

// let varVal = "local";
// const ipVal = GetIp();
// if (ipVal === "176.0.15.164") {
//   varVal = "dev";
// } else if (ipVal === "176.0.15.247") {
//   varVal = "uat";
// } else if (ipVal === "10.152.98.222") {
//   varVal = "prd";
// }

// console.log("ipVal-sftp: ", ipVal);
// console.log("varVal-sftp: ", varVal);

export async function uploadFileToSftp(
  localFilePath: string,
  fileName: string
): Promise<string> {
  const sftp = new SftpClient();
  const sftpConfig = getSftpConfig();

  //   let remoteDir =
  //     varVal === "prd"
  //       ? "/home/spcisprd/sppinprdfiles"
  //       : "/home/spcis/sppin_files";

  const remoteDir = getRemoteDir();

  const remotePath = `${remoteDir}/${fileName}`;

  try {
    await sftp.connect(sftpConfig);

    const exists = await sftp.exists(remoteDir);
    if (!exists) {
      await sftp.mkdir(remoteDir, true);
    }

    await sftp.put(localFilePath, remotePath);
    return remotePath;
  } finally {
    await sftp.end();
  }
}

export const uploadSampleImage = async (req: Request, res: Response) => {
  try {
    console.log("Inside uploadSampleImage");
    console.log("req.file: ", req.file);
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const batchId = req.body.batchId;

    var countRec = await ResponceData(
      await query(
        `select count(1) as count from V_AI_SUGGESTION where ahs_id_batch = :batchId`,
        { batchId }
      )
    );
    console.log("countRec: ", countRec);
    countRec = countRec[0]?.COUNT;
    countRec++;

    if (!batchId) {
      return res.status(400).json({ error: "BatchId required" });
    }

    // VB naming: BatchId_count.ext (count=1 here)
    const ext = path.extname(req.file.originalname);
    const fileName = `0131_${batchId}_${countRec}${ext}`;
    console.log("fileName: ", fileName);

    // VB local folder: ~/testimg
    const localDir = path.resolve("testimg");
    if (!fs.existsSync(localDir)) {
      fs.mkdirSync(localDir, { recursive: true });
    }

    const localFilePath = path.join(localDir, fileName);
    console.log("localFilePath: ", localFilePath);
    console.log("req?.file?.path: ", req?.file?.path);

    // Move multer temp file → testimg
    fs.renameSync(req.file.path, localFilePath);

    // Upload to SFTP
    const remotePath = await uploadFileToSftp(localFilePath, fileName);
    fs.unlink(localFilePath, () => {});
    return res.json({
      fileName,
      remotePath,
    });
  } catch (err: any) {
    console.error("SFTP upload error:", err);
    return res.status(500).json({ error: err.message });
  }
};
