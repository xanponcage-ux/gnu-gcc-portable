import { Request, Response } from "express";
import SPC0003Model from "../models/SPC0003Model";
import { ResponceData } from "../utils";

export const SPC0003getData03 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    let result3;
    if (req.body.data === 0) {
      result1 = await SPC0003Model.prototype.getPackingCode03(req.body);
    }
    if (req.body.data === 1) {
      result2 = await SPC0003Model.prototype.getOilingCode03(req.body);
    }
    if (req.body.data === 2) {
      result3 = await SPC0003Model.prototype.getWidthTolData(req.body);
    }
    varData = {
      ...{ PackingCode: await ResponceData(result1) },
      ...{ Oilingcode: await ResponceData(result2) },
      ...{ widthTol: await ResponceData(result3) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const savePackingOiling = async (req: Request, res: Response) => {
  try {
    let results = await SPC0003Model.prototype.savePackingOiling(req.body);
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getPackCdList = async (req: Request, res: Response) => {
  try {
    let results = await SPC0003Model.prototype.getPackCdList();
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getPackSeq = async (req: Request, res: Response) => {
  try {
    let results = await SPC0003Model.prototype.getPackSeq(req.body);
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
