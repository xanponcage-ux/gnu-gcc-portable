from flask import Flask, request, jsonify
import tensorflow as tf
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession
import numpy as np
from PIL import Image
import io
from fastapi import FastAPI, HTTPException, status, APIRouter, Request

router = APIRouter()

# Load trained model
model = tf.keras.models.load_model('neu_model.keras', compile=False)
print("✅ Model loaded. Input shape:", model.input_shape)

# Define class names based on your model
CLASS_NAMES = ['HIGH_TEMPERATURE_SCALE', 'STICKY_SCALE', 'PICKLING_PATCH_BLACKBROWN', 'BANDED_SCALE_PITTING_MARK', 'ROLLED_IN_SCALE', 'SCRATCHES']

# Image preprocessing - matches your model's requirements
def preprocess_image(image_bytes):
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        img = img.resize((200, 200))  # Match your model's input size
        img_array = np.array(img) / 255.0  # Normalize as in your model
        img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
        return img_array
    except Exception as e:
        raise

async def CALL_GEMIMI(text,image_bytes):
    try: 
        url = "https://genai-api-development-one-it-423929642383.asia-south1.run.app"
        ### modify the path to the service account here as per the downloaded path to the json
        creds = service_account.IDTokenCredentials.from_service_account_file( '.\svc-genai-api-dev-oneit.json', target_audience=url)
        authed_session = AuthorizedSession(creds)
        messages = [ {"role": "system", 
                      "content": "Explain the type of object like upload image is coil or any serface or not. If this is coil then defind the defect as per steel industry."}, 
            ## context setting for the model
            {"role": "user", "content": text} ]
            ## Your prompt that goes into the Gen AI Model ]
        import json
        payload = { 'deployment_name': 'gemini-2.0-flash',# Other Option: gemini-2.0-flash
                'temperature': '0.1', # can range from 0-2
                'adid': '161606', # e.g., "your personal number â€“ eg - 123456"
                'apikey': 'BWF14TOV9SY6EO8E', # e.g., "key shared with you" 
                'messages': json.dumps(messages), 
                'tools': '<json part of tools>', # if custom tools are required, works with gpt-4o-mini only for now, you can use OpenAI tool calling formatted json for the same 
                'grounding': '1', # applicable only for gemini models for enabling google search 
                'max_tokens': '8000' 
                }

        files = {'file': ('image.jpg', image_bytes, 'image/jpeg')}
        headers= {} #keep headers as blank
        resp = await authed_session.post("https://tslgenaiapidev.corp.tatasteel.com/genai", headers=headers, data=payload, files=files)
        resp.raise_for_status()
        document_info = resp.json().get('candidates')[0].get('content').get('parts')[0].get('text')
        return document_info
    except Exception as e:
        raise


@router.post('/get')
async def check_defect(request: Request):
    """Surface defect detection API"""
    try:
        form_data = await request.form()
        # Access your file(s) by their HTML form field name

        if 'file' not in form_data:
            raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error_code": "NOT_FOUND", "message": "No file provided."}
        )
            
        file = form_data.get("file") 
        

        if not file or file.filename == '':
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "No selected file."}
        )

        if not file or file.filename.count('.') > 1:
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "Wrong Extention."}
        )

        # Validate extension 
        if not file.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "Invalid file type (only PNG, JPG, JPEG, BMP allowed)."}
        )

        # Preprocess and predict
        image_bytes = await file.read()
        img_array = preprocess_image(image_bytes)
        resp = await CALL_GEMIMI('explain the image is steel surface or not, If it is steel surface then, what is the defects in below steel image. please explain in short.', image_bytes)
        predictions = model.predict(img_array)
        predicted_class_idx = np.argmax(predictions[0])
        predicted_class = CLASS_NAMES[predicted_class_idx]
        
        # Format probabilities for all classes
        probabilities = {
            class_name: float(predictions[0][i]) 
            for i, class_name in enumerate(CLASS_NAMES)
        }

        return {
            'message': 'Defect detection complete',
            'predicted_class': predicted_class,
            'confidence': float(predictions[0][predicted_class_idx]),
            'all_probabilities': probabilities,
            'class_names': CLASS_NAMES,
            'AIResp': resp
        }

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": str(e)}
        )

@router.get('/health')
def health_check():
    return {
        'status': 'healthy',
        'model_loaded': True,
        'input_shape': str(model.input_shape),
        'classes': CLASS_NAMES
    }

