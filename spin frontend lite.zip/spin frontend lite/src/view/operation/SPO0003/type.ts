export interface InputDownType {
  key1: string;
  key2: string;
  key3: string;
  key4: string;
  key5: string;
  key6: string;
  key7: string;
  key8: string;
  key9: string;
}

export interface TableType {
  EPL_CD_PROCESS: string;
  EPL_PROC_LINE_DESC: string;
  PDS_ID_COIL: string;
  ID_COIL_COMP: string;
  ID_COIL_DR_M: string;
  DT_COIL_LIST: string;
  TPM_PACK_CD: string;
}
export interface PdiRequestForm {
  pdiStartDt: Date | null;
  pdiEndDt: Date | null;
}
export interface DaughterForm {
  daughterCoil: string;
  idPdi: string;
  motherCoil: string;
  proc: string;
  order: string;
  ordItem: string;
  crThick: string;
  CrWidth: string;
  crIdia: string;
  crOdia: string;
  netWt: string;
  grossWt: string;
  coilNo: string;
  length1: string;
  duration: string;
  packCd: string;
  userId: string;
  shift: string;
  hold_fl: string;
  pack_cd: string;
  opr_rem: string;
  plannedProc: string;
  nextProc: string;
  fgTdc: string;
  oil_type: string;
  productionStart: Date | null;
  productionEnd: Date | null;
  crNoPart: string;
  recoilerTension: string;
  edgeWaviness: string;
  burrHeight: string;
  ordEdge: string;
}

export interface MotherForm {
  motherCoil: string;
  crThick: string;
  CrWidth: string;
  crIdia: string;
  crOdia: string;
  actualWeight: string;
  length1: string;
  productionStart: Date | null;
  productionEnd: Date | null;
  processingTime: Date | null;
  residualWt: string;
  endCut: string;
  sideTrim: string;
  pupCoil: string;
  slitNo: string;
}

export interface OrderForm {
  ordMinThick: string;
  ordMaxThick: string;
  ordMinWidth: string;
  ordMaxWidth: string;
}
export interface DivisionForm {
  mCoilId: string;
  zCoilId: string;
  rem_wt: string;
  rem_length: string;
  odia: string;
  reason: string;
}

export interface MCoilDtlsForm {
  mThick: string;
  mWidth: string;
  mLength: string;
  mNxtProc: string;
  mPlannedProc: string;
  mOutTdc: string;
  mOutGradeDesc: string;
}
export interface PackingForm {
  pCoilId: string;
  pThick: string;
  pWidth: string;
  pOdia: string;
  pIdia: string;
  pNetWt: string;
  pGrossWt: string;
  packingCd: string;
  pStartDt: Date | null;
  pEndDt: Date | null;
}
