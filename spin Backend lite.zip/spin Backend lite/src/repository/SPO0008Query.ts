import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import moment from "moment";

export const getTroubleType = async () => {
  try {
    // const sql: any = `SELECT cd_type trblType, description trblDesc FROM v_trbl_typ_v1`;
    const sql: any = `SELECT cd_value trblType, cd_desc trblDesc FROM v_codes where cd_type = 'TK036'`;
    return await query(sql);
  } catch (error: any) {
    console.log("error-getTroubleType: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const EqpMastQuery = async () => {
  try {
    const sql = `SELECT DISTINCT FAO_CD_EQP_MAST equipMast FROM  V_FACILITY_OUTAGE`;
    return await query(sql);
  } catch (error: any) {
    console.log("error-EqpMastQuery: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const EqpCodeQuery = async () => {
  try {
    const sql = ` SELECT cd_value ||'-'||cd_desc cd_desc,cd_value FROM v_codes WHERE cd_type='EQPMT' ORDER BY CD_DESC1 `;
    return await query(sql);
  } catch (error: any) {
    console.log("error-EqpCodeQuery: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const agencyCodeQuery = async () => {
  try {
    const sql = `select * from v_codes where cd_type='DELAG' order by CD_VALUE`;
    return await query(sql);
  } catch (error: any) {
    console.log("error-agencyCodeQuery: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const delUser = async (usr: any) => {
  try {
    const sql = ` Select * from v_codes where cd_type='DLUSR' and CD_VALUE=:usr `;
    const binds = [`${usr}`];
    return await query(sql, binds);
  } catch (error: any) {
    console.log("error-delUser: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const FacCodeQuery = async () => {
  try {
    const sql = `SELECT DISTINCT FAO_CD_FAC_MAST facCode FROM V_FACILITY_OUTAGE`;
    return await query(sql);
  } catch (error: any) {
    console.log("error-FacCodeQuery: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const delayDataQuery = async (
  fao_tm_stop_st: any,
  fao_tm_stop_en: any,
  fao_cd_process: any,
  FAO_CD_SH_OUTAGE: any,
  fao_cd_eqp_mast: any,
  fao_cd_fac_mast: any,
  FAO_CD_TRBL_TYP: any,
  process: any
) => {
  // console.log(
  //   fao_tm_stop_st,
  //   fao_tm_stop_en,
  //   fao_cd_process,
  //   FAO_CD_SH_OUTAGE,
  //   fao_cd_eqp_mast,
  //   fao_cd_fac_mast,
  //   FAO_CD_TRBL_TYP,
  //   process
  // );
  try {
    let sql = `SELECT TO_CHAR(fao_dt_outage, 'dd-mm-yyyy') outage_dt, fao_cd_sh_outage, fao_cd_process,
          ROUND((fao_tm_stop_en - fao_tm_stop_st) * 24 * 60, 2) DURATION,
          fao_tm_stop_st, fao_tm_stop_en, fao_ts_rec_create, fao_dt_piece_upd,
          fao_id_operator, fao_cd_outage, fao_id_coil, fao_remarks,
          fao_cd_eqp_mast, fao_cd_fac_mast, TOM_CD_TRBL_CLASS FAO_CD_TRBL_TYP,
          tom_description descp
          FROM v_facility_outage, v_trbl_out_cd
          WHERE tom_cd_outage(+) = fao_cd_outage
          and tom_cd_process(+) = fao_cd_process
          AND TRUNC(fao_dt_outage) BETWEEN TO_DATE('${fao_tm_stop_st}', 'dd-mon-yyyy')
          AND TO_DATE('${fao_tm_stop_en}', 'dd-mon-yyyy') AND fao_cd_process = '${process}'`;

    if (FAO_CD_SH_OUTAGE === "All")
      sql = sql + " and FAO_CD_SH_OUTAGE in ('A','B','C') ";
    else sql = sql + " and FAO_CD_SH_OUTAGE in ('" + FAO_CD_SH_OUTAGE + "') ";

    if (fao_cd_eqp_mast === "" || fao_cd_eqp_mast === "All") sql = sql + "";
    else sql = sql + "  and fao_cd_eqp_mast in ('" + fao_cd_eqp_mast + "')";

    if (fao_cd_fac_mast === "" || fao_cd_fac_mast === "All") sql = sql + "";
    else sql = sql + "  and fao_cd_fac_mast in ('" + fao_cd_fac_mast + "')";

    // if (FAO_CD_TRBL_TYP === "" || FAO_CD_TRBL_TYP === "All") sql = sql + "";
    // else
    //   sql = sql + " and  TOM_CD_TRBL_CLASS(+) in ('" + FAO_CD_TRBL_TYP + "') ";
    sql =
      sql +
      " order by fao_dt_outage,fao_cd_sh_outage,fao_tm_stop_st, fao_tm_stop_en ";
    // const binds = [
    //   `${fao_tm_stop_st}`,
    //   `${fao_tm_stop_en}`,
    //   `${fao_cd_process}`,
    // ];
    // const binds = {
    //   fromdt: fao_tm_stop_st, // use the appropriate date format
    //   todt: fao_tm_stop_en,
    //   unit: "S", //fao_cd_process,
    // };
    // console.log("sql: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log("error-delayDataQuery: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getRsnQuery = async () => {
  try {
    const sql = `SELECT tom_cd_outage||'-'||tom_description FROM v_trbl_out_cd WHERE tom_cd_process = 'S' ORDER BY tom_cd_outage`;
    return await query(sql);
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const eqpFacQuery = async (tom_cd_outage: any, tom_cd_process: any) => {
  try {
    const sql = `Select tom_cd_fac_mas, tom_cd_eqp_mast From v_trbl_out_cd Where  tom_cd_outage = NVL(:RsnBreak,:RsnParent) And tom_cd_process = 'P'`;
    const binds = [`${tom_cd_outage}`, `${tom_cd_process}`];
    return await query(sql, binds);
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const updBrkQuery = async (
  FAO_TM_STOP_EN: any,
  FAO_CD_OUTAGE: any,
  RSNSDOLD: any,
  FAO_REMARKS: any,
  REMARKSCDOLD: any,
  FAO_CD_FAC_MAST: any,
  FAO_CD_EQP_MAST: any,
  OutageRsnDesc: any,
  FAO_CD_PROCESS: any,
  FAO_DT_OUTAGE: any,
  FAO_TM_STOP_ST: any,
  FAO_CD_SH_OUTAGE: any
) => {
  try {
    const sql = `
          UPDATE V_FACILITY_OUTAGE
  SET FAO_TM_STOP_EN = TO_DATE(:EndTime, 'DD-MM-YYYY HH24:MI:SS'),
      FAO_CD_OUTAGE = NVL(:RsnCD, :RsnCDParent),
      FAO_REMARKS = NVL(:Remarks, :RemarksParent),
      
      fao_cd_eqp_mast = :EqpCd,
      fao_cd_rsn_out = :OutageRsnDesc
  WHERE FAO_CD_PROCESS = :P_Line
      AND FAO_DT_OUTAGE = TO_DATE(:OutDt, 'DD-MM-YYYY')
      AND FAO_TM_STOP_ST = TO_DATE(:StrtTime, 'DD-MM-YYYY HH24:MI:SS')
      AND FAO_CD_SH_OUTAGE = :OutShift
          `;
    //--fao_cd_fac_mast = :FacCd,
    const binds = {
      EndTime: moment(FAO_TM_STOP_EN).format("DD-MM-YYYY HH:mm:ss"),
      RsnCD: FAO_CD_OUTAGE,
      RsnCDParent: RSNSDOLD,
      Remarks: FAO_REMARKS,
      RemarksParent: REMARKSCDOLD,
      //FacCd: FAO_CD_FAC_MAST,
      EqpCd: FAO_CD_EQP_MAST,
      OutageRsnDesc: OutageRsnDesc,
      P_Line: FAO_CD_PROCESS,
      OutDt: FAO_DT_OUTAGE,
      StrtTime: moment(FAO_TM_STOP_ST, "DD-MM-YYYY HH:mm:ss").format(
        "DD-MM-YYYY HH:mm:ss"
      ),
      OutShift: FAO_CD_SH_OUTAGE,
    };
    // console.log(binds);
    return await query(sql, binds);
  } catch (error: any) {
    console.log("err1: " + error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertBrkQuery = async (
  FAO_TM_STOP_EN: any,
  FAO_CD_OUTAGE: any,
  RSNSDOLD: any,
  FAO_REMARKS: any,
  REMARKSCDOLD: any,
  FAO_CD_FAC_MAST: any,
  FAO_CD_EQP_MAST: any,
  OutageRsnDesc: any,
  FAO_CD_PROCESS: any,
  FAO_DT_OUTAGE: any,
  PersonalNo: any,
  FAO_TM_STOP_ST: any,
  FAO_CD_SH_OUTAGE: any
) => {
  try {
    // const sql = `INSERT INTO V_FACILITY_OUTAGE(
    //     FAO_TM_STOP_EN,
    //     fao_cd_rsn_out,
    //     FAO_REMARKS,
    //           fao_cd_fac_mast,
    //       fao_cd_eqp_mast,
    //         FAO_CD_PROCESS,
    //         FAO_CD_OUTAGE,
    //         FAO_DT_OUTAGE,
    //     FAO_TM_STOP_ST,
    //     FAO_CD_SH_OUTAGE,
    //      FAO_ID_OPERATOR,
    //      FAO_TS_COIL_CREATE,
    //       FAO_TS_REC_CREATE
    //       )
    //       VALUES (
    //           TO_DATE(:EndTime, 'DD-MM-YYYY HH24:MI:SS'),
    //            NVL(:RsnCD, :RsnCDParent),
    //            NVL(:Remarks, :RemarksParent),
    //             :FacCd,
    //             :EqpCd,
    //             :P_Line,
    //              :OutageRsnDesc,
    //              TO_DATE(:OutDt, 'DD-MM-YYYY HH24:MI:SS'),
    //              TO_DATE(:StrtTime, 'DD-MM-YYYY HH24:MI:SS'),
    //              :OutShift,
    //              SUBSTR(:P_NO, 1, 6),
    //              SYSDATE,
    //               SYSDATE
    //               )`
    const sql = `
              INSERT INTO V_FACILITY_OUTAGE(
                  FAO_CD_PROCESS,
                  FAO_TM_STOP_ST,
                  FAO_TM_STOP_EN,
                  FAO_CD_OUTAGE,
                  FAO_CD_SH_OUTAGE,
                  FAO_DT_OUTAGE,
                  FAO_ID_OPERATOR,
                  FAO_TS_COIL_CREATE,
                  FAO_TS_REC_CREATE,
                  FAO_REMARKS,
                  fao_cd_fac_mast,
                  fao_cd_eqp_mast,
                  fao_cd_rsn_out
              )
          VALUES (
                  :P_Line,
                  TO_DATE(:StrtTime, 'DD-MM-YYYY HH24:MI:SS'),
                  TO_DATE(:EndTime, 'DD-MM-YYYY HH24:MI:SS'),
                  NVL(:RsnCD, :RsnCDParent),
                  :OutShift,
                  TO_DATE(:OutDt, 'DD-MM-YYYY'),
                  SUBSTR(:P_NO, 1, 6),
                  SYSDATE,
                  SYSDATE,
                  NVL(:Remarks, :RemarksParent),
                  :FacCd,
                  :EqpCd,
                  :OutageRsnDesc
              )
              `;
    //:FacCd,
    //fao_cd_fac_mast,
    const binds = {
      EndTime: moment(FAO_TM_STOP_EN).format("DD-MM-YYYY HH:mm:ss"),
      RsnCD: FAO_CD_OUTAGE,
      RsnCDParent: RSNSDOLD,
      Remarks: FAO_REMARKS,
      RemarksParent: REMARKSCDOLD,
      FacCd: FAO_CD_FAC_MAST,
      EqpCd: FAO_CD_EQP_MAST,
      OutageRsnDesc: OutageRsnDesc,
      P_Line: FAO_CD_PROCESS,
      OutDt: FAO_DT_OUTAGE,
      StrtTime: moment(FAO_TM_STOP_ST).format("DD-MM-YYYY HH:mm:ss"),
      OutShift: FAO_CD_SH_OUTAGE,
      P_NO: PersonalNo,
    };
    // console.log(binds);
    return await query(sql, binds);
  } catch (error: any) {
    console.log("err2" + error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const deleteBrkQuery = async (
  FAO_TM_STOP_ST: any,
  FAO_DT_OUTAGE: any,
  FAO_CD_PROCESS: any,
  FAO_CD_EQP_MAST: any
  //FAO_CD_FAC_MAST: any
) => {
  try {
    const sql = `delete from v_facility_outage where FAO_TM_STOP_ST =to_date(:lsStartDt,'DD-MM-YYYY HH:MI:SS PM') and FAO_DT_OUTAGE=to_date(:lsOutageDt, 'DD-MM-YYYY') and FAO_CD_PROCESS = :lsProcessLine and FAO_CD_EQP_MAST = :lsEqpCd `; //and FAO_CD_FAC_MAST = :lsFactMast
    const binds = {
      lsStartDt: FAO_TM_STOP_ST,
      lsOutageDt: FAO_DT_OUTAGE,
      lsProcessLine: FAO_CD_PROCESS,
      lsEqpCd: FAO_CD_EQP_MAST,
      //lsFactMast: FAO_CD_FAC_MAST,
    };
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const updateRsnQuery = async (
  // FAO_REMARKS: any,
  // FAO_CD_OUTAGE: any,
  // FAO_TM_STOP_ST: any,
  // FAO_DT_OUTAGE: any,
  // FAO_CD_PROCESS: any,
  // FAO_CD_EQP_MAST: any,
  // FAO_CD_FAC_MAST: any
  data: any
) => {
  try {
    // console.log("data2: ", data);
    const sql = `
      update v_facility_outage
          SET 
            FAO_REMARKS = :lsRemarks ,
            FAO_CD_OUTAGE = :lsReason ,
            FAO_CD_EQP_MAST = :lsEqpCd,
            FAO_CD_FAC_MAST = :lsFactMast,
            FAO_DT_PIECE_UPD = Sysdate
          WHERE FAO_TM_STOP_ST = to_date(:lsStartDt, 'DD-MM-YYYY HH24:MI:SS')
          AND FAO_DT_OUTAGE = to_date(:lsOutageDt , 'DD-MM-YYYY')
          AND FAO_CD_PROCESS = :lsProcessLine `; //and FAO_CD_EQP_MAST = :lsEqpCd and FAO_CD_FAC_MAST= :lsFactMast
    const binds = {
      lsRemarks: data?.remarks,
      lsReason: data?.reason,
      lsStartDt: data?.stDate,
      lsOutageDt: data?.outageDt,
      lsProcessLine: data?.p_line,
      lsEqpCd: data?.eqpMast,
      lsFactMast: data?.faqMast,
    };
    // console.log("sql: ", sql);
    // console.log("binds: ", binds);
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
