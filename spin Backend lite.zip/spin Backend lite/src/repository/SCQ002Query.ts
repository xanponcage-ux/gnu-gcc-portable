import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const SCQ002getPlantData = async (data: any) => {
  try {
    return {
      PlanCode: await ResponceData(await getCommonPlantData()),
    };
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ002getBatchData = async (data: any) => {
  try {
    let sql = `SELECT DISTINCT EOM_ID_BATCH,EOM_CD_STATUS
      FROM V_EPA_PRODN
      WHERE EOM_CD_EPA='${data?.plant}'
      AND EOM_CD_QLTY_ACTL<>'SCRP'
      
    `;
    if (data?.status === "UPDATE REMARKS") {
      sql += `AND (EOM_CD_STATUS LIKE '%B' OR EOM_CD_STATUS LIKE '%F')`;
    }
    if (data?.status === "HOLD") {
      sql += ` AND (EOM_CD_STATUS LIKE '%D' OR EOM_CD_STATUS LIKE '%Q')`;
    }
    sql += ` ORDER BY 1`;
    let batchesResults = { batch: await ResponceData(await query(sql)) };
    return batchesResults;
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ002getTableData = async (data: any) => {
  try {
    let sql = ``;
    if (data?.status === "HOLD") {
      sql = `SELECT DISTINCT CHR_TS_HOLD HOLD_DT,EOM_UOM,CHR_CD_RSN_HOLD Hold_Rsn,(SELECT CD_DESC FROM V_EPA_HOLD_RSN 
              WHERE CD_HOLD =CHR_CD_RSN_HOLD 
              AND CD_COMP='1000' AND ROWNUM=1)HOLD_DESC, CHR_ID_OP_HOLD Hold_By
              ,eom_cd_prod,eom_cd_qlty_actl,eom_sec1,eom_sec2,eom_length,eom_tdc_actl,eom_ms_piece_actl,eom_ms_gross_cal,
              nvl(eom_ms_scrap/1000,0) EOM_MS_SCRAP,eom_cd_status,  eom_cd_curr_proc,eom_cd_next_proc,eom_id_order_cus,
              eom_id_ord_item_cus,enc_cust_name,
              (select cd_desc from v_codes where eom_cd_status=cd_value and cd_type='E0001') cd_desc 
              ,NVL(LTRIM(EOM_NO_MATNR,'0'),LTRIM(ENC_NO_MATNR,'0')) MATERIAL_NO,(SELECT MAKTX FROM 
              V_MAKT WHERE MANDT='600' AND MATNR=NVL(EOM_NO_MATNR,ENC_NO_MATNR) AND ROWNUM=1)MATERIAL_DESC
              ,CHR_ID_COIL BATCHID,CHR_CD_RSN_HOLD Holdrsn,CHR_OPR_REMARKS OP_REMARKS
              FROM v_epa_prodn, v_end_cust_ord_epa,v_coil_hold_rls
              WHERE eom_id_order_cus = enc_id_order(+) 
              and eom_id_ord_item_cus=enc_no_item(+) 
              and eom_id_batch = chr_id_coil(+) 
              and eom_cd_epa=chr_cd_epa(+)      
              and eom_id_batch= :BatchId
              and eom_cd_epa= :plant
              order by CHR_TS_HOLD desc`;
    }

    if (data?.status === "UPDATE REMARKS") {
      sql = `
        SELECT eom_id_batch BATCHID,EOM_UOM,eom_cd_prod,eom_cd_qlty_actl,eom_sec1,eom_sec2,eom_length,
        eom_tdc_actl,eom_ms_piece_actl,eom_ms_gross_cal,nvl(eom_ms_scrap/1000,0) EOM_MS_SCRAP,eom_cd_status,  
        eom_cd_curr_proc,eom_cd_next_proc,eom_id_order_cus,eom_id_ord_item_cus,enc_cust_name,
        (select cd_desc from v_codes where eom_cd_status=cd_value and cd_type='E0001') cd_desc 
        ,NVL(LTRIM(EOM_NO_MATNR,'0'),LTRIM(ENC_NO_MATNR,'0')) MATERIAL_NO,
        (SELECT MAKTX FROM V_MAKT WHERE MANDT='600' AND MATNR=NVL(EOM_NO_MATNR,ENC_NO_MATNR) 
        AND ROWNUM=1)MATERIAL_DESC,'' CHR_OPR_REMARKS
        FROM v_epa_prodn, v_end_cust_ord_epa
        WHERE eom_id_order_cus = enc_id_order(+) 
        and eom_id_ord_item_cus=enc_no_item(+)  
        and eom_id_batch= :BatchId
        and eom_cd_epa= :plant
        AND (EOM_CD_STATUS LIKE '%B' OR EOM_CD_STATUS LIKE '%F')
        AND EOM_CD_QLTY_ACTL<>'SCRP'
        ORDER BY EOM_TS_CREATION`;
    }

    let binds = {
      plant: data?.plant ? data.plant : "",
      BatchId: data?.batchId ? data?.batchId : "",
    };
    return await ResponceData(await query(sql, binds));
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ002getRsnData = async (data: any) => {
  try {
    let sql: any = `SELECT distinct CD_DESC,CD_HOLD FROM  V_EPA_HOLD_RSN order by   CD_HOLD`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ002Procedure = async (data: any) => {
  try {
    let sql: any = `call TRMQ0006(
              p_plant                =>:p_plant,
              p_batch                =>:p_batch,
              p_rsn_hold_cd          =>:p_rsn_hold_cd,  
              p_op_remarks           =>:p_op_remarks,  
              p_status               =>:p_status,
              p_curr_proc            =>:p_curr_proc,
              p_next_proc            =>:p_next_proc,
              p_net_wt               =>:p_net_wt,  
              p_flag                 =>:p_flag,     
              p_user                 =>:p_user,          
              ls_out_flag            =>:ls_out_flag
            )`;

    const binds = {
      p_plant: data?.p_plant ? data?.p_plant : "",
      p_batch: data?.p_batch ? data?.p_batch : "",
      p_rsn_hold_cd: data?.p_rsn_hold_cd ? data?.p_rsn_hold_cd : "",
      p_op_remarks: data?.p_op_remarks ? data?.p_op_remarks : "",
      p_status: data?.p_status ? data?.p_status : "",
      p_curr_proc: data?.p_curr_proc ? data?.p_curr_proc : "",
      p_next_proc: data?.p_next_proc ? data?.p_next_proc : "",
      p_net_wt: data?.p_net_wt ? data?.p_net_wt : "",
      p_flag: data?.p_flag ? data?.p_flag : "",
      p_user: data?.p_user,
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ002updateHoldRemarks = async (data: any) => {
  try {
    let ehrOpRemarks = "";
    // let opRemarks = `SELECT EHR_PREV_OP_REMARKS, EHR_OP_REMARKS FROM V_EPA_MATL_HOLD_RLS,V_CODES WHERE CD_TYPE = 'EPA459' AND EHR_CD_EPA = CD_VALUE AND EHR_CD_EPA =:PLANT AND EHR_ID_BATCH =:BATCH_ID`;
    let opRemarks = `SELECT CHR_OPR_REMARKS FROM V_COIL_HOLD_RLS, V_CODES WHERE CD_TYPE = 'EPA459' AND CHR_CD_EPA = CD_VALUE AND CHR_CD_EPA =:PLANT AND CHR_ID_COIL =:BATCH_ID`;

    let remBinds = {
      PLANT: data?.Plant,
      BATCH_ID: data?.Batch_id,
    };
    let resOrmx = await ResponceData(await query(opRemarks, remBinds));
    if (resOrmx.length > 0) {
      ehrOpRemarks = resOrmx[0]?.EHR_PREV_OP_REMARKS;
    }
    const sql = `UPDATE V_COIL_HOLD_RLS SET chr_opr_remarks =:opr_remarks WHERE chr_cd_epa =:plant AND chr_id_coil =:batch_id`;

    let binds = {
      Plant: data?.Plant ? data?.Plant : "",
      Batch_id: data?.Batch_id ? data?.Batch_id : "",
      opr_remarks: data?.OprRemaks ? data?.OprRemaks : "",
      prev_opr_remarks: ehrOpRemarks,
      userid: data?.userid,
    };
    return await ResponceData(await query(sql, binds));
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

// Implementation of wt reduction feature

export const getHoldBatchForWtRed = async (data: any) => {
  try {
    let sql: any = `SELECT EOM_ID_BATCH BATCH_ID, EOM_CD_STATUS STATUS, EOM_FL_HOLD HOLD_FLAG,
       EOM_LENGTH LEN, EOM_MS_GROSS_ACTL GROSS_WT, EOM_MS_PIECE_ACTL NET_WT,
       EOM_SEC1 THICK, EOM_SEC2 WIDTH, EOM_ID_ORDER_CUS ORDER_CUST,
       EOM_ID_ORD_ITEM_CUS ITEM_CUST, EOM_ID_PAR_COIL_NO PARENT_COIL,
       EOM_ID_FIRST_PAR MOTHER_COIL, EOM_TDC_ACTL TDC
      FROM V_EPA_PRODN
      WHERE (EOM_CD_STATUS LIKE '%P' OR EOM_CD_STATUS LIKE '%D')`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

// Implementation - Saving AI response in DB

export const aiFeatureEnable = async (data: any) => {
  try {
    const sql = `select cd_value flag from v_codes where cd_type = 'TK035'`;

    return await ResponceData(await query(sql));
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const saveAiHoldAnalysis = async (data: any) => {
  try {
    // const updateQry = `
    //   UPDATE V_AI_SUGGESTION SET
    //     AHS_AI_SUGG = :aiSugg,
    //     AHS_REC_UPD_DT = SYSDATE,
    //     AHS_REC_UPD_BY = '${data?.userId}'
    //   WHERE AHS_ID_BATCH = '${data?.batchId}'
    //   AND AHS_CD_EPA = '${data?.plant}' `;

    // const aiRespPlain = aiRespRaw.replaceAll("**", "");

    // const updateBinds = {
    //   aiSugg: aiRespRaw,
    // };

    const chkCoilQry = ` select count(*) BATCH_COUNT from V_AI_SUGGESTION 
     where AHS_ID_BATCH = '${data?.batchId}'
     and AHS_CD_EPA = '${data?.plant}' and AHS_SUGG_CAT_CD = 1 `; //cat dc =1 , hold AI suggestion
    // console.log("chkCoilQry: ", chkCoilQry);

    let chkCoilQryResult = await ResponceData(await query(chkCoilQry));
    // console.log("chkCoilQryResult: ", chkCoilQryResult);

    const coilCount = chkCoilQryResult?.[0]?.BATCH_COUNT;
    // console.log("coilCount: ", coilCount);

    const aiRespRaw: string = String(data?.aiResp) ?? "";
    const insertQry = `
      INSERT INTO V_AI_SUGGESTION (
        AHS_CD_EPA,
        AHS_ID_BATCH,
        AHS_SEQ_ID,
        AHS_SUGG_CAT_CD,
        AHS_SUGG_CAT_DESC,
        AHS_IMG_LINK,
        AHS_AI_SUGG,
        AHS_OTH_REM,
        AHS_REC_CRT_DT,
        AHS_REC_CRT_BY,
        AHS_REC_UPD_DT,
        AHS_REC_UPD_BY
      ) VALUES (
        :plant,
        :batchId,
        :seqId,
        :suggCatCd,
        :suggCatDesc,
        :imgLink,
        :aiSugg,
        NULL,
        SYSDATE,
        :createdBy,
        NULL,
        NULL ) `;

    const insertBinds = {
      plant: data?.plant,
      batchId: data?.batchId,
      seqId: coilCount + 1,
      suggCatCd: "01",
      suggCatDesc: "AI HOLD SUGGESTION FROM SCQ002",
      imgLink: data?.imgPath,
      aiSugg: aiRespRaw,
      createdBy: data?.userId,
    };

    let sqlQry = ``,
      binds;

    // if (coilCount > 0) {
    //   // sqlQry = updateQry;
    //   // binds = updateBinds;
    // } else {
    sqlQry = insertQry;
    binds = insertBinds;
    // }

    // console.log("sql-saveAiHoldAnalysis SCQ002: ", sqlQry);
    // console.log("binds-saveAiHoldAnalysis SCQ002: ", binds);
    return await query(sqlQry, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getPrevAiAnalysis = async (data: any) => {
  try {
    const sql = `SELECT
        AHS_CD_EPA   AS PLANT,
        AHS_ID_BATCH AS BATCH_ID,
        AHS_SEQ_ID   AS SEQ_ID,
        AHS_REC_CRT_BY AS CRT_BY,
        AHS_REC_CRT_DT  AS CRT_DT,
        /* For NCLOB, NVARCHAR2 max in SQL is 2000 chars */
        DBMS_LOB.SUBSTR(AHS_AI_SUGG, 2000, 1) AS AI_SUGG
        --DBMS_LOB.GETLENGTH(AHS_AI_SUGG)       AS AI_LEN
      FROM V_AI_SUGGESTION
      WHERE AHS_ID_BATCH = :batchId
      ORDER BY TO_NUMBER(AHS_SEQ_ID) ASC, AHS_REC_CRT_DT ASC `;

    const binds = { batchId: data?.batchId };

    // console.log("sql-getPrevAiAnalysis: ", sql);
    // console.log("binds-getPrevAiAnalysis: ", binds);

    const result = await ResponceData(await query(sql, binds));
    // console.log("result-getPrevAiAnalysis: ", result);

    return result;
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

// This api is not being used currently
export const prevAiAnalysisExists = async (data: any) => {
  try {
    const chkCoilQry = ` select count(*) BATCH_COUNT from V_AI_SUGGESTION 
    where AHS_ID_BATCH = '${data?.batchId}'
    and AHS_CD_EPA = '${data?.plant}' and AHS_SUGG_CAT_CD = 1 `; //cat dc =1 , hold AI suggestion
    console.log("chkCoilQry-prevAiAnalysisExists: ", chkCoilQry);

    let chkCoilQryResult = await ResponceData(await query(chkCoilQry));
    console.log("chkCoilQryResult-prevAiAnalysisExists: ", chkCoilQryResult);

    const coilCount = chkCoilQryResult?.[0]?.BATCH_COUNT;
    console.log("coilCount-prevAiAnalysisExists: ", coilCount);

    if (coilCount > 0) return "Y";
    return "N";

    // return await ResponceData(await query(sql));
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
