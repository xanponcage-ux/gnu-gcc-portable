import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const indenting = async (data: any) => {
  try {
    let binds: any = {
      Plant: data.Plant,
      //Status: req.body.Status,
    };
    if (data?.type === "getData") {
      if (data.Plant) {
        return {
          batch: await ResponceData(
            await query(`
            select distinct EOM_ID_BATCH 
            from v_epa_prodn where eom_cd_status in (select CD_VALUE from v_codes WHERE CD_TYPE='TK004')
            AND EOM_CD_EPA = ${data.Plant}
            AND eom_ms_gross_cal >= 0
            AND eom_id_batch = eom_id_first_par 
            AND EOM_CD_CURR_PROC in ('S', 'N', 'T')
            `)
          ),
          process: await ResponceData(
            await query(`
            select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
            FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} AND EPL_CD_PROCESS in ('S', 'N', 'T') ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
            `)
          ),
          status: await ResponceData(
            await query(`
            select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
            WHERE CD_TYPE='TK004'
            `)
          ),
          checkReqStatus: await ResponceData(
            await query(`SELECT CD_VALUE FROM V_CODES
            WHERE CD_TYPE='TK004'
            AND SUBSTR(CD_DESC1,1,2)='RI'`)
          ),
          checkCancelStatus: await ResponceData(
            await query(`SELECT CD_VALUE FROM V_CODES
              WHERE CD_TYPE='TK004'
              AND SUBSTR(CD_DESC1,1,2)='IN'`)
          ),
          order: await ResponceData(
            await query(`
            SELECT distinct EOM_SCO_ORDER
            FROM v_epa_prodn a 
            WHERE EOM_CD_EPA = ${data.Plant}
            AND eom_ms_gross_cal >= 0
            `)
          ),
          plannedPath: await ResponceData(
            await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
             FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} ORDER  BY 1`)
          ),
        };
      } else {
        return getCommonPlantData();
      }
    } else if (data?.type === "IndentCoilDetails") {
      let QrygetCoils = `SELECT distinct
        eom_cd_epa         plant,
        EOM_CD_CURR_PROC   process,
        (SELECT epl_proc_line_desc FROM v_epa_proc_line WHERE epl_cd_process = eom_cd_curr_proc) proc_desc,
        eom_id_batch       coil_id,
        eom_ms_gross_cal   coil_wt,
        eom_sec1           thk,
        eom_sec2           width,
        eom_tdc_actl       tdc,
        eom_cd_prod        prod_cd,
        eom_cd_status      status,
        eom_idia           idia,
        CASE
        WHEN eom_cd_status = 'VG' THEN 'N'
        ELSE 'Y'
        END AS schedule_flag,
        CASE
        WHEN eom_cd_status = 'VI' THEN 'Y'
        ELSE 'N'
        END AS indent_flag,
        round(SYSDATE - eom_ts_creation) coil_age,
        eom_no_cast        cast_no,
        eom_no_matnr       coil_mat,
        (select LISTAGG(CAD_DEF2_COMM,' ; ') from v_coil_card
           where CAD_ID_COIL= eom_id_batch 
           and CAD_DEF2_COMM like '@SLP%') SLP_REMARKS,
        (
            SELECT
                maktx
            FROM
                v_makt
            WHERE
                mandt = '600'
                AND matnr = eom_no_matnr
        ) coil_mat_desc,
        TO_CHAR(eom_ts_creation,'dd-mm-yyyy hh24:MI:SS') coil_arrival_dt,
        (
            SELECT
                tpm_pack_cd
            FROM
                v_pack_master
            WHERE
                tpm_cd_epa = eom_cd_epa
                AND tpm_mark_cust = eom_mk_customer
        ) packing,
        (
            SELECT
                tom_cust_tdc
            FROM
                v_oiling_master
            WHERE
                tom_cd_epa = eom_cd_epa
                AND tom_mark_cust = eom_mk_customer
                AND tom_cust_tdc = eom_tdc_actl
        ) oiling,
        (SELECT f_get_SAPGRADE('${data.Plant}', EOM_ID_ORDER_CUS, EOM_ID_ORD_ITEM_CUS) FROM DUAL) PLAN_GRADE,
        ENC_MARK_CUST, 
        ENC_MARK_CUST_NAME, 
        ENC_DESPATCH_WK, 
        ENC_SHIP_TO_PRTY_DESC,
        eom_ts_creation
    FROM
        v_epa_prodn a left join v_end_cust_ord_epa b on a.EOM_ID_ORDER_CUS = b.ENC_ID_ORDER
        and a.EOM_ID_ORD_ITEM_CUS = b.ENC_NO_ITEM
    WHERE
        eom_cd_epa = '${data.Plant}'
        AND eom_cd_status IN (
            SELECT
                cd_value
            FROM
                v_codes
            WHERE
                cd_type = 'TK004'
        )
        AND eom_ms_gross_cal >= 0
        AND eom_id_batch = eom_id_first_par 
        --AND EOM_CD_CURR_PROC in ('S', 'N', 'T') -- Due to this VG coils were not coming
        `;

      if (
        data?.Status &&
        Array.isArray(data?.Status) &&
        data?.Status.length > 1
      ) {
        if (
          data?.Status &&
          Array.isArray(data?.Status) &&
          data?.Status.length > 1
        ) {
          let dt = data?.Status.map((d: any) => `'${d}'`).join();
          QrygetCoils += ` AND eom_cd_status in(` + dt + `) `;
        }
      } else {
        if (data?.Status && data?.Status?.length > 0) {
          QrygetCoils += ` AND eom_cd_status = nvl('${
            Array.isArray(data?.Status) ? data?.Status[0] : data?.Status
          }', eom_cd_status) `;
        }
      }
      if (data?.BatchId && data?.BatchId?.length > 0) {
        QrygetCoils += ` AND EOM_ID_BATCH = '${data?.BatchId}' `;
      }
      if (data?.process && data?.process?.length > 0) {
        QrygetCoils += ` AND EOM_CD_CURR_PROC = '${data?.process}' `;
      }
      if (data?.ThickFR?.length > 0 && data?.ThickTo?.length > 0) {
        QrygetCoils += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFR}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFR}',EOM_SEC1))`;
      } else if (data?.ThickFR?.length > 0 || data?.ThickTo?.length > 0) {
        QrygetCoils += ` AND EOM_SEC1 = '${
          data?.ThickFR?.length > 0 ? data?.ThickFR : data?.ThickTo
        }'`;
      }
      if (data?.WidthFr?.length > 0 && data?.WidthTo?.length > 0) {
        QrygetCoils += ` AND EOM_SEC2 BETWEEN NVL('${data?.WidthFr}',EOM_SEC2) AND NVL('${data?.WidthTo}',NVL('${data?.WidthFr}',EOM_SEC2))`;
      } else if (data?.WidthFr?.length > 0 || data?.WidthTo?.length > 0) {
        QrygetCoils += ` AND EOM_SEC2 = '${
          data?.WidthFr?.length > 0 ? data?.WidthFr : data?.WidthTo
        }'`;
      }
      if (data?.Tdc && data?.Tdc?.length > 0) {
        QrygetCoils += ` AND EOM_TDC_ACTL = '${data?.Tdc}' `;
      }
      if (data?.prodCd && data?.prodCd?.length > 0) {
        QrygetCoils += ` AND EOM_CD_PROD = '${data?.prodCd}' `;
      }
      if (data?.fromDt && data?.fromDt?.length > 0) {
        QrygetCoils += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.toDt}',NVL('${data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      QrygetCoils += " order by EOM_TS_CREATION";

      console.log("QrygetCoils indent data: ", QrygetCoils);
      return await query(QrygetCoils);
    } else if (data?.type === "procedureCall") {
      var sql = `call TPLB0003(
          p_plant => :p_plant,
          p_coil_id => :p_coil_id,
          ls_out_flag => :ls_out_flag
        )`;
      const binds = {
        p_plant: data?.plantId,
        p_coil_id: data?.coilId,
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      return await query(sql, binds);
    } else if (data?.type === "deleteIndent") {
      var sql = `call TPLB003A(
          p_plant => :p_plant,
          p_coil_id => :p_coil_id,
          ls_out_flag => :ls_out_flag
        )`;
      const binds = {
        p_plant: data?.plantId,
        p_coil_id: data?.coilId,
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };

      return await query(sql, binds);
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};
