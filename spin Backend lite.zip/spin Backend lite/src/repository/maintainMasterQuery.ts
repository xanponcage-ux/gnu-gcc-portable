import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getEpaCode02 = async () => {
  try {
    const sql = `SELECT
      DISTINCT EPL_CD_EPA
     FROM
         V_EPA_PROC_LINE`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};

// export const getProcLineData02 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code ? parseInt(data?.code) : 0,
//     };
//     let sql = `SELECT
//         EPL_ACTIVE_PLANT_FL,
//         EPL_ACTIVITY_FLAG,
//         EPL_ACTIVITY_NM,
//         EPL_ACTIVITY_TIME,
//         EPL_ADDRESS,
//         EPL_BUSINESS_UNIT,
//         EPL_BUSI_ROLE,
//         EPL_CD_COMP,
//         EPL_CD_CUST,
//         EPL_CD_EPA,
//         EPL_CD_PROCESS,
//         EPL_CONSP_FLAG,
//         EPL_ID_PRINTER,
//         EPL_NO_PROC_SEQ,
//         EPL_PLNG_FLAG,
//         EPL_PROC_LINE_DESC,
//         EPL_PRODUCTION_TYPE,
//         EPL_REM1,
//         EPL_REM2,
//         EPL_REM3,
//         EPL_SAP_INTERFACE_IND,
//         EPL_SERVER,
//         NVL(EPL_STOR_LOC, 0) EPL_STOR_LOC,
//         EPL_THK_TOL_FLAG,
//         EPL_URL,
//         EPL_EPA_DESC,
//         EPL_PROC_LINE_DESC
//       FROM
//         V_EPA_PROC_LINE
//       WHERE EPL_CD_EPA = :code `;
//     if (data.process && data.process?.length > 0) {
//       sql += ` AND EPL_CD_PROCESS = :process`;
//       binds["process"] = data?.process;
//     }
//     if (data.flag && data.flag?.length > 0) {
//       sql += ` AND EPL_ACTIVE_PLANT_FL = :flag`;
//       binds["flag"] = data?.flag;
//     }
//     sql += "ORDER BY EPL_NO_PROC_SEQ";
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getProcPath02 = async (data: any) => {
//   try {
//     let sql = "";
//     let binds: any = {};
//     if (data.code?.length > 0 || data.process?.length > 0) {
//       binds = {
//         code: data?.code ? parseInt(data?.code) : 0,
//       };
//       sql = `SELECT
//           *
//         FROM
//           V_EPA_PROC_PATH
//         WHERE  PPH_CD_EPA = :code`;
//       if (data.process && data.process?.length > 0) {
//         sql += ` AND PPH_CD_PROC_PATH = :process`;
//         binds["process"] = data?.process;
//       }
//     } else {
//       sql = `SELECT
//           *
//         FROM
//         V_EPA_PROC_PATH`;
//     }
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
export const getPlantData = async () => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};

//for my new Page

// export const getPackingCode03 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code ? parseInt(data?.code) : 0,
//     };
//     let sql = ` SELECT
//     TPM_CD_EPA,
//     TPM_MARK_CUST,
//     TPM_PACK_SEQ,
//      TPM_TDC TDC,
//     (SELECT NAME1 FROM V_KNA1
//      WHERE MANDT = '600' AND KUNNR = LPAD(TPM_MARK_CUST,10,'0')) CUST_NAME,
//     TPM_PACK_CD,
//     TPM_CRT_ID,
//     TPM_CRT_DT CRT_DT,
//     TPM_UPD_ID,
//     TPM_UPD_DT
//     FROM
//         V_PACK_MASTER
//         WHERE TPM_CD_EPA = :code `;

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getOilingcode03 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code ? parseInt(data?.code) : 1,
//     };
//     let sql = `SELECT
//           TOM_CD_EPA,
//           TOM_MARK_CUST,
//           TOM_CUST_TDC,
//           TOM_OIL_CD,
//           TOM_CRT_ID,
//           TOM_CRT_DT CRT_DT,
//           TOM_UPD_ID,
//           TOM_UPD_DT
//         FROM
//         V_OILING_MASTER
//         WHERE  TOM_CD_EPA = :code`;

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
//procedure for save packing and oiling data.
// export const savePackingOiling = async (data: any) => {
//   try {
//     const sql = `call TSKEPADBA.MSTB003(
//         ls_cd_epa            =>:ls_cd_epa,
//         ls_mark_cust         =>:ls_mark_cust,
//         ls_cust_tdc          =>:ls_cust_tdc,
//         ls_pack_seq          =>:ls_pack_seq,
//         ls_pack_cd           =>:ls_pack_cd,
//         ls_crt_id            =>:ls_crt_id,
//         ls_flag              =>:ls_flag,
//         lb_status            =>:lb_status,
//         ls_out_flag          =>:ls_out_flag)`;

//     const binds = {
//       ls_cd_epa: data[0]?.ls_cd_epa,
//       ls_mark_cust: data[0].ls_mark_cust,
//       ls_cust_tdc: data[0]?.ls_cust_tdc ? data[0]?.ls_cust_tdc : "",
//       ls_pack_seq: data[0].ls_pack_seq,
//       ls_pack_cd: data[0].ls_pack_cd,
//       ls_crt_id: data[0].ls_crt_id,
//       ls_flag: data[0].ls_flag,
//       lb_status: data[0].lb_status,
//       ls_out_flag: {
//         type: oracledb.STRING,
//         dir: oracledb.BIND_OUT,
//         maxSize: 500,
//       },
//     };
//     console.log("binds====>", binds);
//     return await query(sql, binds);
//   } catch (error: any) {
//     console.log("error====>", error);
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };
//for my new page

//for page - 04

// export const upcomingpageCode04 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code ? parseInt(data?.code) : 0,
//     };
//     let sql = `SELECT
//         TYR_CD_EPA,
//         TYR_APP_GRP,
//         TYR_PNO,
//         TYR_NAME,
//         TYR_EMAIL,
//         TYR_TELNO,
//         TYR_CRT_ID,
//         TO_CHAR(TYR_CRT_DT, 'YYYY-MM-DD') TYR_CRT_DT,
//         TYR_UPD_ID,
//         TO_CHAR(TYR_UPD_DT, 'YYYY-MM-DD') TYR_UPD_DT,
//         TYR_ACT_STATUS,
//         TYR_MARK_CUST
//       FROM
//       v_yield_approver_mast
//         WHERE TYR_CD_EPA = :code `;

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const upcomingpage_02_Code04 = async (data: any) => {
//   try {
//     let binds: any = {
//       code: data?.code ? parseInt(data?.code) : 1,
//     };
//     let sql = `SELECT
//         EYM_CD_EPA,
//         EYM_CATEGORY,
//         EYM_CAT_TYPE,
//         EYM_YIELD,
//         EYM_NO_MATNR,
//         EYM_MATNR_CODE,
//         EYM_PRC_SEQ,
//         EYM_PROCESS,
//         EYM_OD_FROM,
//         EYM_OD_TO,
//         EYM_SEC3_FROM,
//         EYM_SEC3_TO,
//         EYM_IDIA,
//         EYM_REMARK,
//         EYM_PROD,
//         EYM_TDC_REM,
//         EYM_GRADE,
//         EYM_QLTY
//       FROM
//         v_yield_master
//         WHERE  EYM_CD_EPA = :code`;

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
//for page sc0_order _book

// export const getEpaPlant06 = async () => {
//   try {
//     return getCommonPlantData();
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getTdcsec06 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT ESP_TDC_DOWNGRADE
//     FROM
//     V_EPA_SECONDS_PRIME_TDC WHERE ESP_STATUS = 'A'`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getSECONDSTdc06 = async (data: any) => {
//   try {
//     let binds: any = {};

//     let sql = `SELECT
//     NVL (ESP_CD_EPA, '') CD_EPA,
//     --NVL (ESP_QLTY_PRIME, '') QLTY_PRIME,
//     --NVL (ESP_QLTY_DOWNGRADE, '') QLTY_DOWNGRADE,
//     NVL (ESP_TDC_PRIME, '') TDC_PRIME,
//     NVL (ESP_TDC_DOWNGRADE, '') TDC_DOWNGRADE,
//     --NVL (ESP_SEC1_FROM, '') SEC1_FROM,
//     --NVL (ESP_SEC1_TO, '') SEC1_TO,
//     --NVL (ESP_SEC2_FROM, '') SEC2_FROM,
//     --NVL (ESP_SEC2_TO, '') SEC2_TO,
//     --NVL (ESP_SHEET_IND, '') SHEET_IND,
//     --NVL (ESP_NO_MATNR, '') NO_MATNR,
//     --NVL (ESP_WT_MIN, '') WT_MIN,
//     --NVL (ESP_WT_MAX, '') WT_MAX,
//     NVL (ESP_CRT_USR, '') S_CRT_USR,
//     NVL (ESP_CRT_DT, '') S_CRT_DT,
//     NVL (ESP_UPD_USR, '') S_UPD_USR,
//     NVL (ESP_UPD_DT, '') S_UPD_DT,
//     NVL (ESP_STATUS, '') STATUS
//   FROM
//   V_EPA_SECONDS_PRIME_TDC WHERE ESP_STATUS = 'A'`;
//     if (data?.epa) {
//       sql += ` AND ESP_CD_EPA = '${data?.epa}'`;
//     }
//     if (data.tdcsc && data.tdcsc?.length > 0) {
//       sql += `AND ESP_TDC_DOWNGRADE = '${data?.tdcsc}'`;
//     }
//     console.log(sql);
//     return await query(sql);
//   } catch (error: any) {
//     console.log("+>", error);
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getActTdc06 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT TDM_ACT_TDC
//    FROM
//     V_TDC_MAP WHERE TDM_CD_STATUS = 'A'`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
export const getEndTdc06 = async () => {
  try {
    const sql = `SELECT
    DISTINCT TDM_END_TDC
   FROM
    V_TDC_MAP WHERE TDM_CD_STATUS = 'A'`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
// export const getTdcMap06 = async (data: any) => {
//   try {
//     let binds: any = {};
//     let sql = `SELECT
//     TDM_ACT_TDC ACT_TDC,
//     TDM_END_TDC END_TDC,
//     TDM_CRT_ID CRT_ID,
//     TDM_CRT_DT CRT_DATE,
//     TDM_UPD_ID UPD_ID,
//     TDM_UPD_DT UPD_DT,
//     TDM_CD_STATUS CD_STATUS,
//     TDM_CD_EPA CD_EPA,
//     TDM_CD_COMP CD_COMP
//     FROM
//     V_TDC_MAP WHERE TDM_CD_STATUS = 'A'`;

//     if (data?.acttdc) {
//       sql += ` AND TDM_ACT_TDC ='${data?.acttdc}'`;
//     }
//     if (data.endTDC && data.endTDC?.length > 0) {
//       sql += ` AND TDM_END_TDC = '${data?.endTDC}'`;
//     }
//     return await query(sql);
//   } catch (error: any) {
//     console.log("-->", error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const callProcedure06 = async (data: any) => {
//   try {
//     const sql = `call TSKEPADBA.MSTB001(
//         ls_act_tdc => :ls_act_tdc,
//         ls_end_tdc => :ls_end_tdc,
//         ls_flag    => :ls_flag,
//         lb_status => :lb_status,
//         ls_user   => :ls_user,
//         ls_cd_epa => :ls_cd_epa,
//         ls_tdc_prime => :ls_tdc_prime,
//         ls_tdc_downgrade => :ls_tdc_downgrade,      
//         ls_sec1_from => :ls_sec1_from,
//         ls_sec1_to         => :ls_sec1_to,
//         ls_sec2_from      => :ls_sec2_from,
//         ls_sec2_to      => :ls_sec2_to,
//         ls_sheet_ind      => :ls_sheet_ind,
//         ls_no_matnr      => :ls_no_matnr,
//         ls_wt_min          => :ls_wt_min,
//         ls_wt_max        => :ls_wt_max,
//         ls_qlty_prime         => :ls_qlty_prime,
//         ls_qlty_downgrade      => :ls_qlty_downgrade,
//         ls_message => :ls_message
//         )`;
//     const binds = {
//       ls_act_tdc: data?.ls_Act_tdc ? data?.ls_Act_tdc : "",
//       ls_end_tdc: data?.ls_end_tdc ? data?.ls_end_tdc : "",
//       ls_flag: data?.ls_flag ? data?.ls_flag : "",
//       lb_status: data?.lb_status ? data?.lb_status : "",
//       ls_user: data?.ls_user ? data?.ls_user : "",
//       ls_cd_epa: data?.ls_cd_epa ? data?.ls_cd_epa : "",
//       ls_tdc_prime: data?.ls_tdc_prime ? data?.ls_tdc_prime : "",
//       ls_tdc_downgrade: data?.ls_tdc_downgrade ? data?.ls_tdc_downgrade : "",
//       ls_sec1_from: data?.ls_sec1_from ? data?.ls_sec1_from : "",
//       ls_sec1_to: data?.ls_sec1_to ? data?.ls_sec1_to : "",
//       ls_sec2_from: data?.ls_sec2_from ? data?.ls_sec2_from : "",
//       ls_sec2_to: data?.ls_sec2_to ? data?.ls_sec2_to : "",
//       ls_sheet_ind: data?.ls_sheet_ind ? data?.ls_sheet_ind : "",
//       ls_no_matnr: data?.ls_no_matnr ? data?.ls_no_matnr : "",
//       ls_wt_min: data?.ls_wt_min ? data?.ls_wt_min : "",
//       ls_wt_max: data?.ls_wt_max ? data?.ls_wt_max : "",
//       ls_qlty_prime: data?.ls_qlty_prime ? data?.ls_qlty_prime : "",
//       ls_qlty_downgrade: data?.ls_qlty_downgrade ? data?.ls_qlty_downgrade : "",
//       ls_message: {
//         type: oracledb.STRING,
//         dir: oracledb.BIND_OUT,
//         maxSize: 500,
//       },
//     };
//     return await query(sql, binds);
//   } catch (error: any) {
//     console.log("e: ", error);
//     throw new Error.InternalServerError("Error");
//   }
// };
