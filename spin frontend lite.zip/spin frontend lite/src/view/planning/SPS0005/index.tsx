/* ------------------ To keep track of changes --------------------------------------
  
Changed on - 19.02.2026, By Ritya
Purpose - Making TDC & Thickness in order data dialog box editable for WIP schedling, process - SLT, NCTL, WCTL as well 
  So, that coil can be scheduled with downgraded or diverted tdc as well. This is new requirement. 
  Earlier this could be done only for RM coils
  
Changed on - 19.06.2026, By Ritya
Purpose - 1. Coils planned in Slitter must have Idia in PDI either 508 or 610.
              2. For coils in slit + ctl plan, if order has idia 0 or null, provide option to edit Idia.
              3. All rows in PDI must have same Idia.

Changed on - 31.07.2026, By Ritya
Purpose   - Diversion tdc logic modified to display tdc mapped in IPD instead of old logic.
  ----------------------------------------------------------------------------------- */

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";

import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
//import Paper, { PaperProps } from '@mui/material/Paper';
import Draggable from "react-draggable";
import CloseIcon from "@mui/icons-material/Close";
//import ReactModal from "react-modal-resizable-draggable";

import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  ListSubheader,
} from "@mui/material";
import {
  SPS0005SchedulingApi,
  SPS0005GetOrderDataApi,
  SPS0005ScheduleID,
  SPS0005ToleranceApi,
  SPS0005DiversionRes,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import ArchitectureIcon from "@mui/icons-material/Architecture";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
//import { TableType, PopupObj } from "./type";
//import { LoopMsg } from "../../type";
import { useMaterialUIController } from "../../../context";
//import { Collapse } from "@mui/material";
//import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
//import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
//import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
//import { returnStatement } from "@babel/types";
import Alert from "@mui/material/Alert";
import { Option } from "../../planning/SPS0005/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPS0005 = () => {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [table1, setTable1] = React.useState<any>(null);
  const [table2, setTable2] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  //const [destPlant, setDestPlant] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [plannedPath, setPlannedPath] = React.useState<Array<SelectType>>([]);
  const [coilData, setCoilData] = React.useState<Array<SelectType>>([]);
  const [selectedCoil, setSelectedCoil] = React.useState<string>("");
  const [thickness, setThickness] = React.useState<string>("");
  const [thicknessTo, setThicknessTo] = React.useState<string>("");
  //const [hight, setHight] = React.useState<string>("");
  const [width, setWidth] = React.useState<string>("");
  const [widthTo, setWidthTo] = React.useState<string>("");
  const [tdc, setTdc] = React.useState<string>("");
  const [isComputed, setIsComputed] = React.useState<Boolean>(false);
  const [orderData, setOrderData] = React.useState<Array<SelectType>>([]);
  // const [selectedOrder, setSelectedOrder] = React.useState<string>("");
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [processData, setProcessData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);
  //const [cellVal, setCellVal] = React.useState<any>(null);
  const [packingCode, setPackingCode] = React.useState<any>([]);
  const [oilingCode, setOilingCode] = React.useState<any>([]);
  const [scheduleDetailsData, setScheduleDetailsData] = React.useState<
    Array<SelectType>
  >([]);
  const [selectedRMData, setSelectedRMData] = React.useState<any>([]);
  //const [tempData, setTempData] = React.useState<any>([]);
  //---popup---\\
  const [isPopUp, setIsPopUp] = React.useState<any>({
    popUp: false,
    data: "",
  });
  //const [open, setOpen] = React.useState(false);
  const [orderTableData, setOrderTableData] = React.useState([]);
  const [orderItem, setOrderItem] = React.useState<string>("");
  const [orderTDC, setOrderTDC] = React.useState<any>("");
  const [ordTDCList, setOrdTDCList] = React.useState<Array<SelectType>>([]);

  const [downTDCList, setDownTDCList] = React.useState<Array<SelectType>>([]);
  const [divTDCList, setDivTDCList] = React.useState<Array<SelectType>>([]);

  const [order_Id, setOrder_Id] = React.useState<string>("");
  const [orderThick, setOrderThick] = React.useState<any>("");
  const [orderWidth, setOrderWidth] = React.useState<string>("");
  const [orderTypeData, setOrderTypeData] = React.useState<Array<SelectType>>(
    []
  );
  const [orderType, setOrderType] = React.useState<string>("");
  const [selPlanPath, setSelPlanPath] = React.useState<string>("");

  const [yieldOk, setYieldOk] = React.useState<Boolean>(false);
  const [scheId, setScheId] = React.useState<string>("");
  const [isConfirmed, setIsConfirmed] = React.useState(false);

  const [prodCd, setProdCd] = React.useState<any>("");
  //const [fromDt, setFromDt] = React.useState<any>("");
  //const [toDt, setToDt] = React.useState<any>("");
  const [Idia, setIdia] = React.useState<any>("");

  const [subProcLine, setSubProcLine] = React.useState<Array<SelectType>>([]);

  const [showSaveMsgSuccess, setShowSaveMsgSuccess] = React.useState(false);
  const [showSaveMsgError, setShowSaveMsgError] = React.useState(false);
  const [saveMsg, setSaveMsg] = React.useState<any>("");
  //const [planPathFlag, setPlanPathFlag] = React.useState<any>("");
  const [selectedPlanPath, setSelectedPlanPath] = React.useState<any>("");
  const [contrYield, setContrYield] = React.useState<string>("");
  const [actlYield, setActlYield] = React.useState<string>("");
  const [activityNM, setActivityNM] = React.useState(false);
  const [selectedOrderId, setSelectedOrderId] = React.useState<string>("");
  const [tolerence, setTolerence] = React.useState<any>([]);

  const schdOp: Array<SelectType> = [
    { value: "RM", label: "RM Schedulling", id: 1 },
    { value: "WIP", label: "WIP Schedulling", id: 2 },
  ];

  const [schedule, setSchedule] = React.useState<Array<SelectType>>([]);
  const [selectedSchd, setSelectedSchd] = React.useState<string>(
    schdOp[0].value
  );

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "From Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "To Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };
  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  function isWidthEditable() {
    return (
      selectedSchd !== "WIP" &&
      (selectedProcess === "S" || selectedProcess === "K")
    );
  }

  // visible everywhere except for slit and packing
  // pkt and pcs/pkt
  function isVisibleNT() {
    return selectedProcess !== "S" && selectedProcess !== "K";
  }

  const scheduleDetailsTableClm: any = [
    {
      field: "id",
      headerSort: false,
    },
    {
      title: "Setup CD",
      field: "ddlSchStCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "select",
      editorParams: {
        values: [
          { label: "A01", value: "A01" },
          { label: "A02", value: "A02" },
          { label: "A03", value: "A03" },
          { label: "A04", value: "A04" },
          { label: "A05", value: "A05" },
          { label: "A06", value: "A06" },
          { label: "A07", value: "A07" },
          { label: "A08", value: "A08" },
          { label: "A09", value: "A09" },
          { label: "A10", value: "A10" },
        ],
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      field: "txtSubProcLine",
      title: "Sub Proc Line",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      headerSort: false,
      minWidth: 80,
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: subProcLine,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      cellEdited: function (cell: any) {
        const subProc = cell.getValue();
        const row = cell.getRow();
        if (subProc === "R" && selectedProcess === "S") {
          let rmCoilWidth = table?.getSelectedRows()?.[0]?._row?.data?.EOM_SEC2;
          row.update({
            txtSchWidth: rmCoilWidth,
          });
        }
        // Force the table to update - this will trigger a re-evaluation of the editable function
        row.getTable().redraw(true);
      },
    },
    {
      title: "Batch ID",
      field: "txtSchBatch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Input Wt",
      field: "txtNetWt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "txtSchPlannedPath",
      title: "Planned Path",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      headerSort: false,
      minWidth: 80,
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: plannedPath,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },

      cellEdited: function (cell: any) {
        const row = cell.getRow();
        const rowData = row.getData();
        // reset Idia if planned path changes
        if (rowData.txtSchIdia && !rowData?.txtOrderIdia) {
          row.update({
            txtSchIdia: "",
          });
        }
        // force re-evaluation of editable conditions
        row.getTable().redraw(true);
      },
    },
    {
      title: "Order Id",
      field: "txtSchOrd",
      headerFilter: "input",
      width: 100,
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "input",
      cellClick: function (e: any, row: any) {
        let plannedPath = row.getData().txtSchPlannedPath;

        setSelPlanPath(plannedPath);

        if (!plannedPath) {
          alertify.error("Select Planned Path!");
          return;
        }

        let ordId, width, batchStatus;
        if (selectedSchd === "WIP") {
          let tableSelectedRow = table.getSelectedRows()[0];
          batchStatus = tableSelectedRow.getData().EOM_CD_STATUS;
          ordId = tableSelectedRow.getData().EOM_ID_ORDER_CUS;
          width = tableSelectedRow.getData().EOM_SEC2;

          console.log("tableSelectedRow: ", tableSelectedRow.getData());
          // if (batchStatus === "NB") {
          //   row.getCell("txtSchOrd").setValue(ordId);
          // }
        }

        fetchOrdTDCListData();
        let data = row.getData();
        let obj: any = {
          id: data?.id,
          plant: data?.txtSchBatch,
          ordtype: "",
          ordid: data?.txtSchOrdm,
          orditem: data?.txtSchItem,
          ordtdc: data?.txtSchTdc,
          ordthick: data?.txtSchThick,
          ordwidth: data?.txtSchWidth,
          lastSlit: data?.txtSchNoslt,
          lastCoilWidth: data?.txtCoilWidth,
          oiling: data?.txtOiling,
          packing: data?.txtPacking,
          //lastPlantWt: data?.txtSchPlantwt,
          lastPlantWt: selectedRMData.EOM_MS_PIECE_ACTL,
          plannedWt: data?.txtSchAimWt,
          ordlen: data?.txtSchLength,
        };
        data?.txtSchThick
          ? setOrderThick(data?.txtSchThick?.toFixed(3))
          : setOrderThick("");
        data?.txtSchTdc ? setOrderTDC(data?.txtSchTdc) : setOrderTDC("");

        if (ordId && selectedSchd === "WIP" && batchStatus.endsWith("B")) {
          setOrder_Id(ordId);
        } else {
          setOrder_Id("");
        }

        // If selected process is other then slit width should set automatically
        let width1 = table.getSelectedRows()[0]?.getData()?.EOM_SEC2;
        if (width1 && selectedProcess !== "S") {
          setOrderWidth(width1);
        } else {
          setOrderWidth("");
        }

        setIsPopUp({ popUp: true, data: obj });
      },
      formatter: function (cell: any) {
        cell.getElement().style["border"] = "1.5px solid #748da6";

        var value = cell.getValue();

        return value;
      },
    },
    {
      title: "Item",
      field: "txtSchItem",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        return value;
      },
    },
    // { title: "Sco Order", field: "txtSchScoOrd", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { title: "Item", field: "txtSchScoItem", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      title: "Thick",
      field: "txtSchThick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "txtSchWidth",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "number",
      formatter: function (cell: any) {
        var value = cell.getValue();
        const subProc = cell.getRow().getData().txtSubProcLine;
        if (
          ((selectedProcess === "S" || selectedProcess === "K") &&
            selectedSchd === "RM") ||
          (selectedSchd === "WIP" && subProc === "S" && selectedProcess === "S")
        ) {
          cell.getElement().style["border"] = "1.5px solid #748da6";
        }
        return value;
      },
      cellEdited: function (cell: any) {
        let updatedData = cell.getValue();
        let coilWidth = cell?._cell?.row?.data?.txtCoilWidth;
        let plantWt = selectedRMData.EOM_MS_PIECE_ACTL; //cell?._cell?.row?.data?.txtSchPlantwt;
        let slits = cell?._cell?.row?.data?.txtSchNoslt;
        let aimWt = ((updatedData * slits) / coilWidth) * plantWt;
        let row = cell.getRow();
      },
      editable: function (cell: any) {
        const subProc = cell.getRow().getData().txtSubProcLine;

        return (
          isWidthEditable() ||
          (selectedSchd === "WIP" && subProc === "S" && selectedProcess === "S")
        );
      },
    },
    {
      title: "Length",
      field: "txtSchLength",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      width: 70,
      formatter: function (cell: any) {
        var value = cell.getValue();
        return value?.toFixed(3);
      },
    },
    {
      title: "Tdc",
      field: "txtSchTdc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",

      formatter: function (cell: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    // {
    //   title: "Plan wt",
    //   field: "txtSchPlantwt",
    //   headerFilter: "input",
    //   bottomCalc: "sum",
    //   headerFilterPlaceholder: "search...",
    //   bottomCalcParams: { precision: 3 },
    //   //editor: "number",
    //   formatter: function (cell: any) {
    //     var value = cell.getValue();
    //     // cell.getElement().style["background-color"] = "#748da6";
    //     // cell.getElement().style["color"] = "#FFFFFF";
    //     return value;
    //   },
    //   cellEdited: function (cell: any) {
    //     let updatedData = cell.getValue();
    //     let coilWidth = cell?._cell?.row?.data?.txtCoilWidth;
    //     let fgCoil = cell?._cell?.row?.data?.txtSchWidth;
    //     let slits = cell?._cell?.row?.data?.txtSchNoslt;
    //     let aimWt = ((fgCoil * slits) / coilWidth) * updatedData;
    //     let row = cell.getRow();
    //     row.update({
    //       txtSchAimWt: aimWt.toFixed(3),
    //     });
    //   },
    // },
    {
      title: "Planned wt",
      field: "txtSchAimWt",
      headerFilter: "input",
      bottomCalc: "sum",
      editor: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
      cellEdited: function (cell: any) {
        let updatedPlanWt = cell.getValue();
        let row = cell.getRow();

        let item = row?.getData()?.txtSchItem;

        if (item.length !== 0) {
          let maxWt = row?.getData()?.txtSchMaxwt;
          let pktNo = Math.ceil(updatedPlanWt / maxWt);

          let thick = row?.getData()?.txtSchThick;
          let width = row?.getData()?.txtSchWidth;
          let length = row?.getData()?.txtSchLength;

          let perShtWt = (thick * width * length * 7.85) / 1000000;
          let temp = updatedPlanWt / perShtWt;
          let pcsPerPkt = Math.floor(temp / pktNo);

          // row.update({
          //   txtPktNo: pktNo,
          //   txtPcsPkt: pcsPerPkt,
          // });
        }
        row.update({
          txtSchAimWt: updatedPlanWt,
          // txtPktNo: pktNo,
        });
      },
    },
    {
      // title: activityNM ? "Packet(nos)" : "No Slt/Bundle", // Created different col for packet no
      title: "No Slt/Bundle",
      field: "txtSchNoslt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "number",
      visible: !isVisibleNT(),
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      cellEdited: function (cell: any) {
        let updatedData = cell.getValue();
        let coilWidth = cell?._cell?.row?.data?.txtCoilWidth;
        //let plantWt = cell?._cell?.row?.data?.txtSchPlantwt;
        let plantWt = selectedRMData.EOM_MS_PIECE_ACTL;
        let fgCoil = cell?._cell?.row?.data?.txtSchWidth;
        let aimWt = ((fgCoil * updatedData) / coilWidth) * plantWt;
        let row = cell.getRow();
        // row.update({
        //   txtSchAimWt: aimWt.toFixed(3),
        // });
      },
    },
    {
      // title: activityNM ? "Pcs/Packet" : "No Part",
      title: "No Part",
      field: "txtSchNoPart",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "input",
      type: "number",
      visible: !isVisibleNT(),
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },

    {
      title: "Packet(nos)",
      field: "txtPktNo",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "number",
      visible: isVisibleNT(),
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      cellEdited: function (cell: any) {
        let updatedPktValue = cell.getValue();
        let row = cell.getRow();
        let item = row?.getData()?.txtSchItem;

        if (item.length !== 0) {
          let plannedWt = row?.getData()?.txtSchAimWt;

          let thick = row?.getData()?.txtSchThick;
          let width = row?.getData()?.txtSchWidth;
          let length = row?.getData()?.txtSchLength;

          let perShtWt = (thick * width * length * 7.85) / 1000000;
          let temp = plannedWt / perShtWt;
          let pcsPerPkt = Math.floor(temp / updatedPktValue);

          row.update({
            txtPktNo: updatedPktValue,
            // txtPcsPkt: pcsPerPkt,
          });
        }
        return value;
      },
    },
    {
      title: "Pcs/Packet",
      field: "txtPcsPkt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "input",
      type: "number",
      visible: isVisibleNT(),
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      title: "No Pcs",
      field: "txtSchNoPcs",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: "input",
      type: "number",
      visible: false,
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },

    {
      field: "txtPacking",
      title: "Packing Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      headerSort: false,
      minWidth: 100,
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: packingCode,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      field: "txtOiling",
      title: "Oiling Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      headerSort: false,
      minWidth: 100,
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: oilingCode,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      title: "Idia",
      field: "txtSchIdia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",

      editor: "select",
      editorParams: {
        values: {
          508: 508,
          610: 610,
        },
      },
      editable: function (cell: any) {
        const data = cell.getRow().getData();
        const isOrderIdiaZero = !data.txtOrderIdia || data.txtOrderIdia === 0;
        return (
          selectedProcess === "S" &&
          data.txtSchPlannedPath !== "SKW" &&
          isOrderIdiaZero
        );
      },

      formatter: function (cell: any) {
        const value = cell.getValue();
        const data = cell.getRow().getData();

        const isEditable =
          selectedProcess === "S" &&
          data.txtSchPlannedPath !== "SKW" &&
          (!data.txtOrderIdia || data.txtOrderIdia === 0);

        if (isEditable) {
          cell.getElement().style["border"] = "1.5px solid #748da6";
        } else {
          // optional: show locked feel
          cell.getElement().style["backgroundColor"] = "#f5f5f5";
          cell.getElement().style["color"] = "#666";
        }

        return value;
      },
    },
    {
      title: "Remarks",
      field: "txtSchRemark",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "input",

      minWidth: 200,
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      title: "Plan Grade",
      field: "txtplanGrade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Width",
      feild: "txtCoilWidth",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Prod cd",
      field: "txtSchProdCd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty cd",
      field: "txtSchQltycd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Min Wt",
      field: "txtSchMinwt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      //editor: "input",
      // formatter: function (cell: any) {
      //   var value = cell.getValue();
      //   cell.getElement().style["background-color"] = "#748da6";
      //   cell.getElement().style["color"] = "#FFFFFF";
      //   return value;
      // },
    },
    {
      title: "Max Wt",
      field: "txtSchMaxwt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      //editor: "input",
      // formatter: function (cell: any) {
      //   var value = cell.getValue();
      //   cell.getElement().style["background-color"] = "#748da6";
      //   cell.getElement().style["color"] = "#FFFFFF";
      //   return value;
      // },
    },
    {
      title: "Mark Customer",
      field: "txtmkCust",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      //visible: false,
    },
    {
      title: "",
      field: "",
      formatter: "buttonCross",
      cellClick: function (e: any, cell: any) {
        deleteCell(cell);
      },
    },
  ];

  const scheduleDetailsNonEditable: any = [
    {
      title: "Setup CD",
      field: "ddlSchStCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Proc Line",
      field: "ddlSchProcLn",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Batch ID",
      field: "txtSchBatch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "txtSchPlannedPath",
      title: "Planned Path",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Id",
      field: "txtSchOrd",
      headerFilter: "input",
      hozAlign: "right",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Item",
      field: "txtSchItem",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    // { title: "Sco Order", field: "txtSchScoOrd", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { title: "Item", field: "txtSchScoItem", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      title: "Prod cd",
      field: "txtSchProdCd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "txtSchThick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Width",
      field: "txtSchWidth",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "txtSchLength",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Tdc",
      field: "txtSchTdc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    ,
    // {
    //   title: "Plan wt",
    //   field: "txtSchPlantwt",
    //   headerFilter: "input",
    //   bottomCalc: "sum",
    //   bottomCalcParams: { precision: 3 },
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "No Slits/Bndls",
      field: "txtSchNoslt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: !isVisibleNT(),
    },
    {
      title: "No Part",
      field: "txtSchNoPart",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: !isVisibleNT(),
    },
    {
      title: "No Pcs",
      field: "txtSchNoPcs",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Packet(nos)",
      field: "txtPktNo",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: isVisibleNT(),
    },
    {
      title: "Pcs/Packet",
      field: "txtPcsPkt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: isVisibleNT(),
    },
    {
      title: "Planned wt",
      field: "txtSchAimWt",
      headerFilter: "input",
      bottomCalc: "sum",
      headerFilterPlaceholder: "search...",
      bottomCalcParams: { precision: 3 },
      editor: "number",
      hozAlign: "right",
    },
    {
      title: "Remarks",
      field: "txtSchRemark",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plan Grade",
      field: "txtplanGrade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Width",
      feild: "txtCoilWidth",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Packing Code",
      field: "txtPacking",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Oiling Code",
      field: "txtOiling",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty cd",
      field: "txtSchQltycd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Idia",
      field: "txtSchIdia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Min Wt",
      field: "txtSchMinwt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Max Wt",
      field: "txtSchMaxwt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const deleteCell = async (cell: any) => {
    let filteredCoils = scheduleDetailsData?.filter(
      (item) => item.id !== cell._cell.row.data.id
    );
    // scheduleDtDetails.replaceData(filteredCoils);
    // setScheduleDetailsData(filteredCoils);
    setScheduleDetailsData([]);
    setScheduleDetailsData(filteredCoils);
  };

  // function isVisibleNT() {
  //   return selectedProcess === "N" || selectedProcess === "T";
  // }

  const column: Array<any> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },
    // {
    //   rowHandle: true,
    //   formatter: "handle",
    //   headerSort: false,
    //   width: 30,
    //   minWidth: 30,
    // },
    {
      field: "EOM_ID_BATCH",
      title: "Batch",
      width: 100,
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        let SLP_Remarks = cell?._cell?.row?.data?.SLP_REMARKS;
        if (SLP_Remarks != null) {
          cell.getElement().style["background-color"] = "#008000";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
    },
    {
      field: "MATERIL_NO",
      title: "Material No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATERIAL_DESC",
      title: "Material Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_SEC1",
      title: "Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "EOM_SEC2",
      title: "Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      field: "EOM_LENGTH",
      title: "Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      field: "EOM_TDC_ACTL",
      title: "Tdc/Grade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "COIL_GRADE",
      title: "Coil Grade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_MS_PIECE_ACTL",
      title: "Net Wt(MT)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      field: "GROSS_CAL",
      title: "Res Wt(MT)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      field: "CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "POST_TREAT_ACTL",
      title: "Actl Post Treat",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "YS",
      title: "YS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    // { field: "EOM_ID_ORD_ITEM_CUS", title: "Item", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      field: "EOM_CD_STATUS",
      title: "Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // { field: "MillOrd", title: "Mill Ord", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Mill_Item", title: "Item", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Remarks", title: "Remarks", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Salvage_Remark", title: "Salvaging Remarks", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Top_Remrk", title: "Top Remarks", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "BottamRemrk", title: "Bottom Remarks", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "FileName", title: "File Name", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "WrkCentr", title: "Work Center", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Materil_No1", title: "Material No 1", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Material_desc1", title: "Material Desc 1", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // {
    //     field: "EOM_MATNR1_QTY", title: "Material 1 Qty", "headerFilter": "input", "headerFilterPlaceholder": "search...", formatter: function (cell, formatterParams) {
    //         var value = cell.getValue();
    //         if (value) {
    //             return value.toFixed(3);
    //         }
    //         return value
    //     },
    // },
    // { field: "Materil_No2", title: "Material No 2", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Material_desc2", title: "Material Desc 2", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "EOM_MATNR2_QTY", title: "Material 2 Qty", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Materil_No3", title: "Material No 3", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Material_desc3", title: "Material Desc 3", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "EOM_MATNR3_QTY", title: "Material 3 Qty", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Materil_No4", title: "Material No 4", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "Material_desc4", title: "Material Desc 4", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "EOM_MATNR4_QTY", title: "Material 4 Qty", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // { field: "PRV_SPC_OPR_COMNTS", title: "Previous SPC Operator Remarks", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      title: "Age (Days)",
      field: "AGE_DAYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "No Pcs",
      field: "EOM_NO_PIECES",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleNT(),
      hozAlign: "right",
    },

    {
      field: "EOM_MS_SCRAP",
      title: "Scrap Wt",
      headerFilter: "input",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "EOM_ID_ORDER_CUS",
      title: "Order ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Yrd",
      field: "EOM_CD_YRD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc X",
      field: "EOM_ID_LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc Y",
      field: "EOM_ID_LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc Z",
      field: "EOM_ID_POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_IDIA",
      title: "Idia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      field: "EOM_CD_PROD",
      title: "Prod",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_QLTY_ACTL",
      title: "Qlty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MK_CUSTOMER",
      title: "Mark Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SOURCE_PLANT",
      title: "Source Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      field: "OPR_REMARKS",
      title: "Hold Opr Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rls Remarks",
      field: "RELEASE_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Addl Rls Remarks",
      field: "RELEASE_REMARKS1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SLP_REMARKS",
      title: "Salvaging Remarks", //SLP
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const columnNoneditable: Array<any> = [
    {
      formatter: "",
      hozAlign: "center",
      download: true,
      headerSort: false,
      title: "",
    },
    {
      field: "EOM_ID_BATCH",
      title: "Batch",
      width: 100,
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_PROD",
      title: "Prod",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_QLTY_ACTL",
      title: "Qlty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATERIL_NO",
      title: "Material No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATERIAL_DESC",
      title: "Material Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "EOM_SEC1",
      title: "Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      field: "EOM_SEC2",
      title: "Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },

    {
      field: "EOM_TDC_ACTL",
      title: "Tdc/Grade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "YS",
      title: "YS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_MS_PIECE_ACTL",
      title: "Net Wt(MT)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "GROSS_CAL",
      title: "Res Wt(MT)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "EOM_CD_STATUS",
      title: "Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Age (Days)",
      field: "AGE_DAYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "EOM_MS_SCRAP",
      title: "Scrap Wt",
      headerFilter: "input",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Yrd",
      field: "EOM_CD_YRD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc X",
      field: "EOM_ID_LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc Y",
      field: "EOM_ID_LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc Z",
      field: "EOM_ID_POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_IDIA",
      title: "Idia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MK_CUSTOMER",
      title: "Mark Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setSelectedCode("");
    setSelectedProcess("");
    fetchEpaData();
  };
  const handleChangeSubProc = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setSelectedProcess(event);
    fetchSubProcData(event);
  };
  const handleChangeCoilId = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setSelectedCoil(event);
  };

  const handleChangeStatus = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setSelectedStatus(event);
  };
  const handleChangeThickFrom = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setThickness(event);
  };
  const handleChangeThickTo = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setThicknessTo(event);
  };
  const handleChangeWidthFrom = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setWidth(event);
  };
  const handleChangeWidthTo = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setWidthTo(event);
  };
  const handleChangeTdc = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setTdc(event?.toUpperCase().slice(0, 5));
  };
  const handleChangeProdCd = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setProdCd(event);
  };
  const handleChangeIdia = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTableData([]);
    setScheduleDetailsData([]);
    setIdia(event);
  };
  const handleChangeOrderId = (event: React.ChangeEvent<HTMLInputElement>) => {
    setOrder_Id(event);
    setOrderTableData([]);
  };
  const handleChangeOrderItem = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setOrderItem(event);
    setOrderTableData([]);
  };
  const handleChangeOrderTdc = (event: React.ChangeEvent<HTMLInputElement>) => {
    setOrderTDC(event);
    setOrderTableData([]);
  };
  const handleChangeOrderType = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setOrderType(event);
    setOrderTableData([]);
  };
  const handleChangeOrderThick = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setOrderThick(event);
    setOrderTableData([]);
  };
  const handleChangeOrderWidth = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setOrderWidth(event);
    setOrderTableData([]);
  };

  const handleSchdOpChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event);
    setSelectedSchd(event);
    setTableData([]);
    setScheduleDetailsData([]);
    setSelectedProcess("");
    setSelectedStatus("");
  };

  React.useEffect(() => {
    fetchEpaData();
    setTableData([]);
    setScheduleDetailsData([]);
    setOrderTableData([]);
  }, []);

  React.useEffect(() => {
    if (!(selectedOrderId?.length == 0)) {
      fetchPackingData();
    }
  }, [selectedOrderId?.ENC_ID_ORDER]);

  React.useEffect(() => {
    if (!(selectedProcess?.length == 0)) {
      fetchEpaData();
      fetchActivityNMData();
    }
  }, [selectedProcess]);

  //call Packing Code function
  // React.useEffect(() => {
  // if (!(selectedPlanPath?.length == 0)) {
  //     checkPackingFlag(selectedPlanPath);
  //   }
  // }, [selectedPlanPath]);

  React.useEffect(() => {
    if (!(orderTDC?.length == 0)) {
      if (ordTDCList?.length == 0) {
        fetchOrdTDCListData();
      }
    }
  }, [orderTDC]);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: isComputed ? columnNoneditable : column,
          height: 200,
          layout: "fitDataFill",
          // movableRows: true,
          selectable: 1,
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData, isComputed]);

  table?.on("rowSelected", function (data: any) {
    if (isComputed === true) {
      return;
    }
    setScheduleDetailsData([]);
    setSelectedRMData([]);
    setContrYield("");
    setActlYield("");

    let cell: any = data._row;
    //let array: any = [...scheduleDetailsData];
    let filteredSchedDetailsData = scheduleDetailsData?.filter(
      (item) => item.id == 9 // remove data.
    );
    let array: any = [...filteredSchedDetailsData];
    setSelectedRMData(cell.getData());
    array.push({
      //id: scheduleDetailsData.length,
      id: 1,
      ddlSchStCD: "A01",
      ddlSchProcLn: selectedProcess,
      txtSubProcLine: "",
      txtSchBatch: cell.getData().EOM_ID_BATCH,
      txtNetWt: cell.getData().EOM_MS_PIECE_ACTL,
      ddlProcRt: "",
      txtSchPlannedPath: "",
      txtSchOrd: "",
      txtSchItem: "",
      txtSchScoOrd: "",
      txtSchScoItem: "",
      txtSchProdCd: cell.getData().EOM_CD_PROD,
      txtSchQltycd: cell.getData().EOM_CD_QLTY_ACTL,
      txtSchIdia: cell.getData().EOM_IDIA,
      txtSchMinwt: "",
      txtSchMaxwt: "",
      txtSchThick: cell.getData().EOM_SEC1,
      txtSchWidth: cell.getData().EOM_SEC2,
      txtSchLength: cell.getData().EOM_LENGTH,
      ddlSchOfcut: "N",
      //txtSchTdc: cell.getData().EOM_TDC_ACTL,
      txtSchTdc: "",
      txtSchPlantwt: cell.getData().EOM_MS_PIECE_ACTL.toFixed(3),
      txtSchPktwt: "",
      txtSchNoslt: 1,
      txtSchNoPcs: "",
      txtSchNoStk: "",
      txtSchNoPkt: "",
      txtPacking: "",
      txtOiling: "",
      // txtSchAimWt: (
      //   (1 * cell.getData().EOM_MS_PIECE_ACTL) /
      //   cell.getData().EOM_SEC2
      // ).toFixed(3) /******** */,
      txtSchAimWt: cell.getData().EOM_MS_PIECE_ACTL.toFixed(3),
      txtSchPkgTyp: "",
      txtSchPkgDesc: "",
      txtSchRwrkInd: "",
      txtSchNoPart: 1,
      txtSchPlanRsn: "",
      txtSchPlanRsnCode: "",
      txtSchPlanRsnDesc: "",
      txtSchRemark: "",
      txtCoilWidth: cell.getData().EOM_SEC2,
      txtplanGrade: "",
      txtPktNo: 1,
      txtPcsPkt: 1,
      delete: "",
    });
    setScheduleDetailsData(array);
    return;
  });

  React.useEffect(() => {
    if (scheduleDetailsData?.length > 0) {
      setTable1(
        new Tabulator("#table1", {
          data: scheduleDetailsData,
          columns: isComputed
            ? scheduleDetailsNonEditable
            : scheduleDetailsTableClm,
          height: 350,
          // movableRows: true,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable1(null);
    }
    return () => table1?.destroy();
  }, [scheduleDetailsData, isComputed, packingCode, oilingCode]);

  const column3: Array<any> = [
    {
      // formatter: "rowSelection",
      formatter: function (cell) {
        var value = cell.getData().BTR;
        if (value === "0") {
          return "";
        } else {
          return "<input type='checkbox'>";
        }
      },
      hozAlign: "center",
      download: false,
      headerSort: false,
      title: "",
      width: "5px",
      frozen: true,
      selectable: function (row) {
        var btrValue = row.getData().BTR;
        return btrValue !== "0";
      },
      cellClick: function (e, cell) {
        const row = cell.getRow();
        const btrValue = cell.getValue();
        if (btrValue === "0") {
          row.deselect();
        }
      },
    },
    {
      title: "Order Id",
      field: "ENC_ID_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    {
      title: "Item No",
      field: "ENC_NO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Order Qty.(TON)",
      field: "ENC_ORD_QUANTITY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "BTR (Balance to Roll)",
      field: "BTR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value === "0") {
          cell.getElement().style.color = "red";
          cell.getElement().style.fontWeight = "bold";
        }
        return value;
      },
    },
    {
      title: "TDC/Grade",
      field: "ENC_NO_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Edge",
      field: "ENC_ORDER_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Post Treat",
      field: "ORDER_POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Min Thick",
      field: "ENC_SEC1_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Max Thick",
      field: "ENC_SEC1_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Min Width",
      field: "ENC_SEC2_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Max Width",
      field: "ENC_SEC2_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "ENC_LENGTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Plan Grade",
      field: "PLANGRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Max Weight",
      field: "ENC_MAX_PIECE_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Min Weight",
      field: "ENC_MIN_PIECE_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "IDIA",
      field: "ENC_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    // {
    //   title: "Packing Code",
    //   feild: "PACKING",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Oiling Code",
    //   feild: "OILING",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Qlty Cd",
      field: "ENC_CD_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    // { "title": "NO TRACKING", "field": "ENC_NO_TRACKING", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    // {
    //   title: "DESPATCHED",
    //   field: "DESP",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   formatter: function (cell: any) {
    //     var value = cell.getValue();
    //     if (value) {
    //       return value.toFixed(3);
    //     }
    //     return value;
    //   },
    // },
    // {
    //   title: "DISPATCHABLE",
    //   field: "DISPL",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   formatter: function (cell: any) {
    //     var value = cell.getValue();
    //     if (value) {
    //       return value.toFixed(3);
    //     }
    //     return value;
    //   },
    // },
    // {
    //   title: "LINKED",
    //   field: "LINKED",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   formatter: function (cell: any) {
    //     var value = cell.getValue();
    //     if (value) {
    //       return value.toFixed(3);
    //     }
    //     return value;
    //   },
    // },
    {
      title: "Mark Customer",
      field: "ENC_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Mark Cust Name",
      field: "ENC_MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Type",
      field: "ENC_ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Code",
      field: "ENC_CD_END_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Customer Name",
      field: "ENC_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material",
      field: "ENC_NO_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Material Desc",
      field: "MATERIAL_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Product Cd",
      field: "ENC_CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Crt Dt",
      field: "ENC_DT_ORD_CREATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "DELV DT",
      field: "ENC_DT_DELV",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Desc",
      field: "ENC_ORD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "ROADDEST DESC",
      field: "ENC_ROADDEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "RAILDEST DESC",
      field: "ENC_RAILDEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Plant",
      field: "ENC_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  React.useEffect(() => {
    if (orderTableData?.length > 0) {
      setTable2(
        new Tabulator("#table3", {
          data: orderTableData,
          columns: column3,
          height: 200,
          //movableRows: true,
          layout: "fitDataFill",
          selectable: 1,
        })
      );
    }
  }, [orderTableData]);

  React.useEffect(() => {
    if (yieldOk && isComputed) {
      confirmData();
    }
  }, [yieldOk, isComputed]);

  table2?.on("rowSelected", function (selectedData: any) {
    const btrValue = selectedData?._row?.getData()?.BTR;
    if (btrValue === "0") {
      table2.deselectRow(selectedData._row);
      return;
    }

    const data = {
      ord_tdc: selectedData?._row?.getData()?.ENC_NO_TDC,
      mark_cust: selectedData?._row?.getData()?.ENC_MARK_CUST,
    };
    setSelectedOrderId(selectedData?._row?.getData()?.ENC_ID_ORDER);
    fetchPackingData(data);
    const id: any = isPopUp?.data?.id;
    let slits = isPopUp?.data?.lastSlit;
    let coilWidth = isPopUp?.data?.lastCoilWidth;
    let planWt = isPopUp?.data?.lastPlantWt;
    slits = slits ? slits : 1;
    coilWidth = coilWidth ? coilWidth : 1;
    planWt = planWt ? planWt : 1;
    let aimWidth = (slits * planWt) / coilWidth;

    //Calculation for packet no & pcs/packet in ctl

    let thick = selectedData?._row?.getData()?.ENC_SEC1_MAX;
    let width = selectedData?._row?.getData()?.ENC_SEC2_MAX;
    let length = selectedData?._row?.getData()?.ENC_LENGTH_MAX;

    let perShtWt = (thick * width * length * 7.85) / 1000000;

    let plannedWt = isPopUp?.data?.plannedWt;
    let maxWt = selectedData?._row?.getData()?.ENC_MAX_PIECE_WT;
    let pktNo = Math.ceil(plannedWt / maxWt);

    let pcsPerPkt = Math.floor(plannedWt / perShtWt / pktNo);

    let rmCoilWidth = table?.getSelectedRows()?.[0]?._row?.data?.EOM_SEC2;
    // console.log("==> ", rmCoilWidth);

    const orderIdia = selectedData?._row?.getData()?.ENC_IDIA;

    table1?.updateData([
      {
        id: id,
        txtSchOrd: selectedData?._row?.getData()?.ENC_ID_ORDER,
        txtSchItem: selectedData?._row?.getData()?.ENC_NO_ITEM,
        txtSchQltycd: selectedData?._row?.getData()?.ENC_CD_QLTY,
        // txtSchIdia: selectedData?._row?.getData()?.ENC_IDIA,
        txtSchIdia: orderIdia && orderIdia !== 0 ? Number(orderIdia) : "",
        txtOrderIdia: orderIdia, // ✅ NEW FIELD
        txtSchMinwt: selectedData?._row?.getData()?.ENC_MIN_PIECE_WT,
        txtSchMaxwt: selectedData?._row?.getData()?.ENC_MAX_PIECE_WT,
        txtSchWidth:
          selectedSchd === "RM"
            ? selectedData?._row?.getData()?.ENC_SEC2_MAX
            : rmCoilWidth,
        txtSchLength: selectedData?._row?.getData()?.ENC_LENGTH_MAX,
        txtOiling: "",
        txtPacking: "",
        // txtSchAimWt: (
        //   aimWidth * selectedData?._row?.getData()?.ENC_SEC2_MAX
        // ).toFixed(3),
        txtplanGrade: selectedData?._row?.getData()?.PLANGRADE,
        txtmkCust: selectedData?._row?.getData()?.ENC_MARK_CUST,
        txtSchTdc: selectedData?._row?.getData()?.ENC_NO_TDC,
        txtPktNo: "", //pktNo,
        txtPcsPkt: "", //pcsPerPkt,
      },
    ]);
    setIsPopUp({ popUp: false, data: "" });
  });

  const confirmData = async () => {
    setYieldOk(false);
    let dataArr: any = [];
    const gridData = scheduleDetailsData;
    if (!(gridData?.length > 0)) {
      alertify.error("Please select a row!");
      return;
    }
    try {
      setLoading(true);
      const token = await GetAuthorization();
      const res = await SPS0005ToleranceApi(token);
      if (res.statusText !== "" && res.statusText !== "OK") {
        alertify.error(res?.data?.err ? res.data.err : res?.toString());
      } else {
        setTolerence(res?.data[0]?.CD_VALUE);
      }
    } catch (error) {
      alertify.error(error, "Something went Wrong");
    } finally {
      setLoading(false);
    }
    let varData1: any = [];
    let idiaSet = new Set();
    dataArr = table1?.getRows();
    for (let i = 0; i < dataArr.length; i++) {
      let x = dataArr[i];
      if (
        !x?._row?.data?.txtSchBatch ||
        x?._row?.data?.txtSchBatch.length === 0
      ) {
        alertify.error("Setup Code can't be Null ");
        return;
      }
      if (
        !x?._row?.data?.txtSubProcLine ||
        x?._row?.data?.txtSubProcLine.length === 0
      ) {
        alertify.error("Please Select Sub Process Line!");
        return;
      }
      if (
        !x?._row?.data?.txtSchPlannedPath ||
        x?._row?.data?.txtSchPlannedPath.length === 0
      ) {
        alertify.error("Please Select Planned path ");
        return;
      }
      if (!x?._row?.data?.txtSchOrd || x?._row?.data?.txtSchOrd.length === 0) {
        alertify.error("Please Select Order");
        return;
      }
      if (
        !x?._row?.data?.txtSchItem ||
        x?._row?.data?.txtSchItem.length === 0
      ) {
        alertify.error("Item cannot be Null");
        return;
      }
      if (
        !x?._row?.data?.txtSchWidth ||
        x?._row?.data?.txtSchWidth.length === 0
      ) {
        alertify.error("Please Enter Width");
        return;
      }
      if (
        !x?._row?.data?.txtSchNoslt ||
        x?._row?.data?.txtSchNoslt.length === 0
      ) {
        alertify.error("Please Enter No of Slits");
        return;
      }
      if (
        !x?._row?.data?.txtSchAimWt ||
        x?._row?.data?.txtSchAimWt.length === 0
      ) {
        alertify.error("Please Enter Planned Weight");
        return;
      }
      if (
        !x?._row?.data?.txtSubProcLine ||
        x?._row?.data?.txtSubProcLine.length === 0
      ) {
        alertify.error("Please Select Sub Process Line!");
        return;
      }

      const idia = Number(x?._row?.data?.txtSchIdia);

      if (selectedProcess === "S" && !idia) {
        alertify.error("Please select Idia at row no " + (i + 1));
        return;
      }

      if (selectedProcess === "S" && idia !== 508 && idia !== 610) {
        alertify.error(
          "Invalid Idia at row no " +
            (i + 1) +
            ". Allowed values are 508 or 610 only"
        );
        return;
      }
      idiaSet.add(idia);

      const planPath = x?._row?.data?.txtSchPlannedPath;

      let dataArr1: any = [];
      dataArr1 = table?.getSelectedRows();

      let coilWidth = dataArr1[0]?._row?.data?.EOM_SEC2;
      let sumWidthOrder = 0;
      let currentSetupCd = dataArr[0]?._row?.data?.ddlSchStCD;

      for (let i = 0; i < dataArr.length; i++) {
        let setupCd = dataArr[i]?._row?.data?.ddlSchStCD;

        let x = dataArr[i];
        let coilWidthOrder = x?._row?.data?.txtSchWidth;
        let noSlt = x?._row?.data?.txtSchNoslt;
        // console.log("noSlt: ", noSlt);

        if (setupCd !== currentSetupCd) {
          const diffWidth = coilWidth - sumWidthOrder;

          if (diffWidth > tolerence) {
            alertify.error(
              `Difference in width - ${diffWidth} is greater than 
              Tolerance - ${tolerence} for setup - ${currentSetupCd}`
            );
            return;
          }
          sumWidthOrder = 0;
          currentSetupCd = setupCd;
        }
        sumWidthOrder += coilWidthOrder * noSlt;
      }

      const diffWidth = coilWidth - sumWidthOrder;

      if (diffWidth > tolerence) {
        alertify.error(
          `Difference in width is ${diffWidth} which is 
          greater than Tolerance - ${tolerence} for setupCd: ${currentSetupCd}`
        );
        return;
      }

      try {
        setLoading(true);
        const token = await GetAuthorization();
        const res = await SPS0005SchedulingApi(token, {
          type: "checkPackingFlag",
          planPath: planPath,
        });
        if (res.statusText !== "" && res.statusText !== "OK") {
          alertify.error(res?.data?.err ? res.data.err : res?.toString());
        } else {
          if (
            res?.data.selectedPlanPath[0].LN_PRC_CNT === 1 &&
            x?._row?.data?.txtPacking === ""
          ) {
            let rowCount = x?._row?.data?.id;
            let msg = "Please Select Packing Code at row no " + rowCount + " !";

            alertify.error(msg);
            return;
          }
        }
      } catch (error) {
        alertify.error(error, "Something went Wrong");
      } finally {
        setLoading(false);
      }
      varData1.push({
        p_plant: selectedCode,
        p_mcoil: x?._row?.data?.txtSchBatch,
        p_process_ln: selectedProcess,
        p_subProc_ln: x?._row?.data?.txtSubProcLine,
        p_planPath: x?._row?.data?.txtSchPlannedPath,
        p_order: x?._row?.data?.txtSchOrd,
        p_ordItm: x?._row?.data?.txtSchItem,
        p_no_slt:
          selectedProcess === "S" || selectedProcess === "K"
            ? x?._row?.data?.txtSchNoslt
            : x?._row?.data?.txtPktNo,
        p_no_part:
          selectedProcess === "S" || selectedProcess === "K"
            ? x?._row?.data?.txtSchNoPart
            : x?._row?.data?.txtPcsPkt,
        p_ctl_pkt: x?._row?.data?.txtSchNoPkt,
        p_thk: x?._row?.data?.txtSchThick,
        p_width: x?._row?.data?.txtSchWidth,
        p_length: x?._row?.data?.txtSchLength,
        p_plan_wt: x?._row?.data?.txtSchPlantwt,
        p_aim_wt: x?._row?.data?.txtSchAimWt,
        p_setupno: x?._row?.data?.ddlSchStCD,
        p_pack_cd: x?._row?.data?.txtPacking,
        p_oil_cd: x?._row?.data?.txtOiling,
        p_user: user,
        p_row_seq: i,
        p_remarks: x?._row?.data?.txtSchRemark,
        p_fgGrade: x?._row?.data?.txtplanGrade,
        p_ctl_pkt_pcs: x?._row?.data?.txtSchNoPcs,
        p_tdc: x?._row?.data?.txtSchTdc,
      });
    }

    if (selectedProcess === "S" && idiaSet.size > 1) {
      alertify.error("All rows must have same Idia (508 or 610)");
      return;
    }

    if (!isComputed) {
      try {
        setLoading(true);
        const token = await GetAuthorization();
        const res = await SPS0005ScheduleID(token);
        if (res.statusText !== "" && res.statusText !== "OK") {
          alertify.error(res?.data?.err ? res.data.err : res?.toString());
        } else {
          setScheId(res?.data[0]?.SCH_ID);
          varData1.map((row: any) => {
            row["p_schedule_id"] = res?.data[0]?.SCH_ID;
          });
        }
      } catch (error) {
        alertify.error(error, "Something went Wrong");
      } finally {
        setLoading(false);
      }
    }
    const varData2 = {
      UserID: user,
      plantId: selectedCode,
      scheId: scheId.toString(),
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: isComputed ? "confirmData" : "computeData",
        //type: pType,
        data: isComputed ? varData2 : varData1,
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data: ", res.data);
            // if (res?.data?.FC?.substr(0, 1) === "1") {
            //   alertify.error(res?.data?.FC);
            //   return;
            // }
            // if (res?.data?.N[0]?.substr(0, 1) === "N") {
            //   alertify.error(res?.data?.N[0]);
            //   return;
            // }
            // if (res?.data?.substr(0, 1) === "1") {
            //   alertify.error(res?.data);
            //   return;
            // }
            if (isComputed) {
              //Confirm .then loop
              if (res.data[0] !== "Y") {
                setShowSaveMsgSuccess(false);
                setShowSaveMsgError(true);
                setSaveMsg(res.data);
                alertify.error(`${res.data}`);
              } else {
                setShowSaveMsgSuccess(true);
                setShowSaveMsgError(false);
                setSaveMsg(res.data);
                alertify.success(`${res.data}`);
                setIsConfirmed(true);
                setScheduleDetailsData([]);
                fetchData();
                setContrYield("");
                setActlYield("");
              }
            } else {
              if (res?.data?.FC?.substr(0, 1) === "1") {
                alertify.error(res?.data?.FC);
                return;
              }
              if (res?.data?.N[0]?.substr(0, 1) === "N") {
                alertify.error(res?.data?.N[0]);
                return;
              }
              if (res.data?.YZ?.substr(0, 1) === "Z") {
                setShowSaveMsgSuccess(true);
                setShowSaveMsgError(false);
                setSaveMsg(res.data?.YZ);
                let msg = res.data?.YZ;

                let start = msg.indexOf("=");
                let end = msg.indexOf(")");

                let contractYld = msg.substr(start + 1, end - 1 - start);
                contractYld = contractYld.replace("(", "");

                let first = msg.lastIndexOf("(");
                let last = msg.lastIndexOf(")");

                let acceptYld = msg.substr(first + 1, last - 1 - first);

                setContrYield(contractYld);
                setActlYield(acceptYld);
                alertify.confirm(
                  "Alert!",
                  "Yield Deviation found in coils. Do you want to continue?",
                  function () {
                    setIsComputed(true);
                    setYieldOk(true);
                  },
                  function () {}
                );
              }
              if (res.data?.YZ?.substr(0, 1) !== "Y") {
                alertify.error(`${res.data?.YZ}`);
              } else if (res.data?.N?.length > 0) {
                setShowSaveMsgSuccess(false);
                setShowSaveMsgError(true);
                setSaveMsg(res.data?.N);
                alertify.error(`${res.data?.N}`);
              } else {
                let msg = "All Coils are accepted";
                setShowSaveMsgSuccess(true);
                setShowSaveMsgError(false);
                setSaveMsg(msg);
                alertify.success(msg);
                setIsComputed(true);
              }
            }
          }
        })
        .catch((e: any) => {
          setShowSaveMsgSuccess(false);
          setShowSaveMsgError(true);
          setSaveMsg(e?.error?.message);
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  // fetch packing data
  const fetchPackingData = async (data: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "packingCode",
        Plant: selectedCode,
        MarkCust: data.mark_cust ? data.mark_cust : "",
        Tdc: data.ord_tdc ? data.ord_tdc : "",
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            //if (res?.data?.length > 0) {
            var varPackingCode: Array<SelectType> = [];
            res?.data?.packingCode?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varPackingCode?.push({
                  value: x?.PACK_CD?.toString(),
                  label: x?.PACK_CD?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPackingCode(varPackingCode);

            var varOilingCode: Array<SelectType> = [];
            res?.data?.oilingCode?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varOilingCode?.push({
                  value: x?.OIL_CD?.toString(),
                  label: x?.OIL_CD?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setOilingCode(varOilingCode);
            // }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
        proc: selectedProcess,
        //proc: selectedSchd == "RM" ? "0" : selectedProcess,
        schd: selectedSchd,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varbatchData: Array<SelectType> = [];
              res?.data?.batch?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varbatchData?.push({
                    value: x?.EOM_ID_BATCH?.toString(),
                    label: x?.EOM_ID_BATCH?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setCoilData(varbatchData);
              const varorderData: Array<SelectType> = [];
              res?.data?.order?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varorderData?.push({
                    value: x?.EOM_ID_ORDER?.toString(),
                    label: x?.EOM_ID_ORDER?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setOrderData(varorderData);
              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcessData(varprocessData);
              const varstatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.VALUE?.toString(),
                    label: x?.LABEL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
              var varPlannedPath: Array<SelectType> = [];
              res?.data?.plannedPath?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varPlannedPath?.push({
                    value: x?.PPH_CD_PROC_PATH?.toString(),
                    label: x?.PPH_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlannedPath(varPlannedPath);

              var varOrderType: Array<SelectType> = [];
              res?.data?.orderTypeData?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varPlannedPath?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_VALUE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setOrderTypeData(varOrderType);

              var varPackingCode: Array<SelectType> = [];
              res?.data?.packingCode?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varPackingCode?.push({
                    value: x?.PACK_CD?.toString(),
                    label: x?.PACK_CD?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPackingCode(varPackingCode);

              var varOilingCode: Array<SelectType> = [];
              res?.data?.oilingCode?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varOilingCode?.push({
                    value: x?.OIL_CD?.toString(),
                    label: x?.OIL_CD?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setOilingCode(varOilingCode);

              setTolerence(res?.data?.toleranceLimit[0].CD_VALUE);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchSubProcData = (value?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "getSubProcData",
        procLine: value,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            var varSubProcLine: Array<SelectType> = [];
            res?.data?.subProcLine?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varSubProcLine?.push({
                  value: x?.SUB_PROC_LINE?.toString(),
                  label: x?.SUB_PROC_LINE_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setSubProcLine(varSubProcLine);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const fetchActivityNMData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "getActivityNMData",
        Plant: selectedCode,
        procLine: selectedProcess,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const actNm = res?.data?.activityNM[0].EPL_ACTIVITY_NM;

            if (actNm == "CTL" || actNm == "NCTL" || actNm == "WCTL") {
              setActivityNM(true);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchOrdTDCListData = () => {
    setLoading(true);
    // getDiversionTdc();
    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "getOrdTDCList",
        Plant: selectedCode,
        Coil_ID: selectedRMData.EOM_ID_BATCH,
        Coil_TDC: selectedRMData.EOM_TDC_ACTL,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            var varData: Array<SelectType> = [];
            res?.data?.ordTDCList?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData?.push({
                  value: x?.EOM_TDC_ACTL?.toString(),
                  label: x?.EOM_TDC_ACTL?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));

            setOrdTDCList(varData);
            // setOrderTDC(selectedRMData.EOM_TDC_ACTL);

            var varDownTDCData: Array<SelectType> = [];
            res?.data?.downgradeTDCList?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varDownTDCData?.push({
                  value: x?.ESP_TDC_DOWNGRADE?.toString(),
                  label: x?.ESP_TDC_DOWNGRADE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setDownTDCList(varDownTDCData);
            setOrderTDC(selectedRMData.EOM_TDC_ACTL);

            var varDivTDCData: Array<SelectType> = [];
            res?.data?.diversionTDCList?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varDivTDCData?.push({
                  value: x?.DIV_TDC?.toString(),
                  label: x?.DIV_TDC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            // console.log("**", varDivTDCData);
            setDivTDCList(varDivTDCData);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleOrderSearch = () => {
    //setOrderData([])
    if (!orderTDC) {
      alertify.error("TDC is mandatory");
      return;
    }
    // if (orderTDC.length !== 4) {
    //   alertify.error("TDC length should be 4");
    //   return;
    // }
    getOrderData();
  };

  const getOrderData = () => {
    setLoading(true);
    let dataArr: any = [];
    dataArr = table1?.getRows();
    // let planPath = dataArr[0]?._row?.data.txtSchPlannedPath;
    GetAuthorization().then((token: TokenType) => {
      SPS0005GetOrderDataApi(token, {
        orderId: order_Id,
        orderItem: orderItem,
        orderTDC: orderTDC,
        orderType: orderType,
        orderThick: orderThick.toString(),
        orderWidth: orderWidth.toString(),
        plant: selectedCode,
        planPath: selPlanPath,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length === 0) {
              alertify.error("No data exists for given input");
              return;
            }
            if (res?.data?.length > 0) {
              setOrderTableData(res.data);
            } else {
              alertify.error("No Order Data exists for given input");
              setOrderTableData(res.data);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const addEmptyRows = () => {
    var array: any = [...scheduleDetailsData];
    if (array.length === 0) {
      alertify.error("No data exists to duplicate");
      return;
    }
    let lastIndex: number = array.length - 1;
    if (array?.length > 0) {
      array.push({
        id: scheduleDetailsData.length + 1,
        ddlSchStCD: "A01",
        ddlSchProcLn: selectedProcess,
        txtSubProcLine: array[lastIndex].txtSubProcLine,
        txtSchBatch: array[lastIndex].txtSchBatch,
        txtNetWt: array[lastIndex].txtNetWt,
        ddlProcRt: array[lastIndex].ddlProcRt,
        // txtSchPlannedPath: array[lastIndex].txtSchPlannedPath,
        txtSchPlannedPath: "",
        txtSchOrd: "",
        txtSchItem: "",
        txtSchScoOrd: array[lastIndex].txtSchScoOrd,
        txtSchScoItem: array[lastIndex].txtSchScoItem,
        txtSchProdCd: array[lastIndex].txtSchProdCd,
        txtSchQltycd: "",
        txtSchIdia: "",
        txtSchMinwt: "",
        txtSchMaxwt: "",
        txtSchThick: array[lastIndex].txtSchThick,
        txtSchWidth: 1,
        //txtSchWidth: lastIndex,
        txtSchLength: array[lastIndex].txtSchLength,
        ddlSchOfcut: "N",
        txtSchTdc: array[lastIndex].txtSchTdc,
        //txtSchPlantwt: 1,
        txtSchPlantwt: selectedRMData.EOM_MS_PIECE_ACTL,
        txtSchPktwt: array[lastIndex].txtSchPktwt,
        txtSchNoslt: 1,
        txtSchNoPcs: array[lastIndex].txtSchNoPcs,
        txtSchNoStk: array[lastIndex].txtSchNoStk,
        txtSchNoPkt: array[lastIndex].txtSchNoPkt,
        // txtSchAimWt: (1 / array[lastIndex].txtCoilWidth).toFixed(3),
        txtSchAimWt: array[lastIndex].txtSchAimWt,
        txtSchPkgTyp: array[lastIndex].txtSchPkgTyp,
        txtOiling: array[lastIndex].txtOiling,
        txtPacking: array[lastIndex].txtPacking,
        txtSchPkgDesc: array[lastIndex].txtSchPkgDesc,
        txtSchRwrkInd: array[lastIndex].txtSchRwrkInd,
        txtSchNoPart: array[lastIndex].txtSchNoPart,
        txtSchPlanRsn: array[lastIndex].txtSchPlanRsn,
        txtSchPlanRsnCode: array[lastIndex].txtSchPlanRsnCode,
        txtSchPlanRsnDesc: array[lastIndex].txtSchPlanRsnDesc,
        txtSchRemark: array[lastIndex].txtSchRemark,
        txtOrdMinWidth: array[lastIndex].txtOrdMinWidth,
        txtOrdMaxWidth: array[lastIndex].txtOrdMaxWidth,
        txtplanGrade: array[lastIndex].txtplanGrade,
        txtCoilWidth: array[lastIndex].txtCoilWidth,
        delete: "",
      });
      setScheduleDetailsData(array);
    }
  };

  const fetchData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!selectedProcess) {
      alertify.error("Please Select the Process Line");
      return;
    }
    if (!selectedSchd) {
      alertify.error("Please select schedule!");
      return;
    }
    if (selectedSchd === "WIP" && !selectedStatus) {
      alertify.error("Please select Status");
      return;
    }

    setScheduleDetailsData([]);
    setIsComputed(false);
    setIsConfirmed(false);
    setLoading(true);
    setShowSaveMsgSuccess(false);
    setShowSaveMsgError(false);
    setSaveMsg("");

    GetAuthorization().then((token: TokenType) => {
      SPS0005SchedulingApi(token, {
        type: "materialData",
        Plant: selectedCode,
        Process: selectedProcess,
        BatchId: selectedCoil,
        Status: selectedStatus,
        Tdc: tdc,
        ThickFR: thickness,
        ThickTo: thicknessTo,
        WidthFr: width,
        WidthTo: widthTo,
        ProdCd: prodCd,
        FromDt: DateFormat(inputObj.key1.value),
        ToDt: DateFormat(inputObj.key2.value),
        Idia: Idia,
        Schd: selectedSchd,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              setTableData(res.data);
            } else {
              alertify.error("No Data Found!");
              setTableData([]);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // function PaperComponent(props: PaperProps) {
  //   return (
  //     <Draggable
  //       handle="#draggable-dialog-title"
  //       cancel={'[class*="MuiDialogContent-root"]'}
  //     >
  //       <Paper {...props} />
  //     </Draggable>
  //   );
  // }

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setTableData([]);
    setScheduleDetailsData([]);
    setSelectedCoil("");
    setStatusData([]);
    setThickness("");
    setThicknessTo("");
    setWidth("");
    setWidthTo("");
    setTdc("");
    setScheId("");
    setProdCd("");
    setIdia("");
    setInputObj(varInput);
    setContrYield("");
    setActlYield("");
    setSelectedSchd(schdOp[0].value);
  };

  // const getDiversionTdc = () => {
  //   setLoading(true);
  //   let gridData = table?.getSelectedRows();
  //   console.log(gridData);
  //   GetAuthorization().then((token: TokenType) => {
  //     SPS0005DiversionRes(token, {
  //       coilId: gridData[0]?._row?.data?.EOM_ID_BATCH,
  //       qltyCd: gridData[0]?._row?.data?.EOM_CD_QLTY_ACTL,
  //       tdc: gridData[0]?._row?.data?.EOM_TDC_ACTL,
  //     })
  //       .catch((e) => {
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something Wents wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };

  // This function is used to make Order TDC and thickness in order dialog as readonly
  // For wip schd, line E & K
  const disableOrdTdcThick = () => {
    return (
      selectedSchd === "WIP" &&
      (selectedProcess === "E" || selectedProcess === "K")
    );
  };

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }
  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Dialog
              style={{
                paddingLeft: "160px",
                paddingRight: "160px",
                paddingTop: "100px",
              }}
              open={isPopUp.popUp}
              maxWidth="small"
              //fullWidth={true}
              //PaperComponent={PaperComponent}
              onClose={() => {
                setIsPopUp({ popUp: false, data: "" });
              }}
            >
              <DialogTitle
                style={{ cursor: "move", padding: "6px" }}
                id="draggable-dialog-title"
              >
                Order Data
                <IconButton
                  style={{ position: "absolute", top: "0", right: "0" }}
                  onClick={() => {
                    setIsPopUp({ popUp: false, data: "" });
                  }}
                >
                  <CloseIcon />
                </IconButton>
              </DialogTitle>
              <DialogContent
                sx={{
                  marginTop: "-10px",
                  // backgroundColor: "#f0f0f0",
                }}
              >
                <Grid
                  item
                  xs={12}
                  container
                  spacing={1}
                  sx={{
                    p: 2,
                    backgroundColor: csTheme?.palette.background.paper,
                    borderRadius: 5,
                    gap: 2,
                  }}
                >
                  <Grid item xs={2}>
                    <Input
                      label="Order Id"
                      value={order_Id}
                      // onChange={(e: any) => {
                      //   setOrder_Id(e);
                      // }}
                      onChange={handleChangeOrderId}
                    />
                  </Grid>
                  <Grid item xs={1}>
                    <Input
                      label="Item No"
                      value={orderItem}
                      // onChange={(e: any) => {
                      //   setOrderItem(e);
                      // }}
                      onChange={handleChangeOrderItem}
                    />
                  </Grid>

                  {/* ---- Date - 19.02.2026, Making TDC & Thick in order data dialog box as editable for WIP as well 
  So, that coil can be scheduled with downgraded or diverted tdc as well.  ---- */}

                  <Grid item xs={2}>
                    <FormControl sx={{ width: "100%" }}>
                      <InputLabel
                        size="small"
                        style={{
                          width: "100%",
                        }}
                      >
                        TDC
                      </InputLabel>
                      <Select
                        // defaultValue=""
                        defaultValue={selectedRMData.EOM_TDC_ACTL}
                        id="grouped-select"
                        label="Grouping"
                        readOnly={disableOrdTdcThick()}
                        // selectedSchd
                        //   ? selectedSchd === "WIP" &&
                        //     (selectedProcess === "E" ||
                        //       selectedProcess === "K")
                        //   : false
                        // }
                        // onChange={handleChangeOrderTdc}
                        style={{
                          backgroundColor: disableOrdTdcThick()
                            ? "#F4E9E9"
                            : "",
                          // backgroundColor:
                          //   selectedSchd && selectedSchd === "WIP"
                          //     ? "#F4E9E9"
                          //     : "",
                          width: "100%",
                          height: "34px",
                          fontSize: "8px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                        // onChange={(e: any) => {
                        //   setOrderTDC(e);
                        //   setOrderTableData([]);
                        // }}
                        onChange={(e: any) => {
                          setOrderTDC(e.target.value);
                          setOrderTableData([]);
                        }}
                        // onChange={handleChangeOrderTdc}
                      >
                        <MenuItem value="">
                          <em> ------</em>
                        </MenuItem>
                        <ListSubheader>Order TDC</ListSubheader>
                        {ordTDCList.map((option) => (
                          <MenuItem key={option.id} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                        <ListSubheader>Downgrade TDC</ListSubheader>
                        {downTDCList.map((option) => (
                          <MenuItem key={option.id} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                        <ListSubheader>Diversion TDC</ListSubheader>
                        {divTDCList.map((option) => (
                          <MenuItem key={option.id} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>

                  {/* <Grid item xs={2}>
                    <SelectInput
                      label="TDC"
                      data={ordTDCList}
                      value={orderTDC}
                      readOnly={selectedSchd ? selectedSchd === "WIP" : false}
                      style={{
                        backgroundColor:
                          selectedSchd && selectedSchd === "WIP"
                            ? "#F4E9E9"
                            : "",
                      }}
                      // onChange={(e: any) => {
                      //   setOrderTDC(e);
                      // }}
                      onChange={handleChangeOrderTdc}
                    />
                  </Grid> */}

                  <Grid item xs={1.8}>
                    <SelectInput
                      label="Order Type"
                      data={orderTypeData}
                      value={orderType}
                      // onChange={(e: any) => {
                      //   setOrderType(e);
                      // }}
                      onChange={handleChangeOrderType}
                    />
                  </Grid>

                  <Grid item xs={1.2}>
                    <Input
                      label="Thick"
                      //readOnly={true}
                      // style={{ backgroundColor: "#F4E9E9" }}
                      style={{
                        backgroundColor: disableOrdTdcThick() ? "#F4E9E9" : "",
                      }}
                      value={orderThick}
                      readOnly={disableOrdTdcThick()}
                      // readOnly={selectedSchd ? selectedSchd === "WIP" : false}
                      // onChange={(e: any) => {
                      //   setOrderThick(e);
                      // }}
                      onChange={handleChangeOrderThick}
                    />
                  </Grid>

                  <Grid item xs={1.2}>
                    <Input
                      label="Width"
                      value={orderWidth}
                      // readOnly={selectedSchd ? selectedSchd === "WIP" : false}
                      readOnly={
                        selectedProcess ? selectedProcess !== "S" : false
                      }
                      // style={{
                      //   backgroundColor:
                      //     selectedSchd && selectedSchd === "WIP"
                      //       ? "#F4E9E9"
                      //       : "",
                      // }}
                      style={{
                        backgroundColor:
                          selectedProcess && selectedProcess !== "S"
                            ? "#F4E9E9"
                            : "",
                      }}
                      // onChange={(e: any) => {
                      //   setOrderWidth(e);
                      // }}
                      onChange={handleChangeOrderWidth}
                    />
                  </Grid>

                  <Grid item xs={1.25}>
                    <ButtonElement
                      children="Search"
                      onClick={() => {
                        handleOrderSearch();
                      }}
                    />
                  </Grid>
                </Grid>
                {loading ? <Loader /> : null}
                {orderTableData?.length > 0 && <div id="table3"></div>}
              </DialogContent>
              <DialogActions></DialogActions>
            </Dialog>

            {/* <ReactModal 
                  initWidth={900} 
                  initHeight={300}  
                    className={"flexible-modal"}
                    //onRequestClose={setIsPopUp({ popUp: false, data: "" })} 
                    onClose={() => {
                      setIsPopUp({ popUp: false, data: "" });
                    }}
                    isOpen={isPopUp.popUp}>          
          <div className="body">
          <h4 > Order Details </h4>
          <Grid
                item
                xs={12}
                container
                //spacing={0}
                sx={{
                  p: 2,
                  backgroundColor: csTheme?.palette.background.paper,
                  //borderRadius: 5,
                  gap: 2,
                }}
              >
                <Grid item xs={2}>
                  <Input
                    label="Order Id"
                    value={order_Id}
                    onChange = {handleChangeOrderId}
                  />
                </Grid>
                <Grid item xs={1}>
                  <Input
                    label="Item No"
                    value={orderItem}
                    onChange = {handleChangeOrderItem}
                  />
                </Grid>
                <Grid item xs={1.5}>
                  <SelectInput
                    label="TDC"
                    data={ordTDCList}
                    value={orderTDC}
                    onChange = {handleChangeOrderTdc}
                  />
                </Grid>

                <Grid item xs={1.5}>
                  <SelectInput
                    label="Order Type"
                    data={orderTypeData}
                    value={orderType}
                    onChange = {handleChangeOrderType}
                  />
                </Grid>

                <Grid item xs={1}>
                  <Input
                    label="Thick"
                    //readOnly={true}
                    style={{ backgroundColor: "#F4E9E9" }}
                    value={orderThick}
                    onChange = {handleChangeOrderThick}
                  />
                </Grid>

                <Grid item xs={1}>
                  <Input
                    label="Width"
                    value={orderWidth}
                    onChange = {handleChangeOrderWidth}
                  />
                </Grid>

                <Grid item xs={1.25}>
                  <ButtonElement
                    children="Search"
                    onClick={() => {
                      handleOrderSearch();
                    }}
                  />                  
                </Grid>
                <Grid item xs={1}>
                 <Button
                    children="Close"
                    onClick={() => {
                      setIsPopUp({ popUp: false, data: "" });
                    }}
                  />
                  </Grid>
              </Grid>
              {loading ? <Loader /> : null}
              {orderTableData?.length > 0 && <div id="table3"></div>}
            
                    </div>
                </ReactModal>
        
      */}

            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={1.5}>
                      <Grid item xs={2.5}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            fetchEpaData(e);
                            setScheduleDetailsData([]);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2.5}>
                        <SelectInput
                          label="Process*"
                          data={processData}
                          value={selectedProcess}
                          size={"small"}
                          //onChange={(e: string) => setSelectedProcess(e)}
                          onChange={handleChangeSubProc}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Coil Id"
                          data={coilData}
                          id={"id"}
                          value={selectedCoil}
                          size={"small"}
                          // onChange={(e: string) => {
                          //   setSelectedCoil(e);
                          // }}
                          onChange={handleChangeCoilId}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Status"
                          data={statusData}
                          value={selectedStatus}
                          size={"small"}
                          //onChange={(e: string) => setSelectedStatus(e)}
                          onChange={handleChangeStatus}
                        />
                      </Grid>
                      <Grid item xs={1.2}>
                        <Input
                          label="Thick From"
                          value={thickness}
                          size={"small"}
                          type={"number"}
                          //onChange={(e: string) => setThickness(e)}
                          onChange={handleChangeThickFrom}
                        />
                      </Grid>
                      <Grid item xs={1.2}>
                        <Input
                          label="Thick To"
                          value={thicknessTo}
                          size={"small"}
                          type={"number"}
                          //onChange={(e: string) => setThicknessTo(e)}
                          onChange={handleChangeThickTo}
                        />
                      </Grid>
                      <Grid item xs={1.2}>
                        <Input
                          label="Width From"
                          value={width}
                          size={"small"}
                          type={"number"}
                          //onChange={(e: string) => setWidth(e)}
                          onChange={handleChangeWidthFrom}
                        />
                      </Grid>
                      <Grid item xs={1.2}>
                        <Input
                          label="Width To"
                          value={widthTo}
                          size={"small"}
                          type={"number"}
                          onChange={handleChangeWidthTo}
                        />
                      </Grid>
                      <Grid item xs={1}>
                        <Input
                          label="Tdc"
                          value={tdc}
                          size={"small"}
                          onChange={handleChangeTdc}
                        />
                      </Grid>
                      {/* <Grid item xs={1.5}>
                      <Input
                        label="Prod Cd"
                        id={"prodCd"}
                        value={prodCd}
                        onChange={handleChangeProdCd}
                      />
                    </Grid> */}
                      <Grid item xs={4}>
                        {/* From Date */}
                        <Box component="span">
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i < 2 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>
                      <Grid item xs={1.5}>
                        <Input
                          label="Idia"
                          id={"Idia"}
                          value={Idia}
                          // onChange={(e: string) => {
                          //   setIdia(e);
                          // }}
                          onChange={handleChangeIdia}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <SelectInput
                          label="Schedule"
                          // id={"schd"}
                          data={schdOp}
                          value={selectedSchd}
                          onChange={handleSchdOpChange}
                        />
                      </Grid>

                      <Grid item xs={1}>
                        <ButtonElement onClick={() => fetchData()}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="RM Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel("RM Details", tableData, table)
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            marginTop: "-0.5rem",
                          }}
                          align="right"
                        >
                          {" "}
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                        <p
                          align="left"
                          style={{
                            background: "green",
                            width: "10px",
                            height: "10px",
                          }}
                        >
                          {" "}
                          <div
                            style={{
                              whiteSpace: "nowrap",
                              marginTop: "-1.5rem",
                              paddingLeft: "1rem",
                            }}
                          >
                            SLP Remarks
                          </div>
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title={"Schedule Details"}
                headerContainer={
                  <Grid container>
                    <Grid item>
                      {/* {isComputed && !isConfirmed ? ( */}
                      {contrYield ? (
                        <p style={{ marginRight: "10px" }}>
                          <a style={{ marginRight: "50px", fontSize: "12px" }}>
                            Coil ID : {selectedRMData.EOM_ID_BATCH}{" "}
                          </a>
                          <a style={{ marginRight: "20px", fontSize: "12px" }}>
                            Sched ID : {scheId}{" "}
                          </a>
                          <a style={{ marginRight: "10px", fontSize: "12px" }}>
                            Contr Yld : {contrYield}{" "}
                          </a>
                          <a style={{ marginRight: "5px", fontSize: "12px" }}>
                            Accp yld : {actlYield}{" "}
                          </a>
                        </p>
                      ) : null}
                      {isComputed && !isConfirmed && !contrYield ? (
                        <p style={{ marginRight: "180px" }}>
                          <a> Sched ID : {scheId} </a>
                        </p>
                      ) : null}
                    </Grid>
                    <Grid item>
                      {!isComputed ? (
                        <Tooltip title="Add">
                          <IconButton
                            onClick={addEmptyRows}
                            disabled={restricted !== "RL_RW"}
                          >
                            <LibraryAddIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      ) : null}
                    </Grid>
                    <Grid item>
                      <Tooltip title={isComputed ? "Confirm" : "Compute"}>
                        <IconButton
                          onClick={confirmData}
                          disabled={restricted !== "RL_RW"}
                        >
                          {!isComputed ? (
                            <ArchitectureIcon sx={{ color: "#ffffff" }} />
                          ) : (
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          )}
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel(
                              "Schedule Details",
                              scheduleDetailsData,
                              table1
                            )
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {scheduleDetailsData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {scheduleDetailsData?.length} of{" "}
                          {scheduleDetailsData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
                {showSaveMsgError && (
                  <Grid item xs={12}>
                    <Alert variant="filled" severity="error">
                      {saveMsg}
                    </Alert>
                  </Grid>
                )}
                {showSaveMsgSuccess && (
                  <Grid item xs={12}>
                    <Alert variant="filled" severity="success">
                      {saveMsg}
                    </Alert>
                  </Grid>
                )}
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0005;
