# CodeGenie -> OpenAI-compatible local bridge (Roo/Continue/Cline)
# No credentials are stored in this source file.

import json
import os
import time
import unicodedata
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List

# Use the Windows/system trust store when available. This is useful behind
# corporate TLS inspection proxies such as Zscaler.
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI(title="CodeGenie OpenAI-Compatible Bridge v2")

BASE_DIR = Path(__file__).resolve().parent
CODEGENIE_URL = os.getenv(
    "CODEGENIE_URL",
    "https://asia-south1-tsl-generative-ai.cloudfunctions.net/code_genie_api_calls",
).strip()
CODEGENIE_PROXY = os.getenv("CODEGENIE_PROXY", "http://127.0.0.1:13124").strip()
APPLICATION_NAME = os.getenv("CODEGENIE_APPLICATION_NAME", "Code Genie").strip()
REQUEST_TIMEOUT = float(os.getenv("CODEGENIE_TIMEOUT", "300"))
MODEL_FILE = Path(os.getenv("CODEGENIE_MODELS_FILE", str(BASE_DIR / "models.json")))
ALLOW_RAW_MODEL_IDS = os.getenv("CODEGENIE_ALLOW_RAW_MODEL_IDS", "1").strip() not in {"0", "false", "False"}
DEFAULT_MODEL = os.getenv("CODEGENIE_MODEL", "claude-4.5-sonnet").strip()

# Optional launcher overrides. When enabled, these take precedence over
# whatever Roo/Continue/Cline sends in the request.
FORCE_MODEL = os.getenv("CODEGENIE_FORCE_MODEL", "0").strip().lower() in {"1", "true", "yes", "on"}
FORCE_TEMPERATURE = os.getenv("CODEGENIE_FORCE_TEMPERATURE", "0").strip().lower() in {"1", "true", "yes", "on"}
FORCE_MAX_TOKENS = os.getenv("CODEGENIE_FORCE_MAX_TOKENS", "0").strip().lower() in {"1", "true", "yes", "on"}

LAUNCH_TEMPERATURE = os.getenv("CODEGENIE_TEMPERATURE", "1.0").strip()
LAUNCH_MAX_TOKENS = os.getenv("CODEGENIE_MAX_TOKENS", "MAX").strip()


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _json_text(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def _canonical_model_key(value: str) -> str:
    """Normalize UI/model names without changing the final deployment string."""
    s = unicodedata.normalize("NFKC", str(value or "")).strip()
    # Normalize common unicode dash characters that sometimes get pasted into UI fields.
    for ch in ("‐", "‑", "‒", "–", "—", "﹘", "﹣", "－"):
        s = s.replace(ch, "-")
    s = " ".join(s.split())
    return s.lower()


def load_model_catalog() -> List[Dict[str, Any]]:
    try:
        raw = json.loads(MODEL_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except Exception as exc:
        raise RuntimeError(f"Could not read model catalog {MODEL_FILE}: {exc}")

    if isinstance(raw, dict):
        raw = raw.get("models", [])
    if not isinstance(raw, list):
        raise RuntimeError("models.json must contain a list or {'models': [...]} object")
    return [x for x in raw if isinstance(x, dict)]


def resolve_model(requested: str) -> str:
    requested = str(requested or "").strip() or DEFAULT_MODEL
    key = _canonical_model_key(requested)

    # Exact aliases from models.json win. This prevents invisible-character / display-name
    # problems and lets the user map friendly names to CodeGenie's exact deployment_name.
    for item in load_model_catalog():
        deployment = str(item.get("deployment_name") or "").strip()
        aliases = [item.get("id"), item.get("name"), *(item.get("aliases") or [])]
        for alias in aliases:
            if alias and _canonical_model_key(str(alias)) == key:
                if not deployment:
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            f"Model '{requested}' is listed but its CodeGenie deployment_name "
                            "has not been captured yet. Fill it in models.json from the working "
                            "CodeGenie Network payload."
                        ),
                    )
                return deployment

    if ALLOW_RAW_MODEL_IDS:
        # Raw deployment IDs are allowed for easy testing. Normalize only unicode dash characters
        # and surrounding whitespace; do not invent or rewrite provider-specific names.
        normalized = unicodedata.normalize("NFKC", requested).strip()
        for ch in ("‐", "‑", "‒", "–", "—", "﹘", "﹣", "－"):
            normalized = normalized.replace(ch, "-")
        return normalized

    raise HTTPException(status_code=400, detail=f"Unknown model '{requested}'")


def available_models() -> List[Dict[str, Any]]:
    out = []
    for item in load_model_catalog():
        deployment = str(item.get("deployment_name") or "").strip()
        if not deployment:
            continue
        model_id = str(item.get("id") or deployment).strip()
        out.append(
            {
                "id": model_id,
                "object": "model",
                "owned_by": "codegenie",
                "display_name": str(item.get("name") or model_id),
                "deployment_name": deployment,
                "tool_use": item.get("tool_use"),
            }
        )
    # Always expose the known working default even if models.json is missing/broken.
    if not any(m["id"] == DEFAULT_MODEL for m in out):
        out.append({"id": DEFAULT_MODEL, "object": "model", "owned_by": "codegenie"})
    return out


def build_form(body: Dict[str, Any]) -> Dict[str, str]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        raise HTTPException(status_code=400, detail="messages must be a non-empty array")

    client_model = str(body.get("model") or DEFAULT_MODEL).strip()
    requested_model = DEFAULT_MODEL if FORCE_MODEL else client_model
    deployment_name = resolve_model(requested_model)

    # Temperature:
    # - Launcher mode can force the selected value.
    # - Otherwise preserve the client's value.
    if FORCE_TEMPERATURE:
        try:
            temperature = float(LAUNCH_TEMPERATURE)
        except (TypeError, ValueError):
            temperature = 1.0
    else:
        temperature = body.get("temperature")
        if not isinstance(temperature, (int, float)):
            temperature = 1.0

    # Keep the supported CodeGenie range.
    temperature = max(0.0, min(1.0, float(temperature)))

    form: Dict[str, str] = {
        "adid": required_env("CODEGENIE_ADID"),
        "messages": _json_text(messages),
        "deployment_name": deployment_name,
        "temperature": str(temperature),
        "apikey": required_env("CODEGENIE_APIKEY"),
        "application_name": APPLICATION_NAME,
    }

    # Output tokens:
    # MAX means "no bridge-side limiter": max_tokens is omitted entirely.
    # If the launcher forces a numeric value, that value is used regardless
    # of what the client sends.
    # Without launcher forcing, a positive client max_tokens is forwarded.
    mt = None

    if FORCE_MAX_TOKENS:
        launch_value = str(LAUNCH_MAX_TOKENS or "MAX").strip().upper()
        if launch_value not in {"MAX", "NONE", "DEFAULT", "UNLIMITED", "-1", "0", ""}:
            try:
                parsed = int(launch_value)
                if parsed > 0:
                    mt = parsed
            except (TypeError, ValueError):
                mt = None
    else:
        raw_mt = body.get("max_tokens")
        if raw_mt is None:
            raw_mt = body.get("max_completion_tokens")
        try:
            parsed = int(raw_mt) if raw_mt is not None else None
            if parsed is not None and parsed > 0:
                mt = parsed
        except (TypeError, ValueError):
            mt = None

    if mt is not None:
        form["max_tokens"] = str(mt)

    # Native OpenAI-style tools. This is required for Roo agent mode.
    tools = body.get("tools")
    if isinstance(tools, list) and tools:
        form["tools"] = _json_text(tools)

    # Keep the upstream request minimal for broad model compatibility.
    # tool_choice / parallel_tool_calls / penalties are intentionally not
    # forwarded unless CodeGenie's contract is later confirmed for them.

    print(
        "[ROO REQUEST]",
        f"client_model={client_model!r}",
        f"selected_model={requested_model!r}",
        f"deployment={deployment_name!r}",
        f"temperature={temperature}",
        f"max_tokens={form.get('max_tokens', 'MAX/provider-controlled')}",
        f"messages={len(messages)}",
        f"message_json_chars={len(form['messages'])}",
        f"tools={len(tools) if isinstance(tools, list) else 0}",
        f"stream={bool(body.get('stream'))}",
    )
    return form

def call_codegenie(form: Dict[str, str]) -> Dict[str, Any]:
    session = requests.Session()
    if CODEGENIE_PROXY:
        session.proxies.update({"http": CODEGENIE_PROXY, "https": CODEGENIE_PROXY})

    multipart = [(key, (None, value)) for key, value in form.items()]
    try:
        response = session.post(CODEGENIE_URL, files=multipart, timeout=REQUEST_TIMEOUT)
    except Exception as exc:
        print("[CODEGENIE CONNECTION ERROR]", type(exc).__name__, str(exc))
        raise HTTPException(status_code=502, detail=f"CodeGenie connection failed: {exc}")

    print("[CODEGENIE] Upstream HTTP status:", response.status_code)
    if not response.ok:
        detail = response.text[:3000]
        print("========== CODEGENIE UPSTREAM ERROR ==========")
        print(f"HTTP STATUS: {response.status_code}")
        print(detail)
        print("==============================================")
        raise HTTPException(status_code=502, detail=f"CodeGenie HTTP {response.status_code}: {detail}")

    try:
        data = response.json()
    except Exception:
        print("[CODEGENIE NON-JSON]", response.text[:3000])
        raise HTTPException(status_code=502, detail="CodeGenie returned non-JSON data")

    if not isinstance(data, dict) or "choices" not in data:
        print("[CODEGENIE UNEXPECTED RESPONSE]", str(data)[:3000])
        raise HTTPException(status_code=502, detail="CodeGenie returned an unexpected response shape")
    return data


def _normalize_tool_calls(tool_calls: Any) -> Any:
    if not isinstance(tool_calls, list):
        return tool_calls
    normalized = []
    for i, tc in enumerate(tool_calls):
        if not isinstance(tc, dict):
            continue
        item = dict(tc)
        item.setdefault("index", i)
        normalized.append(item)
    return normalized


def as_sse(data: Dict[str, Any]) -> StreamingResponse:
    """Convert CodeGenie's complete response into OpenAI-compatible SSE chunks."""
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    model = data.get("model") or DEFAULT_MODEL
    response_id = data.get("id") or f"chatcmpl-{uuid.uuid4().hex}"
    created = data.get("created") or int(time.time())
    finish_reason = choice.get("finish_reason")

    def chunks() -> Iterable[str]:
        first = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
        }
        yield "data: " + json.dumps(first, separators=(",", ":")) + "\n\n"

        content = message.get("content")
        if content not in (None, ""):
            chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"content": content}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(chunk, separators=(",", ":")) + "\n\n"

        tool_calls = _normalize_tool_calls(message.get("tool_calls"))
        if tool_calls:
            chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"tool_calls": tool_calls}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(chunk, separators=(",", ":")) + "\n\n"

        final_chunk = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
        }
        yield "data: " + json.dumps(final_chunk, separators=(",", ":")) + "\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(chunks(), media_type="text/event-stream")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "gateway": CODEGENIE_URL,
        "proxy": CODEGENIE_PROXY or "DIRECT",
        "default_model": DEFAULT_MODEL,
        "forced_model": FORCE_MODEL,
        "temperature": LAUNCH_TEMPERATURE if FORCE_TEMPERATURE else "client-controlled",
        "max_output_tokens": (
            "MAX/provider-controlled"
            if FORCE_MAX_TOKENS and str(LAUNCH_MAX_TOKENS).strip().upper() in {"MAX", "NONE", "DEFAULT", "UNLIMITED", "-1", "0", ""}
            else (LAUNCH_MAX_TOKENS if FORCE_MAX_TOKENS else "client-controlled")
        ),
        "models_file": str(MODEL_FILE),
        "credentials_configured": bool(os.getenv("CODEGENIE_ADID") and os.getenv("CODEGENIE_APIKEY")),
        "bridge_token_limit": "none",
    }


@app.get("/models")
@app.get("/v1/models")
def models():
    return {"object": "list", "data": available_models()}


@app.post("/chat/completions")
@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Request body must be JSON")

    form = build_form(body)
    data = call_codegenie(form)
    if body.get("stream"):
        return as_sse(data)
    return JSONResponse(content=data)
