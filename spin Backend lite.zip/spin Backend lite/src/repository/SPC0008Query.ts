import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData08 = async (data: any) => {
  try {
    let binds: any = {};

    let sql: any = `SELECT
      SOI_ID_ORDER ORDER_ID,
      SOI_NO_ITEM ITEM_NO,
      SOI_NO_END_MATNR END_MATNR_NO,
      SOI_END_PROD_DESC END_PROD_DESC,
      SOI_CD_PROD CD_PROD,
      SOI_CD_QLTY CD_QLTY,
      SOI_SEC1_MIN THICKNESS_MIN,
      SOI_SEC1_MAX THICKNESS_MAX,
      SOI_SEC2_MIN WIDTH_MIN,
      SOI_SEC2_MAX WIDTH_MAX,
      SOI_LENGTH_MIN LENGTH_MIN,
      SOI_LENGTH_MAX LENGTH_MAX,
      SOI_QUANTITY QUANTITY,
      SOI_PRICE PRICE,
      SOI_CD_BASE_QLTY CD_BASE_QLTY,
      SOI_CD_EPA CD_EPA,
      SOI_NO_TRACKING TRACKING_NO,
      SOI_DT_DELIVERY DELIVERY_DT,
      SOI_CD_STATUS CD_STATUS,
      SOI_ID_USER ID_USER,
      SOI_DT_ORDER ORDER_DT,
      SOI_CD_PUR_GRP CD_PUR_GRP,
      SOI_CD_TYPE_ORDER CD_TYPE_ORDER,
      SOI_NO_INP_MATNR NO_INP_MATNR,
      SOI_NO_TDC TDC_NO,
      SOI_VAL_START_DT VAL_START_DT,
      SOI_VAL_END_DT VAL_END_DT,
      SOI_UOM UOM,
      SOI_CD_COMP CD_COMP,
      SOI_CD_PROCESS CD_PROCESS,
      SOI_IDIA IDIA,
      SOI_ODIA ODIA,
      SOI_MAT_CHAR MAT_CHAR,
      SOI_INP_MATNR1
      FROM
      V_SCO_ORDER_ITEM`;

    if (data.epa && data.epa?.length > 0) {
      sql += ` Where SOI_CD_EPA = '${data?.epa}'`;
      binds["epa"] = data?.epa;
    }
    if (data.order && data.order?.length > 0) {
      sql += ` AND SOI_ID_ORDER = '${data?.order}'`;
      binds["order"] = data?.order;
    }
    if (data.endmaterialNo && data.endmaterialNo?.length > 0) {
      sql += ` AND SOI_NO_END_MATNR = '${data?.endmaterialNo}'`;
      binds["endmaterialNo"] = data?.endmaterialNo;
    }
    if (data.inpmaterialNo && data.inpmaterialNo?.length > 0) {
      sql += ` AND SOI_NO_INP_MATNR = '${data?.inpmaterialNo}'`;
      binds["inpmaterialNo"] = data?.inpmaterialNo;
    }
    return await query(sql);
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getEpa08 = async () => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getOrderData08 = async () => {
  try {
    const sql = `SELECT
      DISTINCT SOI_ID_ORDER
    FROM
      V_SCO_ORDER_ITEM`;
    return await query(sql);
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getNoEnd08 = async () => {
  try {
    const sql: any = `SELECT DISTINCT SOI_NO_END_MATNR FROM V_SCO_ORDER_ITEM`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getNoInp08 = async () => {
  try {
    const sql: any = `SELECT DISTINCT SOI_NO_INP_MATNR FROM V_SCO_ORDER_ITEM`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
