import { Router } from "express";
import {
  getMBatchList,
  getMotherTableData,
  getTableData,
  saveDataTemp,
} from "../controllers/SPO0004Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPO0004Route = Router();

SPO0004Route.route("/SPO0004/getTableData").post(
  authenticationMiddleware.bearer,
  getTableData
);

SPO0004Route.route("/SPO0004/getMBatchList").post(
  authenticationMiddleware.bearer,
  getMBatchList
);

SPO0004Route.route("/SPO0004/saveDataTemp").post(
  authenticationMiddleware.bearer,
  saveDataTemp
);

SPO0004Route.route("/SPO0004/getMotherTableData").post(
  authenticationMiddleware.bearer,
  getMotherTableData
);

export default SPO0004Route;
