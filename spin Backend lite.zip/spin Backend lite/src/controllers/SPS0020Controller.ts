import { Request, Response } from "express";
import SPS0020Model from "../models/SPS0020Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const SPS0020Controller = async (req: Request, res: Response) => {
  try {
    if (req.body.type === "pageData") {
      const results1 = await ResponceData(
        await SPS0020Model.prototype.getPlantCode(req.body)
      );
      const results2 = await ResponceData(
        await SPS0020Model.prototype.getReportType(req.body)
      );
      console.log("results1: ", results1);
      let plantData = results1[0]?.EPL_CD_EPA;
      const results3 = await ResponceData(
        await SPS0020Model.prototype.getSourcePlant({ plant: plantData })
      );
      return res
        .status(200)
        .json({ plant: results1, report: results2, sourcePlant: results3 });
    } else if (req.body.type === "getTableData") {
      //api
      const result4 = await ResponceData(
        await SPS0020Model.prototype.getTableData(req.body)
      );
      //console.log('cont', result4)
      return res.status(200).json(result4);
    } else if (req.body.type === "sourcePlant") {
      const results = await ResponceData(
        await SPS0020Model.prototype.getSourcePlant(req.body)
      );
      return res.status(200).json(results);
    } else if (req.body.type === "yieldWiseData") {
      const results5 = await ResponceData(
        await SPS0020Model.prototype.getyieldwisedata(req.body)
      );
      return res.status(200).json(results5);
    } else if (req.body.type === "secondsData") {
      const results6 = await ResponceData(
        await SPS0020Model.prototype.getSecondsData(req.body)
      );
      return res.status(200).json(results6);
    } else if (req.body.type === "scrapData") {
      const results7 = await ResponceData(
        await SPS0020Model.prototype.getScrapData(req.body)
      );
      return res.status(200).json(results7);
    }
    return res.status(200).json();
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
