import { Request, Response } from "express";
import SPS0005Model from "../models/SPS0005Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import OracleDB from "oracledb";

export const scheduling = async (req: Request, res: Response) => {
  try {
    if (req.body.type === "computeData") {
      let results: any = { N: [], YZ: null, FC: null };
      let countSucc = 0;
      let inpArr = req.body.data;
      let arrLen = inpArr?.length;
      //Chemistry will be checked for all rows.
      for (let i = 0; i < arrLen; i++) {
        let chkQry = `select F_CHEM_CHK('${req.body.data[i].p_plant}','${req.body.data[i].p_mcoil}','${req.body.data[i].p_tdc}') as fm_chk FROM DUAL`;
        const chkResult = await query(chkQry); // 0 -- Pass,  1 -- Fail
        const chkQryRes = await ResponceData(chkResult);

        // console.log("chkQryRes: ", chkQryRes);

        if (chkQryRes[0]?.FM_CHK?.substr(0, 1) === "1") {
          results["FC"] =
            chkQryRes[0]?.FM_CHK + ` For TDC - ${req.body.data[i].p_tdc}`;
          // console.log("results1: ", results);
          return res.status(200).json(results);
        } else if (chkQryRes[0]?.FM_CHK?.substr(0, 1) === "0") {
          // console.log("Inside 2");
          countSucc++;
        }
      }
      // let chkQry = `select F_CHEM_CHK('${req.body.data[0].p_plant}','${req.body.data[0].p_mcoil}','${req.body.data[0].p_tdc}') as fm_chk FROM DUAL`;
      // const chkResult = await query(chkQry); // 0 -- Pass,  1 -- Fail
      // const chkQryRes = await ResponceData(chkResult);
      // let results: any = { N: [], YZ: null, FC: null };
      // if (chkQryRes[0]?.FM_CHK?.substr(0, 1) === "1") {
      //   results["FC"] = chkQryRes[0]?.FM_CHK;
      //   return res.status(200).json(results);
      // }
      // else if (chkQryRes[0]?.FM_CHK?.substr(0, 1) === "0") {
      // console.log("countSucc : ", countSucc);
      if (countSucc === arrLen) {
        let dataArr = req.body.data;

        let result = await SPS0005Model.prototype.deleteScheduling(dataArr[0]);
        let count = 0;
        // let results: any = { N: [], YZ: null, FC: "0" };
        results["FC"] = "0";
        for (let i = 0; i < dataArr.length; i++) {
          let inputData = { type: req?.body?.type, ...req?.body?.data[i] };
          let output = await SPS0005Model.prototype.scheduling(inputData);
          if (output?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            count = 1;
            results["N"].push(output?.outBinds?.ls_out_flag);
            break;
          }
        }
        if (count === 0) {
          let binds = {
            p_plant: req?.body?.data[0]?.p_plant,
            p_schd_no: req?.body?.data[0]?.p_schedule_id,
            p_user: req?.body?.data[0]?.p_user,
            ls_out_flag: {
              type: OracleDB.STRING,
              dir: OracleDB.BIND_OUT,
              maxSize: 500,
            },
          };
          let output = await query(
            `
            call TPLB0005(
              p_plant => :p_plant,
              p_schd_no => :p_schd_no,
              p_user => :p_user,
              ls_out_flag => :ls_out_flag
            )
          `,
            binds
          );
          results["YZ"] = output?.outBinds?.ls_out_flag;
        }
        // console.log("results: ", results);
        return res.status(200).json(results);
      } else {
        // This will not get executed cause function will return above cases. But just in case.
        // console.log("results3:  ", results);
        // return res.status(200).json(chkResult.rows[0][0]);
        return res.status(200).json(results);
      }
    } else if (req.body.type === "confirmData") {
      let results = await SPS0005Model.prototype.scheduling(req.body);
      let output = results?.outBinds?.ls_out_flag;
      return res.status(200).json(output);
    } else {
      let varData: any = {};
      varData = await SPS0005Model.prototype.scheduling(req.body);

      return res.status(200).json(await ResponceData(varData));
    }
  } catch (error: any) {
    console.log("error:-", error);
    return res.status(400).json({
      error: error?.message ? error?.message?.toString() : "Errorrrrrr",
    });
  }
};

export const getOrderData = async (req: Request, res: Response) => {
  try {
    const results = await ResponceData(
      await SPS0005Model.prototype.getOrderData(req.body)
    );
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const scheduleID = async (req: Request, res: Response) => {
  try {
    const results = await ResponceData(
      await SPS0005Model.prototype.scheduleID()
    );

    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getToleranceLimit = async (req: Request, res: Response) => {
  try {
    const results = await ResponceData(
      await SPS0005Model.prototype.getToleranceLimit()
    );
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getDiversionRes = async (req: Request, res: Response) => {
  try {
    let data = req.body;
    const results = await ResponceData(
      await SPS0005Model.prototype.getDiversionRes(data)
    );
    return res.status(200).json(results);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
