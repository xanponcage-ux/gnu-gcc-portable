export interface InputChangeType {
  key1: string;
  key2: string;
  key3: string;
  key4: string;
  key5: string;
  key6: string;
  key7: string;
  key8: string;
  key9: string;
}
export interface TableType {
  EGP_CD_EPA: string;
  CIR_ID_COIL: string;
  EIC_ID_COIL: string;
}

export interface PopupObj {
  popUp: boolean;
  id: string | number;
}

export interface Option {
  label: string;
  value: string;
}
