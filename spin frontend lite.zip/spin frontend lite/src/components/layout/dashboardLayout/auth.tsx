import axiosAPI from "../../../apiConfig/axiosAPI";
import { GetAuthorization } from "src/utils";
import API from "src/constant/api";
import ENV from "src/constant/env";
import alertify from "src/components/alert";
import { setTheme, useMaterialUIController } from "src/context";
import { useEffect, useState } from "react";
import Loader from "src/components/preloader";

function Auth(props: any) {
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [admin, setAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const validateUser = async (ls_line = "") => {
    // console.log("API[ENV.server].getAuthData: ", API[ENV.server].getAuthData);
    // console.log("API[ENV.server]: ", API[ENV.server]);
    // console.log("API: ", API);

    const token = await GetAuthorization();

    try {
      if (user == null || user == undefined || user === ``) {
        props.setRestricted(true);
      }

      var userId = user;
      var pageName = window.location.href.slice(
        window.location.href.lastIndexOf("/") + 1
      );

      var authDetails: any = await getScreenAuth(
        ls_line,
        userId,
        pageName,
        token?.accessToken
      );
      // console.log("1-authDetails: ", authDetails);
      if (authDetails) {
        if (authDetails.PS_AUTH_USER_SCR != "Y") {
          props.setRestricted(true);
        } else {
          props.setRestricted(authDetails.LS_READ_WRITE_FLAG);
          if (authDetails.LS_READ_WRITE_FLAG === "RL_RW") {
            setAdmin(true);
            alertify.success(
              "You are authorized to make changes from this page"
            );
          } else {
            alertify.error(
              "You are not authorized to make changes from this page"
            );
          }
        }
      } else {
        props.setRestricted(true);
        setAdmin(false);
      }
    } catch {
      props.setRestricted(true);
      setAdmin(false);
    } finally {
      setLoading(false);
    }

    // GetAuthorization().then((token: any) => {
    //   axiosAPI({
    //     method: "POST",
    //     url: API[ENV.server].getAuthData, //screenAuth
    //     headers: {
    //       Authorization: "Bearer " + token?.accessToken,
    //     },
    //   })
    //     .then(async (res) => {
    //       console.log("res-1: ", res);
    //       if (res.statusText !== "" && res.statusText !== "OK") {
    //         alertify.error(res?.data?.err ? res.data.err : res?.toString());
    //       } else if (res?.data) {
    //         try {
    //           if (user == null || user == undefined || user === ``) {
    //             props.setRestricted(true);
    //           }

    //           var userId = user;
    //           var pageName = window.location.href.slice(
    //             window.location.href.lastIndexOf("/") + 1
    //           );

    //           var authDetails: any = await getScreenAuth(
    //             ls_line,
    //             userId,
    //             pageName,
    //             token?.accessToken
    //           );
    //           console.log("1-authDetails: ", authDetails);
    //           if (authDetails) {
    //             if (authDetails.PS_AUTH_USER_SCR != "Y") {
    //               props.setRestricted(true);
    //             } else {
    //               props.setRestricted(authDetails.LS_READ_WRITE_FLAG);
    //               if (authDetails.LS_READ_WRITE_FLAG === "RL_RW") {
    //                 setAdmin(true);
    //                 alertify.success(
    //                   "You are authorized to make changes from this page"
    //                 );
    //               } else {
    //                 alertify.error(
    //                   "You are not authorized to make changes from this page"
    //                 );
    //               }
    //             }
    //           } else {
    //             props.setRestricted(true);
    //             setAdmin(false);
    //           }
    //         } catch {
    //           props.setRestricted(true);
    //           setAdmin(false);
    //         }

    //         // if (ENV.server === "dev") {
    //         //   props.setRestricted(false);
    //         //   setAdmin(true);
    //         // }
    //       }
    //     })
    //     .catch((e: any) => {
    //       console.log("e", e);
    //       alertify.error(
    //         e?.error?.message ? e.error.message : "Something Wents wrong!"
    //       );
    //     })
    //     .finally(() => {
    //       setLoading(false);
    //     });
    // });
  };

  const getScreenAuth = (ls_line, userId, pageName, token) =>
    new Promise((resolve, reject) => {
      // console.log("Inside getScreenAuth: ");

      var data = { ls_line: ls_line, user: userId, page: pageName };
      // console.log("data: ", data);

      axiosAPI({
        method: "POST",
        url: API[ENV.server].getAuthData,
        headers: {
          Authorization: "Bearer " + token,
        },
        data,
      }).then((response) => {
        // console.log("response: ", response);
        if (response.statusText != "" && response.statusText != "OK") {
          reject(null);
        } else {
          var authDetails = response.data;
          // console.log("authDetails::: ", authDetails);
          if (authDetails) {
            resolve(authDetails);
          } else {
            reject(null);
          }
        }
      });
    });

  useEffect(() => {
    if (props.isRestricted == null) {
      validateUser();
    }
  }, [props]);

  return (
    <>
      {loading ? <Loader /> : null}
      {props.isRestricted === true && (
        <h4 style={{ color: "red", textAlign: "center" }}>
          You are not authorized to view this page !
        </h4>
      )}

      {props.isRestricted !== true && props.children}
    </>
  );
}
export default Auth;
