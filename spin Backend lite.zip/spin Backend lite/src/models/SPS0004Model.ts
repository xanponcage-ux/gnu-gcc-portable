// const SPS0004Query = require("../repository/SPS0004Query");

import {
  getBatchData,
  getBatchDLinkData,
  getChemChk,
  getFittingOrderData,
  saveData,
} from "../repository/SPS0004Query";

export default class SPS0004Model {
  getBatchData(data: any) {
    return getBatchData(data);
  }
  getFittingOrderData(data: any) {
    return getFittingOrderData(data);
  }
  getBatchDLinkData(data: any) {
    return getBatchDLinkData(data);
  }
  saveData(data: any) {
    return saveData(data);
  }
  getChemChk(data: any) {
    return getChemChk(data);
  }
}
