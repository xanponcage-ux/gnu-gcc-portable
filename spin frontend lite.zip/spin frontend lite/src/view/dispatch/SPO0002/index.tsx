import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, SelectInput } from "../../../components/input";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
//import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import PrintIcon from "@mui/icons-material/Print";
import {
  SPO0002ConfirmApi,
  SPO0002GetDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { InputChangeType } from "./type";
//import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "../../../context";
import { FormType } from "../../../view/auth/type";
import { useReactToPrint } from "react-to-print";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPO0002 = () => {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  //const [selectedCoil, setSelectedCoil] = React.useState<string>("");
  const [thickness, setThickness] = React.useState<string>("");
  const [thicknessTo, setThicknessTo] = React.useState<string>("");
  const [widthFrom, setWidthFrom] = React.useState<string>("");
  const [widthTo, setWidthTo] = React.useState<string>("");
  const [value, setValue] = React.useState<number>(0);
  const [open, setOpen] = React.useState<boolean>(false);
  const [textValue, setTextValue] = React.useState("");

  const [labelStatus, setLabelStatus] = React.useState<Array<SelectType>>([]);

  const contentRef = React.useRef<HTMLDivElement>(null);
  const reactToPrintFn = useReactToPrint({ contentRef });

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Dispatch From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "Dispatch To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Batch",
      },
      value: "",
      onChange: (e: any) =>
        onInputChange(e?.toString()?.toUpperCase().slice(0, 10), "key3"),
    },
    key4: {
      config: {
        type: "input",
        label: "M Batch",
      },
      value: "",
      onChange: (e: any) =>
        onInputChange(e?.toString()?.toUpperCase().slice(0, 10), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "Prod From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "input",
        label: "Prod To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    // key7: {
    //   config: {
    //     type: "input",
    //     label: "Pkg From",
    //   },
    //   value: "",
    //   onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    // },
    // key8: {
    //   config: {
    //     type: "input",
    //     label: "Pkg To",
    //   },
    //   value: "",
    //   onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    // }
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };
  const column: Array<any> = [
    {
      title: "",
      formatter: "rowSelection",
      // titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      headerSort: false,
      frozen: true,
    },
    {
      field: "EOM_ID_BATCH",
      title: "Batch ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      frozen: true,
    },
    {
      field: "EOM_CD_PROD",
      title: "Prod",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_QLTY_ACTL",
      title: "Qlty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Thick",
      field: "EOM_SEC1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Width",
      field: "EOM_SEC2",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Length",
      field: "EOM_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "TDC",
      field: "EOM_TDC_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hidden",
      field: "EOM_NO_PIECES1",
      visible: false,
    },
    {
      title: "Pcs",
      field: "EOM_NO_PIECES",
      headerFilter: "input",
      //bottomCalc: "sum",
      headerFilterPlaceholder: "search...",
      // Commented on 03.02.26, this fld need not be editable
      // editor: "number",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(1);
        // cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      // cellEdited: function (cell: any) {
      //   let txtNoPcs = cell?._cell?.row?.data?.EOM_NO_PIECES1;
      //   let editNoPcs = cell?._cell?.row?.data?.EOM_NO_PIECES;
      //   if (txtNoPcs < editNoPcs) {
      //     alertify.error("Modify Pcs cannot be greater than current Pcs!");
      //     let row = cell.getRow();
      //     row.update({
      //       EOM_NO_PIECES: txtNoPcs,
      //     });
      //     return;
      //   }
      //   let row = cell.getRow();
      //   row.update({
      //     EOM_NO_PIECES: editNoPcs,
      //   });
      // },
    },
    {
      title: "Net Wt",
      field: "EOM_MS_PIECE_ACTL",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      //editor: "input",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Gross Wt Hidden",
      field: "EOM_MS_GROSS_ACTL1",
      visible: false,
    },
    {
      title: "Gross Wt",
      field: "EOM_MS_GROSS_ACTL",
      headerFilter: "input",
      //bottomCalc: "sum",
      headerFilterPlaceholder: "search...",
      // Commented on 03.02.26, this fld need not be editable
      // editor: "number",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        // cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      // cellEdited: function (cell: any) {
      //   let updatedData = cell.getValue();
      //   let txtGrossWt = cell?._cell?.row?.data?.EOM_MS_GROSS_ACTL;
      //   let row = cell.getRow();
      //   row.update({
      //     txtGrossWt: updatedData.toFixed(3),
      //   });
      // },
    },
    // { "field": "EOM_UOM", "title": "UOM", "headerFilter": "input", "headerFilterPlaceholder": "search...", },
    {
      field: "EOM_ID_ORDER_CUS",
      title: "Customer Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_ORD_ITEM_CUS",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "ORDER_TYPE",
      title: "Order Type",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SCO_ORDER",
      title: "SCO Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SCO_ITEM",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CUSTOMER_NAME",
      title: "Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_STATUS",
      title: "Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "STATUS_DESC",
      title: "Status Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_NO_CAST",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_FL_SEND_SAP",
      title: "Send to SAP flag",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_FIRST_PAR",
      title: "Mother Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_PAR_COIL_NO",
      title: "Parent Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_PASSED_PROC",
      title: "Current Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_PASSED_PROC",
      title: "Passed Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_PREV_PROC",
      title: "Prev",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_CURR_PROC",
      title: "Curr",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_NEXT_PROC",
      title: "Next",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // { "field": "EOM_DT_PIECE_UPD", "title": "Fg Declare dt", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      field: "AGE",
      title: "Age(Days)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_OP_DECSN",
      title: "Operator",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PARTY_DESC",
      title: "Ship to Party",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // { "field": "STORAGE_LOC", "title": "Storage Location", "headerFilter": "input", "headerFilterPlaceholder": "search..." },
    {
      field: "EOM_IDIA",
      title: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ODIA",
      title: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MARK_CUST",
      title: "Mark Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MKCUSTOMER_NAME",
      title: "Mark Customer Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_TS_CREATION",
      title: "Production Date",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      //formatter: function (cell, formatterParams) {
      //     var value = cell.getValue();
      //     if (value) {
      //         var date = new Date(value);
      //         var year = date.getFullYear();
      //         var month = date.getMonth();
      //         var dt = date.getDate();
      //         if (dt < 10) {
      //             dt = "0" + dt;
      //         }
      //         var newVal =
      //             dt +
      //             "-" +
      //             months[month] +
      //             "-" +
      //             year +
      //             " " +
      //             date.toLocaleTimeString('en-US', {
      //                 hour12: false,
      //             });
      //         return newVal;
      //     }
      //     return value;
      // }, headerFilter: "input",
    },
    {
      field: "EOM_CD_SHIFT",
      title: "Shift",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATNR",
      title: "Batch Material No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATR_DESC",
      title: "Batch Material Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATNR",
      title: "FG Material No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MATR_DESC",
      title: "FG Material Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Dual Marking",
      field: "GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setSelectedCode("");
    fetchEpaData();
  };
  // const handlePlantChange = (event: React.SyntheticEvent, newValue: number) => {
  //   fetchEpaData(newValue);
  // };
  //Page Load
  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: column,
          height: 480,
          layout: "fitDataFill",
          selectable: 1,
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const ConfirmPacking = (value: any) => {
    if (value?.length === 0) {
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0002ConfirmApi(token, {
        type: "confirmPacking",
        plant: selectedCode,
        userid: user,
        row: value,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            var msg = res.data;
            if (res.data.startsWith("Y-")) {
              alertify.success(msg);
              //alertify.success("Y- Successfully Confirmed");
            } else {
              //let msg = res.data.outBinds.ls_out_flag;
              alertify.error(msg.toString().replace("N-", ""));
            }
            table?.deselectRow();
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
          // alertify.error(
          //   e?.error?.message ? e.error.message : "Something Wents wrong!"
          // );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const confirmData = (data: any) => {
    const gridData = table?.getSelectedRows();
    if (gridData?.length === 0) {
      alertify.error("Please select a row!");
      return;
    }
    let newData: Array<string> = [];
    for (let i = 0; i < gridData.length; i++) {
      newData.push(gridData[i]?._row?.getData());
    }
    ConfirmPacking(newData);
  };
  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0002GetDataApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varstatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
              setSelectedStatus("KB");

              const varLabelstatusData: Array<SelectType> = [];
              res?.data?.labelStatus?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varLabelstatusData?.push({
                    value: x?.STATUS?.toString(),
                    label: x?.STATUS?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              // console.log("varLabelstatusData: ", varLabelstatusData);
              setLabelStatus(varLabelstatusData);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0002GetDataApi(token, {
        type: "coilData",
        Plant: selectedCode,
        Status: selectedStatus,
        batch: inputObj.key3.value,
        mBatch: inputObj.key4.value,
        thickFrom: thickness,
        thickTo: thicknessTo,
        widthFrom: widthFrom,
        widthTo: widthTo,
        ProdDtFrom: DateFormat(inputObj.key5.value),
        ProdDtTo: DateFormat(inputObj.key6.value),
        DisDtFrom: DateFormat(inputObj.key1.value),
        DisDtTo: DateFormat(inputObj.key2.value),
        // PkgDtFrom: DateFormat(inputObj.key7.value),
        // PkgDtTo: DateFormat(inputObj.key8.value),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0 && res?.data?.length > 0) {
              setTableData(res.data);
            } else if (res?.data?.Length === 0) {
              alertify.error("No data found");
            } else {
              alertify.error("No data found");
              setTableData(res.data?.procPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleDownloadLabel = async () => {
    //Label generation allowed only for status maintained in v_codes - TK030
    const isStatusAllowed = labelStatus?.some(
      (statusItem) => statusItem.value === selectedStatus
    );

    if (!isStatusAllowed) {
      alertify.error("Print label not allowed for this status.");
      return;
    }
    if (table === null || table === undefined) {
      alertify.error("Click on SEARCH to display data");
      return;
    }
    // if (selectedStatus != "WB" && selectedStatus != "WC") {
    //   alertify.error("Print label not allowed for this status");
    //   return;
    // }
    var selectedRows = table?.getSelectedRows();
    if (selectedRows?.length == 0) {
      alertify.error("Please select a row to generate label");
      return;
    }

    var newData: any[] = [];
    selectedRows.forEach(function (item: any) {
      newData.push(item.getData());
    });

    console.log("newData: ", newData);
    let d;
    let c;

    for (var i = 0; i < newData.length; i++) {
      var a = document.body.appendChild(document.createElement("a"));

      let batchId = newData?.[i]?.EOM_ID_BATCH;
      let isCtl = false;
      if (batchId.substr(6, 1) === "T") {
        isCtl = true;
      }

      let applId = newData?.[i]?.APPL_ID;
      if (applId === null || applId === "") {
        alertify.error("Application ID not found. Label cannot be generated!");
        return;
      }

      let gradeVal = newData?.[i]?.GRADE;
      if (gradeVal === null || gradeVal === "") {
        alertify.error("Grade not found. Label cannot be generated!");
        return;
      }
      let dualMkVal = newData?.[i]?.GRADE_DESC;
      if (dualMkVal === null || dualMkVal === "" || dualMkVal === "N.A") {
        alertify.error(
          "Dual Marking Specification not found. Label cannot be generated!"
        );
        return;
      }
      let castVal = newData?.[i]?.EOM_NO_CAST;
      if (castVal === null || castVal === "") {
        alertify.error("Cast No. not found. Label cannot be generated!");
        return;
      }
      let cmlNo = newData?.[i]?.CML_NO;
      if (cmlNo === null || cmlNo === "") {
        alertify.error("CML no. not found. Label cannot be generated!");
        return;
      }

      //a.download = `${newData?.[i]?.EOM_ID_BATCH}` + "_FG" + ".txt";
      var dateSplit = newData?.[i]?.EOM_TS_CREATION;
      let netWt = newData?.[i]?.EOM_MS_PIECE_ACTL?.toFixed(3);
      let grossWt = newData?.[i]?.EOM_MS_GROSS_ACTL?.toFixed(3);
      let ysVal = newData?.[i]?.YS?.toFixed(3);
      let thick = newData?.[i]?.EOM_SEC1?.toFixed(3);
      let width = newData?.[i]?.EOM_SEC2?.toFixed(1);
      let length = parseInt(newData?.[i]?.EOM_LENGTH);
      let noPcs = newData?.[i]?.EOM_NO_PIECES;

      // This should be before saveLabel, otherwise it will count one moer as saveLabel is inserting data in table
      const seqNo = await getSeqNo();
      console.log("seqNo: ", seqNo);

      let isSaved: any = await saveLabelInfo();
      if (!isSaved) {
        return;
      }

      if (isCtl) {
        d = [
          "INPUT OFF",
          "VERBOFF",
          "INPUT ON",
          "SYSVAR(48) = 0",
          'ERROR 15,"FONT NOT FOUND"',
          'ERROR 18,"DISK FULL"',
          'ERROR 26,"PARAMETER TOO LARGE"',
          'ERROR 27,"PARAMETER TOO SMALL"',
          'ERROR 37,"CUTTER DEVICE NOT FOUND"',
          'ERROR 1003,"FIELD OUT OF LABEL"',
          "SYSVAR(35)=0",
          'OPEN "tmp:setup.sys" FOR OUTPUT AS #1',
          'PRINT#1,"Printing,Media,Print Area,Media Margin (X),0"',
          'PRINT#1,"Printing,Media,Clip Default,On"',
          "CLOSE #1",
          'SETUP "tmp:setup.sys"',
          'KILL "tmp:setup.sys"',
          "CLIP ON",
          "CLIP BARCODE ON",
          "LBLCOND 3,2",
          "CLL",
          'OPTIMIZE "BATCH" ON',
          "PP405,1000",
          'PRIMAGE "HSMISI.PCX"',
          "PP65,430",
          'PRIMAGE "HSMTATASTEEL.PCX"',
          "PP279,58:AN7",
          "DIR4",
          "NASC 8",
          'FT "Inter SemiBold",10,0,104',
          'PT "Batch ID"',
          'PP212,482:FT "Inter Black",16,0,109',
          "PT " + `"${newData?.[i]?.PROD_INFO || ""}"`,
          'PP315,56:FT "Inter Black",24,0,82',
          "PT " + `"${newData?.[i]?.EOM_ID_BATCH}"`,
          'PP154,477:FT "Inter SemiBold",11,0,79',
          'PT "TSDPL CR, Kalinganagar"',
          'PP650,55:BARSET "CODE128B",2,1,2,54',
          "PB " +
            `"${
              newData?.[i]?.EOM_ID_BATCH + ";" + netWt + ";" + grossWt
              //  +
              // ";" +
              // seqNo
            }"`, //TK02F5S041;6.621;6.623"',
          'PP700,56:FT "Univers Bold"',
          "FONTSIZE 10",
          "FONTSLANT 0",
          "PT " +
            `"${
              newData?.[i]?.EOM_ID_BATCH + ";" + netWt + ";" + grossWt
              // +
              // "" +
              // ";" +
              // seqNo
            }"`,
          'PP384,54:FT "Inter SemiBold",10,0,104',
          'PT "Grade / Specification"',
          'PP420,58:FT "Inter Black",10,0,89',
          "PT " + `"${gradeVal || ""}"`, // grade value
          'PP482,56:FT "Inter SemiBold",10,0,104',
          'PT "Section"',
          'PP514,56:FT "Inter Black",10,0,88',
          "PT " + `"${thick + " X " + width + " X " + length + "(mm)"}"`,
          'PP282,688:FT "Inter SemiBold",10,0,104',
          'PT "Cast No "',
          'PP315,690:FT "Inter Black",10,0,88',
          "PT " + `"${castVal || ""}"`,
          'PP388,688:FT "Inter SemiBold",10,0,82',
          'PT "Net Weight / Gross Weight"',
          'PP482,691:FT "Inter SemiBold",10,0,93',
          'PT "Date Of Manufacturing "',
          'PP514,690:FT "Inter Black",10,0,88',
          "PT " + `"${newData?.[i]?.EOM_TS_CREATION || ""}"`,
          "PP207,56:AN1",
          "DIR1",
          "PX1092,65,3",
          "PP550,56:AN7",
          "DIR4",
          'FT "Inter SemiBold",7,0,99',
          'PT "Customer Name / Destination"',
          'PP571,56:FT "Inter Black",7,0,84',
          "PT " + `"${newData?.[i]?.CUSTOMER_NAME || ""}"`,
          "PP546,1146:AN1",
          "DIR2",
          "PL1088,3",
          "PP748,67:AN7",
          "DIR4",
          'FT "Inter Black",4,0,153',
          'PT "TSDPL"',
          "PP792,50:AN1",
          "DIR2",
          "PL3,1",
          "PP765,67:AN7",
          "DIR4",
          'FT "Inter SemiBold"',
          "FONTSIZE 4",
          "FONTSLANT 0",
          'PT "Weighed on mill scale certified by weights & measure Department, which is accepted for the SRP ( Self"',
          'PP779,67:PT "removal procesure) by central excise and/or customs department and all the statutory purposes."',
          "PP736,56:AN1",
          "DIR1",
          "PX604,63,3",
          "PP748,366:AN7",
          "DIR4",
          'FT "Inter Black",4,0,153',
          'PT "WEIGH BRIDGE IN"',
          "PP762,659:AN1",
          "DIR2",
          "PL601,3",
          "PP736,657:DIR1",
          "PX304,63,3",
          "PP42,58:PX224,147,3",
          "PP76,116:AN7",
          "DIR4",
          'FT "Inter Black",8,0,146',
          'PT "MADE"',
          'PP107,147:FT "Inter Black",8,0,173',
          'PT "IN"',
          'PP138,119:FT "Inter Black",8,0,146',
          'PT "INDIA"',
          'PP558,694:FT "Inter SemiBold",7,0,99',
          'PT "Dual Marking Specification"',
          'PP638,695:FT "Inter SemiBold",7,0,99',
          'PT "Coil No"',
          'PP620,775:FT "Inter Black",14,0,84',
          "PT " + `"${newData?.[i]?.EOM_ID_FIRST_PAR}"`,
          'PP405,1027:FT "Inter SemiBold",6,0,99',
          "PT " + `"${newData?.[i]?.LIC_NO || ""}"`, //ISI Logo up',
          'PP520,1020:FT "Inter SemiBold",6,0,72',
          "PT " + `"${newData?.[i]?.CML_NO || ""}"`, // ISI Logo down,
          'PP420,690:FT "Inter Black",12,0,71',
          "PT " + `"${netWt + "(MT) / " + grossWt + "(MT)"}"`,
          "PP40,1148:DIR1",
          'BARSET "QRCODE",1,1,4,2,1',
          "PB " +
            `"https://madeinindia.qcin.org/product-details/${
              applId + "/" + newData?.[i]?.EOM_ID_BATCH
            }"`,
          "PP43,482:DIR4",
          'FT "Inter SemiBold",11,0,79',
          'PT "Processing Agent Of"',
          // 'PP663,695:FT "Inter SemiBold",7,0,99',
          // 'PT "Slit Position"',
          // 'PP663,826:FT "Inter Black",7,0,84',
          // "PT " + `"${newData?.[i]?.SLIT_POS || ""}"`,
          "PP582,1146:DIR1",
          'BARSET "QRCODE",1,1,3,2,3',
          "PB " +
            `"${
              newData?.[i]?.EOM_ID_BATCH +
              "," +
              (castVal || "") +
              "," +
              (thick || "") +
              " X " +
              (width || "") +
              " X " +
              (length || "") +
              "," +
              netWt +
              "," +
              (gradeVal || "") +
              "," +
              newData?.[i]?.EOM_ID_FIRST_PAR +
              "," +
              grossWt +
              "," +
              (newData?.[i]?.EOM_TS_CREATION || "")
            } "`,
          "PP685,695:DIR4",
          'FT "Inter SemiBold",7,0,99',
          // 'PT "Ten Length"', // Not needed for SPIN
          // 'PP685,816:FT "Inter Black",7,0,84',
          'PP583,695:FT "Inter Black"',
          // "PT " + `"${(newData?.[i]?.EOM_LENGTH?.toFixed(1) || "") + " mtrs"}"`, //Length is required in Ten Len,
          'PP623,56:FT "Inter Black",7,0,84',
          "PT YS Value: " + `${(ysVal || "") + " MPa"}`,
          'PP623,264:FT "Inter Black",8,0,84',
          'PP625,345:FT "Inter Black",8,0,84',
          'PP583,695:FT "Inter Black"',
          "FONTSIZE 10",
          "FONTSLANT 0",
          "PT " + `"${dualMkVal || ""}"`, // Dual marking value
          'PP680,695:FT "Inter SemiBold",7,0,99',
          'PT "No of Pieces"',
          'PP680,833:FT "Inter Black",7,0,84',
          "PT " + `"${noPcs}"`,
          'LAYOUT RUN "',
          "PF",
          "PRINT KEY OFF",
        ];
      } else {
        d = [
          "INPUT OFF",
          "VERBOFF",
          "INPUT ON",
          "SYSVAR(48) = 0",
          'ERROR 15,"FONT NOT FOUND"',
          'ERROR 18,"DISK FULL"',
          'ERROR 26,"PARAMETER TOO LARGE"',
          'ERROR 27,"PARAMETER TOO SMALL"',
          'ERROR 37,"CUTTER DEVICE NOT FOUND"',
          'ERROR 1003,"FIELD OUT OF LABEL"',
          "SYSVAR(35)=0",
          'OPEN "tmp:setup.sys" FOR OUTPUT AS #1',
          'PRINT#1,"Printing,Media,Print Area,Media Margin (X),0"',
          'PRINT#1,"Printing,Media,Clip Default,On"',
          "CLOSE #1",
          'SETUP "tmp:setup.sys"',
          'KILL "tmp:setup.sys"',
          "CLIP ON",
          "CLIP BARCODE ON",
          "LBLCOND 3,2",
          "CLL",
          'OPTIMIZE "BATCH" ON',
          "PP405,1000",
          'PRIMAGE "HSMISI.PCX"',
          "PP65,430",
          'PRIMAGE "HSMTATASTEEL.PCX"',
          "PP279,58:AN7",
          "DIR4",
          "NASC 8",
          'FT "Inter SemiBold",10,0,104',
          'PT "Batch ID"',
          'PP212,482:FT "Inter Black",16,0,109',
          "PT " + `"${newData?.[i]?.PROD_INFO || ""}"`,
          'PP315,56:FT "Inter Black",24,0,82',
          "PT " + `"${newData?.[i]?.EOM_ID_BATCH}"`,
          'PP154,477:FT "Inter SemiBold",11,0,79',
          'PT "TSDPL CR, Kalinganagar"',
          'PP650,55:BARSET "CODE128B",2,1,2,54',
          "PB " +
            `"${
              newData?.[i]?.EOM_ID_BATCH + ";" + netWt + ";" + grossWt
              // +
              // ";" +
              // seqNo
            }"`, //TK02F5S041;6.621;6.623"',
          'PP700,56:FT "Univers Bold"',
          "FONTSIZE 10",
          "FONTSLANT 0",
          "PT " +
            `"${
              newData?.[i]?.EOM_ID_BATCH + ";" + netWt + ";" + grossWt
              // +
              // "" +
              // ";" +
              // seqNo
            }"`,
          'PP384,54:FT "Inter SemiBold",10,0,104',
          'PT "Grade / Specification"',
          'PP420,58:FT "Inter Black",10,0,89',
          "PT " + `"${gradeVal || ""}"`, // grade value
          'PP482,56:FT "Inter SemiBold",10,0,104',
          'PT "Section"',
          'PP514,56:FT "Inter Black",10,0,88',
          "PT " + `"${thick + " X " + width + "(mm)"}"`,
          'PP282,688:FT "Inter SemiBold",10,0,104',
          'PT "Cast No "',
          'PP315,690:FT "Inter Black",10,0,88',
          "PT " + `"${castVal || ""}"`,
          'PP388,688:FT "Inter SemiBold",10,0,82',
          'PT "Net Weight / Gross Weight"',
          'PP482,691:FT "Inter SemiBold",10,0,93',
          'PT "Date Of Manufacturing "',
          'PP514,690:FT "Inter Black",10,0,88',
          "PT " + `"${newData?.[i]?.EOM_TS_CREATION || ""}"`,
          "PP207,56:AN1",
          "DIR1",
          "PX1092,65,3",
          "PP550,56:AN7",
          "DIR4",
          'FT "Inter SemiBold",7,0,99',
          'PT "Customer Name / Destination"',
          'PP571,56:FT "Inter Black",7,0,84',
          "PT " + `"${newData?.[i]?.CUSTOMER_NAME || ""}"`,
          "PP546,1146:AN1",
          "DIR2",
          "PL1088,3",
          "PP748,67:AN7",
          "DIR4",
          'FT "Inter Black",4,0,153',
          'PT "TSDPL"',
          "PP792,50:AN1",
          "DIR2",
          "PL3,1",
          "PP765,67:AN7",
          "DIR4",
          'FT "Inter SemiBold"',
          "FONTSIZE 4",
          "FONTSLANT 0",
          'PT "Weighed on mill scale certified by weights & measure Department, which is accepted for the SRP ( Self"',
          'PP779,67:PT "removal procesure) by central excise and/or customs department and all the statutory purposes."',
          "PP736,56:AN1",
          "DIR1",
          "PX604,63,3",
          "PP748,366:AN7",
          "DIR4",
          'FT "Inter Black",4,0,153',
          'PT "WEIGH BRIDGE IN"',
          "PP762,659:AN1",
          "DIR2",
          "PL601,3",
          "PP736,657:DIR1",
          "PX304,63,3",
          "PP42,58:PX224,147,3",
          "PP76,116:AN7",
          "DIR4",
          'FT "Inter Black",8,0,146',
          'PT "MADE"',
          'PP107,147:FT "Inter Black",8,0,173',
          'PT "IN"',
          'PP138,119:FT "Inter Black",8,0,146',
          'PT "INDIA"',
          'PP558,694:FT "Inter SemiBold",7,0,99',
          'PT "Dual Marking Specification"',
          'PP638,695:FT "Inter SemiBold",7,0,99',
          'PT "Coil No"',
          'PP620,775:FT "Inter Black",14,0,84',
          "PT " + `"${newData?.[i]?.EOM_ID_FIRST_PAR}"`,
          'PP405,1027:FT "Inter SemiBold",6,0,99',
          "PT " + `"${newData?.[i]?.LIC_NO || ""}"`, //ISI Logo up',
          'PP520,1020:FT "Inter SemiBold",6,0,72',
          "PT " + `"${newData?.[i]?.CML_NO || ""}"`, // ISI Logo down,
          'PP420,690:FT "Inter Black",12,0,71',
          "PT " + `"${netWt + "(MT) / " + grossWt + "(MT)"}"`,
          "PP40,1148:DIR1",
          'BARSET "QRCODE",1,1,4,2,1',
          "PB " +
            `"https://madeinindia.qcin.org/product-details/${
              applId + "/" + newData?.[i]?.EOM_ID_BATCH
            }"`,

          // `"https://madeinindia.qcin.org/product-details/94a6833f336b4575b5bc3c570ba91bd8/${newData?.[i]?.EOM_ID_BATCH}"`, // +
          // `${newData?.[i]?.EOM_ID_BATCH}`,
          "PP43,482:DIR4",
          'FT "Inter SemiBold",11,0,79',
          'PT "Processing Agent Of"',
          'PP663,695:FT "Inter SemiBold",7,0,99',
          'PT "Slit Position"',
          'PP663,826:FT "Inter Black",7,0,84',
          "PT " + `"${newData?.[i]?.SLIT_POS || ""}"`,
          "PP582,1146:DIR1",
          'BARSET "QRCODE",1,1,3,2,3',
          "PB " +
            `"${
              newData?.[i]?.EOM_ID_BATCH +
              "," +
              (castVal || "") +
              "," +
              (thick || "") +
              " X " +
              (width || "") +
              // " X " +
              // (newData?.[i]?.EOM_LENGTH || "") +
              "," +
              netWt +
              "," +
              (gradeVal || "") +
              "," +
              newData?.[i]?.EOM_ID_FIRST_PAR +
              "," +
              grossWt +
              "," +
              (newData?.[i]?.EOM_TS_CREATION || "")
            } "`,
          "PP685,695:DIR4",
          'FT "Inter SemiBold",7,0,99',
          'PT "Ten Length"', // Not needed for SPIN
          'PP685,816:FT "Inter Black",7,0,84',
          "PT " + `"${(newData?.[i]?.EOM_LENGTH?.toFixed(1) || "") + " mtrs"}"`, //Length is required in Ten Len,
          'PP623,56:FT "Inter Black",7,0,84',
          "PT YS Value: " + `${(ysVal || "") + " MPa"}`,
          'PP623,264:FT "Inter Black",8,0,84',
          // 'PT "Part No  "',
          'PP625,345:FT "Inter Black",8,0,84',
          // 'PT  ""', //No logic right now for part no.
          'PP583,695:FT "Inter Black"',
          "FONTSIZE 7",
          "FONTSLANT 0",
          "PT " + `"${dualMkVal || ""}"`, // Dual marking value
          "PP609,695:PT ",
          'PP711,695:FT "Inter SemiBold",7,0,99',
          "PT ",
          'PP711,833:FT "Inter Black",7,0,84',
          "PT ",
          'LAYOUT RUN ""',
          "PF",
          "PRINT KEY OFF",
        ];
      }

      var b = "";
      for (var i = 0; i < d.length; i++) {
        b += d?.[i] + "\r\n";
      }
      const newWindow = window.open("", "_blank");
      newWindow?.document.write(
        "<html><head><title>Label Data</title></head><body><pre>"
      );
      newWindow?.document.write(b);
      newWindow?.document.write("</pre></body></html>");
      newWindow?.document.close();
      // b = encodeURIComponent(b);
      // a.href = "data:text/html," + b;
      // a.click();
    }
    // setOpen(true);
    // setTextValue(c);
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }

    var date = new Date();
    var fileName = "SPS0005_" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    setSelectedCode("");
    setTableData([]);
    setSelectedStatus("");
    setThickness("");
    setThicknessTo("");
    setThickness("");
    setWidthFrom("");
    setWidthTo("");
    setInputObj(varInput);
  };

  const saveLabelInfo = async (): Promise<boolean> => {
    try {
      if (!(selectedCode?.length > 0)) {
        alertify.error("Please select Plant!");
        return false;
      }

      const selectedRow = table?.getSelectedRows()?.[0]?.getData();

      if (!selectedRow) {
        alertify.error("Please select a row");
        return false;
      }

      const batchId = selectedRow.EOM_ID_BATCH;
      const mBatch = selectedRow.EOM_ID_FIRST_PAR;

      setLoading(true);

      const token = await GetAuthorization();

      const res = await SPO0002GetDataApi(token, {
        type: "saveLabelInfo",
        plant: selectedCode ?? "",
        batchStatus: selectedStatus ?? "",
        batchId: batchId ?? "",
        firstPar: mBatch ?? "",
        user: user,
      });

      if (res?.statusText && res.statusText !== "OK") {
        alertify.error(res?.data?.err || res?.toString());
        return false;
      }

      if (res?.data?.startsWith("N")) {
        alertify.error(res.data);
        return false;
      }

      return true;
    } catch (error: any) {
      alertify.error(error?.message || "Something went wrong!");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const getSeqNo = async () => {
    try {
      if (!(selectedCode?.length > 0)) {
        alertify.error("Please select Plant!");
        return false;
      }

      const selectedRow = table?.getSelectedRows()?.[0]?.getData();

      if (!selectedRow) {
        alertify.error("Please select a row");
        return false;
      }

      const batchId = selectedRow.EOM_ID_BATCH;

      setLoading(true);

      const token = await GetAuthorization();

      const res = await SPO0002GetDataApi(token, {
        type: "getLabelCount",
        plant: selectedCode ?? "",
        batchId: batchId ?? "",
        user: user,
      });

      if (res?.statusText && res.statusText !== "OK") {
        alertify.error(res?.data?.err || res?.toString());
        return false;
      }
      console.log("res?.data: ", res?.data);

      const labelCount = res?.data;
      const seqNo = labelCount + 1;
      return seqNo;
    } catch (error: any) {
      alertify.error(error?.message || "Something went wrong!");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // const statusData = [
  //   { label: "VS", value: "VS", id: 1 },
  //   { label: "VT", value: "VT", id: 2 },
  //   { label: "VN", value: "VN", id: 3 },
  // ];

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Dialog
            open={open}
            maxWidth="lg"
            onClose={() => {
              setOpen(false);
            }}
          >
            <DialogTitle>Print made in india FG Label</DialogTitle>
            <DialogContent>
              <Grid item xs={12}>
                <div ref={contentRef}>
                  <Grid container spacing={1} sx={{ pl: 5 }}>
                    <div>{textValue}</div>
                  </Grid>
                </div>
              </Grid>
            </DialogContent>
            <DialogActions>
              <ButtonElement
                onClick={() => {
                  setOpen(false);
                }}
                color="secondary"
              >
                Close
              </ButtonElement>
              <ButtonElement color="secondary" onClick={reactToPrintFn}>
                Print
              </ButtonElement>
            </DialogActions>
          </Dialog>
          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              {loading ? <Loader /> : null}
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Status"
                          data={statusData}
                          value={selectedStatus}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedStatus(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={3}>
                        <Grid container spacing={2}>
                          {formData.map(
                            (x: FormType, i: number) =>
                              i >= 2 &&
                              i < 4 && (
                                <Grid item key={x?.key} xs={6}>
                                  <Input
                                    id={x?.key}
                                    value={x?.data?.value}
                                    {...x?.data?.config}
                                    // onChange={x?.data?.onChange}
                                    onChange={(e: string) => {
                                      if (x?.data?.onChange) {
                                        x.data.onChange(e);
                                      }
                                      setTableData([]);
                                    }}
                                  />
                                </Grid>
                              )
                          )}
                        </Grid>
                      </Grid>
                      <Grid item xs={1.2}>
                        <Box component="span">
                          <Input
                            label="Thick From"
                            value={thickness}
                            size={"small"}
                            type={"number"}
                            onChange={(e: string) => {
                              setThickness(e);
                              setTableData([]);
                            }}
                          />
                        </Box>
                      </Grid>
                      <Grid item xs={1.2}>
                        <Box component="span">
                          <Input
                            label="Thick To"
                            value={thicknessTo}
                            size={"small"}
                            type={"number"}
                            onChange={(e: string) => {
                              setThicknessTo(e);
                              setTableData([]);
                            }}
                          />
                        </Box>
                      </Grid>
                      <Grid item xs={1.2}>
                        <Box component="span">
                          <Input
                            label="Width From"
                            value={widthFrom}
                            size={"small"}
                            type={"number"}
                            onChange={(e: string) => {
                              setWidthFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Box>
                      </Grid>
                      <Grid item xs={1.2}>
                        <Box component="span">
                          <Input
                            label="Width To"
                            value={widthTo}
                            size={"small"}
                            type={"number"}
                            onChange={(e: string) => {
                              setWidthTo(e);
                              setTableData([]);
                            }}
                          />
                        </Box>
                      </Grid>

                      <Grid item xs={3.5}>
                        <Box component="span">
                          Production Date
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 4 &&
                                i <= 5 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>
                      <Grid item xs={3.5}>
                        <Box component="span">
                          Dispatch Date
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i <= 1 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                      }}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>
                      {/* <Grid item xs={3.5}>
                        <Box component="span" > 
                        Packing Date
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 6  && i<=7 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={x?.data?.value?.length > 0 ? x?.data?.value : null}
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                </Grid>
                              )
                            )}
                          </Grid>
                        </Box>
                      </Grid>  */}
                      <Grid item xs={1}>
                        <Box component="span">
                          {" "}
                          &nbsp;
                          <Grid container>
                            <ButtonElement onClick={() => fetchData(value)}>
                              Search
                            </ButtonElement>
                          </Grid>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Package Material & Declare FG"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Generate Label">
                        <IconButton
                          onClick={handleDownloadLabel}
                          disabled={restricted !== "RL_RW"}
                        >
                          <PrintIcon sx={{ color: "#ffffff" }} />
                          {/* <DownloadForOfflineIcon sx={{ color: "#ffffff" }} /> */}
                          {/* </PrintIcon> */}
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    {/* <Grid item>
                    <Tooltip title="Download Label">
                      <IconButton 
                       onClick={handleDownloadLabel}                     
                      >                    
                        <DownloadForOfflineIcon sx={{ color: "#ffffff" }} /> 
                      </IconButton>
                    </Tooltip>
                  </Grid> */}
                    {/* <Grid item>
                    {value === 0 &&(
                      <Tooltip title="Confirm">
                        <IconButton
                          onClick={() => {
                            confirmData(value);
                          }}
                        >
                          <SaveIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    )}
                  </Grid> */}
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPO0002;
