import { Router } from "express";
import {
  getData01,
  getEpaData01,
  updateCoilStatus01,
  // scheduling,
  // getOrderData,
  // indenting,
  // scheduleID,
  // scheduleDeletion,
} from "../controllers/planningController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const planningRoute = Router();

// planningRoute
//   .route("/planning/scheduling")
//   .post(authenticationMiddleware.bearer, scheduling);
planningRoute
  .route("/planning/updateCoilStatus")
  .post(authenticationMiddleware.bearer, updateCoilStatus01);
// planningRoute
//   .route("/planning/orderData")
//   .post(authenticationMiddleware.bearer, getOrderData);
// planningRoute
//   .route("/planning/indenting")
//   .post(authenticationMiddleware.bearer, indenting);
// planningRoute
//   .route("/planning/scheduleID")
//   .post(authenticationMiddleware.bearer, scheduleID);
// planningRoute
//   .route("/planning/scheduleDeletion")
//   .post(authenticationMiddleware.bearer, scheduleDeletion);

export default planningRoute;
