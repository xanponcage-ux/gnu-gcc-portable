import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { useMaterialUIController } from "../../../context";
import { DateFormat } from "../../../utils";
import { GetAuthorization } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
  iconButtonClasses,
} from "@mui/material";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import DeleteIcon from "@mui/icons-material/Delete";
import CreateIcon from "@mui/icons-material/Create";
import {
  SPC0003GetDataApi,
  // SPC001GetPlantData,
  GetPlantDataApi,
  SPC0003ProcedureApi,
  SPC0003getPackCodeList,
  SPC0003GetPackSeq,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import { ColumnDefinition } from "tabulator-tables";
import Auth from "../../../components/layout/dashboardLayout/auth";

const formatDate = (date: any) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  //user id
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;
  //

  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [isEditable, setIsEditable] = React.useState<boolean>(true);

  const [value, setValue] = React.useState<number>(0);

  const [tablepkg, setTablepkg] = React.useState<any>(null);
  const [tableoil, setTableoil] = React.useState<any>(null);

  const [pkgTableData, setPkgTableData] = React.useState<any>([]);
  const [tableDataoil, setTableDataoil] = React.useState<any>([]);
  const [packCdList, setPackCdList] = React.useState<any>([]);
  const [selectedPackCode, setSelectedPackCode] = React.useState<string>("");
  const [packSeq, setPackSeq] = React.useState<number>();

  const [widthTolTable, setWidthTolTable] = React.useState<any>(null);
  const [widthTolTableData, setWidthTolTableData] = React.useState<any>([]);

  const productList: Array<SelectType> = [
    { value: "SLT", label: "SLT", id: 1 },
    { value: "CTL", label: "CTL", id: 2 },
  ];

  const formatDate = (date: any) => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const packingColumn: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
    },
    {
      title: "Plant",
      field: "TPM_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Customer ID",
      field: "TPM_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      // editor: isEditable ? "input" : true,
      validator: "integer",
      editor: function (
        cell: any,
        onRendered: any,
        success: any,
        cancel: any,
        editorParams: any
      ) {
        if (cell._cell.row.data.ls_flag) {
          var editor = document.createElement("input");
          //create and style input
          editor.style.padding = "3px";
          editor.style.width = "100%";
          editor.style.boxSizing = "border-box";
          editor.value = cell.getValue() ? cell.getValue() : "";
          editor.maxLength = 6;
          onRendered(function () {
            editor.focus();
          });

          //when the value has been set, trigger the cell to update
          function successFunc() {
            success(editor.value);
            getPackSeq(editor.value);
          }

          editor.addEventListener("change", successFunc);
          editor.addEventListener("blur", successFunc);

          return editor;
        }
      },
      editorParams: {
        elementAttributes: {},
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        cell.getElement().style["border"] = "1.5px solid #748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Customer name",
      field: "CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    //Value of pack seq is fetched through API
    // {
    //   title: "Pack Seq",
    //   field: "TPM_PACK_SEQ",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "center",
    //   //editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editor: function (
    //     cell: any,
    //     onRendered: any,
    //     success: any,
    //     cancel: any,
    //     editorParams: any
    //   ) {
    //     if (cell._cell.row.data.ls_flag) {
    //       var editor = document.createElement("input");
    //       //create and style input
    //       editor.style.padding = "3px";
    //       editor.style.width = "100%";
    //       editor.style.boxSizing = "border-box";
    //       editor.value = cell.getValue() ? cell.getValue() : "";
    //       editor.maxLength = 3;
    //       onRendered(function () {
    //         editor.focus();
    //       });

    //       //when the value has been set, trigger the cell to update
    //       function successFunc() {
    //         success(editor.value);
    //       }

    //       editor.addEventListener("change", successFunc);
    //       editor.addEventListener("blur", successFunc);

    //       return editor;
    //     }
    //   },
    //   formatter: function (cell: any, formatterParams: any) {
    //     var value = cell.getValue();
    //     // cell.getElement().style["background-color"] = "#748da6";
    //     cell.getElement().style["border"] = "1.5px solid #748da6";
    //     // cell.getElement().style["color"] = "#FFFFFF";
    //     if (value) {
    //       return value;
    //     }
    //     return value;
    //   },
    // },
    {
      title: "Pack Code",
      field: "TPM_PACK_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "list" : true,
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: packCdList,
      },
      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "4",
      //   },
      // },

      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Width Min",
      field: "TPM_SEC2_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "integer",
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Width Max",
      field: "TPM_SEC2_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "integer",
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Product Type",
      field: "TPM_PRODUCT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "list" : true,
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: productList,
      },

      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },

    {
      title: "Created By",
      field: "TPM_CRT_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Created On",
      field: "CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Updated By",
      field: "TPM_UPD_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Updated On",
      field: "TPM_UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
  ];

  const pathColumn: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      headerSort: false,
    },
    {
      title: "Plant",
      field: "TOM_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    // {
    //   title: "Plant",
    //   field: "TOM_CD_EPA",
    //   headerFilter: "input",
    //   frozen: true,
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "center",
    //   //editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editor: function (
    //     cell: any,
    //     onRendered: any,
    //     success: any,
    //     cancel: any,
    //     editorParams: any
    //   ) {
    //     if (cell._cell.row.data.ls_flag) {
    //       var editor = document.createElement("input");
    //       //create and style input
    //       editor.style.padding = "3px";
    //       editor.style.width = "100%";
    //       editor.style.boxSizing = "border-box";
    //       editor.value = cell.getValue() ? cell.getValue() : "";
    //       editor.maxLength = 4;
    //       onRendered(function () {
    //         editor.focus();
    //       });

    //       //when the value has been set, trigger the cell to update
    //       function successFunc() {
    //         success(editor.value);
    //       }

    //       editor.addEventListener("change", successFunc);
    //       editor.addEventListener("blur", successFunc);

    //       return editor;
    //     }
    //   },
    // },
    {
      title: "Customer Mark",
      field: "TOM_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "number" : true,
      validator: "integer",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
      // editor: function (
      //   cell: any,
      //   onRendered: any,
      //   success: any,
      //   cancel: any,
      //   editorParams: any
      // ) {
      //   if (cell._cell.row.data.ls_flag) {
      //     var editor = document.createElement("input");
      //     //create and style input
      //     editor.style.padding = "3px";
      //     editor.style.width = "100%";
      //     editor.style.boxSizing = "border-box";
      //     editor.value = cell.getValue() ? cell.getValue() : "";
      //     editor.maxLength = 6;
      //     onRendered(function () {
      //       editor.focus();
      //     });

      //     //when the value has been set, trigger the cell to update
      //     function successFunc() {
      //       success(editor.value);
      //     }

      //     editor.addEventListener("change", successFunc);
      //     editor.addEventListener("blur", successFunc);

      //     return editor;
      //   }
      // },
    },
    {
      title: "Customer TDC",
      field: "TOM_CUST_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      // validator: "integer",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
      // editor: function (
      //   cell: any,
      //   onRendered: any,
      //   success: any,
      //   cancel: any,
      //   editorParams: any
      // ) {
      //   if (cell._cell.row.data.ls_flag) {
      //     var editor = document.createElement("input");
      //     //create and style input
      //     editor.style.padding = "3px";
      //     editor.style.width = "100%";
      //     editor.style.boxSizing = "border-box";
      //     editor.value = cell.getValue() ? cell.getValue() : "";
      //     editor.maxLength = 8;
      //     onRendered(function () {
      //       editor.focus();
      //     });

      //     //when the value has been set, trigger the cell to update
      //     function successFunc() {
      //       success(editor.value);
      //     }

      //     editor.addEventListener("change", successFunc);
      //     editor.addEventListener("blur", successFunc);

      //     return editor;
      //   }
      // },
    },

    {
      title: "Oil Code",
      field: "TOM_OIL_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      editorParams: {
        elementAttributes: {
          maxlength: "1",
        },
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
    },
    {
      title: "Oil Type",
      field: "TOM_OIL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Created By",
      field: "TOM_CRT_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Created On",
      field: "CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Updated By",
      field: "TOM_UPD_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Updated On",
      field: "TOM_UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Flag",
      field: "ls_flag",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setSelectedCode("");
    setSelectedProcess("");
    fetchEpaData();
  };

  React.useEffect(() => {
    fetchEpaData();
    getPackCdList();
  }, []);

  React.useEffect(() => {
    if (pkgTableData?.length > 0) {
      setTablepkg(
        new Tabulator("#table", {
          data: pkgTableData,
          columns: packingColumn,
          height: 300,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
          selectable: 1,
        })
      );
    } else {
      setTablepkg(null);
    }
  }, [pkgTableData]);

  React.useEffect(() => {
    if (tableDataoil?.length > 0) {
      setTableoil(
        new Tabulator("#table", {
          data: tableDataoil,
          columns: pathColumn,
          height: 600,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
          selectable: 1,
        })
      );
    } else {
      setTableoil(null);
    }
  }, [tableDataoil]);

  const fetchEpaData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantCodeData(varData);
            setSelectedCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003GetDataApi(token, {
        data: data,
        process: selectedProcess,
        code: selectedCode?.split(" - ")[0],
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0) {
              setPkgTableData(res.data?.PackingCode); // PackingCode
            } else if (data === 1) {
              setTableDataoil(res.data?.Oilingcode);
            } else {
              setWidthTolTableData(res?.data?.widthTol);
            }
          }
        })
        .catch((e: any) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcelpkg = () => {
    if (pkgTableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    const fileName = "SPC0003_" + "Packaging" + ".xlsx";

    const cleanedData = pkgTableData.map((row: any) => {
      const newRow = { ...row };
      Object.keys(newRow).forEach((key) => {
        if (newRow[key] === null) {
          newRow[key] = "";
        }
      });
      return newRow;
    });

    tablepkg.setData(cleanedData).then(() => {
      tablepkg.download("xlsx", fileName, {
        sheetName: "Sheet1",
      });

      tablepkg.setData(pkgTableData);
    });
  };

  const downloadExceloil = () => {
    if (tableDataoil.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    const fileName = "SPC0003_" + "Oiling_Code" + ".xlsx";

    const cleanedData = tableDataoil.map((row: any) => {
      const newRow = { ...row };
      Object.keys(newRow).forEach((key) => {
        if (newRow[key] === null) {
          newRow[key] = "";
        }
      });
      return newRow;
    });

    tableoil.setData(cleanedData).then(() => {
      tableoil.download("xlsx", fileName, {
        sheetName: "Sheet1",
      });

      tableoil.setData(tableDataoil);
    });

    // tableoil.download("xlsx", fileName, {
    //   sheetName: "Sheet1",
    // });
  };

  const deletePacking = () => {
    if (pkgTableData.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = tablepkg.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tablepkg.getSelectedRows()?.map((row: any) => {
      if (value === 0) {
        setLoading(true);
        let varData: any = {};
        varData["ls_cd_epa"] = row._row.data.TPM_CD_EPA;
        varData["ls_mark_cust"] = row._row.data.TPM_MARK_CUST;
        varData["ls_pack_seq"] = row._row.data.TPM_PACK_SEQ;
        varData["ls_pack_cd"] = row._row.data.TPM_PACK_CD;
        varData["ls_crt_id"] = row._row.data.TPM_CRT_ID;
        varData["ls_crt_dt"] = row._row.data.CRT_DT;
        varData["ls_flag"] = "D";
        varData["lb_status"] = "PACK";
        return varData;
      }
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const deleteOiling = () => {
    if (tableDataoil.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = tableoil.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableoil.getSelectedRows()?.map((row: any) => {
      if (value === 1) {
        let varData2: any = {};
        varData2["ls_cd_epa"] = row._row.data.TOM_CD_EPA;
        varData2["ls_mark_cust"] = row._row.data.TOM_MARK_CUST;
        varData2["ls_cust_tdc"] = row._row.data.TOM_CUST_TDC;
        varData2["ls_pack_cd"] = row._row.data.TOM_OIL_CD;
        varData2["ls_crt_id"] = row._row.data.TOM_CRT_ID;
        varData2["ls_crt_dt"] = row._row.data.CRT_DT;
        varData2["ls_upd_id"] = row._row.data.TOM_UPD_ID;
        varData2["ls_upd_dt"] = row._row.data.TOM_UPD_DT;
        varData2["ls_flag"] = "D";
        varData2["lb_status"] = "OIL";
        return varData2;
      }
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (res.statusText !== "" && res.statusText !== "OK") {
              alertify.error(res?.data?.outBinds?.ls_out_flag);
            } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
              alertify.success(res?.data?.outBinds?.ls_out_flag);
              fetchData(value);
            } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
              alertify.error(res?.data?.outBinds?.ls_out_flag);
              fetchData(value);
            }
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // const Edit = () => {
  //   setIsEditable(true);
  //   alertify.success("Edit mode enabled. You can now edit the table.");
  // };
  let isInsert = false;

  const Addpkg = () => {
    setIsEditable(true);
    const dateSys = formatDate(new Date());
    let arr = [...pkgTableData];

    arr.unshift({
      TPM_CD_EPA: selectedCode,
      TPM_MARK_CUST: "",
      TPM_PACK_SEQ: "",
      TPM_PACK_CD: "",
      TPM_CRT_ID: user,
      CRT_DT: dateSys,
      TPM_UPD_ID: "",
      TPM_UPD_DT: "",
      ls_flag: "I",
    });
    setPkgTableData(arr);
  };

  const Addoil = () => {
    setIsEditable(true);
    const dateSys = formatDate(new Date());
    let arr1 = [...tableDataoil];

    arr1.unshift({
      TOM_CD_EPA: selectedCode,
      TOM_MARK_CUST: "",
      TOM_CUST_TDC: "",
      TOM_OIL_CD: "",
      TOM_CRT_ID: user,
      CRT_DT: dateSys,
      TOM_UPD_ID: "",
      TOM_UPD_DT: "",
      // TOM_CRT_DT: dateSys,
      ls_flag: "I",
    });
    setTableDataoil(arr1);
  };

  const SaveOil = () => {
    setIsEditable(true);
    if (tableDataoil.length === 0) {
      alertify.error("No data to inserted");
      return;
    }
    const selectedRows = tableoil.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableoil.getSelectedRows()?.map((row: any) => {
      let varData: any = {};
      varData["ls_cd_epa"] = row._row.data.TOM_CD_EPA;
      varData["ls_mark_cust"] = row._row.data.TOM_MARK_CUST;
      varData["ls_pack_cd"] = row._row.data.TOM_OIL_CD;
      varData["ls_crt_id"] = row._row.data.TOM_CRT_ID;
      varData["ls_cust_tdc"] = row._row.data.TOM_CUST_TDC;
      varData["ls_crt_dt"] = formatDate(new Date(row._row.data.CRT_DT));
      varData["ls_upd_id"] = row._row.data.TOM_UPD_ID;
      varData["ls_upd_dt"] = row._row.data.TOM_UPD_DT;
      varData["ls_flag"] = row._row.data.ls_flag ? row._row.data.ls_flag : "U";
      varData["lb_status"] = "OIL";
      varData["ls_oil_type"] = row._row.data.TOM_OIL_TYPE;
      return varData;
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const SavePackingCd = (process: string) => {
    let pkSeqn = Number(packSeq);
    setIsEditable(true);
    if (pkgTableData.length === 0) {
      alertify.error("No data to insert");
      return;
    }
    const selectedRows = tablepkg.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    for (let i = 0; i < selectedRows?.length; i++) {
      let selectedData = selectedRows[i]?.getData();
      // console.log("selectedData: ", selectedData);

      let widthMin = selectedData?.TPM_SEC2_MIN;
      let widthMax = selectedData?.TPM_SEC2_MAX;
      let prodType = selectedData?.TPM_PRODUCT;

      if (widthMin === null || widthMin === undefined) {
        alertify.error("Min Width is Mandatory!");
        return;
      }
      if (widthMax === null || widthMax === undefined) {
        alertify.error("Max Width is Mandatory!");
        return;
      }
      if (prodType === null || prodType === undefined) {
        alertify.error("Product Type is Mandatory!");
        return;
      }
    }
    const selectedData = tablepkg.getSelectedRows()?.map((row: any) => {
      let varData: any = {};
      varData["ls_cd_epa"] = row._row.data.TPM_CD_EPA;
      varData["ls_mark_cust"] = row._row.data.TPM_MARK_CUST;
      // varData["ls_pack_seq"] = row._row.data.TPM_PACK_SEQ;
      varData["ls_pack_seq"] = row._row.data.ls_flag
        ? Number(pkSeqn + 1)
        : pkSeqn;
      varData["ls_cust_tdc"] = row._row.data.TDC;
      varData["ls_pack_cd"] = row._row.data.TPM_PACK_CD;
      varData["ls_crt_id"] = user;
      varData["ls_sec2_min"] = row._row.data.TPM_SEC2_MIN;
      varData["ls_sec2_max"] = row._row.data.TPM_SEC2_MAX;
      varData["ls_product"] = row._row.data.TPM_PRODUCT;
      varData["ls_flag"] = row._row.data.ls_flag ? row._row.data.ls_flag : "U";
      varData["lb_status"] = "PACK";
      return varData;
    });
    if (selectedData[0]?.ls_mark_cust === "") {
      alertify.error("Mark Customer can't blank!");
      return;
    }
    if (selectedData[0]?.ls_pack_cd === "") {
      alertify.error("Packing Code can't blank!");
      return;
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "U") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getPackCdList = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003getPackCodeList(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.SPM_PKG_SUBRAN_CD?.toString(),
                  label: x?.PACK_CODE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPackCdList(varData);
            setSelectedPackCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getPackSeq = (custId: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      let data = {
        custId: custId,
      };
      SPC0003GetPackSeq(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            setPackSeq(Number(res?.data[0]?.PACK_SEQ));
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setPkgTableData([]);
    setTableDataoil([]);
  };

  //Added on 27.10.25, Width Tolerance Tab Code

  const widthTolCol: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
    },
    {
      title: "Plant",
      field: "WTM_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Mark Cust CD",
      field: "WTM_MARK_CUST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "number" : true,
      validator: "integer",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Order Edge",
      field: "WTM_ORD_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : false,
      editorParams: {
        maxLength: 1,
        elementAttributes: {
          maxlength: "1",
        },
      },
      validator: "string|max:1",
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Width Tolerance",
      field: "WTM_WIDTH_TOL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "number" : false,
      validator: "numeric",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },
    {
      title: "Created By",
      field: "WTM_CRT_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Created On",
      field: "WTM_CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Updated By",
      field: "WTM_UPD_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Updated On",
      field: "WTM_UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
  ];

  React.useEffect(() => {
    if (widthTolTableData?.length > 0) {
      setWidthTolTable(
        new Tabulator("#widthTable", {
          data: widthTolTableData,
          columns: widthTolCol,
          height: 300,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
          selectable: 1,
        })
      );
    } else {
      setWidthTolTable(null);
    }
  }, [widthTolTableData]);

  const AddWidthTol = () => {
    setIsEditable(true);
    const dateSys = formatDate(new Date());
    let arr = [...widthTolTableData];

    arr.unshift({
      WTM_CD_EPA: selectedCode,
      WTM_MARK_CUST_CD: "",
      WTM_ORD_EDGE: "",
      WTM_WIDTH_TOL: "",
      WTM_CRT_BY: user,
      WTM_CRT_DT: dateSys,
      ls_flag: "I",
    });
    setWidthTolTableData(arr);
  };

  const saveWidthTol = () => {
    setIsEditable(true);
    if (widthTolTableData.length === 0) {
      alertify.error("No data to insert");
      return;
    }
    const selectedRows = widthTolTable.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    for (let i = 0; i < selectedRows?.length; i++) {
      let selectedData = selectedRows[i]?.getData();

      let markCustCd = selectedData?.WTM_MARK_CUST_CD;
      let ordEdge = selectedData?.WTM_ORD_EDGE;
      let widthTol = selectedData?.WTM_WIDTH_TOL;

      if (markCustCd === null || markCustCd === undefined) {
        alertify.error("Mark Cust Cd is Mandatory!");
        return;
      }
      if (ordEdge === null || ordEdge === undefined) {
        alertify.error("Order Edge is Mandatory!");
        return;
      }
      if (widthTol === null || widthTol === undefined) {
        alertify.error("Width Tolerance is Mandatory!");
        return;
      }
    }
    const selectedData = widthTolTable.getSelectedRows()?.map((row: any) => {
      let varData: any = {};
      varData["ls_cd_epa"] = row._row.data.WTM_CD_EPA;
      varData["ls_mark_cust"] = row._row.data.WTM_MARK_CUST_CD;
      varData["ls_crt_id"] = user;
      varData["ls_ord_edge"] = row._row.data.WTM_ORD_EDGE;
      varData["ls_width_tol"] = row._row.data.WTM_WIDTH_TOL;
      varData["ls_flag"] = row._row.data.ls_flag ? row._row.data.ls_flag : "U";
      varData["lb_status"] = "WIDTH";
      return varData;
    });

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "U") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const deleteWidthTol = () => {
    if (widthTolTableData.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = widthTolTable.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = widthTolTable.getSelectedRows()?.map((row: any) => {
      if (value === 2) {
        setLoading(true);
        let varData: any = {};
        varData["ls_cd_epa"] = row._row.data.WTM_CD_EPA;
        varData["ls_mark_cust"] = row._row.data.WTM_MARK_CUST_CD;
        varData["ls_crt_id"] = user;
        varData["ls_ord_edge"] = row._row.data.WTM_ORD_EDGE;
        varData["ls_width_tol"] = row._row.data.WTM_WIDTH_TOL;
        varData["ls_flag"] = "D";
        varData["lb_status"] = "WIDTH";
        return varData;
      }
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0003ProcedureApi(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
            alertify.success(res?.data?.outBinds?.ls_out_flag);
            fetchData(value);
          } else if (res?.data?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
            alertify.error(res?.data?.outBinds?.ls_out_flag);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcelWidthTol = () => {
    if (widthTolTableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    const fileName = "SPC0003_" + "Width_Tolerance_Data" + ".xlsx";

    // Process the data to replace null values with empty strings
    const cleanedData = widthTolTableData.map((row: any) => {
      const newRow = { ...row };
      Object.keys(newRow).forEach((key) => {
        if (newRow[key] === null) {
          newRow[key] = "";
        }
      });
      return newRow;
    });

    // Set the processed data to the table before download
    widthTolTable.setData(cleanedData).then(() => {
      widthTolTable.download("xlsx", fileName, {
        sheetName: "Sheet1",
      });

      // Restore original data after download
      widthTolTable.setData(widthTolTableData);
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={10}>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <SelectInput
                        label="Plant*"
                        data={plantCodeData}
                        id={"id"}
                        value={selectedCode}
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedCode(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <ButtonElement onClick={() => fetchData(value)}>
                        Search
                      </ButtonElement>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <>
                  <Tooltip title="Add">
                    <IconButton
                      onClick={() => {
                        value === 0
                          ? Addpkg()
                          : value === 1
                          ? Addoil()
                          : AddWidthTol();
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <LibraryAddIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Save">
                    <IconButton
                      onClick={() => {
                        value === 1
                          ? SaveOil()
                          : value === 0
                          ? SavePackingCd("insert")
                          : saveWidthTol();
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <SaveIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton
                      onClick={() => {
                        value === 0
                          ? deletePacking()
                          : value === 1
                          ? deleteOiling()
                          : deleteWidthTol();
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <DeleteIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Download">
                    <IconButton
                      onClick={() => {
                        value === 0
                          ? downloadExcelpkg()
                          : value === 1
                          ? downloadExceloil()
                          : downloadExcelWidthTol();
                      }}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Packing Code" />
                    <Tab label="Oiling Code" />
                    <Tab label="Width Tolerance" />
                  </Tabs>
                </Box>
                {value === 0 && pkgTableData?.length > 0 && (
                  <div id="table"></div>
                )}
                {value === 1 && tableDataoil?.length > 0 && (
                  <div id="table"></div>
                )}
                {value === 2 && widthTolTableData?.length > 0 && (
                  <div id="widthTable"></div>
                )}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
