// const SPC0001Query = require("../repository/SPC0001Query");
import { getInvData, getInvMonData } from "../repository/SPC0001Query";

export default class SPC0001Model {
  getInvData(data: any) {
    return getInvData(data);
  }
  getInvMonData(data: any) {
    return getInvMonData(data);
  }
}
