export interface csTheme {
    breakpoints: object,
    components: object,
    custom: {
        fonts: {
            small: string,
        }
    },
    direction: object,
    mixins: object,
    palette: {
        mode: string,
        primary: {
            main: string,
            contrastText: string,
        },
        secondary: {
            main: string,
            contrastText: string,
        },
        divider: string,
        background: {
            default: string,
            paper: string,
        },
        text: {
            primary: string,
            primaryRev?: string,
            secondary: string,
            error?: string,
        },
    },
    shadows: object,
    shape: object,
    spacing: object,
    transitions: object,
    typography: object,
    unstable_sx: object,
    unstable_sxConfig: object,
    zIndex: object
}

export interface Theme {
    children?: string | JSX.Element | JSX.Element[],
    theme?: csTheme
}