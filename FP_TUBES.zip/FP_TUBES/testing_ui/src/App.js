import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { BarElement, Chart, registerables } from "chart.js";
import "./index.css";
import kiwiImg from "./upload/kiwi.png";

Chart.register(...registerables);

// Defect type configuration for 6 classes
const DEFECT_TYPES = {
  HIGH_TEMPERATURE_SCALE: {
    name: "RM-HIGH TEMPERATURE SCALE",
    description: "Network of fine cracks on the surface",
    severity: "High",
    color: "#e74c3c",
    icon: "🕸️",
    action: "Requires surface treatment to prevent propagation",
  },
  STICKY_SCALE: {
    name: "RM-STICKY SCALE",
    description: "Non-metallic materials trapped in steel",
    severity: "Critical",
    color: "#9b59b6",
    icon: "🔘",
    action: "May require material replacement if severe",
  },
  PICKLING_PATCH_BLACKBROWN: {
    name: "RM-PICKLING PATCH (BLACKBROWN)",
    description: "Irregular surface discolorations",
    severity: "Moderate",
    color: "#f39c12",
    icon: "🟡",
    action: "Inspect for underlying corrosion",
  },
  BANDED_SCALE_PITTING_MARK: {
    name: "RM-BANDED SCALE  PITTING MARK",
    description: "Small holes or cavities on the surface",
    severity: "High",
    color: "#e67e22",
    icon: "🕳️",
    action: "Clean and apply protective coating",
  },
  ROLLED_IN_SCALE: {
    name: "RM-R.I.S. (Rolled In Scale)",
    description: "Oxide scale pressed into surface during rolling",
    severity: "Moderate",
    color: "#3498db",
    icon: "⚙️",
    action: "Surface grinding may be required",
  },
  SCRATCHES: {
    name: "RM-SCRATCHES",
    description: "Linear surface marks from mechanical damage",
    severity: "Low",
    color: "#2ecc71",
    icon: "➖",
    action: "Can often be polished out",
  },
  Not_RECOGNIZED: {
    name: "Not_RECOGNIZED",
    description: "Please Upload the different image!",
    severity: "Low",
    color: "#2ecc71",
    icon: "❓",
    action: "New Upload!",
  },
};

const SEVERITY_LEVELS = {
  Critical: { color: "#e74c3c", icon: "❗" },
  High: { color: "#f39c12", icon: "⚠️" },
  Moderate: { color: "#f1c40f", icon: "ℹ️" },
  Low: { color: "#2ecc71", icon: "✓" },
};

function App(props) {
  const [image, setImage] = useState(null);
  const [predictions, setPredictions] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [expandedDefect, setExpandedDefect] = useState(null);
  const [AIResp, setAIResp] = useState("");
  const [AISelectedResp, setAISelectedResp] = useState([]);

  const onDrop = useCallback((acceptedFiles, rejectedFiles) => {
    setError(null);
    setPredictions(null);
    setUploadProgress(0);
    setExpandedDefect(null);
    setAIResp("");
    setAISelectedResp([]);

    if (rejectedFiles?.length) {
      const errorMap = {
        "file-invalid-type": "Please upload only JPG/PNG/BMP images",
        "too-many-files": "Please upload only one image at a time",
        "file-too-large": "File exceeds 5MB limit",
      };
      setError({
        message: errorMap[rejectedFiles[0].errors[0].code] || "Invalid file",
        type: "validation",
      });
      return;
    }

    const file = acceptedFiles[0];
    const reader = new FileReader();
    reader.onload = () => setImage(reader.result);
    reader.readAsDataURL(file);
    predictDefects(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/jpeg": [".jpeg", ".jpg"],
      "image/png": [".png"],
      "image/bmp": [".bmp"],
    },
    maxFiles: 1,
    maxSize: 5 * 1024 * 1024,
    multiple: false,
  });

  const predictDefects = async (file) => {
    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);
    // formData.append("annotated", 'No');

    try {
      const response = await fetch("http://localhost:5000/api/get_tube_counts/get", {
        //  const response = await fetch(
        //    "https://tsldev19.corp.tatasteel.com:8226/api/get_tube_counts/get",
        //    {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to analyze image");
      }

      const data = await response.json();
      console.log(data?.AIResp)
      // Process and enhance the prediction results
      data.all_probabilities = {
        ...data?.all_probabilities,
        Not_RECOGNIZED: 0.93,
      };

      const sortedClasses = Object.entries(data.all_probabilities)
        .sort((a, b) => b[1] - a[1])
        .map(([defectClass, probability]) => ({
          class: defectClass,
          name: DEFECT_TYPES[defectClass]?.name || defectClass,
          probability,
          description: DEFECT_TYPES[defectClass]?.description,
          severity: DEFECT_TYPES[defectClass]?.severity || "Unknown",
          color: DEFECT_TYPES[defectClass]?.color || "#95a5a6",
          action: DEFECT_TYPES[defectClass]?.action || "Inspection recommended",
          icon: DEFECT_TYPES[defectClass]?.icon || "❓",
        }));
      setAIResp(data?.AIResp);
      let arr = [
        "RM-HIGH TEMPERATURE SCALE",
        "RM-STICKY SCALE",
        "RM-PICKLING PATCH (BLACKBROWN)",
        "RM-BANDED SCALE  PITTING MARK",
        "RM-R.I.S. (Rolled In Scale)",
        "RM-SCRATCHES",
      ];

      let isAnyFound = arr?.filter((term) => data?.AIResp?.includes(term));
      setAISelectedResp(
        sortedClasses[0]?.name?.includes("RM-") &&
          !isAnyFound.includes(sortedClasses[0]?.name)
          ? isAnyFound.concat([sortedClasses[0]?.name])
          : isAnyFound
      );
      setPredictions({
        probabilities: data.all_probabilities,
        primaryDefect: sortedClasses[0],
        sortedClasses,
        classNames: data.class_names,
        confidence: data.confidence,
        timestamp: new Date().toLocaleString(),
      });
    } catch (err) {
      console.error("API Error:", err);

      const errorMessages = {
        ERR_NETWORK: {
          message:
            "Cannot connect to the server. Please check your network connection.",
          type: "connection",
        },
        ECONNABORTED: {
          message: "Request timed out. Please try again.",
          type: "timeout",
        },
      };

      const errorInfo = errorMessages[err.code] || {
        message: err.message || "Prediction failed. Please try another image.",
        type: "unknown",
      };

      setError(errorInfo);
    } finally {
      setLoading(false);
      setUploadProgress(0);
    }
  };

  const chartData = predictions && {
    labels: predictions.sortedClasses.map((item) => item.name),
    datasets: [
      {
        label: "Defect Probability",
        data: predictions.sortedClasses.map((item) => item.probability),
        backgroundColor: predictions.sortedClasses.map((item) => item.color),
        borderColor: predictions.sortedClasses.map((item) =>
          item.probability > 0.5 ? "rgba(0, 0, 0, 0.8)" : "rgba(0, 0, 0, 0.2)"
        ),
        borderWidth: 1,
        hoverBorderWidth: 2,
      },
    ],
  };

  const toggleDefectDetails = (defectClass) => {
    setExpandedDefect(expandedDefect === defectClass ? null : defectClass);
  };

  const resetAnalysis = () => {
    setImage(null);
    setPredictions(null);
    setError(null);
    setExpandedDefect(null);
  };

  console.log(AISelectedResp);

  return (
    <div className="app">
      <header>
        <div className="app-header">
          <img src={kiwiImg} width="100" />
          {/* <img src={kiwiImg1} width="100" /> */}
          {/* kiwi Scan */}
        </div>
      </header>

      {predictions == null && (
        <div className="upload-section">
          <div
            {...getRootProps()}
            className={`dropzone ${isDragActive ? "active" : ""}`}
          >
            <input {...getInputProps()} />
            <div className="dropzone-content">
              {isDragActive ? (
                <p className="dropzone-text">
                  Drop the steel surface image here...
                </p>
              ) : (
                <>
                  <p className="dropzone-text">
                    Drag & drop a steel surface image here
                  </p>
                  <p className="dropzone-subtext">
                    Supports JPG, PNG, BMP (max 5MB)
                  </p>
                  <button className="browse-btn">
                    Or click to browse files
                  </button>
                </>
              )}
            </div>
          </div>

          {error && (
            <div className={`error ${error.type}`}>
              <span className="error-icon">
                {error.type === "connection"
                  ? "🔌"
                  : error.type === "validation"
                  ? "📁"
                  : "⚠️"}
              </span>
              <div className="error-content">
                <h4>{error.message}</h4>
                <button onClick={() => setError(null)} className="retry-btn">
                  Try Again
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {loading && (
        <div className="loading-overlay">
          <div className="loading-content">
            <div className="spinner"></div>
            <h3>Analyzing Surface Defects</h3>
            <p>Processing your image with our AI model...</p>
            {uploadProgress > 0 && (
              <div className="progress-container">
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
                <span className="progress-text">
                  {uploadProgress}% uploaded
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {image && (
        <div className="results-container">
          <div className="image-section">
            <div className="section-header">
              <h2>Surface Analysis</h2>
              <button onClick={resetAnalysis} className="reset-btn">
                Analyze New Image
              </button>
            </div>
            <div className="image-preview">
              <img src={image} alt="Uploaded steel surface for analysis" />
            </div>
          </div>

          {predictions && (
            <>
              <div className="primary-defect-section">
                <div className="recommended-action">
                  <h4>Defect Analysis Summary:</h4>
                  {AIResp?.replaceAll("**", "")
                    ?.split("\n")
                    ?.map((x) => (
                      <p>{x}</p>
                    ))}
                </div>
                <h2 style={{ marginTop: "30px", marginBottom: "20px" }}>
                  Expected Defect:
                </h2>
                <div className="severity-alert">
                  <div
                    className="severity-icon"
                    style={{ backgroundColor: predictions.primaryDefect.color }}
                  >
                    {predictions.primaryDefect.icon}
                  </div>
                  <div className="severity-content" style={{ display: "flex" }}>
                    <h3>
                      {AISelectedResp?.map((x, i) => (
                        <span
                          onClick={props?.onSelect}
                          style={{ cursor: "pointer" }}
                        >
                          {x} {i + 1 < AISelectedResp?.length ? "    /   " : ""}
                        </span>
                      ))}
                    </h3>
                    <div className="confidence-meter">
                      <div className="meter-labels">
                        <span>Confidence:</span>
                        <span>
                          {(
                            predictions.primaryDefect.probability * 100
                          ).toFixed(1)}
                          %
                        </span>
                      </div>
                      <div className="meter-bar">
                        <div
                          className="meter-fill"
                          style={{
                            width: `${
                              predictions.primaryDefect.probability * 100
                            }%`,
                            backgroundColor: predictions.primaryDefect.color,
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* <div className="recommended-action">
                  <h4>detail :</h4>
                  <p>{AIResp}</p>
                </div> */}
              </div>

              {/* <div className="chart-section">
                <h3>Defect Probability Distribution</h3>
                <div className="chart-container">
                  <BarElement
                    data={chartData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        y: {
                          beginAtZero: true,
                          max: 1,
                          title: { 
                            display: true, 
                            text: 'Probability',
                            font: { weight: 'bold' }
                          },
                          ticks: {
                            callback: value => `${(value * 100).toFixed(0)}%`
                          }
                        },
                        x: {
                          title: { 
                            display: true, 
                            text: 'Defect Types',
                            font: { weight: 'bold' }
                          }
                        }
                      },
                      plugins: {
                        tooltip: {
                          callbacks: {
                            label: context => `${context.dataset.label}: ${(context.raw * 100).toFixed(1)}%`,
                            afterLabel: context => {
                              const defect = predictions.sortedClasses[context.dataIndex];
                              return [
                                `Severity: ${defect.severity}`,
                                `Description: ${defect.description}`
                              ];
                            }
                          }
                        },
                        legend: { display: false }
                      }
                    }}
                  />
                </div>
              </div> */}

              <div className="detailed-analysis">
                <h3>Detailed Defect Analysis</h3>
                <div className="defects-grid">
                  {predictions.sortedClasses.map((defect) => (
                    <div 
                      key={defect.class} 
                      className={`defect-card ${expandedDefect === defect.class ? 'expanded' : ''}`}
                      onClick={() => toggleDefectDetails(defect.class)}
                    >
                      <div className="defect-header">
                        <div className="defect-icon" style={{ backgroundColor: defect.color }}>
                          {defect.icon}
                        </div>
                        <div className="defect-title">
                          <h4>{defect.name}</h4>
                          <span className={`severity-badge ${defect.severity.toLowerCase()}`}>
                            {defect.severity}
                          </span>
                        </div>
                        <div className="defect-confidence">
                          <span>{(defect.probability * 100).toFixed(1)}%</span>
                        </div>
                      </div>

                      <div className="defect-progress">
                        <div 
                          className="progress-fill" 
                          style={{ 
                            width: `${defect.probability * 100}%`,
                            backgroundColor: defect.color
                          }}
                        ></div>
                      </div>

                      {expandedDefect === defect.class && (
                        <div className="defect-details">
                          <div className="detail-row">
                            <span className="detail-label">Description:</span>
                            <p>{defect.description}</p>
                          </div>
                          <div className="detail-row">
                            <span className="detail-label">Recommended Action:</span>
                            <p>{defect.action}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="analysis-meta">
                <p>Analysis performed on: {predictions.timestamp}</p>
                <p className="disclaimer">
                  Note: This analysis is provided for informational purposes
                  only. For critical applications, consult with a materials
                  engineer.
                </p>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
