import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const upcomingpageCode04 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT
          TYR_CD_EPA,
          TYR_APP_GRP,
          TYR_PNO,
          TYR_NAME,
          TYR_EMAIL,
          TYR_TELNO,
          TYR_CRT_ID,
          TO_CHAR(TYR_CRT_DT, 'YYYY-MM-DD') TYR_CRT_DT,
          TYR_UPD_ID,
          TO_CHAR(TYR_UPD_DT, 'YYYY-MM-DD') TYR_UPD_DT,
          TYR_ACT_STATUS,
          TYR_MARK_CUST
        FROM
        v_yield_approver_mast
          WHERE TYR_CD_EPA = :code `;

    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const upcomingpage_02_Code04 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 1,
    };
    let sql = `SELECT
          EYM_CD_EPA,
          EYM_CATEGORY,
          EYM_CAT_TYPE,
          EYM_YIELD,
          EYM_NO_MATNR,
          EYM_MATNR_CODE,
          EYM_PRC_SEQ,
          EYM_PROCESS,
          EYM_OD_FROM,
          EYM_OD_TO,
          EYM_SEC3_FROM,
          EYM_SEC3_TO,
          EYM_IDIA,
          EYM_REMARK,
          EYM_PROD,
          EYM_TDC_REM,
          EYM_GRADE,
          EYM_QLTY
        FROM
          v_yield_master
          WHERE  EYM_CD_EPA = :code`;

    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
