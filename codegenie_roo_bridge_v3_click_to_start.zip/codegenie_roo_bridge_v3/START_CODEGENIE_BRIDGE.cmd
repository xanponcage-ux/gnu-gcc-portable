@echo off
setlocal
cd /d "%~dp0"

call "%~dp0BRIDGE_CREDENTIALS.cmd"

if "%CODEGENIE_ADID%"=="" goto :badcreds
if "%CODEGENIE_APIKEY%"=="" goto :badcreds
if /I "%CODEGENIE_ADID%"=="YOUR_ADID" goto :badcreds
if /I "%CODEGENIE_APIKEY%"=="YOUR_CODEGENIE_API_KEY" goto :badcreds

if "%PY%"=="" set "PY=C:\CompanyGenAIBridge\.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo.
  echo ERROR: Python was not found here:
  echo %PY%
  echo.
  echo Edit PY in BRIDGE_CREDENTIALS.cmd if your venv is elsewhere.
  pause
  exit /b 1
)

"%PY%" "%~dp0launcher.py"
if errorlevel 1 (
  echo.
  echo Bridge/launcher exited with an error.
  pause
)
exit /b

:badcreds
echo.
echo FIRST-TIME SETUP REQUIRED
echo -------------------------
echo Open BRIDGE_CREDENTIALS.cmd in Notepad and enter your:
echo   CODEGENIE_ADID
echo   CODEGENIE_APIKEY
echo Then double-click START_CODEGENIE_BRIDGE.cmd again.
echo.
pause
