import { Request, Response } from "express";
import SCO006Model from "../models/SCO006Model";
import { ResponceData } from "../utils";

export const SCO006Api = async (req: Request, res: Response) => {
  try {
    // console.log("hi Controller", req.body);
    const result1 = await SCO006Model.prototype.SCO006Model(req.body);
    if (
      req.body?.route === "procedureCall" &&
      result1?.outBinds?.ls_out_flag[0] === "N"
    ) {
      console.log("falied", result1);
      return res.status(200).json(result1);
    }
    console.log("Next Step");
    if (
      req.body?.route === "procedureCall" &&
      (req.body?.data?.p_radio_value === 8 ||
        req.body?.data?.p_radio_value === 9)
    ) {
      console.log("Entered-");
      for (let i in req.body?.data?.reasonData) {
        let reasonValues = ["", ""];
        reasonValues = req.body?.data?.reasonData[i]?.Column2.split("-");
        let varData = {
          route: "saveData",
          p_plant: req.body?.data?.p_plant,
          p_batch: req.body?.data?.p_batch,
          p_curr_proc: req.body?.data?.p_curr_proc,
          p_rsn_cd: reasonValues[0],
          p_rsn_cat: req.body?.data?.reasonData[i]?.Column1,
          p_rsn_desc: reasonValues[1],
          p_scr_qty: req.body?.data?.reasonData[i]?.Column4,
          ln_rsn: req.body?.data?.P_RADIO_VALUE === 8 ? "B" : "A",
        };
        console.log("test", varData);
        console.log(await SCO006Model.prototype.SCO006Model(varData));
      }
    }
    // console.log("Final result", result1);
    return res.status(200).json(result1);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
