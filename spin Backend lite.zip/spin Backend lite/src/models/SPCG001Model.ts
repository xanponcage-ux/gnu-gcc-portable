// const SPCG001Query = require("../repository/SPCG001Query");
import * as repo from "../repository/SPCG001Query";

export default class SPCG001Model {
  getData01(data: any) {
    return repo.getData01(data);
  }
  getData02(data: any) {
    return repo.getData02(data);
  }
  getData03(data: any) {
    return repo.getData03(data);
  }
  getData04(data: any) {
    return repo.getData04(data);
  }
  getStatusCodeData01() {
    return repo.getStatusCodeData01();
  }
  getInvoiceData01() {
    return repo.getInvoiceData01();
  }
  getMaterialData01() {
    return repo.getMaterialData01();
  }
  getProdData01() {
    return repo.getProdData01();
  }
  getQltyData01() {
    return repo.getQltyData01();
  }
  getTdcData01() {
    return repo.getTdcData01();
  }
  saveTableData(batchId: any, yard: any) {
    return repo.saveTableData(batchId, yard);
  }
  tabAccess() {
    return repo.tabAccess();
  }
  getYardValue() {
    return repo.getYardValue();
  }
  deleteCoil(batchId: any, plantCd: any) {
    return repo.deleteCoil(batchId, plantCd);
  }
}
