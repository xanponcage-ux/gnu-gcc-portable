/* ------------------------ SCRAP POSTING INSIDE OPERATION -----------------------------------------------------
Chnaged on - 22.07.26,
Purpose    - Checkbox disabled for rows where scrap has already been sent to SAP.
------------------------------------------------------------------------------------------------------------*/

import React, { useState } from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Auth from "../../../components/layout/dashboardLayout/auth";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization } from "../../../utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import { SCO0006Action } from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, PopupObj } from "./type";
import { setTheme, useMaterialUIController } from "../../../context";

const O_SCO0006 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [scheduleDetailsData, setScheduleDetailsData] = React.useState([]);
  const [restricted, setRestricted] = React.useState(null);
  //---popup design 2---
  //const [isPopUp, setIsPopUp] = React.useState<any>({type: null,data: ""});
  //-------------------------------------------------
  // const [qltyPop, setQltyPop] = React.useState<string>("");
  // const [tdcPop, setTdcPop] = React.useState<any>("");
  // const [popUpTable1Data, setPopUpTable1Data] = React.useState<Array<any>>([]);
  // const [popUpTable1, setPopUpTable1] = React.useState<any>();
  // const [popUpTable2Data, setPopUpTable2Data] = React.useState<Array<any>>([]);
  // const [popUpTable2, setPopUpTable2] = React.useState<any>();
  const [secondTdcLook, setSecondTdcTableLook] = React.useState<any>({
    popUp: false,
    data: [],
  });
  // -------This page data -----------------

  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [coilId, setCoilId] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [secondTdcTableData, setSecondTdcTableData] = React.useState<any>([]);
  const [secondTdcTable, setSecondTdcTable] = React.useState<any>();
  const [tdcOptions, setTdcOptions] = React.useState<any>([]);
  const [alertPopup, setAlertPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });

  const [actlProc, setActlProc] = React.useState<string>("");

  //POP UP for Remarks
  const [remarksPopUp, setRemarksPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });
  const [remarksTable, setRemarksTable] = React.useState<any>(null);
  const [remarksTableData, setRemarksTableData] = React.useState<any>([]);
  const [selectDesable, setSelectDesable] = React.useState<any>(true);
  const [selectDesableTotal, setSelectDesableTotal] = React.useState<any>(0);

  // POP UP FOR REMARKS AGAINST HOLD COL
  const [holdNoPopUp, setHoldNoPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });
  const [scrapTable, setScrapTable] = React.useState<any>(null);
  const [scrapDataTableData, setScrapDataTableData] = React.useState<any>([]);
  const [categoryTableData, setCategoryTableData] = React.useState<any>([]);
  const [matirialTableData, setmatirialCDTableData] = React.useState<any>([]);
  //Added for selected rsn cat

  // // const [selectedRsnCat, setSelectedRsnCat] = useState("");
  // const [rsnCode, setRsnCode] = React.useState<Array<SelectType>>([]);
  // const [selectedRsnCode, setSelectedRsnCode] = React.useState<string>("");

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCO0006Action(token, {
        route: "SCO006getfetchData",
        Plant: selectedCode,
        CoilId: coilId,
        BatchId: batchId,
        Status: selectedStatus,
        User: user,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            //console.log(res?.data);
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.PlanCode?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              //fetchEpaData(varData[0].value);

              const varstatusData: Array<SelectType> = [];
              res?.data?.Status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_VALUE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
            } else {
              //plant cHANGE
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      let varData = new Tabulator("#table", {
        data: tableData,
        columns: column,
        height: 350,
        // selectableRows: 1,
        layout: "fitData",
        selectable: 1,
      });
      setTable(varData);
    } else {
      setTable(null);
    }
  }, [tableData, tdcOptions]);

  const column: Array<any> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      //frozen: true,
      headerSort: false,
      title: "",
    },
    // {
    //   rowHandle: true,
    //   formatter: "handle",
    //   headerSort: false,
    //   width: 30,
    //   minWidth: 30,
    //   maxWidth:60
    // },
    {
      field: "id",
      title: "id",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },

    {
      field: "EBS_FIRST_PAR",
      title: "Mother Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      cellClick: async function (e: any, cell: any) {
        const [updatedEndCut, updatedPupCoil, updatedSideTrim]: any =
          await getScrapData(cell._cell.row.data.EBS_FIRST_PAR);

        const id = {
          id: cell._cell.row.data.id,
          batch: cell._cell.row.data.EBS_FIRST_PAR,
          scrap: cell._cell.row.data.SCRAP,
          process: cell._cell.row.data.PROCESS,
          first_par: cell._cell.row.data?.EBS_FIRST_PAR,
          residual: cell._cell.row.data?.residual,
          endCut: updatedEndCut ? updatedEndCut?.toFixed(3) : "",
          pupCoil: updatedPupCoil ? updatedPupCoil?.toFixed(3) : "",
          sideTrim: updatedSideTrim ? updatedSideTrim?.toFixed(3) : "",
        };
        if (Number(cell._cell.row.data?.residual) < 0) {
          alertify.error("Residual weight is nagative!");
        } else {
          SCO0006ActionApiCall(
            { FIRST_PAR: cell._cell.row.data?.EBS_FIRST_PAR },
            { plant: cell._cell.row.data?.EBS_CD_EPA }
          );
          setSelectDesableTotal(0);
          setHoldNoPopUp({ popUp: true, data: id });
        }
      },
    },
    {
      field: "FG",
      title: "FG (Ton)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return Number(value)?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "SCRAP",
      title: "Scrap Wt.(Ton)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "FGSCRAP",
      title: "FG + Scrap (Ton)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "INP_MASS",
      title: "Input Wt.(Ton)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "residual", //!=0>red
      title: "Residual (Ton)",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (Number(value?.toFixed(3)) < 0) {
          cell.getElement().style["background-color"] = "red";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    // {
    //   field: "SCRAP_MATERIAL",
    //   title: "Scrap Material",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   formatter: (cell: any) => {
    //     var value = cell.getValue();
    //     cell.getElement().style["background-color"] = "#748da6";
    //     cell.getElement().style["color"] = "#FFFFFF";
    //     return value;
    //   },
    // },
    {
      field: "RM_MATNR",
      title: "RM Matnr",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      field: "RM_TDC",
      title: "RM TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "RM_THK",
      title: "RM THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "RM Width",
      field: "RM_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "EBS_CD_EPA",
      title: "Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      field: "PROCESS",
      title: "Process",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    // {
    //   formatter: () => {
    //     return "<i class='fa-solid fa-square' style='color:#49a3f1'></i>";
    //   },
    //   width: 40,
    //   cellClick: function (e: any, cell: any) {
    //     const id = cell._cell.row.data.id;
    //     SCO0006ActionApiCall({ FIRST_PAR: cell._cell.row.data?.EBS_FIRST_PAR });
    //     setHoldNoPopUp({ popUp: true, data: id });
    //   },
    // },
  ];

  const fetchData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCO0006Action(token, {
        route: "SCO0006getBatchInformation",
        plant: selectedCode,
        coilId: coilId,
        batch: batchId,
        status: selectedStatus,
        User: user,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: any = [];
            if (res?.data?.length > 0) {
              res?.data?.map((row: any, item: any) => {
                //Added - Correct -0 value in residual col
                let inpMass = Number(row?.INP_MASS?.toFixed(3));
                let fg = Number(row?.FG?.toFixed(3));
                let scrap = Number(row?.SCRAP?.toFixed(3));
                let sum = fg + scrap;
                let fgScSum = Number(sum.toFixed(3));

                let resWt = inpMass - fgScSum;

                varData.push({
                  ...row,
                  residual: resWt,
                  // Number(row.INP_MASS?.toFixed(3)) -
                  // (Number(row.FG?.toFixed(3)) +
                  //   Number(row.SCRAP?.toFixed(3))),
                  FGSCRAP: fgScSum,
                  // Number(row.FG?.toFixed(3)) + Number(row.SCRAP?.toFixed(3)),
                });
              });
              setTableData(varData);
            } else {
              alertify.success("No records found");
              setTableData([]);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setCoilId("");
    setSelectedStatus("");
    setBatchId("");
    setSelectedCode("");
    setTableData([]);
    setSecondTdcTableData([]);
    setSecondTdcTableLook({ popUp: false, data: [] });
  };

  const SCO0006ActionApiCall = async (
    type?: any,
    inputObj1?: any,
    inputObj2?: any
  ) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCO0006Action(token, {
        route: "getPopupData",
        type: { ...type, ...inputObj1 },
        ...inputObj1,
        ...inputObj2,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            var varData = res.data?.data;
            varData.push({ new: true });
            varData.push({ new: true });
            setScrapDataTableData(varData);
            setCategoryTableData(res.data?.category);
            setmatirialCDTableData(res.data?.matirialCD);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    let secondTdcDesicionColumn: any = [
      {
        formatter: "rowSelection",
        hozAlign: "center",
        download: false,
        //frozen: true,
        headerSort: false,
        title: "",
      },

      {
        field: "Column1",
        title: "Reason Category",
        headerFilter: "input",
        headerFilterPlaceholder: "search...",
        width: 450,
        editor: "list",
        cellEdited: function (cell: {
          getValue: () => any;
          getRow: () => any;
        }) {
          const value = cell.getValue();
          const row = cell.getRow();

          GetAuthorization().then((token: TokenType) => {
            SCO0006Action(token, {
              route: "getRsnCodeData",
              rsnCat: value,
            }).then((res) => {
              if (res.data?.length === 0) {
                alertify.error("No reason codes");
                return;
              }

              const reasonCodes = res?.data?.REASON_DESP.map(
                (row: { ESR_RSN_CD: string; ESR_RSN_DESC: string }) => {
                  return row.ESR_RSN_CD + " - " + row.ESR_RSN_DESC;
                }
              );

              row.update({
                Column2EditorParams: { values: reasonCodes },
              });
            });
          });
        },
        formatter: (cell: any) => {
          var value = cell.getValue();
          // cell.getElement().style["background-color"] = "#748da6";
          // cell.getElement().style["color"] = "#FFFFFF";

          return value;
        },
        editorParams: {
          values: [],
        },
      },
      {
        field: "Column2",
        title: "Reason Code",
        headerFilter: "input",
        headerFilterPlaceholder: "search...",
        width: 450,
        editor: "list",
        formatter: (cell: any) => {
          // var value = cell.getValue();
          // console.log("->", cell._cell.row.data?.Column1);
          // console.log("col2: ", value);
          // cell.getElement().style["background-color"] = "#748da6";
          // cell.getElement().style["color"] = "#FFFFFF";
          // console.log("Rsn Code: ", value);

          // if (cell._cell.row.data?.Column1 !== "") return value;
          return cell.getValue();
        },
        editorParams: function (cell: {
          getRow: () => {
            (): any;
            new (): any;
            getData: {
              (): { (): any; new (): any; Column2EditorParams: any };
              new (): any;
            };
          };
        }) {
          // values: [],
          return cell.getRow().getData().Column2EditorParams || { values: [] };
        },
      },

      {
        field: "Column4",
        title: "Tonnage",
        width: 400,
        headerFilter: "input",
        headerFilterPlaceholder: "search...",
        formatter: (cell: any) => {
          var value = cell.getValue();
          // cell.getElement().style["background-color"] = "#748da6";
          // cell.getElement().style["color"] = "#FFFFFF";
          return value;
        },
        bottomCalc: "sum",
        //editor: "input",
        editor: function (
          cell: any,
          onRendered: any,
          success: any,
          cancel: any,
          editorParams: any
        ) {
          //console.log(cell.getData().Column1)
          if (!cell.getData().Column1) {
            alertify.error("Please Select Reason Category");
            return;
          }
          if (!cell.getData().Column2) {
            alertify.error("Please Select Reason Code");
            return;
          }

          var editor = document.createElement("input");
          //create and style input
          editor.style.padding = "3px";
          editor.style.width = "100%";
          editor.style.boxSizing = "border-box";
          editor.value = cell.getValue() ? cell.getValue() : 0;
          editor.type = "number";

          onRendered(function () {
            editor.focus();
          });

          //when the value has been set, trigger the cell to update
          function successFunc() {
            let row = cell.getRow();
            success(editor.value);
          }

          editor.addEventListener("change", successFunc);
          editor.addEventListener("blur", successFunc);

          return editor;
        },
      },
    ];
    if (secondTdcTableData?.length > 0) {
      const colFunction = async () => {
        try {
          setLoading(true);
          const token = await GetAuthorization();
          let varParam = {
            route: "getPopupData",
            type: "Seconds Tdc Reason Data",
          };
          const res = await SCO0006Action(token, varParam);
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            secondTdcDesicionColumn[1].editorParams.values =
              res?.data?.REASON_CATEGORY.map((row: any) => {
                // console.log("Reason cat: ", row.ESR_RSN_CAT);
                return row.ESR_RSN_CAT;
              });
            // secondTdcDesicionColumn[2].editorParams.values =
            //   res?.data?.REASON_DESP.map((row: any) => {
            //     return row.ESR_RSN_CD + " - " + row.ESR_RSN_DESC;
            //   });
            //console.log(res?.data)
          }
        } catch (error) {
          console.log(error);
          alertify.error(error, "Something went Wrong");
        } finally {
          setLoading(false);
        }
      };
      colFunction();
    }
    //console.log(secondTdcDesicionColumn);
    if (secondTdcTableData?.length > 0) {
      setSecondTdcTable(
        new Tabulator("#table6", {
          data: secondTdcTableData,
          columns: secondTdcDesicionColumn,
          height: 237,
          //movableRows: true,
          layout: "fitDataFill",
        })
      );
    }
  }, [secondTdcTableData]);

  const remarksCol: any = [
    {
      title: "Remarks",
      field: "CD_DESC",
      cellClick: function (e: any, cell: any) {
        {
          handleClose(cell);
        }
      },
    },
  ];

  React.useEffect(() => {
    if (remarksTableData.length > 0) {
      setRemarksTable(
        new Tabulator("#remarksTable", {
          height: "100%",
          data: remarksTableData,
          columns: remarksCol,
        })
      );
    } else {
      setRemarksTable(null);
    }
  }, [remarksTableData]);

  const handleClose = (cell: any) => {
    const rowId = remarksPopUp?.data;
    table?.updateRow(rowId, {
      REMARKS_FIELD: cell._cell?.row?.data?.CD_DESC,
    });
    setRemarksPopUp({ popUp: false, data: "" });
  };

  const scrapCol: any = [
    {
      // formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      //frozen: true,
      headerSort: false,
      title: "",
      formatter: function (cell: any) {
        var value = cell.getData().EBS_REC_STATUS;
        if (value === "Y") {
          return "";
        } else {
          return "<input type='checkbox'>";
        }
      },
      cellClick: function (e: any, cell: any) {
        const row = cell.getRow();
        const checkbox = cell
          .getElement()
          .querySelector("input[type='checkbox']");
        if (checkbox && checkbox.checked) {
          row.toggleSelect();
        }
      },
    },
    {
      title: "Reason Category",
      field: "ESR_RSN_CAT",
      editor: function (
        cell: any,
        onRendered: (arg0: () => void) => void,
        success: (arg0: any) => void,
        cancel: any,
        editorParams: any
      ) {
        var form = document.createElement("span");
        var formElement: any = document.createElement("select");
        formElement.style.padding = "3px";
        formElement.style.width = "100%";
        formElement.style.boxSizing = "border-box";
        let data: any = [];
        categoryTableData?.filter((x: { ESR_RSN_CAT: string | any[] }) => {
          if (x?.ESR_RSN_CAT?.length > 0 && !data.includes(x?.ESR_RSN_CAT)) {
            data.push(x?.ESR_RSN_CAT);
          }
        });
        for (var i = 0; i < data?.length; i++) {
          var option = document.createElement("option");
          option.setAttribute("value", data[i]);
          option.label = data[i];
          option.value = data[i];
          formElement.appendChild(option);
        }

        onRendered(function () {
          formElement.focus();
          // formElement?.style?.css = "100%";
        });

        function successFunc() {
          success(formElement.value);
        }

        formElement.addEventListener("change", successFunc);
        formElement.addEventListener("blur", successFunc);

        form.appendChild(formElement);
        return document.body.appendChild(form);
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    {
      title: "",
      field: "ESR_RSN_CD_BCK",
      visible: false,
      // hidden: true
    },
    {
      title: "Reason Code",
      field: "ESR_RSN_CD",
      editor: function (
        cell: {
          _cell: { row: { data: { ESR_RSN_CAT: string | any[] } } };
          getRow: () => {
            (): any;
            new (): any;
            update: { (arg0: { ESR_RSN_DESC: any }): void; new (): any };
          };
        },
        onRendered: (arg0: () => void) => void,
        success: (arg0: any) => void,
        cancel: any,
        editorParams: any
      ) {
        var form = document.createElement("span");
        var formElement: any = document.createElement("select");
        formElement.style.padding = "3px";
        formElement.style.width = "100%";
        formElement.style.boxSizing = "border-box";
        categoryTableData?.map((x: any) => {
          if (
            cell._cell.row.data.ESR_RSN_CAT?.length > 0 &&
            x?.ESR_RSN_CAT == cell._cell.row.data.ESR_RSN_CAT
          ) {
            var option = document.createElement("option");
            option.setAttribute("value", x.ESR_RSN_CD);
            option.label = x.ESR_RSN_CD + " - " + x.ESR_RSN_DESC;
            option.value = x.ESR_RSN_CD;
            formElement.appendChild(option);
          }
        });

        onRendered(function () {
          formElement.focus();
          // formElement?.style?.css = "100%";
        });

        function successFunc() {
          success(formElement.value);
          var dataVal = categoryTableData?.filter(
            (x: { ESR_RSN_CAT: any; ESR_RSN_CD: any }) => {
              return (
                cell._cell.row.data.ESR_RSN_CAT?.length > 0 &&
                x?.ESR_RSN_CAT == cell._cell.row.data.ESR_RSN_CAT &&
                x.ESR_RSN_CD == formElement.value
              );
            }
          )?.[0];
          cell.getRow().update({
            ESR_RSN_DESC: dataVal?.ESR_RSN_DESC,
          });
        }

        // formElement.addEventListener("change", successFunc);
        formElement.addEventListener("blur", successFunc);

        form.appendChild(formElement);
        return document.body.appendChild(form);
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    {
      title: "Reason Desc",
      field: "ESR_RSN_DESC",
    },
    {
      title: "Post Status",
      field: "EBS_REC_STATUS",
      visible: false,
    },
    {
      title: "Scrap Qty",
      field: "SCRAP_QTY",
      // bottomCalc: 'sum',
      editor: function (
        cell: any,
        onRendered: any,
        success: any,
        cancel: any,
        editorParams: any
      ) {
        var editor = document.createElement("input");
        //create and style input
        editor.style.padding = "3px";
        editor.style.width = "100%";
        editor.style.boxSizing = "border-box";
        editor.value = cell.getValue() ? cell.getValue() : "";
        editor.maxLength = 4; // Set maxLength here
        editor.type = "number"; // Set maxLength here
        cell?.getRow()?.deselect();
        onRendered(function () {
          editor.focus();
        });

        //when the value has been set, trigger the cell to update
        function successFunc() {
          success(editor.value);
        }

        editor.addEventListener("change", successFunc);
        editor.addEventListener("blur", successFunc);

        return editor;
      },
      formatter: function (cell: any) {
        var value = cell?.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        if (value) {
          return parseFloat(value)?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Scrap Material",
      field: "SCAP_MATERIAL",
      minWidth: 150,
      editor: function (
        cell: any,
        onRendered: (arg0: () => void) => void,
        success: (arg0: any) => void,
        cancel: any,
        editorParams: any
      ) {
        var form = document.createElement("span");
        var formElement: any = document.createElement("select");
        formElement.style.padding = "3px";
        formElement.style.width = "100%";
        formElement.style.fontSize = "10px";
        formElement.style.boxSizing = "border-box";
        for (var i = 0; i < matirialTableData?.length; i++) {
          var option = document.createElement("option");
          option.setAttribute("value", matirialTableData[i].MATNR);
          option.label = matirialTableData[i].MATNRDESC;
          option.value = matirialTableData[i].MATNR;
          formElement.appendChild(option);
        }

        onRendered(function () {
          formElement.focus();
          formElement.style.fontSize = "10px";
        });

        function successFunc() {
          success(formElement.value);
        }

        formElement.addEventListener("change", successFunc);
        formElement.addEventListener("blur", successFunc);

        form.appendChild(formElement);
        return document.body.appendChild(form);
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        // cell.getElement().style["background-color"] = "#748da6";
        // cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    {
      field: "new",
      formatter: (cell: { getValue: () => any }) => {
        var value = cell.getValue();
        if (value) {
          return `<Tooltip title="New"><i class='fa fa-exclamation-circle' style='color: green; margin: 3px 10px; font-size: 14px'></i></Tooltip>`;
        } else return "";
      },
    },
  ];

  React.useEffect(() => {
    if (scrapDataTableData.length > 0) {
      let newScrapTable = new Tabulator("#scrapTable", {
        layout: "fitColumns",
        height: "100%",
        data: scrapDataTableData,
        columns: scrapCol,
      });
      newScrapTable?.on("rowSelectionChanged", function (cell, row) {
        // handleDecision1(row);
        // row?.deselect();
        let calc = 0;
        newScrapTable?.getSelectedRows()?.map((x) => {
          //if (x?._row?.data?.SCRAP_QTY == holdNoPopUp?.data?.scrap) {
          if (!isNaN(x?._row?.data?.SCRAP_QTY)) {
            calc = calc + Number(x?._row?.data?.SCRAP_QTY);
          }
        });
        console.log(calc, holdNoPopUp?.data);
        setSelectDesableTotal(calc?.toFixed(3));
        if (
          calc?.toFixed(3) ==
          (
            Number(holdNoPopUp?.data?.scrap) +
            Number(holdNoPopUp?.data?.residual)
          )?.toFixed(3)
        ) {
          setSelectDesable(false);
        } else {
          setSelectDesable(true);
        }
      });
      // newScrapTable?.on("rowDeSelected", function (cell, row) {
      //   // handleDecision1(row);
      //   console.log(row)
      //   setSelectDesable(true);
      // });
      setScrapTable(newScrapTable);
    } else {
      setScrapTable(null);
    }
  }, [scrapDataTableData]);

  const getProcess = async (CoilId?: any) => {
    try {
      setLoading(true);
      const token = await GetAuthorization();
      const res = await SCO0006Action(token, {
        route: "getProcess",
        CoilId: CoilId,
      });

      if (res.statusText !== "" && res.statusText !== "OK") {
        alertify.error(res?.data?.err ? res.data.err : res?.toString());
      } else {
        setActlProc(res?.data[0].EBS_CD_PROCESS);
        return res?.data[0].EBS_CD_PROCESS;
      }
    } catch (error) {
      alertify.error(error, "1- Something went Wrong");
    } finally {
      setLoading(false);
    }
  };

  const getScrapData = async (CoilId?: any) => {
    try {
      setLoading(true);
      const token = await GetAuthorization();
      const res = await SCO0006Action(token, {
        route: "getScrapData",
        batchId: CoilId,
      });

      if (res.statusText !== "" && res.statusText !== "OK") {
        alertify.error(res?.data?.err ? res.data.err : res?.toString());
      } else {
        let endCutVal = res?.data[0]?.END_CUT;
        let pupCoilVal = res?.data[0]?.PUP_COIL;
        let sideTrimVal = res?.data[0]?.TRIM_LOSS;

        return [endCutVal, pupCoilVal, sideTrimVal];
      }
    } catch (error) {
      alertify.error(error, "Something went Wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveButton = async () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    const selectedRows = scrapTable.getRows();

    if (selectedRows?.length === 0) {
      alertify.error("Please select Row!");
      return;
    }

    const proc1 = await getProcess(holdNoPopUp?.data?.batch);

    let count = 0;

    const selectedData: any = [];
    selectedRows?.map((rows: any) => {
      let varData: any = {};
      if (
        rows?._row?.modules?.select?.selected &&
        !(
          rows?._row?.data?.ESR_RSN_CAT?.length > 0 &&
          rows?._row?.data?.SCRAP_QTY > 0 &&
          rows?._row?.data?.SCAP_MATERIAL?.length > 0
        )
      ) {
        console.log(rows?._row?.data);
        count = 1;
      }
      if (rows?._row?.data?.ESR_RSN_CAT?.length > 0) {
        varData["ESR_RSN_CAT"] = rows?._row?.data?.ESR_RSN_CAT;
        varData["ESR_RSN_CD_BCK"] = rows?._row?.data?.ESR_RSN_CD_BCK;
        varData["ESR_RSN_CD"] = rows?._row?.data?.ESR_RSN_CD;
        varData["ESR_RSN_DESC"] = rows?._row?.data?.ESR_RSN_DESC;
        varData["SCRAP_QTY"] = rows?._row?.data?.SCRAP_QTY;
        varData["SCAP_MATERIAL"] = rows?._row?.data?.SCAP_MATERIAL;
        varData["new"] = rows?._row?.data?.new;
        varData["isSelected"] =
          rows?._row?.modules?.select?.selected && rows?._row?.data?.new
            ? "Y1"
            : rows?._row?.modules?.select?.selected
            ? "Y"
            : "N";
        selectedData.push(varData);
      }
    });

    if (count != 0) {
      alertify.error("Please select all the fields!");
      return;
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCO0006Action(token, {
        route: "saveData",
        plant: selectedCode,
        data: selectedData,
        batch: holdNoPopUp?.data?.batch,
        // process: holdNoPopUp?.data?.process,
        process: proc1 ? proc1 : "",
        first_par: holdNoPopUp?.data?.first_par,
        scrapTot: holdNoPopUp?.data?.scrap,
        user: user,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            // alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: any = [];
            if (res?.data?.ouptput?.length > 0) {
              if (res?.data?.ouptput?.includes("Y-")) {
                alertify.success(res?.data?.ouptput);
              } else {
                alertify.error(res?.data?.ouptput);
              }
              setHoldNoPopUp({ popUp: false, data: "" });
              fetchData();
            } else {
              alertify.error("Err!");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleSaveForm = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    const selectedRows = table.getSelectedRows();

    if (selectedRows?.length === 0) {
      alertify.error("Please select Row!");
      return;
    }

    let count = 0;

    const selectedData: any = [];
    selectedRows?.map((rows: any) => {
      let varData: any = {};
      console.log(rows?._row?.data);
      if (!(rows?._row?.data?.EBS_FIRST_PAR?.length > 0)) {
        count = 1;
      }
      if (rows?._row?.data?.EBS_FIRST_PAR?.length > 0) {
        varData["batch"] = rows?._row?.data?.EBS_FIRST_PAR;
        selectedData.push(varData);
      }
    });

    if (count != 0) {
      alertify.error("Please select all the fields!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCO0006Action(token, {
        route: "saveForm",
        plant: selectedCode,
        data: selectedData,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            // alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: any = [];
            if (res?.data?.ouptput?.length > 0) {
              alertify.success(res?.data?.ouptput?.join());
              setHoldNoPopUp({ popUp: false, data: "" });
              fetchData();
            } else {
              alertify.error("Err!");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={2} sx={{ pl: 1 }}>
            {/* --------HOLD NO POP UP--------------------- */}
            {holdNoPopUp.popUp && (
              <Dialog
                open={holdNoPopUp.popUp}
                maxWidth="md"
                onClose={() => {
                  setHoldNoPopUp({ popUp: false, data: "" });
                }}
              >
                <DialogTitle>Scrap Data</DialogTitle>
                <DialogContent>
                  <Grid
                    container
                    style={{ marginTop: "5px", marginBottom: "5px" }}
                    spacing={2}
                  >
                    <Grid item xs={2}>
                      <Input
                        label="Batch"
                        value={holdNoPopUp?.data?.batch}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>
                    <Grid item xs={1.5}>
                      <Input
                        label="Actual Scrap Wt."
                        value={holdNoPopUp?.data?.scrap?.toFixed(3)}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>
                    <Grid item xs={0.5}>
                      +
                    </Grid>
                    <Grid item xs={1.5}>
                      <Input
                        label="Residual Wt."
                        value={holdNoPopUp?.data?.residual?.toFixed(3)}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>
                    <Grid item xs={0.5}>
                      =
                    </Grid>
                    <Grid item xs={1.5}>
                      <Input
                        label="Total Scrap Wt."
                        value={(
                          Number(holdNoPopUp?.data?.scrap) +
                          Number(holdNoPopUp?.data?.residual)
                        )?.toFixed(3)}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <Input
                        label="Selected Scrap Wt."
                        value={selectDesableTotal}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>
                    <Grid item xs={1}></Grid>
                    <Grid item xs={2}>
                      <Input
                        label="End Cut"
                        value={holdNoPopUp?.data?.endCut}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setEndCut(e)}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <Input
                        label="Side Trim"
                        value={holdNoPopUp?.data?.sideTrim}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setSideTrim(e)}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <Input
                        label="Pup Coil"
                        value={holdNoPopUp?.data?.pupCoil}
                        size={"small"}
                        readOnly={true}
                        onChange={(e: string) => setPupCoil(e)}
                      />
                    </Grid>
                  </Grid>
                  {loading ? <Loader /> : null}
                  {scrapDataTableData?.length > 0 ? (
                    <div id="scrapTable" />
                  ) : null}
                </DialogContent>
                <DialogActions>
                  <Button
                    onClick={() => {
                      setHoldNoPopUp({ popUp: false, data: "" });
                      table?.deselectRow();
                      setSelectDesable(true);
                    }}
                    color="secondary"
                  >
                    Close
                  </Button>
                  <Button
                    color="secondary"
                    disabled={selectDesable}
                    onClick={handleSaveButton}
                  >
                    Save
                  </Button>
                </DialogActions>
              </Dialog>
            )}

            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <Grid
                      container
                      spacing={3}
                      sx={{
                        gap: 1.5,
                      }}
                    >
                      <Grid item xs={3} sx={{ ml: 3 }}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            fetchEpaData(e);
                            setScheduleDetailsData([]);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      {/* <Grid item xs={2}>
                      <Input
                        label="Coil Id"
                        value={coilId}
                        size={"small"}
                        onChange={(e: string) => setCoilId(e)}
                      />
                    </Grid>


                    <Grid item xs={1}>
                      <SelectInput
                        label="Status"
                        data={statusData}
                        value={selectedStatus}
                        size={"small"}
                        onChange={(e: string) => setSelectedStatus(e)}
                      />
                    </Grid> */}
                      <Grid item xs={2}>
                        <Input
                          label="Batch ID"
                          value={batchId}
                          size={"small"}
                          onChange={(e: string) => setBatchId(e)}
                        />
                      </Grid>
                      <Grid item xs={1}>
                        <ButtonElement onClick={() => fetchData()}>
                          Search
                        </ButtonElement>
                      </Grid>

                      {/* <Grid item xs={1}>
                      <ButtonElement onClick={()=>{handleConfirm()}} > 
                        Confirm
                      </ButtonElement>
                    </Grid> */}
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Scrap Information"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel("Batch Information", tableData, table)
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    {/* <Grid item>
                    <Tooltip title="Save">
                      <IconButton onClick={() => handleSaveForm()}>
                        <SaveIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid> */}
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            {secondTdcLook.popUp && secondTdcTableData?.length > 0 && (
              // <Grid item xs={5.5} sx={{ ml: 40, mr: 30 }}>
              <Grid item xs={12}>
                <TableContainer
                  title={`Reason Category Details for Batch - ${secondTdcLook.data.EOM_ID_BATCH} `}
                >
                  {secondTdcTableData?.length > 0 && <div id="table6"></div>}
                </TableContainer>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default O_SCO0006;
