import { Request, Response } from "express";
import SPO0005Model from "../models/SPO0005Model";
import { ResponceData } from "../utils";
import { Console } from "console";

export const getData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0005Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getTableData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0005Model.prototype.getTableData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const callDeleteProcedure = async (req: Request, res: Response) => {
  try {
    const data = req.body.data;
    let results: any = {};

    for (let i in data) {
      let singleData = data[i];
      let result1: any = await SPO0005Model.prototype.callDeleteProcedure(
        singleData
      );
      let outBinds = result1.outBinds.ls_out_flag;

      results = outBinds;
    }

    return res.status(200).json(results);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
