import { Router } from "express";
import {
  //getData01,
  scheduleDeletion,
} from "../controllers/SPS0015Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0015Route = Router();
SPS0015Route.route("/SPS0015/scheduleDeletion").post(
  authenticationMiddleware.bearer,
  scheduleDeletion
);

export default SPS0015Route;
