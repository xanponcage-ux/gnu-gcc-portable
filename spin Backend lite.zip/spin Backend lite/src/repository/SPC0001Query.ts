import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

// hold_operator_remarks, HOLD_CODE_REASON subquery changed. -- 02.07.2026

export const getInvData = async (data: any) => {
  try {
    let binds: any = {
      plant: data?.epa,
    };
    let sql: any = `SELECT EOM_ID_BATCH BATCH_ID
      ,NVL(EOM_CD_STATUS, '') STATUS
      ,(SELECT DISTINCT CD_DESC FROM V_CODES WHERE  CD_TYPE = 'E0001' AND  CD_VALUE = EOM_CD_STATUS) STATUS_DESC
      ,(SELECT DISTINCT CD_DESC1 FROM V_CODES WHERE  CD_TYPE = 'E0001' AND  CD_VALUE = EOM_CD_STATUS) PRODUCT_FORM
      ,NVL(EOM_CD_PROD, '') PROD
      ,NVL(EOM_CD_QLTY_ACTL, '') QLTY
      --,NVL(SUBSTR(F_GET_GRADE (EOM_CD_EPA, EOM_ID_BATCH, EOM_ID_ORDER_CUS , EOM_ID_ORD_ITEM_CUS,NULL),3), '') GRADE_DESC
      ,NVL(EOM_SEC1, '') THICK
      ,NVL(EOM_SEC2, '') WIDTH
      ,NVL(EOM_LENGTH, '') LENGTH
      ,NVL(EOM_TDC_ACTL, '') ACTUAL_TDC
      ,(SELECT TMA_TDC_GRD_DESC FROM V_TDC_MAIN WHERE TMA_TDC_NO = EOM_TDC_ACTL) GRADE_DESC
      ,NVL(EOM_MS_PIECE_ACTL, '') NET_WT_PCS
      --,NVL(EOM_MS_GROSS_CAL, '') NET_WT_PCS
      ,NVL(EOM_MS_GROSS_ACTL, '') GROSS_WT_PCS
      ,NVL(EOM_MS_SCRAP, '') SCRAP_WT
      ,NVL(EOM_FL_SEND_SAP, '') SEND_TO_SAP
      ,TO_CHAR (EOM_TS_CREATION, 'DD-MM-YYYY HH24:MI:SS') AS PRODN_ARRIVAL_DATE
      ,ROUND(SYSDATE-EOM_TS_CREATION) AGE_DAYS
      ,NVL(EOM_NO_CAST, '') CAST_NO
      ,NVL(EOM_ID_PAR_COIL_NO, '') PARENT_CHARG
      ,NVL(EOM_ID_FIRST_PAR, '') MOTHER_CHARG
      ,ROUND(SYSDATE-EIC_TS_CREATION) MOTHER_CHARG_AGE
      ,NVL(C.EIC_MS_GROSS_ACTL, '') MOTHER_WT
      ,NVL(C.EIC_NO_MATNR, '') RAW_MATRL_NO
      ,NVL(EOM_CD_PREV_PROC, '') PREV_PROC
      ,NVL(EOM_CD_CURR_PROC, '') CURR_PROC
      ,NVL(EOM_CD_NEXT_PROC, '') NEXT_PROC
      ,NVL(EOM_PASSED_PROC, '') PASSED_PROC
      ,NVL(EOM_PLANNED_PROC, '') PLAN_PROC
      ,NVL(EOM_ID_ORDER_CUS, '') CUSTOMER_ORDER
      ,NVL(EOM_ID_ORD_ITEM_CUS, '') ITEM
      ,NVL(ENC_ORDER_TYPE, '') ORDER_TYPE
      ,NVL(ENC_CD_END_CUST, '') CUSTOMER_CODE
      ,NVL(ENC_CUST_NAME, '') CUSTOMER_NM
      ,NVL(ENC_MARK_CUST, '') MK_CUST_CD
      ,NVL(ENC_MARK_CUST_NAME, '') MK_CUST_NM
      ,NVL(ENC_NO_TRACKING, '') TRACKING_NO
      ,NVL(EOM_NO_MATNR,ENC_NO_MATNR) FG_MATERIAL_NO
      ,(SELECT MAKTG FROM V_MAKT WHERE MATNR = EOM_NO_MATNR ) FG_MAT_DESC
      ,(SELECT MAKTG FROM V_MAKT WHERE MATNR = EIC_NO_MATNR ) MOTHER_CHARG_DESC
      ,NVL(EOM_SCO_ORDER, '') SCO_ORDER
      ,NVL(EOM_SCO_ITEM, '') SCO_ITEM
      ,NVL(EOM_NO_PIECES, '') NO_PIECES
      ,NVL(EOM_NO_INVOICE, '') INVOICE_NO
      ,NVL(TO_CHAR(EOM_DT_INVOICE, 'DD-MM-YYYY'), '') INVOICE_DT
      ,(SELECT DISTINCT (LPAD(ENC_ROAD_DEST,6,'0')) FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) ROAD_DESTN
      ,(SELECT DISTINCT ENC_ROADDEST_DESC FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) ROAD_DEST_DESCRIPTION
       ,(SELECT DISTINCT (LPAD(ENC_RAIL_DEST,6,0)) FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) RAIL_DESTN
       ,(SELECT DISTINCT ENC_RAILDEST_DESC FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) RAIL_DESTN_DESCRIPTION
      ,NVL(EOM_CD_YRD, '') YARD
      ,NVL(EOM_ID_LOC_X, '') LOC_X
      ,NVL(EOM_ID_LOC_Y, '') LOC_Y
      ,NVL(EOM_ID_POS, '') LOC_Z
      ,NVL(EOM_CD_EPA, '') SPC
      ,EOM_IDIA COIL_IDIA
      ,EOM_ODIA COIL_ODIA
      ,ENC_IDIA ORDER_IDIA
      ,ENC_ODIA ORDER_ODIA
      ,ENC_FRT_IND FRT_IND
      ,ENC_ORDER_EDGE ORD_EDGE
      ,(SELECT EPL_EPA_DESC FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA = A.EOM_CD_EPA AND ROWNUM=1) SPC_NAME
      ,NVL(EOM_OPER_COMMENT, '') OPERATOR_REMARKS
      ,NVL(EOM_OPER_ID, '') OPERATOR_ID
      ,( SELECT DISTINCT MAX(TRIM(REPLACE(CAD_DEF2_COMM, CHR(10),' '))) FROM V_COIL_CARD 
      WHERE CAD_ID_COIL = A.EOM_ID_FIRST_PAR AND (CAD_DEF2_COMM LIKE 'SLP%' OR CAD_DEF2_COMM LIKE '@SLP%') ) SALVAGING_REMARKS
      ,(SELECT LISTAGG (CHR_CD_RSN_HOLD|| '-' || (SELECT DISTINCT CD_DESC FROM V_EPA_HOLD_RSN WHERE CD_HOLD = E.CHR_CD_RSN_HOLD 
          AND CD_COMP = (SELECT DISTINCT EPL_CD_COMP  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA = E.CHR_CD_EPA)), ' ; ' ) 
          WITHIN GROUP (ORDER BY CHR_CD_RSN_HOLD)
          FROM V_COIL_HOLD_RLS E WHERE CHR_CD_EPA=A.EOM_CD_EPA AND CHR_ID_COIL=A.EOM_ID_BATCH
          AND CHR_REMARKS is null 
       ) HOLD_CODE_REASON
      ,(SELECT listagg(chr_opr_remarks, ' ; ') WITHIN GROUP (ORDER BY CHR_CD_RSN_HOLD)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          AND CHR_REMARKS is null          
        ) hold_operator_remarks
      /*,(SELECT DISTINCT CHR_CD_RSN_HOLD|| '-' || (SELECT DISTINCT CD_DESC FROM V_EPA_HOLD_RSN 
        WHERE CD_HOLD = E.CHR_CD_RSN_HOLD AND CD_COMP =
        (SELECT DISTINCT EPL_CD_COMP  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA = E.CHR_CD_EPA))
        FROM V_COIL_HOLD_RLS E WHERE CHR_CD_EPA=A.EOM_CD_EPA AND CHR_ID_COIL=A.EOM_ID_BATCH
        AND CHR_TS_HOLD = ( SELECT MAX(CHR_TS_HOLD) FROM V_COIL_HOLD_RLS WHERE
        CHR_CD_EPA=E.CHR_CD_EPA AND CHR_ID_COIL=E.CHR_ID_COIL) AND ROWNUM=1) HOLD_CODE_REASON
      ,(SELECT (chr_opr_remarks)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_opr_remarks is not null) and rownum=1) hold_operator_remarks*/
       ,(SELECT (chr_rls_remarks)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks is not null) and rownum=1) release_remarks
       ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) release_remarks1
       ,(SELECT (CHR_ID_OP_RELEASE)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) QA_PERSON_ID
      ,NVL(EIC_TDC_AIM, '') MOTHER_BATCH_AIM_TDC
      ,NVL(EIC_TDC_ACTL, '') MOTHER_BATCH_TDC
      ,NVL(EIC_CD_PROD, '') MOTHER_BATCH_PROD_CD
      ,NVL(EIC_SOURCE_PLANT,EIC_CD_PLANT) SOURCE_PLANT
      --,NVL(EIC_NO_INVOICE, '') INVOICE_NO
      --,NVL(TO_CHAR(EIC_DT_INVOICE, 'DD-MM-YYYY'), '') INVOICE_DT
      ,EOM_DELV_NO DELIVERY_NO --,EIC_NO_DELIVERY  DELIVERY_NO
      ,EIC_DELV_ITEM  DELIVERY_ITEM
      ,EIC_MARK_CUST INDENT_CUST_CODE
      ,EIC_MK_CUSTOMER  INTEND_CUST
      ,(SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=A.EOM_ID_FIRST_PAR And TCO_CAST_NO=A.EOM_NO_CAST And TCO_TEST_PARA IN ('YS','LYS') AND ROWNUM=1) LYS
      ,(SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=A.EOM_ID_FIRST_PAR And TCO_CAST_NO=A.EOM_NO_CAST And TCO_TEST_PARA IN ('UTS') AND ROWNUM=1) UTS
      ,NVL(ENC_CD_SHIP_TO_PRTY, '') SHIP_TO_PARTY_CD
      ,NVL(ENC_SHIP_TO_PRTY_DESC, '') SHIP_TO_PARTY_DESC 
      ,DECODE(EOM_CD_ST_ACTL,'9','Scrap','3','Diverted','5','Downgraded','0','Additional Process','Prime') Process_FLag 
      ,(SELECT ROUND(SYSDATE - TO_DATE (SUBSTR (ind_id_message, 1, 10), 'YYYY-MM-DD'))
        FROM v_l3_yms_indent
        WHERE ind_id_coil = A.EOM_ID_BATCH
        AND ind_id_message = (SELECT MAX (ind_id_message)
                           FROM v_l3_yms_indent
                          WHERE ind_id_coil = A.EOM_ID_BATCH)
                          ) AS AGE_INDENT
      ,EIC_TRANSITION_SLAB
      ,EOM_ID_ORD_CUS_AIM CUST_ORD_AIM
      ,EOM_ID_ITM_CUS_AIM CUST_ITEM_AIM
      ,EOM_INV_LOSS INV_LOSS
      ,EIC_WO_NO MILL_ORD_MOTH_BATCH
      ,EIC_ITEM_NO MILL_ITEM_MOTH_BATCH
      ,(SELECT ROUND(SYSDATE - STB_TIMESTAMP) 
        FROM v_status_bkup V
        WHERE STB_ID_COIL = A.EOM_ID_BATCH
        AND STB_NEW_STATUS = A.EOM_CD_STATUS
        AND STB_TIMESTAMP = (SELECT MAX (STB_TIMESTAMP)
                           FROM v_status_bkup where STB_NEW_STATUS =V.STB_NEW_STATUS AND STB_ID_COIL=V.STB_ID_COIL )) STATUS_AGE
      ,ENC_POST_TREAT ORDER_POST_TREAT
      ,EIC_POST_TREAT_ACTL POST_TREAT_ACTL
      from v_epa_prodn A,v_end_cust_ord_epa B, v_input_coil C    
      where eom_cd_epa = enc_cd_epa(+)    
      and EOM_ID_ORDER_CUS = enc_id_order(+)    
      and  EOM_ID_ORD_ITEM_CUS = enc_no_item(+)    
      and eom_cd_epa = eic_cd_Epa    
      and eom_id_first_par = eic_id_coil    
      and eom_cd_Epa='131'     `;
    if (data.batch && data.batch?.length > 0) {
      sql += ` and eom_id_batch='${data?.batch}'`;
      binds["batch"] = data?.batch;
    }
    if (data.process && data.process?.length > 0) {
      sql += ` and EOM_CD_CURR_PROC='${data?.process}'`;
      binds["process"] = data?.process;
    }
    if (data.status && data.status?.length > 0) {
      sql += ` and EOM_CD_STATUS='${data?.status}'`;
      binds["status"] = data?.status;
    }
    if (data.mBatch && data.mBatch?.length > 0) {
      sql += ` and eom_id_first_par='${data?.mBatch}'`;
      binds["mBatch"] = data?.mBatch;
    }
    if (data.parentBatch && data.parentBatch?.length > 0) {
      sql += ` and eom_id_par_coil_no='${data?.parentBatch}'`;
      binds["mBatch"] = data?.mBatch;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` and (EOM_NO_MATNR='${data?.materialNo}' OR ENC_NO_MATNR='${data?.materialNo}')`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCd && data.prodCd?.length > 0) {
      sql += ` AND EOM_CD_PROD = '${data?.prodCd}'`;
      binds["prodCd"] = data?.prodCd;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EOM_TDC_ACTL = '${data?.tdc}'`;
      binds["tdc"] = data?.tdc;
    }
    if (data?.productionDateFr || data?.productionDateTo) {
      sql += ` AND EOM_TS_CREATION BETWEEN NVL('${data?.productionDateFr}','01-JAN-1900') AND NVL('${data?.productionDateTo}','31-DEC-9999')`;
      // sql += ` AND TRUNC(EOM_TS_CREATION) BETWEEN TO_DATE('${data?.productionDateFr}', 'DD-MON-YY') AND TO_DATE('${data?.productionDateTo}', 'DD-MON-YY')  `;
      binds.productionDateFr = data?.productionDateFr;
      binds.productionDateTo = data?.productionDateTo;
    }
    if (data?.deliveryDateFr && data?.deliveryDateTo) {
      sql += ` AND ENC_DT_DELV BETWEEN NVL('${data?.deliveryDateFr}','01-JAN-1900') AND NVL('${data?.deliveryDateTo}','31-DEC-9999')`;
      binds.deliveryDateFr = data?.deliveryDateFr;
      binds.deliveryDateTo = data?.deliveryDateTo;
    }
    if (data?.ThickFr && data?.ThickFr != "") {
      sql += ` AND ENC_SEC1_MIN >= nvl('${data?.ThickFr}', enc_sec1_min)`;
      binds["ThickFr"] = data?.ThickFr;
    }
    if (data?.ThickTo && data?.ThickTo !== "") {
      sql += `AND ENC_SEC1_MAX <= nvl('${data?.ThickTo}', ENC_SEC1_MAX) `;
      binds["ThickTo"] = data?.ThickTo;
    }
    if (data?.widthFr && data?.widthFr != "") {
      sql += ` AND ENC_SEC2_MIN >= nvl('${data?.widthFr}', ENC_SEC2_MIN)`;
      binds["widthFr"] = data?.widthFr;
    }
    if (data?.widthTo && data?.widthTo !== "") {
      sql += `AND ENC_SEC2_MAX <= nvl('${data?.widthTo}', ENC_SEC2_MAX)`;
      binds["widthTo"] = data?.widthTo;
    }
    if (data?.prodForm && data?.prodForm?.length > 0) {
      sql += ` and (SELECT DISTINCT CD_DESC1 FROM V_CODES 
      WHERE CD_TYPE = 'E0001' AND CD_VALUE = EOM_CD_STATUS) = '${data?.prodForm}'`;
      binds["prodForm"] = data?.prodForm;
    }
    if (
      data.mBatch?.length === 0 &&
      data?.batch?.length === 0 &&
      data?.parentBatch?.length === 0
    ) {
      sql += ` and eom_cd_status not like '%L'`;
    }

    sql += ` ORDER BY EOM_TS_CREATION`;
    // console.log("sql - getInvData: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getInvMonData = async (data: any) => {
  try {
    let binds: any = {
      plant: data?.epa,
    };
    let sql: any = `SELECT
      sim_id_batch	BATCH_ID	,
     sim_cd_epa	SPC	,
     sim_cd_status	STATUS	,
     sim_cd_prod	PROD	,
     sim_cd_qlty_actl	QLTY	,
     sim_grade_desc	GRADE_DESC	,
     sim_sec1	THICK	,
     sim_sec2	WIDTH	,
     sim_length	LENGTH	,
     sim_tdc_actl	ACTUAL_TDC	,
     sim_ms_gross_cal	NET_WT_PCS	,
     sim_ms_gross_actl	GROSS_WT_PCS	,
     sim_scrap_wt	SCRAP_WT	,
     sim_fl_send_sap	SEND_TO_SAP	,
     sim_prodn_arrival_date	PRODN_ARRIVAL_DATE	,
     sim_age_days	AGE_DAYS	,
     sim_no_cast	CAST_NO	,
     sim_id_par_coil_no	PARENT_CHARG	,
     sim_id_first_par	MOTHER_CHARG	,
     sim_mother_charg_age	MOTHER_CHARG_AGE	,
     sim_mother_wt	MOTHER_WT	,
     sim_raw_matrl_no	RAW_MATRL_NO	,
     sim_cd_prev_proc	PREV_PROC	,
     sim_cd_curr_proc	CURR_PROC	,
     sim_cd_next_proc	NEXT_PROC	,
     sim_passed_proc	PLAN_PROC	,
     sim_planned_proc	PASSED_PROC	,
     sim_id_order_cus	CUSTOMER_ORDER	,
     sim_id_ord_item_cus	ITEM	,
     sim_order_type	ORDER_TYPE	,
     sim_cd_end_cust	CUSTOMER_CODE	,
     sim_cust_name	CUSTOMER_NM	,
     sim_mark_cust	MK_CUST_CD	,
     sim_mark_cust_name	MK_CUST_NM	,
     sim_no_tracking	TRACKING_NO	,
     sim_no_matnr	FG_MATERIAL_NO	,
     sim_id_order	SCO_NO	,
     sim_no_item	SCO_ITEM	,
     sim_no_pieces	NO_PIECES	,
     sim_no_invoice	INVOICE_NO	,
     sim_dt_invoice	INVOICE_DATE	,
     sim_road_destn	ROAD_DESTN	,
     sim_road_dest_description	ROAD_DEST_DESCRIPTION	,
     sim_rail_destn	RAIL_DESTN	,
     sim_rail_destn_description	RAIL_DESTN_DESCRIPTION	,
     sim_cd_yrd	YARD	,
     sim_id_loc_x	LOC_X	,
     sim_id_loc_y	LOC_Y	,
     sim_id_pos	LOC_Z	,
     sim_spc_name	SPC_NAME	,
     sim_oper_comment	OPERATOR_REMARKS	,
     sim_oper_id	OPERATOR_ID	,
     sim_salvaging_remarks	SALVAGING_REMARKS	,
     sim_hold_code_reason	HOLD_CODE_REASON	,
     sim_hold_operator_remarks	HOLD_OPERATOR_REMARKS	,
     sim_mother_batch_aim_tdc	MOTHER_BATCH_AIM_TDC	,
     sim_mother_batch_tdc	MOTHER_BATCH_TDC	,
     sim_mother_batch_prod_cd	MOTHER_BATCH_PROD_CD	,
     sim_source_plant	SOURCE_PLANT	,
     sim_lys	LYS	,
     sim_uts	UTS	,
     sim_cd_ship_to_prty	SHIP_TO_PARTY_CD	,
     sim_ship_to_prty_desc	SHIP_TO_PARTY_DESC	
  FROM
      v_spc_inven_monthly
  WHERE
      sim_cd_epa = '${data?.epa}'
      and sim_year_mon = (select to_char(sysdate,'yyyymm') from dual)`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
