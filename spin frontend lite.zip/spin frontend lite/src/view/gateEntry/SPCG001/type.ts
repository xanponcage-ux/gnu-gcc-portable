import { dateInput, input } from "../../type";

export interface InputChangeType {
  // key1: input,
  key2: input;
  key3: input;
  key4: input;
  key5: input;
  key6: input;
  key7: input;
  key8: input;
  key9: input;
  key10: input;
  key11: input;
  key12: input;
}

export interface TableType {
  EGP_CD_EPA: string;
  EIC_CD_STATUS: string;
  EIC_NO_INVOICE: string;
  EIC_NO_MATNR: string;
  EIC_CD_PROD: string;
  EIC_CD_QLTY_ACTL: string;
  EIC_TDC_ACTL: string;
  YARD: string;
}
