from flask import Flask, request, jsonify
import tensorflow as tf
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession
import numpy as np
from PIL import Image
import io
from fastapi import HTTPException, status, APIRouter, Request
import requests

router = APIRouter()

# Load trained model
model = tf.keras.models.load_model('neu_model.keras', compile=False)
print("✅ Model loaded. Input shape:", model.input_shape)

# Define class names based on your model
CLASS_NAMES = ['HIGH_TEMPERATURE_SCALE', 'STICKY_SCALE', 'PICKLING_PATCH_BLACKBROWN', 'BANDED_SCALE_PITTING_MARK', 'ROLLED_IN_SCALE', 'SCRATCHES']

# Image preprocessing - matches your model's requirements
def preprocess_image(image_bytes):
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        img = img.resize((200, 200))  # Match your model's input size
        img_array = np.array(img) / 255.0  # Normalize as in your model
        img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
        return img_array
    except Exception as e:
        raise

async def CALL_API(image_bytes, annotated, conf, flag):
    try: 
        url = "https://asia-south1-tsl-tda-ai.cloudfunctions.net/counting_tube-1"
        payload = {
            "passkey": "6yIB1KUuEiws67Nnui09oklp",
            "conf": conf if conf else 0.7,
            "flag": flag if flag else "Tube",
            "annotated": annotated if annotated else 'No'
        }
        files = {'image': ('image.jpg', image_bytes, 'image/jpeg')}
        headers= {} #keep headers as blank
        resp =  requests.post(url, headers=headers, data=payload, files=files)
        resp.raise_for_status()
        document_info = resp.json()
        print(f"Status Code: {resp.status_code}")
        print("resp Body:")
        return document_info
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": str(e)}
        )


@router.post('/get')
async def check_defect(request: Request):
    """Surface defect detection API"""
    try:
        form_data = await request.form()
        # Access your file(s) by their HTML form field name

        if 'file' not in form_data:
            raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error_code": "NOT_FOUND", "message": "No file provided."}
        )
            
        file = form_data.get("file") 
        annotated = form_data.get("annotated")
        flag = form_data.get("flag")
        conf = form_data.get("conf")

        if not file or file.filename == '':
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "No selected file."}
        )

        if not file or file.filename.count('.') > 1:
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "Wrong Extention."}
        )

        # Validate extension 
        if not file.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": "Invalid file type (only PNG, JPG, JPEG, BMP allowed)."}
        )

        # Preprocess and predict
        image_bytes = await file.read()
        # img_array = preprocess_image(image_bytes)
        resp = await CALL_API(image_bytes, annotated, conf, flag)

        return {
            'message': 'Complete',
            'AIResp': resp
        }

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error_code": "ERROR", "message": str(e)}
        )

@router.get('/health')
def health_check():
    return {
        'status': 'healthy',
        'responce': 'working',
    }

