import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import { MaterialUIControllerProvider } from "./context";
import { HashRouter } from "react-router-dom";
// import Chatbot from "./view/chatbot";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  <MaterialUIControllerProvider>
    {/* {!window.location.protocol?.includes("https") && <Chatbot />}   */}
    <App />
  </MaterialUIControllerProvider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
