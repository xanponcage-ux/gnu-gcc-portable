import { Router } from "express";
import { callPkgProc, getBatchData } from "../controllers/SPS0003Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0003Route = Router();

SPS0003Route.route("/SPS0003/callPkgProc").post(
  authenticationMiddleware.bearer,
  callPkgProc
);

SPS0003Route.route("/SPS0003/getBatchData").post(
  authenticationMiddleware.bearer,
  getBatchData
);

export default SPS0003Route;
