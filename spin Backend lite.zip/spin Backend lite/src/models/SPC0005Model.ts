const SPC0005Query = require("../repository/SPC0005Query");

export default class SPC0005Model {
  getSpecLimit05(data: any) {
    return SPC0005Query.getSpecLimit05(data);
  }
  getQualityData05(data: any) {
    return SPC0005Query.getQualityData05(data);
  }
  getTdcMain05(data: any) {
    return SPC0005Query.getTdcMain05(data);
  }
  getTdcCode05() {
    return SPC0005Query.getTdcCode05();
  }
  getQltyCode05() {
    return SPC0005Query.getQltyCode05();
  }
  getTdcMainCode05() {
    return SPC0005Query.getTdcMainCode05();
  }
}
