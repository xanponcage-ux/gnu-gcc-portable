import { Router } from "express";
import { SPC0004getData04 } from "../controllers/SPC0004Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0004Route = Router();

SPC0004Route.route("/SPC0004/getcoding_02_Data").post(
  authenticationMiddleware.bearer,
  SPC0004getData04
);

export default SPC0004Route;
