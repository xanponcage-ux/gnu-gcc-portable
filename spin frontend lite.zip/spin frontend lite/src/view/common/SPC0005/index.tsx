/* ------ TDC SPEC LIMIT SCREEN INSIDE COMMON --------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0005GetDataApi,
  SPC0005GetTdcDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import Page from "tabulator-tables";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableDataTs, setTableDataTs] = React.useState<any>([]);
  const [tableDataQc, setTableDataQc] = React.useState<any>([]);
  const [tableDataTm, setTableDataTm] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedLine, setSelectedLine] = React.useState<string>("");
  const [selectedGrade, setSelectedGrade] = React.useState<string>("");
  const [selectedQltyCode, setSelectedQltyCode] = React.useState<string>("");
  const [selectedTestPara, setSelectedTestPara] = React.useState<string>("");
  const [selectedTdc, setSelectedTdc] = React.useState<string>("");
  const [selQltyCode, setSelQltyCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [qltyCodeData, setQltyCodeData] = React.useState<Array<SelectType>>([]);
  const [tdcMainData, setTdcMainData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);

  const column: Array<CulmnType> = [
    {
      title: "Tdc No",
      field: "TSL_TDC_NO",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Test Code",
      field: "TSL_CD_TEST",
      headerFilter: "input",

      headerFilterPlaceholder: "search...",
    },
    {
      title: "Test Para",
      field: "TSL_TEST_PARA",
      headerFilter: "input",

      headerFilterPlaceholder: "search...",
    },

    {
      title: "Para Min",
      field: "TSL_PARA_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Para Max",
      field: "TSL_PARA_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Para Unit",
      field: "TSL_PARA_UNIT",
      headerFilter: "input",
      width: 100,
      headerFilterPlaceholder: "search...",
    },
  ];
  const qltyColumn: Array<CulmnType> = [
    {
      title: "Quality Code",
      field: "CD_QLTY",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade",
      field: "GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade Desc",
      field: "GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Create Date",
      field: "TS_CREATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "SPEC Tolerance Code",
      field: "CD_SPEC_TOL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "DS Quality",
      field: "DS_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PS Indicator",
      field: "PS_INDICATOR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];
  const tdcColumn: Array<CulmnType> = [
    {
      title: "TDC No",
      field: "TDC_NO",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC Desc",
      field: "TDC_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Quality Code",
      field: "CD_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade",
      field: "GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC Grade Desc",
      field: "TDC_GRD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Aim Thickness From",
      field: "SEC1_AIM_FR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Aim Thickness To",
      field: "SEC1_AIM_TO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Aim Width From",
      field: "SEC2_AIM_FR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Aim Width To",
      field: "SEC2_AIM_TO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "End User Code",
      field: "CD_END_USE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "End User Code Desc",
      field: "END_USE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thickness Tolerance Min",
      field: "SEC1_TOL_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thickness Tolerance Max",
      field: "SEC1_TOL_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "HR_TDC_NO",
      field: "HR_TDC_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Prod Code",
      field: "CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "RFD ID",
      field: "RFD_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    fetchTdcData();
    setSelectedTdc("");
    setSelectedTestPara("");
    setSelectedQltyCode("");
    setSelectedGrade("");
  };

  const downloadExcelTs = () => {
    if (tableDataTs == null || tableDataTs.length === 0) {
      alertify.error("No Data exists in the table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0005_" + "TDC_SPEC_LIMIT" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const downloadExcelQc = () => {
    if (tableDataQc == null || tableDataQc.length === 0) {
      alertify.error("No Data exists in the table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0005_" + "QUALITY_CODE" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const downloadExcelTm = () => {
    if (tableDataTm == null || tableDataTm.length === 0) {
      alertify.error("No Data exists in the table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0005_" + "TDC_MAIN" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  React.useEffect(() => {
    setLoading(true);
    fetchTdcData();
    alertify.error("Click on Search to View Table");
    setTable(null);
    setTableDataTs(null);
    setTableDataQc(null);
    setTableDataTm(null);
  }, []);

  React.useEffect(() => {
    setTable(null);
    setTableDataTs(null);
    setTableDataQc(null);
    setTableDataTm(null);
  }, [value]);

  React.useEffect(() => {
    if (tableDataTs?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableDataTs,
          columns: column,
          height: 550,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
        })
      );
    } else {
      setTable(null);
    }
  }, [tableDataTs]);
  React.useEffect(() => {
    if (tableDataQc?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableDataQc,
          columns: qltyColumn,
          height: 550,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
        })
      );
    } else {
      setTable(null);
    }
  }, [tableDataQc]);
  React.useEffect(() => {
    if (tableDataTm?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableDataTm,
          columns: tdcColumn,
          height: 550,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 15,
        })
      );
    } else {
      setTable(null);
    }
  }, [tableDataTm]);

  const fetchTdcData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0005GetTdcDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.tdc?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x.TSL_TDC_NO?.toString(),
                  label: x.TSL_TDC_NO?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantCodeData(varData);
            //setSelectedTdc(varData[0].value);

            const varData1: Array<SelectType> = [];
            res.data?.qlty?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.IQL_CD_QLTY?.toString(),
                  label: x.IQL_CD_QLTY?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setQltyCodeData(varData1);
            //setSelectedQltyCode(varData1[0].value);
            const varData2: Array<SelectType> = [];
            res.data?.tdcMain?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData2.push({
                  value: x.TMA_TDC_NO?.toString(),
                  label: x.TMA_TDC_NO?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setTdcMainData(varData2);
            //setSelectedTdc(varData2[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data?: any) => {
    let varData = {};
    if (data === 0) {
      varData = {
        data: data,
        tdc: selectedTdc,
        testPara: selectedTestPara?.toUpperCase(),
      };
    }
    if (data === 1) {
      varData = {
        data: data,
        grade: selectedGrade,
        qltyCode: selectedQltyCode,
      };
    }
    if (data === 2) {
      varData = { data: data, tdc: selectedTdc, qltyCode: selQltyCode };
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0005GetDataApi(token, varData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0) {
              setTableDataTs(res.data.specLimit);
            } else if (data === 1) {
              setTableDataQc(res.data.tdcQlty);
            } else if (data === 2) {
              setTableDataTm(res.data.tdcMain);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleClearAll = () => {
    setSelectedTdc("");
    setSelectedTestPara("");
    setSelectedQltyCode("");
    setSelectedGrade("");
    setTableDataTs([]);
    setTableDataQc([]);
    setTableDataTm([]);
  };
  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                {value === 0 ? (
                  <>
                    <Grid item xs={3}>
                      <SelectInput
                        id={"id"}
                        data={plantCodeData}
                        value={selectedTdc}
                        label="Tdc No"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedTdc(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <Input
                        id={"id"}
                        value={selectedTestPara}
                        label="Test Para"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedTestPara(e);
                        }}
                      />
                    </Grid>
                  </>
                ) : value === 1 ? (
                  <>
                    <Grid item xs={3}>
                      <SelectInput
                        id={"id"}
                        data={qltyCodeData}
                        value={selectedQltyCode}
                        label="Quality Code"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedQltyCode(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <Input
                        id={"id"}
                        value={selectedGrade}
                        label="Grade"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedGrade(e);
                        }}
                      />
                    </Grid>
                  </>
                ) : (
                  value === 2 && (
                    <>
                      <Grid item xs={3}>
                        <SelectInput
                          id={"id"}
                          value={selectedTdc}
                          data={tdcMainData}
                          label="Tdc No"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedTdc(e);
                          }}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Input
                          id={"id"}
                          value={selQltyCode}
                          label="Quality Code"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelQltyCode(e);
                          }}
                        />
                      </Grid>
                    </>
                  )
                )}
                <Grid item xs={2}>
                  <ButtonElement onClick={() => fetchData(value)}>
                    Search
                  </ButtonElement>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton
                    onClick={() => {
                      value === 0
                        ? downloadExcelTs()
                        : value === 1
                        ? downloadExcelQc()
                        : downloadExcelTm();
                    }}
                  >
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="TDC Spec Limit" />
                    <Tab label="Quality Code" />
                    <Tab label="TDC Main" />
                  </Tabs>
                </Box>
                {value === 0 && tableDataTs?.length > 0 && (
                  <div id="table"></div>
                )}
                {value === 1 && tableDataQc?.length > 0 && (
                  <div id="table"></div>
                )}
                {value === 2 && tableDataTm?.length > 0 && (
                  <div id="table"></div>
                )}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
