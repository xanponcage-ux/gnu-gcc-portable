import { Router } from "express";
import // getData,
// confirmPacking
"../controllers/dispatchController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const dispatchRoute = Router();

// dispatchRoute.route('/dispatch/getData').post(authenticationMiddleware.bearer, getData);
// dispatchRoute.route('/dispatch/confirmPacking').post(authenticationMiddleware.bearer, confirmPacking);

export default dispatchRoute;
