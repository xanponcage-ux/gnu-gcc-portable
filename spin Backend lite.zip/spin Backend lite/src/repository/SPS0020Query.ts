import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getPlantCode = async () => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getReportType = async () => {
  try {
    let sql: any = `SELECT SUBSTR(cd_desc,5) CD_DESC,CD_VALUE FROM V_CODES
                      WHERE CD_TYPE = 'EPA340'
                      AND CD_VALUE <> 'LS_FLAG'
                      AND CD_DESC LIKE 'A%'
                      ORDER BY CD_DESC`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getSourcePlant = async (data?: any) => {
  try {
    let sql: any = `SELECT distinct NVL(EIC_SOURCE_PLANT,EIC_CD_PLANT) src_plant FROM V_INPUT_COIL WHERE EIC_CD_EPA='${data?.plant}' ORDER BY 1`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTableData = async (data: any) => {
  try {
    let value = data?.data;
    let sql: any = `select tcy_cd_epa Plant,(SELECT DISTINCT EPL_EPA_DESC FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA =A.TCY_CD_EPA  ) Plant_Name, Round(sum(tcy_issueprod_wt),1) Issue_For_Production, Round(sum(tcy_prime_wt),1)  Prime, Round(sum(tcy_seconds_wt),1)  Seconds, Round(sum(tcy_scrap_wt),1)  Scrap, case    
                      WHEN SUM(tcy_issueprod_wt) > 0        
                      Then ROUND((SUM(tcy_prime_wt) /SUM(tcy_issueprod_wt))*100,1)    
                      ELSE  0 end Prime_Yield,case WHEN SUM(tcy_issueprod_wt) > 0        
                      Then ROUND(((SUM(tcy_prime_wt)+SUM(tcy_seconds_wt))/SUM(tcy_issueprod_wt))*100,1)    
                      ELSE  0  end Gross_Yield from V_COIL_YIELD A
                      where tcy_yrmon IN '${value?.year}${value.month}'
                      AND tcy_cd_epa = '${data?.plant}'
                      group by tcy_cd_epa`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getyieldwisedata = async (data: any) => {
  try {
    let value = data?.data;
    let sql = ` SELECT
    t.TCY_YRMON              AS "Month",
    t.TCY_CD_EPA             AS "Plant",
    t.TCY_BATCH_ID           AS "CR Mother Coil ID",
    t.TCY_MC_TDC             AS "Mother Coil TDC",
    t.TCY_MC_SEC1            AS "Thickness",
    t.TCY_MC_SEC2            AS "M C Width",
    t.TCY_COMBINATION        AS "Combination",
    t.TCY_MC_SEC2            AS "M C Width Actual",
    t.TCY_MC_EDGE            AS "M Coil Edge",
    t.TCY_MC_GRADE           AS "Mother Coil Grade",
    t.TCY_MC_PROD_CD         AS "Mother Coil Prod Code",
    t.TCY_MC_CAT             AS "Mother Coil Category",
    t.TCY_MC_MARK_CUST       AS "Mother Coil Mark Cust",
    t.TCY_MC_INV_WT          AS "Mother Coil Weight (T)",
    t.TCY_MC_CONSUM_WT       AS "Mother Coil Consumed Wt (T)",
    t.TCY_WIP_WT_TOT         AS "WIP Tonnage (T)",
    t.TCY_WIP_WT_B_HOLD      AS "Hold Tonnage (T)",
    t.TCY_WIP_WT_C_SEG       AS "Segregation Tonnage (T)",
    t.TCY_WIP_WT_D_RWK       AS "Rework/Replan Tonnage (T)",
    t.TCY_ISSUEPROD_WT       AS "Total Issued For Production (T)",
    t.TCY_PRIME_WT           AS "Total Prime Tonnage (T)",
    t.TCY_SECONDS_WT         AS "Total Prime-2 Qty (T)",
    t.TCY_SCRAP_WT           AS "Total Scrap Qty (T)",
    t.TCY_PRIME_YLD          AS "Prime Yield (%)",
    t.TCY_GROSS_YLD          AS "Gross Yield (%)",
    t.TCY_RMDEF_SEC_WT       AS "RM Defect Downgraded to Prime-2 (T)",
    t.TCY_EPADEF_SEC_WT      AS "EPA Defect Downgraded to Prime-2 (T)",
    t.TCY_NOMIDEF_SEC_WT     AS "Nominal Defect Downgraded to Prime-2 (T)",
    t.TCY_PLNGDEF_SEC_WT     AS "Planning Downgraded to Prime-2 (T)",
    t.TCY_MKTDEF_SEC_WT      AS "Marketing Downgraded to Prime-2 (T)",
    t.TCY_CSDDEF_SEC_WT      AS "CSD Downgraded to Prime-2 (T)",
    t.TCY_RMDEF_SCRP_EC_WT   AS "RM Defect Scrap - End Cut (T)",
    t.TCY_EPADEF_SCRP_EC_WT  AS "EPA Defect Scrap - End Cut (T)",
    t.TCY_NOMIDEF_SCRP_EC_WT AS "Nominal Defect Scrap - End Cut (T)",
    t.TCY_PLNGDEF_SCRP_EC_WT AS "Planning Defect Scrap - End Cut (T)",
    t.TCY_RMDEF_SCRP_TRIM_WT AS "RM Defect Scrap - Trim Loss (T)",
    t.TCY_EPADEF_SCRP_TRIM_WT AS "EPA Defect Scrap - Trim Loss (T)",
    t.TCY_NOMIDEF_SCRP_TRIM_WT AS "Nominal Defect Scrap - Trim Loss (T)",
    t.TCY_PLNGDEF_SCRP_TRIM_WT AS "Planning Defect Scrap - Trim Loss (T)",
    t.TCY_RMDEF_SCRP_PUPC_WT AS "RM Defect Scrap - Pup Coil (T)",
    t.TCY_EPADEF_SCRP_PUPC_WT AS "EPA Defect Scrap - Pup Coil (T)",
    t.TCY_NOMIDEF_SCRP_PUPC_WT AS "Nominal Defect Scrap - Pup Coil (T)",
    t.TCY_PLNGDEF_SCRP_PUPC_WT AS "Planning Defect Scrap - Pup Coil (T)",
    t.TCY_MKTDEF_SCRP_WT     AS "Marketing Scrap (T)",
    t.TCY_CSDDEF_SCRP_WT     AS "CSD Defect Scrap (T)",
    t.TCY_SALVAGING          AS "Salvaging Remarks",
    t.TCY_MC_CAST            AS "Cast No",
    t.TCY_SOURCE_PLANT       AS "CR Source Plant",
    t.TCY_PASSED_PROC        AS "Source Plant Passed Process",
    t.TCY_UOM                AS "UOM",
    t.TCY_CRT_BY             AS "Created By",
    TO_CHAR(t.TCY_CRT_ON, 'DD-MM-YYYY HH24:MI:SS')   AS "Created On",
    t.TCY_UPD_BY             AS "Updated By",
    TO_CHAR(t.TCY_UPD_ON, 'DD-MM-YYYY HH24:MI:SS')   AS "Updated On",
    t.TCY_CD_COMP            AS "Company Code",
    t.TCY_WIP_WT_A           AS "WIP WT A",
    t.TCY_FG_SIZE            AS "FG Size"
    FROM V_COIL_YIELD t 
    where tcy_yrmon IN '${value?.year}${value.month}'  
    AND tcy_cd_epa = '${data?.plant}' `;

    // let sql: any = `SELECT TCY_YRMON Month, TCY_BATCH_ID Mother_Coil_ID, TCY_CD_EPA Plant, TCY_CD_COMP Company, TCY_MC_TDC Mother_Coil_TDC,TCY_MC_SEC1 Thickness, TCY_MC_SEC2 Width,
    //   (select ( listagg( distinct EOM_SEC1||'X'||EOM_SEC2, ', ') WITHIN GROUP (ORDER BY 1)) sizes from v_epa_prodn where eom_cd_epa= A.TCY_CD_EPA AND EOM_ID_FIRST_PAR= A.TCY_BATCH_ID) Combination, TCY_MC_GRADE Mother_Coil_Grade, TCY_MC_PROD_CD Mother_Coil_Prod_Cd,
    //   TCY_MC_CAT Mother_Coil_Catg, TCY_MC_MARK_CUST Mother_Coil_Mark_Cust, TCY_MC_INV_WT Mother_Coil_Weight, TCY_MC_CONSUM_WT Mother_Coil_Consumed_Wt, TCY_INPUT_WT Input_tonnage, TCY_ISSUEPROD_WT Issue_For_Production,
    //   TCY_PRIME_WT Prime_Tonnage, TCY_SECONDS_WT Seconds_Tonnage, TCY_SCRAP_WT Scrap_Tonnage, TCY_RMDEF_SEC_WT RM_Defect_Sec, TCY_EPADEF_SEC_WT EPA_Defect_Sec, TCY_NOMIDEF_SEC_WT Nominal_Sec, TCY_PLNGDEF_SEC_WT Planning_Sec,
    //   TCY_MKTDEF_SEC_WT Marketing_Sec, TCY_CSDDEF_SEC_WT CSD_Defect, TCY_UNACC_SEC_WT Unacc_Sec, TCY_RMDEF_SCRP_WT RM_Defect_Scrap, TCY_EPADEF_SCRP_WT EPA_Defect_Scrap, TCY_NOMIDEF_SCRP_WT Nominal_Scrap,
    //   TCY_PLNGDEF_SCRP_WT Planning_Scrap, TCY_MKTDEF_SCRP_WT Marketing_Scrap, TCY_CSDDEF_SCRP_WT CSD_Defect_Scrap, TCY_UNACC_SCRP_WT Unacc_Scrap, TCY_PRIME_YLD Prime_Yield, TCY_GROSS_YLD Gross_Yield,
    //   (select trim(CAD_DEF2_COMM) from v_coil_card where CAD_ID_COIL=A.TCY_BATCH_ID and CAD_DEF2_COMM like 'SLP%' and CAD_CD_COMPANY='1000' AND ROWNUM=1 ) Salvaging_remarks ,
    //   (SELECT DISTINCT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_CD_EPA=A.TCY_CD_EPA AND EIC_ID_cOIL = A.TCY_BATCH_ID AND ROWNUM=1 ) Source_Plant
    //   ,'' Source_Plant_Desc
    //   From V_COIL_YIELD A, V_INPUT_COIL B
    //   where tcy_yrmon IN '${value?.year}${value.month}'
    //   AND A.TCY_BATCH_ID = B.EIC_ID_COIL  AND A.tcy_cd_epa =B.EIC_CD_EPA
    //   AND tcy_cd_epa = '${data?.plant}' `;

    if (value?.sourcePlant && value?.sourcePlant.length > 0) {
      sql += ` AND TCY_SOURCE_PLANT = '${value?.sourcePlant}'`;
    }
    sql += ` ORDER BY  tcy_cd_epa,TCY_YRMON,TCY_BATCH_ID`;

    // console.log("sql-getyieldwisedata: ", sql);

    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getSecondsData = async (data?: any) => {
  try {
    let value = data?.data;
    let sql: any = `SELECT SSY_ID_BATCH BATCH_ID,EOM_SEC1 FG_THK,EOM_SEC2 FG_WIDTH ,EOM_TDC_ACTL FG_TDC,EOM_CD_PROD FG_PROD_CD,SSY_CD_EPA PLANT,SSY_ID_COIL MOTHER_BATCH
      ,EIC_TDC_ACTL MC_TDC ,EIC_CD_PROD MC_PRODCD,EIC_SEC1 MC_THK,EIC_SEC2 MC_WIDTH,EIC_MK_CUSTOMER MC_CUSTOMER,DECODE(EIC_SOURCE_PLANT,NULL,EIC_CD_PLANT,EIC_SOURCE_PLANT)SOURCE_PLANT
      ,'' PRODUCT_TYPE  ,SSY_RSN_CAT,(SELECT DISTINCT ESR_RSN_DESC FROM V_SCRP_SEC_RSN WHERE ESR_cD_EPA=A.SSY_CD_EPA AND ESR_RSN_CAT=A.SSY_RSN_CAT AND ESR_RSN_CD=A.SSY_CD_RSN AND ROWNUM=1)RSN_DESC
      ,SSY_MS_QTY TONN FROM V_SECSCR_YLDDTL A,V_EPA_PRODN B,V_INPUT_COIL C
      WHERE A.SSY_CD_EPA=B.EOM_cD_EPA AND A.SSY_ID_BATCH=B.EOM_ID_BATCH AND A.SSY_CD_EPA=C.EIC_CD_EPA AND A.SSY_ID_COIL=C.EIC_ID_COIL
      AND A.SSY_YEARMON IN '${value?.year}${value.month}'
      AND A.SSY_CD_EPA = '${value?.plant}'
      AND SSY_IND = 'A' order by PLANT`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getScrapData = async (data?: any) => {
  try {
    let value = data?.data;
    let sql: any = `SELECT SSY_ID_BATCH BATCH_ID,EOM_SEC1 FG_THK,EOM_SEC2 FG_WIDTH ,EOM_TDC_ACTL FG_TDC,EOM_CD_PROD FG_PROD_CD,SSY_CD_EPA PLANT,SSY_ID_COIL MOTHER_BATCH
      ,EIC_TDC_ACTL MC_TDC ,EIC_CD_PROD MC_PRODCD,EIC_SEC1 MC_THK,EIC_SEC2 MC_WIDTH,EIC_MK_CUSTOMER MC_CUSTOMER,DECODE(EIC_SOURCE_PLANT,NULL,EIC_CD_PLANT,EIC_SOURCE_PLANT)SOURCE_PLANT
      ,'' PRODUCT_TYPE
      ,SSY_RSN_CAT,(SELECT DISTINCT ESR_RSN_DESC FROM V_SCRP_SEC_RSN WHERE ESR_cD_EPA=A.SSY_CD_EPA AND ESR_RSN_CAT=A.SSY_RSN_CAT AND ESR_RSN_CD=A.SSY_CD_RSN AND ROWNUM=1)RSN_DESC
      ,SSY_MS_QTY TONN
      FROM V_SECSCR_YLDDTL A,V_EPA_PRODN B,V_INPUT_COIL C
      WHERE A.SSY_CD_EPA=B.EOM_cD_EPA AND A.SSY_ID_BATCH=B.EOM_ID_BATCH AND A.SSY_CD_EPA=C.EIC_CD_EPA AND A.SSY_ID_COIL=C.EIC_ID_COIL
      AND A.SSY_YEARMON IN '${value?.year}${value.month}'
      AND A.SSY_CD_EPA = '${value?.plant}'
      AND SSY_IND = 'B' order by PLANT`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
