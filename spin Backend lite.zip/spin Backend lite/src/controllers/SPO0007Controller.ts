import { Request, Response } from "express";
import SPO0007Model from "../models/SPO0007Model";
import { ResponceData } from "../utils";

export const getData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0007Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
