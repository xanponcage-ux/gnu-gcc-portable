import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const deleteScheduling = async (data: any) => {
  try {
    const sql = `DELETE FROM v_schd_temp where tst_prog_id = 'SPS0005'`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getToleranceLimit = async () => {
  try {
    const sql = `SELECT CD_VALUE FROM V_CODES WHERE CD_TYPE = 'TK021'`;
    return await query(sql);
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const scheduling = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data.Plant) {
        var ls_proc = data.schd == "RM" ? "0" : data.proc;

        return {
          batch: await ResponceData(
            await query(`
            select distinct EOM_ID_BATCH 
            from v_epa_prodn where eom_cd_status in ('VG','VF')
            AND EOM_CD_EPA = ${data.Plant}
            `)
          ),
          process: await ResponceData(
            await query(`
            select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
            FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} AND EPL_CD_PROCESS != 'W' ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
            `)
          ),
          status: await ResponceData(
            // await query(`
            // select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
            // WHERE CD_TYPE='TK006'
            // `)

            await query(`
              select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
            WHERE CD_TYPE='TK006' AND CD_DESC1 = '${ls_proc}'||'-'||'${data.schd}' ORDER BY 1
              `)
          ),
          order: await ResponceData(
            await query(`
            SELECT distinct EOM_SCO_ORDER
            FROM v_epa_prodn a 
            WHERE EOM_CD_EPA = ${data.Plant}
            AND eom_ms_gross_cal >= 0
            `)
          ),
          plannedPath: await ResponceData(
            await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
              FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} 
              AND substr(PPH_CD_PROC_PATH,1,1) = '${data.proc}' ORDER  BY 1`)
          ),
          orderTypeData: await ResponceData(
            await query(`SELECT CD_VALUE 
            FROM V_CODES WHERE CD_TYPE='TB005' ORDER BY 1`)
          ),

          toleranceLimit: await ResponceData(
            await query(`SELECT CD_VALUE FROM V_CODES WHERE CD_TYPE = 'TK021'`)
          ),
        };
      } else {
        return getCommonPlantData();
      }
    } else if (data?.type === "materialData") {
      let QrygetCoils = `SELECT eom_id_batch, eom_cd_prod, eom_cd_qlty_actl, 
        (SELECT DISTINCT NVL (iql_grade_desc, '.') grade_desc
                    FROM v_quality
                   WHERE iql_cd_qlty = eom_cd_qlty_actl) grade_desc, eom_sec1,
        eom_sec2, eom_length, eom_idia, '' planned_width,
        eom_no_matnr1 materil_no1, '' material_desc1,
        eom_matnr1_qty eom_matnr1_qty, eom_no_matnr2 materil_no2,
        '' material_desc2, eom_matnr2_qty, eom_no_matnr3 materil_no3,
        '' material_desc3, eom_matnr3_qty, eom_no_matnr4 materil_no4,
        '' material_desc4, eom_matnr4_qty, eom_tdc_actl, 
        (SELECT TMA_GRADE FROM V_TDC_MAIN
WHERE TMA_TDC_NO = eom_tdc_actl) COIL_GRADE, 
eom_cd_yrd,
        eom_id_loc_x, eom_id_loc_y, eom_id_pos, eom_no_pieces,
        (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
                    FROM v_tc_coil_test
                   WHERE tco_prod_no = eom_id_first_par
                     AND tco_cast_no = eom_no_cast
                     AND tco_test_para IN ('UTS')
                     AND ROWNUM = 1) uts,
        (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
                    FROM v_tc_coil_test
                   WHERE tco_prod_no = eom_id_first_par
                     AND tco_cast_no = eom_no_cast
                     AND tco_test_para IN ('LYS', 'YS')
                     AND ROWNUM = 1) ys,
        eom_ms_piece_actl,
        NVL (eom_ms_gross_cal, 0) + NVL (eom_inv_loss, 0) gross_cal,
        eom_ms_scrap, eom_id_order_cus, eom_id_ord_item_cus, '' ord_typ,
        eom_cd_status,
        (SELECT DISTINCT eic_wo_no millord
                    FROM v_input_coil
                   WHERE eic_id_coil = eom_id_batch
                     AND eic_cd_epa = eom_cd_epa
                     AND ROWNUM = 1) millord,
        (SELECT DISTINCT eic_item_no mill_item
                    FROM v_input_coil
                   WHERE eic_id_coil = eom_id_batch
                     AND eic_cd_epa = eom_cd_epa
                     AND ROWNUM = 1) mill_item,    
        eom_no_matnr materil_no,
        (SELECT maktx
           FROM v_makt
          WHERE mandt = '600'
            AND matnr = eom_no_matnr
            AND ROWNUM = 1) material_desc,
        (SELECT eom_oper_comment
           FROM v_epa_prodn
          WHERE eom_id_batch = a.eom_id_batch
            AND eom_cd_epa <> '${data.Plant}'
            AND ROWNUM = 1) prv_spc_opr_comnts,
        ROUND ((SYSDATE - eom_ts_creation), 0) age_days,
        (SELECT eic_mk_customer
           FROM v_input_coil
          WHERE eom_cd_epa = a.eom_cd_epa
            AND eic_id_coil = a.eom_id_batch) mk_customer,
        eom_no_cast cast_no,
        (select nvl(eic_source_plant,eic_cd_plant) source_plant from v_input_coil
        where eom_cd_epa = a.eom_cd_epa
           AND eic_id_coil = a.eom_id_batch
           ) source_plant,(select LISTAGG(CAD_DEF2_COMM,' ; ') from v_coil_card
           where CAD_ID_COIL=a.eom_id_batch 
           and (CAD_DEF2_COMM like '@SLP%' OR CAD_DEF2_COMM LIKE 'SLP%')) SLP_REMARKS,
           (SELECT (chr_opr_remarks)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_opr_remarks is not null) and rownum=1) as opr_remarks
       ,(SELECT (chr_rls_remarks)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks is not null) and rownum=1) release_remarks
       ,(SELECT (chr_rls_remarks1)
          FROM v_coil_hold_rls where chr_id_coil = eom_id_batch
          and chr_ts_hold = (SELECT max(chr_ts_hold) FROM v_coil_hold_rls 
          WHERE chr_id_coil = eom_id_batch and chr_rls_remarks1 is not null) and rownum=1) release_remarks1
        ,(select EIC_POST_TREAT_ACTL from v_input_coil 
          WHERE eic_id_coil = eom_id_batch
          AND eic_cd_epa = eom_cd_epa
          AND ROWNUM = 1) POST_TREAT_ACTL
          FROM v_epa_prodn a
          WHERE eom_cd_epa = '${data.Plant}'
            AND eom_cd_status IN (select CD_VALUE  from v_codes WHERE CD_TYPE='TK006')
            AND eom_ms_gross_cal >= 0  `;

      // if (data?.Schd && data?.Schd?.length > 0 && data?.Schd === "RM") {
      //   QrygetCoils += `AND eom_id_batch = eom_id_first_par`;
      // }

      if (data?.Schd && data?.Schd?.length > 0 && data?.Schd === "RM") {
        QrygetCoils += `AND eom_cd_status in ('VF', 'VG')`;
      }

      if (data?.Schd && data?.Schd?.length > 0 && data?.Schd === "WIP") {
        if (data?.Process?.length > 0)
          QrygetCoils += `AND eom_cd_status in (select CD_VALUE from v_codes
            WHERE CD_TYPE='TK006' AND CD_DESC1 = '${data?.Process}'||'-'||'${data?.Schd}')`;
      }

      if (
        data?.Status &&
        Array.isArray(data?.Status) &&
        data?.Status.length > 1
      ) {
        if (
          data?.Status &&
          Array.isArray(data?.Status) &&
          data?.Status.length > 1
        ) {
          let dt = data?.Status.map((d: any) => `'${d}'`).join();
          QrygetCoils += ` AND eom_cd_status in(` + dt + `) `;
        }
      } else {
        if (data?.Status && data?.Status?.length > 0) {
          QrygetCoils += ` AND eom_cd_status = nvl('${
            Array.isArray(data?.Status) ? data?.Status[0] : data?.Status
          }', eom_cd_status) `;
        }
      }
      if (data?.BatchId && data?.BatchId?.length > 0) {
        QrygetCoils += ` AND EOM_ID_BATCH = '${data?.BatchId}' `;
      }
      if (data?.ThickFR && data?.ThickFR?.length > 0) {
        QrygetCoils += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFR}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFR}',EOM_SEC1))`;
      }
      if (data?.WidthFr && data?.WidthFr?.length > 0) {
        QrygetCoils += ` AND EOM_SEC2 BETWEEN NVL('${data?.WidthFr}',EOM_SEC2) AND NVL('${data?.WidthTo}',NVL('${data?.WidthFr}',EOM_SEC2))`;
      }
      if (data?.Tdc && data?.Tdc?.length > 0) {
        QrygetCoils += ` AND EOM_TDC_ACTL = '${data?.Tdc}' `;
      }
      if (data?.ProdCd && data?.ProdCd?.length > 0) {
        QrygetCoils += ` AND EOM_CD_PROD = '${data?.ProdCd}' `;
      }
      if (data?.FromDt && data?.FromDt?.length > 0) {
        QrygetCoils += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.FromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.ToDt}',NVL('${data.FromDt}',TRUNC(EOM_TS_CREATION)))`;
      }
      if (data?.Idia && data?.Idia?.length > 0) {
        QrygetCoils += ` AND EOM_IDIA = '${data?.Idia}' `;
      }
      // console.log("QrygetCoils: ", QrygetCoils);
      QrygetCoils += " order by EOM_TS_CREATION";
      return await query(QrygetCoils);
    } else if (data?.type === "computeData") {
      let sql = `call TPLB0001(
          p_plant => :p_plant,
          p_mcoil => :p_mcoil,
          p_process_ln  => :p_process_ln,
          p_subProc_ln  => :p_subProc_ln,
          p_planPath  => :p_planPath,
          p_order => :p_order,
          p_ordItm  => :p_ordItm,
          p_no_slt  => :p_no_slt,
          p_no_part => :p_no_part,
          p_ctl_pkt => :p_ctl_pkt,
          p_thk => :p_thk,
          p_width => :p_width,
          p_length  => :p_length,
          p_plan_wt => :p_plan_wt,
          p_aim_wt  => :p_aim_wt,
          p_setupno => :p_setupno, 
          p_user  => :p_user,
          p_row_seq => :p_row_seq,
          p_remarks => :p_remarks,
          p_fgGrade => :p_fgGrade,
          p_ctl_pkt_pcs => :p_ctl_pkt_pcs,
          p_schid => :p_schid,
          p_pack_cd => :p_pack_cd,
          p_oil_cd => :p_oil_cd,
          p_prog_id => :p_prog_id,
          ls_out_flag => :ls_out_flag
        )`;

      const binds = {
        p_plant: data?.p_plant,
        p_mcoil: data?.p_mcoil,
        p_process_ln: data?.p_process_ln,
        p_subProc_ln: data?.p_subProc_ln,
        p_planPath: data?.p_planPath,
        p_order: data?.p_order,
        p_ordItm: data?.p_ordItm,
        p_no_slt: data?.p_no_slt,
        p_no_part: data?.p_no_part ? data?.p_no_part : 1,
        p_ctl_pkt: data?.p_ctl_pkt,
        p_thk: data?.p_thk,
        p_width: data?.p_width,
        p_length: data?.p_length,
        p_plan_wt: data?.p_plan_wt,
        p_aim_wt: data?.p_aim_wt,
        p_setupno: data?.p_setupno,
        p_user: data?.p_user,
        p_row_seq: data?.p_row_seq,
        p_remarks: data?.p_remarks,
        p_fgGrade: data?.p_fgGrade,
        p_ctl_pkt_pcs: data?.p_ctl_pkt_pcs,
        p_schid: data?.p_schedule_id,
        p_pack_cd: data?.p_pack_cd,
        p_oil_cd: data?.p_oil_cd,
        p_prog_id: "SPS0005",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      return await query(sql, binds);
    } else if (data?.type === "confirmData") {
      let currData = data;
      var sql = `call TPLB0002(
          p_plant => :p_plant,
          p_schd_no => :p_schd_no,
          p_user  => :p_user,
          ls_out_flag => :ls_out_flag
        )`;

      const binds = {
        p_plant: currData?.data?.plantId,
        p_schd_no: currData?.data?.scheId,
        p_user: currData?.data?.UserID,
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      return await query(sql, binds);
    } else if (data?.type === "packingCode") {
      if (data.Plant) {
        return {
          packingCode: await ResponceData(
            await query(`
             SELECT TPM_PACK_CD PACK_CD FROM V_PACK_MASTER
             WHERE TPM_CD_EPA = '${data.Plant}' 
             AND TPM_MARK_CUST = '${data.MarkCust}'
             `)
          ),
          oilingCode: await ResponceData(
            await query(`
           SELECT TOM_OIL_CD OIL_CD FROM V_OILING_MASTER
            WHERE TOM_CD_EPA ='${data.Plant}' 
            AND TOM_MARK_CUST = '${data.MarkCust}'
            AND NVL(TRIM(TOM_CUST_TDC),' ') =NVL(NULL,'${data.Tdc}')
           `)
          ),
        };
      }
    } else if (data?.type === "getSubProcData") {
      let qry = `select CD_DESC1 SUB_PROC_LINE, CD_DESC1 || ' - ' || CD_DESC SUB_PROC_LINE_DESC 
          from V_CODES where CD_TYPE = 'TK015' and CD_VALUE = '${data.procLine}'`;
      return {
        subProcLine: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "getOrdTDCList") {
      // let qry = `SELECT
      //                   eom_tdc_actl   fitting_tdc
      //               FROM
      //                   v_epa_prodn
      //               WHERE
      //                   eom_cd_epa = '${data?.Plant}'
      //                   AND eom_id_batch = '${data?.Coil_ID}' -- COIL ID
      //               UNION
      //               SELECT
      //                   esp_tdc_downgrade   fitting_tdc
      //               FROM
      //                   v_epa_seconds_prime_tdc
      //               WHERE
      //                   esp_cd_epa = '${data?.Plant}'
      //                   AND esp_tdc_prime = '${data.Coil_TDC}'  -- COIL TDC
      //                   AND esp_status = 'A'`;
      // console.log(qry);
      let ordTdc = `SELECT
                        eom_tdc_actl   
                    FROM
                        v_epa_prodn
                    WHERE
                        eom_cd_epa = '${data?.Plant}'
                        AND eom_id_batch = '${data?.Coil_ID}' -- COIL ID`;

      let downgradeTdc = `SELECT
                        distinct esp_tdc_downgrade   
                    FROM
                        v_epa_seconds_prime_tdc
                    WHERE
                        esp_cd_epa = '${data?.Plant}'
                        AND esp_tdc_prime = '${data.Coil_TDC}'  -- COIL TDC
                        AND esp_status = 'A'`;

      let diversionTdc = `select TDM_END_TDC DIV_TDC from v_tdc_map 
                          where TDM_ACT_TDC = '${data.Coil_TDC}'
                          and TDM_CD_EPA = '${data?.Plant}'
                          and TDM_CD_STATUS = 'A'`;
      // ` SELECT TIC_TDC_NO FROM v_coil_tdc
      //                 where tic_id_coil='${data?.Coil_ID}' `;
      return {
        ordTDCList: await ResponceData(await query(ordTdc)),
        downgradeTDCList: await ResponceData(await query(downgradeTdc)),
        diversionTDCList: await ResponceData(await query(diversionTdc)),
      };
    } else if (data?.type === "checkPackingFlag") {
      let qry = `select LENGTH(substr('${data?.planPath}',1,LENGTH('${data?.planPath}')-2)) LN_PRC_CNT
                   FROM DUAL`;
      return {
        selectedPlanPath: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "getActivityNMData") {
      let qry = `select EPL_ACTIVITY_NM
      FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= '${data.Plant}'
      AND EPL_CD_PROCESS = '${data.procLine}'
      `;
      return { activityNM: await ResponceData(await query(qry)) };
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getOrderData = async (data: any) => {
  try {
    let sql: any = `SELECT
                    enc_id_order,
                    enc_no_item,
                    enc_ord_quantity,
                    (SELECT F_BAL_TO_ROLL('131',enc_id_order,enc_no_item)BTR FROM DUAL) AS BTR,
                    enc_no_tdc,
                    enc_sec1_min,    
                    enc_sec1_max, 
                    enc_sec2_min,
                    enc_sec2_max,
                    enc_length_max,
                    (SELECT f_get_SAPGRADE('${data.plant}',enc_id_order,enc_no_item) FROM DUAL) PLANGRADE,
                    ENC_MAX_PIECE_WT,
                    ENC_MIN_PIECE_WT,
                    ENC_IDIA,                 
                    ENC_CD_QLTY,
                    enc_mark_cust,
                    enc_mark_cust_name,
                    enc_order_type,
                    enc_cd_end_cust,
                    enc_cust_name,
                    enc_no_matnr,
                    enc_order_edge,
                    ( SELECT
                            nvl(maktx, ' ')
                        FROM
                            v_makt
                        WHERE
                            mandt = '600'
                            AND matnr = enc_no_matnr
                    ) material_desc,
                    enc_cd_prod,                    
                    TO_CHAR(enc_dt_ord_create) enc_dt_ord_create,
                    NVL(TO_CHAR(enc_dt_delv, 'dd-mm-yyyy'),' ') enc_dt_delv,
                    enc_ord_desc,
                    nvl(enc_roaddest_desc,' ') enc_roaddest_desc,
                    nvl(enc_raildest_desc,' ') enc_raildest_desc,
                    enc_cd_epa
                    ,ENC_POST_TREAT ORDER_POST_TREAT
                    -- nvl(SUM(DECODE(eom_cd_status, 'WL', eom_ms_gross_cal)),0) desp,  -- REMOVE
                    -- nvl(SUM(DECODE(eom_cd_status, 'WB', eom_ms_gross_cal)), 0) displ, -- REMOVE
                    -- nvl(SUM(DECODE(substr(eom_cd_status, 2, 1), 'B', eom_ms_gross_cal)), 0) linked,  -- REMOVE
                    --enc_cd_qlty
                FROM
                    v_end_cust_ord_epa
                    -- v_epa_prodn -- REMOVE
                WHERE
                  enc_cd_epa = '131'
                  AND enc_order_type = nvl('${data?.orderType}', enc_order_type)
                  AND enc_st_order = 'A'
                  AND ENC_ORD_QUANTITY != '0.001'
                  -- AND eom_id_order_cus (+) = enc_id_order -- REMOVE
                  -- AND eom_id_ord_item_cus (+) = enc_no_item  -- REMOVE
                  `;
    if (data?.orderId && data?.orderId?.length > 0) {
      sql += ` and enc_id_order = ${data?.orderId}`;
    }

    if (data?.orderItem && data?.orderItem?.length > 0) {
      sql += ` and ENC_NO_ITEM =  ${data?.orderItem}`;
    }

    if (data?.orderTDC && data?.orderTDC?.length > 0) {
      sql += ` and enc_no_tdc = '${data?.orderTDC}'`;
    }

    if (data?.orderType && data?.orderType?.length > 0) {
      sql += ` and enc_order_type = '${data?.orderType}'`;
    }

    if (data?.orderThick && data?.orderThick?.length > 0) {
      sql += ` and ${data?.orderThick}  between  enc_sec1_min and enc_sec1_max `;
    }

    if (data?.orderWidth && data?.orderWidth?.length > 0) {
      sql += ` and ${data?.orderWidth}  between  enc_sec2_min and enc_sec2_max `;
    }

    if (data?.planPath?.includes("N") || data?.planPath?.includes("T")) {
      sql += `and enc_length_max > 0 `;
    }

    sql += ` GROUP BY
              enc_id_order,
              enc_no_item,
              ENC_CD_QLTY,
              ENC_IDIA,
              enc_ord_quantity,
              enc_no_tdc,
              enc_cd_epa,
              enc_sec1_min,   
              enc_sec1_max,    
              enc_sec2_min,
              enc_sec2_max,
              enc_length_max,
              enc_cust_name,
              enc_order_type,
              enc_cd_prod,
              enc_order_type,
              enc_dt_ord_create,
              enc_dt_delv,
              enc_mark_cust,
              enc_mark_cust_name,
              enc_ord_desc,
              enc_roaddest_desc,
              enc_raildest_desc,
              enc_cd_end_cust,
              enc_no_matnr,
              enc_cd_qlty,
              ENC_MAX_PIECE_WT,
              ENC_MIN_PIECE_WT,
              enc_order_edge,
              ENC_POST_TREAT`;

    console.log("sql-order data:: ", sql);
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const scheduleID = async () => {
  try {
    let sql: any = `SELECT EPA_SCH_SEQ.NEXTVAL SCH_ID FROM DUAL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getDiversionRes = async (data: any) => {
  try {
    console.log("DivData: ", data);
    let sql: any = `call TRMQ0007(
      coilid => :coilid,             
      qltycd => :qltycd,              
      tdcno => :tdcno,                
      ls_out_flag => :ls_out_flag       
    )`;
    const binds = {
      coilid: data?.coilId ? data?.coilId : "",
      qltycd: data?.qltyCd ? data?.qltyCd : "",
      tdcno: data?.tdc ? data?.tdc : "",
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    console.log("DivSql: ", sql);
    console.log("DivBinds: ", binds);
    const result = await query(sql, binds);
    console.log("DivResult: ", result);
    return result;
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
