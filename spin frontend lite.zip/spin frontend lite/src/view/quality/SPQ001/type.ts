

export interface InputDownType {
    key1: string,
    key2: string,
    key3: string,
    key4: string,
    key5: string,
    key6: string,
    key7: string,
    key8: string,
    key9: string,
}

export interface TableType {
    EPL_CD_EPA: string,
    EPL_CD_EPA_DESC:string

}