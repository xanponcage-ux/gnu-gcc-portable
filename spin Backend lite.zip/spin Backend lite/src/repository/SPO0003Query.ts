import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const SPO0003Query = async (data: any) => {
  try {
    // ****** PDI Request Started
    if (data?.type === "PDI_REQ_SL") {
      var sql = "";
      if (data?.data === "S") {
        sql = `INSERT INTO V_SL_REQ_PDI (
                  rrp_id_sor_appl,
                  rrp_id_destn_appl,
                  rrp_id_message,
                  rrp_reserved_1,
                  rrp_reserved_2,
                  rrp_no_pdi_req
              ) VALUES (
                  'L3_BKP',
                  'SPC_IS',
                  f_nannow_second_telgrm(SYSDATE),
                  'N',
                  'N',
                  1
              )`;
      }
      if (data?.data === "T") {
        sql = `INSERT INTO V_WCTL_REQ_PDI (
                wct_id_sor_appl,
                wct_id_destn_appl,
                wct_id_message,
                wct_reserved_1,
                wct_reserved_2,
                wct_no_pdi_req
            ) VALUES (
                'L3_BKP',
                'SPC_IS',
                f_nannow_second_telgrm(SYSDATE),
                'N',
                'N',
                1
            )`;
      } else if (data?.data === "N") {
        sql = `INSERT INTO V_NCTL_REQ_PDI (
                nct_id_sor_appl,
                nct_id_destn_appl,
                nct_id_message,
                nct_reserved_1,
                nct_reserved_2,
                nct_no_pdi_req
            ) VALUES (
                'L3_BKP',
                'SPC_IS',
                f_nannow_second_telgrm(SYSDATE),
                'N',
                'N',
                1
            )`;
      }
      return await query(sql);
    }

    //****** PDI Request Ended
    //****** Send Coil Supply Request Started
    if (data?.type === "getCoilList") {
      let qry = "";
      //-- Query for coil ID ready for coil supp req
      if (data?.data === "S") {
        qry = `SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
          WHERE PDS_CD_EPA='131'
          AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM='SLT')
          AND PDS_CD_STATUS   = 'WW'
          ORDER BY 1`;
      }
      if (data?.data === "N" || data?.data === "T" || data?.data === "E") {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qry = `SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
          WHERE PDC_CD_EPA='131'
          AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
          WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
          AND PDC_CD_STATUS   = 'WW'
          ORDER BY 1`;
      }
      return {
        suppCoilList: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "SEND_COIL_SUPP") {
      var sql = "";
      if (data?.data.proc === "S") {
        sql = `INSERT INTO v_sl_cl_sply_req (
                    rsq_id_sor_appl,
                    rsq_id_destn_appl,
                    rsq_id_message,
                    rsq_reserved_1,
                    rsq_reserved_2,
                    rsq_id_coil
                ) VALUES (
                    'L3_BKP',
                    'SPC_IS',
                    f_nannow_second_telgrm(SYSDATE),
                    'N',
                    'N',
                    :ls_coil
                )`;
      } else if (data?.data.proc === "T") {
        sql = ` INSERT INTO tskepadba.t_wctl_cl_sply_req (
                  wcq_id_sor_appl,
                  wcq_id_destn_appl,
                  wcq_id_message,
                  wcq_reserved_1,
                  wcq_reserved_2,
                  wcq_id_coil
              ) VALUES (
                  'L3_BKP',
                  'SPC_IS',
                  f_nannow_second_telgrm(SYSDATE),
                  'N',
                  'N',
                  :ls_coil
              )`;
      } else if (data?.data.proc === "N") {
        sql = ` INSERT INTO tskepadba.t_nctl_cl_sply_req (
                  ncq_id_sor_appl,
                  ncq_id_destn_appl,
                  ncq_id_message,
                  ncq_reserved_1,
                  ncq_reserved_2,
                  ncq_id_coil
              ) VALUES (
                  'L3_BKP',
                  'SPC_IS',
                  f_nannow_second_telgrm(SYSDATE),
                  'N',
                  'N',
                  :ls_coil
              )`;
      }
      const binds = {
        ls_coil: data?.data.coilId ? data?.data.coilId : "",
      };
      return await query(sql, binds);
    }
    // ******** Send Coil Supply Request Ended
    // ******** Register Coil supply Completion Started
    else if (data?.type === "getCoilCompList") {
      //-- Query for coil ID ready for coil supp compl request
      let qry = "";
      if (data?.data === "S") {
        qry = `SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
              WHERE PDS_CD_EPA='131'
              AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM='SLT')
              AND PDS_CD_STATUS   = 'US'
              ORDER BY 1`;
      }
      if (data?.data === "N" || data?.data === "T" || data?.data === "E") {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qry = ` SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
        WHERE PDC_CD_EPA='131'
        AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
        WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
        AND PDC_CD_STATUS   = 'US'
        ORDER BY 1`;
      }
      return {
        suppCoilCompList: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "SEND_COIL_SUPP_COMP") {
      var sql = "";
      if (data?.data.proc === "S") {
        sql = ` INSERT INTO v_yms_sl_sup_comp (
                      ysc_id_sor_appl,
                      ysc_id_destn_appl,
                      ysc_id_message,
                      ysc_reserved_1,
                      ysc_reserved_2,
                      ysc_id_coil,
                      ysc_id_pdi,
                      ysc_position
                  ) VALUES (
                      'L3_BKP',
                      'YMS',
                      f_nannow_second_telgrm(SYSDATE),
                      'N',
                      'N',
                      :ls_coil,
                      NULL,    -- YSC_ID_PDI
                      NULL      -- YSC_POSITION
                  )`;
      } else if (data?.data.proc === "N") {
        sql = ` INSERT INTO tskepadba.t_yms_nctl_sup_comp (
                    nsc_id_sor_appl,
                    nsc_id_destn_appl,
                    nsc_id_message,
                    nsc_reserved_1,
                    nsc_reserved_2,
                    nsc_id_coil,
                    nsc_cd_proc,
                    nsc_id_pdi,
                    nsc_position
                ) VALUES (
                  'L3_BKP',
                  'YMS',
                  f_nannow_second_telgrm(SYSDATE),
                  'N',
                  'N',
                  :ls_coil,
                  NULL,    -- nsc_cd_proc
                  NULL,    -- nsc_id_pdi
                  NULL      -- nsc_position
                )`;
      } else if (data?.data.proc === "T") {
        sql = ` INSERT INTO tskepadba.t_yms_wctl_sup_comp (
                    wsc_id_sor_appl,
                    wsc_id_destn_appl,
                    wsc_id_message,
                    wsc_reserved_1,
                    wsc_reserved_2,
                    wsc_id_coil,
                    wsc_cd_proc,
                    wsc_id_pdi,
                    wsc_position
                ) VALUES (
                  'L3_BKP',
                  'YMS',
                  f_nannow_second_telgrm(SYSDATE),
                  'N',
                  'N',
                  :ls_coil,
                  NULL,    -- nsc_cd_proc
                  NULL,    -- nsc_id_pdi
                  NULL      -- nsc_position
                )`;
      }
      const binds = {
        ls_coil: data?.data.coilId ? data?.data.coilId : "",
      };
      return await query(sql, binds);
    }
    // ******** Register Rejection Started
    else if (data?.type === "getRejectCoilList") {
      //-- Query for coil ID ready for coil supp compl request
      let qry = "";
      if (data?.data === "S") {
        qry = `SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
              WHERE PDS_CD_EPA='131'
              AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM='SLT')
              AND PDS_CD_STATUS   = 'UP'
              ORDER BY 1`;
      }
      if (data?.data === "N" || data?.data === "T" || data?.data === "E") {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qry = ` SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
        WHERE PDC_CD_EPA='131'
        AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
        WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
        AND PDC_CD_STATUS   = 'UP'
        ORDER BY 1`;
      }
      return {
        RejectCoilList: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "REJECT_COIL_SAVE") {
      var sql = "";
      if (data?.data.proc === "S") {
        sql = `Insert into V_SL_REJECT_COIL
         (RMD_ID_SOR_APPL, RMD_ID_DESTN_APPL, RMD_ID_MESSAGE, RMD_REVERSED_1, RMD_REVERSED_2, 
          RMD_ID_COIL, RMD_CD_RSN1, RMD_REJT_TYPE)
          Values
            ('L3_BKP', 'SPC_IS', f_nannow_second_telgrm(SYSDATE), 'N', 'N', 
             :ls_coil, NULL, NULL) `;
      } else if (data?.data.proc === "N") {
        sql = `Insert into V_NCTL_REJECT_COIL
            (NCD_ID_SOR_APPL, NCD_ID_DESTN_APPL, NCD_ID_MESSAGE, NCD_REVERSED_1, NCD_REVERSED_2, 
             NCD_ID_COIL, NCD_CD_RSN1, NCD_REJT_TYPE)
           Values
             ('L3_BKP', 'SPC_IS', f_nannow_second_telgrm(SYSDATE), 'N', 'N', 
              :ls_coil, NULL, NULL) `;
      } else if (data?.data.proc === "T") {
        sql = `Insert into V_WCTL_REJECT_COIL
          (WCD_ID_SOR_APPL, WCD_ID_DESTN_APPL, WCD_ID_MESSAGE, WCD_REVERSED_1, WCD_REVERSED_2, 
           WCD_ID_COIL, WCD_CD_RSN1, WCD_REJT_TYPE)
           Values
             ('L3_BKP', 'SPC_IS', f_nannow_second_telgrm(SYSDATE), 'N', 'N', 
              :ls_coil, NULL, NULL) `;
      }
      const binds = {
        ls_coil: data?.data.coilId ? data?.data.coilId : "",
      };
      return await query(sql, binds);
    }
    // ******** Register Rejection Ended
    // ******** Register Coil supply Completion Ended
    // ******** Daughter Report Started
    else if (data?.type === "getDRMotherCoilList") {
      //-- Query for Mother Coil List
      let qry = "";
      if (data?.data === "S") {
        qry = ` SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
        WHERE PDS_CD_EPA='131'
        AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM='SLT')
        AND PDS_CD_STATUS   = 'WW'
        ORDER BY 1`;
      }
      if (data?.data === "N" || data?.data === "T" || data?.data === "E") {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qry = `SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
        WHERE PDC_CD_EPA='131'
        AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
        WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
        AND PDC_CD_STATUS   = 'WW'
        ORDER BY 1`;
      }
      return {
        drMotherCoilList: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "getDaughterReportData") {
      //-- Query for Daughter Coil List
      let qry = "";
      if (data?.data === "S") {
        qry = `SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
        WHERE PDS_CD_EPA='131'
        AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM='SLT')
        AND PDS_CD_STATUS   = 'UP'
        ORDER BY 1`;
      }
      if (data?.data === "N" || data?.data === "T" || data?.data === "E") {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qry = `SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
        WHERE PDC_CD_EPA='131'
        AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
        WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
        AND PDC_CD_STATUS   = 'UP'
        ORDER BY 1`;
      }
      return {
        drMotherCoilList: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "getPDIList") {
      let qryPdiList = "";
      if (data?.data.proc === "S") {
        qryPdiList = `select DISTINCT pds_pdi from v_pr_data_ip_slt 
      where pds_cd_epa = '131' 
      AND PDS_CD_STATUS   = 'UP' 
      and pds_id_coil = '${data.data.motherCoil}'`;
      } else if (
        data?.data.proc === "N" ||
        data?.data.proc === "T" ||
        data?.data.proc === "E"
      ) {
        qryPdiList = `select DISTINCT pdc_pdi pds_pdi,pdc_order ,pdc_item_no ,pdc_thick ,pdc_width ,
            pdc_out_tdc ,pdc_cut_length from v_pr_data_ip_ctl 
        where pdc_cd_epa='131'
        and pdc_cd_status   = 'UP'
        and pdc_id_coil = '${data.data.motherCoil}'`;
      }
      return {
        pdiList: await ResponceData(await query(qryPdiList)),
      };
    } else if (data?.type === "getDaughterCoilList") {
      try {
        const { proc, motherCoil } = data.data;
        const pdiCount: number = 10;
        const finalResult: any[] = [];
        for (let i = 1; i <= pdiCount; i++) {
          const qry = `
                SELECT SUBSTR(F_GET_FGBATCH(:motherCoil,sysdate,:proc,${i}),3,13) DT_COIL_LIST 
                FROM DUAL`;
          const result = await ResponceData(query(qry, { proc, motherCoil }));

          finalResult.push(result.rows[0][0]);
        }
        return {
          drDaughterCoilList: await ResponceData(finalResult),
        };
      } catch (error: any) {
        //return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
      }
    } else if (data?.type === "getOrderDetails") {
      let qryOrdDtls = "";
      if (data?.data?.proc === "S") {
        qryOrdDtls = `SELECT pds_pdi, pds_order, pds_item_no, pds_thick, pds_width, pds_idia,
       pds_odia, pds_out_tdc, pds_no_part, pds_slit_width, pds_nxt_proc,
       pds_planned_proc, pds_oil_type,
       pds_pack_code, enc_order_edge
      from v_pr_data_ip_slt a join v_end_cust_ord_epa b on a.pds_order = b.ENC_ID_ORDER and a.PDS_ITEM_NO = b.ENC_NO_ITEM
      WHERE pds_cd_epa = '131'
        AND pds_id_coil = '${data.data.motherCoil}'
        AND pds_pdi = '${data.data.idPdi}'`;
      } else if (
        data?.data?.proc === "N" ||
        data?.data?.proc === "T" ||
        data?.data?.proc === "E"
      ) {
        qryOrdDtls = `select pdc_pdi pds_pdi,pdc_order pds_order,pdc_item_no pds_item_no,pdc_thick pds_thick,pdc_width pds_width,
            pdc_idia pds_idia,pdc_odia pds_odia,pdc_out_tdc pds_out_tdc,pdc_no_part pds_no_part,pdc_pallet_width pds_slit_width,
            pdc_cut_length pds_cut_length, pdc_pack_code pds_pack_code, PDC_NXT_PROC PDS_NXT_PROC, PDC_NO_SHEETS
            from v_pr_data_ip_ctl 
            where pdc_cd_epa = '131' 
            and pdc_id_coil = '${data.data.motherCoil}' 
            and pdc_pdi = '${data.data.idPdi}' `;
      }
      return {
        OrderDetails: await ResponceData(await query(qryOrdDtls)),
      };
    } else if (data?.type === "getDautrCoilCount") {
      const qry = `select count(1) DAUTR_COIL_CNT from V_SL_DAUTR_COIL 
      where RDC_ID_INPUT_COIL = '${data.data.motherCoil}' 
      and RDC_ID_PDI = ${data.data.idPdi}`;
      return {
        dautrCoilCount: await ResponceData(await query(qry)),
      };
    }
    // ******** Daughter Report Ended
    // else if (data ?.type === "getPackingList") {
    //   return {
    //     PackingList: await ResponceData(
    //       await query(`
    //             SELECT tpm_pack_cd FROM v_pack_master
    //             WHERE tpm_cd_epa = '131' AND tpm_mark_cust IN (
    //             SELECT enc_mark_cust FROM v_end_cust_ord_epa
    //             WHERE enc_cd_epa = '131'
    //             AND enc_id_order = '${data.data.order}'
    //             AND enc_no_item = '${data.data.ordItem}')
    //            `)
    //     ),
    //     OrderDetails: await ResponceData(
    //       await query(`
    //       select enc_id_order,enc_no_item, enc_sec1_min, enc_sec1_max,
    //       enc_sec2_min, enc_sec2_max,enc_length_min,enc_length_max,enc_idia,enc_odia
    //       from
    //       v_end_cust_ord_epa
    //       where enc_cd_epa = '131'
    //       and enc_id_order = '${data.data.order}'
    //       and enc_no_item ='${data.data.ordItem}'
    //       and rownum = 1
    //       `)
    //     ),
    //   };
    // }
    // ******** Mother Report Started
    else if (data?.type === "getMotherReportData") {
      let qryMotherReport = "";

      if (data?.data === "S") {
        qryMotherReport = ` SELECT DISTINCT PDS_ID_COIL ID_COIL FROM V_PR_DATA_IP_SLT 
        WHERE PDS_CD_EPA='131'
        AND  PDS_CURR_PROC = (SELECT EPL_CD_PROCESS 
        FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' 
        AND EPL_ACTIVITY_NM='SLT')
        AND PDS_CD_STATUS   = 'UP'
        ORDER BY 1`;
      } else if (
        data?.data === "N" ||
        data?.data === "T" ||
        data?.data === "E"
      ) {
        let process: any =
          data?.data === "T" ? "WCTL" : data?.data === "N" ? "NCTL" : "";
        qryMotherReport = ` SELECT DISTINCT PDC_ID_COIL ID_COIL FROM V_PR_DATA_IP_CTL 
        WHERE PDC_CD_EPA='131'
        AND  PDC_CURR_PROC in (SELECT EPL_CD_PROCESS FROM V_EPA_PROC_LINE 
        WHERE EPL_CD_EPA='131' AND EPL_ACTIVITY_NM in ('${process}'))
        AND PDC_CD_STATUS   = 'UP'
        ORDER BY 1`;
      }
      return {
        mrMotherCoilList: await ResponceData(await query(qryMotherReport)),
      };
    } else if (data?.type === "getMotherCoilDetails") {
      let qryMotherDtls = "";
      if (data?.data.proc === "S") {
        qryMotherDtls = ` select  pds_cd_epa,pds_id_coil,pds_thick THICK,
        pds_slit_width WIDTH,pds_length,pds_nxt_proc,
        pds_planned_proc,pds_out_tdc, pds_out_grade_desc
        from v_pr_data_ip_slt a where pds_cd_epa = '131' 
        and  pds_id_coil = '${data.data.motherCoil}'
        and pds_cd_Status = 'UP' and rownum = 1
        `;
      } else if (
        data?.data.proc === "N" ||
        data?.data.proc === "T" ||
        data?.data.proc === "E"
      ) {
        qryMotherDtls = `  select EOM_SEC2 WIDTH, EOM_ACT_THICK THICK from v_epa_prodn
        where EOM_ID_BATCH = '${data.data.motherCoil}'
        `;
      }
      return {
        motherCoilDtls: await ResponceData(await query(qryMotherDtls)),
      };
    }
    // ******** Mother Report Ended
    else if (data?.type === "getOrderList") {
      return {
        order: await ResponceData(
          await query(` select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
                FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= '131' ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS`)
        ),
      };
    } else if (data?.type === "getDivisionData") {
      //-- Query for coil ID ready for Entry Division.
      let varData =
        data?.data?.process === "S"
          ? "SLT"
          : data?.data?.process === "N"
          ? "NCTL"
          : data?.data?.process === "T"
          ? "WCTL"
          : "";
      var sqlSlt = `SELECT DISTINCT PDS_ID_COIL ID_COIL 
                FROM V_PR_DATA_IP_SLT 
                WHERE PDS_CD_EPA='131'
                AND  PDS_CURR_PROC IN (SELECT EPL_CD_PROCESS 
                  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' 
                  AND EPL_ACTIVITY_NM= '${varData}')
                AND PDS_CD_STATUS   IN ('WW','UP')
                AND SUBSTR(PDS_ID_COIL, 1, 2) NOT IN ('PK', 'GS')
                ORDER BY 1`;
      var sqlCtl = `SELECT DISTINCT PDC_ID_COIL ID_COIL 
                FROM V_PR_DATA_IP_CTL
                WHERE PDC_CD_EPA='131'
                AND  PDC_CURR_PROC IN (SELECT EPL_CD_PROCESS 
                  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131' 
                  AND EPL_ACTIVITY_NM= '${varData}')
                AND PDC_CD_STATUS   IN ('WW','UP')
                AND SUBSTR(PDC_ID_COIL, 1, 2) NOT IN ('PK', 'GS')
                ORDER BY 1`;
      var sqlFin = ``;
      if (varData === "SLT") {
        sqlFin = sqlSlt;
      } else {
        sqlFin = sqlCtl;
      }
      console.log("sqlFin-getDivisionData: ", sqlFin);

      const result = await ResponceData(await query(sqlFin));
      console.log("result-getDivisionData: ", result);
      return {
        divMotherCoilList: result,
        // await ResponceData(
        //   await query(`
        //         SELECT DISTINCT PDS_ID_COIL ID_COIL
        //         FROM V_PR_DATA_IP_SLT
        //         WHERE PDS_CD_EPA='131'
        //         AND  PDS_CURR_PROC IN (SELECT EPL_CD_PROCESS
        //           FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA='131'
        //           AND EPL_ACTIVITY_NM= '${varData}')
        //         AND PDS_CD_STATUS   IN ('WW','UP')
        //         ORDER BY 1
        //         `)
        // ),
        entDivReasonList: await ResponceData(
          await query(`select cd_value, cd_value ||' - '|| cd_desc cd_desc
          from v_codes  where cd_type = 'TK017'
          `)
        ),
      };
    } else if (data?.type === "getZCoilList") {
      return {
        divZCoilList: await ResponceData(
          await query(`select SUBSTR(F_ZBATCH_ENTDIV('${data.data.mCoilId}','${data.data.proc}'),3,13) ZBATCH_ENTDIV 
        from dual`)
        ),
      };
    }
    // ActionNM fetch from proce line table
    else if (data?.type === "getActionName") {
      let sql = `select EPL_ACTIVITY_NM from v_epa_proc_line 
    where EPL_CD_EPA = '131' AND  EPL_CD_PROCESS = '${data.data}'`;
      return {
        actionName: await ResponceData(await query(sql)),
      };
    }
    // Check for seconds tdc.
    else if (data?.type === "chkSecondsTdc") {
      let sql = `SELECT COUNT(1) FROM V_EPA_SECONDS_PRIME_TDC
    WHERE ESP_CD_EPA='131'
    AND ESP_TDC_DOWNGRADE = '${data.data}'`;
      return {
        secondsFlag: await ResponceData(await query(sql)),
      };
    } else if (data?.type === "getPackingCoilList") {
      return {
        packingCoilList: await ResponceData(
          await query(` 
             SELECT DISTINCT CID_ID_COIL PDC_ID_COIL 
            FROM V_PR_DATA_IP_CPL
            WHERE CID_CD_EPA='131'
            and CID_CD_STATUS in ('WC', 'WS')
            `)
        ),
      };
    } else if (data?.type === "getPackingCoilDtls") {
      return {
        packingCoilDtls: await ResponceData(
          await query(` 
            SELECT CID_WIDTH PDC_WIDTH, CID_THICK PDC_THICK, CID_ODIA PDC_ODIA, CID_IDIA PDC_IDIA,
            CID_MASS, CID_PACK_CODE 
            FROM V_PR_DATA_IP_CPL 
            WHERE CID_CD_EPA='131'
            and CID_CD_STATUS = 'WC'
            and CID_ID_COIL = '${data.data.pCoilId}'
            `)
        ),
      };
    } else if (data?.type === "getPackingCdList") {
      return {
        packingCdList: await ResponceData(
          await query(` 
          select distinct TPM_PACK_CD from V_PACK_MASTER 
          WHERE TPM_CD_EPA = '131' order by 1 
            `)
        ),
      };
    }
    // Save button on daughter report
    else if (data?.type === "SL_DAUGHTER_REP") {
      if (data?.data.actName === "SLT") {
        console.log("data: ", data);
        var sql = ` INSERT INTO V_SL_DAUTR_COIL
            (RDC_ID_SOR_APPL
            ,RDC_ID_DESTN_APPL
            ,RDC_ID_MESSAGE
            ,RDC_RESERVED_1
            ,RDC_RESERVED_2
            ,RDC_ID_COIL
            ,RDC_SLIT_POS
            ,RDC_BATCH_START
            ,RDC_BATCH_END
            ,RDC_ID_INPUT_COIL
            ,RDC_TS_PROC_STRT
            ,RDC_TS_PROC_END
            ,RDC_CAL_MASS
            ,RDC_NET_MASS
            ,RDC_GROSS_MASS
            ,RDC_WIDTH
            ,RDC_THICK
            ,RDC_MAX_SPEED
            ,RDC_AVG_SPEED
            ,RDC_LENGTH
            ,RDC_ODIA
            ,RDC_IDIA
            ,RDC_RECOILER_TENSION
            ,RDC_RECOILER_TAPER
            ,RDC_OIL_TYPE
            ,RDC_OIL_MAX_QTY
            ,RDC_OIL_MIN_QTY
            ,RDC_REMARKS
            ,RDC_ORDER
            ,RDC_ITEM_NO
            ,RDC_CUST_DESC
            ,RDC_HOLD_FLAG
            ,RDC_HOLD_CODE
            ,RDC_TDC
            ,RDC_GRADE_DESC
            ,RDC_TRIM
            ,RDC_PACK_CODE
            ,RDC_CURR_PROC
            ,RDC_NXT_PROC
            ,RDC_PLANNED_PROC
            ,RDC_ACTL_PROC_PATH
            ,RDC_PART_NUMBER
            ,RDC_EDGE_WAVINESS
            ,RDC_CENTRE_BUCKLE
            ,RDC_CROSSBOW
            ,RDC_BURR_HEIGHT
            ,RDC_SURF_REQ
            ,RDC_HORIZONTAL_GAP
            ,RDC_VERTICAL_GAP
            ,RDC_WIDTH_TOL
            ,RDC_NSPR1
            ,RDC_NSPR2
            ,RDC_NSPR3
            ,RDC_NSPR4
            ,RDC_NSPR5
            ,RDC_NSPR6
            ,RDC_NSPR7
            ,RDC_NSPR8
            ,RDC_NSPR9
            ,RDC_NSPR10
            ,RDC_CSPR1
            ,RDC_CSPR2
            ,RDC_CSPR3
            ,RDC_CSPR4
            ,RDC_CSPR5
            ,RDC_CSPR6
            ,RDC_CSPR7
            ,RDC_CSPR8
            ,RDC_CSPR9
            ,RDC_CSPR10
            ,RDC_ID_PDI
            )
            VALUES
            (
            'L3_BKP'                   --,RDC_ID_SOR_APPL
            ,'SPIN'                       --,RDC_ID_DESTN_APPL
            ,f_nannow_second_telgrm(SYSDATE)                       --,RDC_ID_MESSAGE
            ,'N'                       --,RDC_RESERVED_1
            ,'N'                       --,RDC_RESERVED_2
            ,:ls_daugt_batch                       --,RDC_ID_COIL
            ,:slitPosition                       --,RDC_SLIT_POS
            ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')                      --,RDC_BATCH_START
            ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')                      --,RDC_BATCH_END
            ,:ls_parent                       --,RDC_ID_INPUT_COIL
            ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')                        --,RDC_TS_PROC_STRT
            ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')                       --,RDC_TS_PROC_END
            ,:ls_net_wt                       --,RDC_CAL_MASS
            ,:ls_net_wt                       --,RDC_NET_MASS
            ,:ls_net_wt                       --,RDC_GROSS_MASS
            ,:ls_width                       --,RDC_WIDTH
            ,:ls_thk                       --,RDC_THICK
            ,0                       --,RDC_MAX_SPEED
            ,0                       --,RDC_AVG_SPEED
            ,:ls_coil_len                       --,RDC_LENGTH
            ,:ls_odia                       --,RDC_ODIA
            ,:ls_idia                       --,RDC_IDIA
            ,:recoilerTension                       --,RDC_RECOILER_TENSION
            ,0                       --,RDC_RECOILER_TAPER
            ,:oil_type                       --,RDC_OIL_TYPE
            ,0                       --,RDC_OIL_MAX_QTY
            ,0                       --,RDC_OIL_MIN_QTY
            ,:ls_opr_rem                       --,RDC_REMARKS
            ,:ls_ord                       --,RDC_ORDER
            ,:ls_item                       --,RDC_ITEM_NO
            ,''                       --,RDC_CUST_DESC
            ,:ls_hold_fl                       --,RDC_HOLD_FLAG
            ,:hold_cd  --'00'                       --,RDC_HOLD_CODE
            ,:ls_fgTdc                 --,RDC_TDC
            ,''                       --,RDC_GRADE_DESC
            ,''                       --,RDC_TRIM
            ,:ls_pack_cd                       --,RDC_PACK_CODE
            ,:ls_proc                       --,RDC_CURR_PROC
            ,:ls_nextProc                       --,RDC_NXT_PROC
            ,:ls_plannedProc                        --,RDC_PLANNED_PROC
            ,:ls_proc         --,RDC_ACTL_PROC_PATH
            ,:crNoPart                      --,RDC_PART_NUMBER
            ,:edgeWaviness                       --,RDC_EDGE_WAVINESS
            ,0                       --,RDC_CENTRE_BUCKLE
            ,0                       --,RDC_CROSSBOW
            ,:burrHeight                       --,RDC_BURR_HEIGHT
            ,'0'                       --,RDC_SURF_REQ
            ,0                       --,RDC_HORIZONTAL_GAP
            ,0                       --,RDC_VERTICAL_GAP
            ,0                       --,RDC_WIDTH_TOL
            ,0 --:ls_pdi                       --,RDC_NSPR1
            ,0                       --,RDC_NSPR2
            ,0                       --,RDC_NSPR3
            ,0                       --,RDC_NSPR4
            ,0                       --,RDC_NSPR5
            ,0                       --,RDC_NSPR6
            ,0                       --,RDC_NSPR7
            ,0                       --,RDC_NSPR8
            ,0                       --,RDC_NSPR9
            ,0                       --,RDC_NSPR10
            ,:coilEdgeCond --'0'     --,RDC_CSPR1
            ,:tescopicity --'0'      --,RDC_CSPR2
            ,:zigZagWind  --'0'      --,RDC_CSPR3
            ,:cutrMark  --'0'        --,RDC_CSPR4
            ,:oilCondn  --'0'        --,RDC_CSPR5
            ,'0'                       --,RDC_CSPR6
            ,'0'                       --,RDC_CSPR7
            ,'0'                       --,RDC_CSPR8
            ,'0'                       --,RDC_CSPR9
            ,'0'                       --,RDC_CSPR10
            ,:ls_pdi                    -- RDC_ID_PDI
            )`;
        const binds = {
          //flag: data ?.type,
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          ls_daugt_batch: data?.data.daughterCoil
            ? data?.data.daughterCoil
            : "",
          ls_ord: data?.data.order ? data?.data.order : "",
          ls_item: data?.data.ordItem ? data?.data.ordItem : "",
          ls_proc: data?.data.proc ? data?.data.proc : "",
          ls_thk: data?.data.crThick ? data?.data.crThick : "",
          ls_width: data?.data.CrWidth ? data?.data.CrWidth : "",
          ls_idia: data?.data.crIdia ? data?.data.crIdia : "",
          ls_odia: data?.data.crOdia ? data?.data.crOdia : "",
          ls_net_wt: data?.data.netWt ? data?.data.netWt : "",
          //ls_grs_wt: (data ?.data.grossWt) ? data ?.data.grossWt : "",
          ls_coil_len: data?.data.length ? data?.data.length : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_shift: (data ?.data.shift) ? data ?.data.shift : "",
          ls_opr_rem: data?.data.opr_rem ? data?.data.opr_rem : "",
          ls_hold_fl: data?.data.hold_fl ? data?.data.hold_fl : "",
          ls_pack_cd: data?.data.pack_cd ? data?.data.pack_cd : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : ""
          ls_pdi: data?.data.userId ? data?.data.idPdi : "",
          ls_plannedProc: data?.data.plannedProc ? data?.data.plannedProc : "",
          ls_nextProc: data?.data.nextProc ? data?.data.nextProc : "",
          ls_fgTdc: data?.data.fgTdc ? data?.data.fgTdc : "",
          oil_type: data?.data.oil_type ? data?.data.oil_type : "",
          crNoPart: data?.data.crNoPart ? data?.data.crNoPart : "",
          hold_cd: data?.data.hold_cd ? data?.data.hold_cd : "",
          recoilerTension: data?.data.recoilerTension
            ? data?.data.recoilerTension
            : "",
          edgeWaviness: data?.data.edgeWaviness ? data?.data.edgeWaviness : "",
          burrHeight: data?.data.burrHeight ? data?.data.burrHeight : "",
          slitPosition: data?.data.slitPosition ? data?.data.slitPosition : "",
          coilEdgeCond: data?.data.coilEdgeCond ?? "",
          tescopicity: data?.data.tescopicity ?? "",
          zigZagWind: data?.data.zigZagWind ?? "",
          cutrMark: data?.data.cutrMark ?? "",
          oilCondn: data?.data.oilCondn ?? "",
        };
        console.log("sql: ", sql);
        console.log("binds: ", binds);
        return await query(sql, binds);
      } else if (data?.data.actName === "WCTL") {
        var sql = `  
          INSERT INTO v_wctl_dautr_coil (
              wcc_id_sor_appl,
              wcc_id_destn_appl,
              wcc_id_message,
              wcc_reserved_1,
              wcc_reserved_2,
              wcc_id_batch,
              wcc_id_pdi,
              wcc_batch_start,
              wcc_batch_end,
              wcc_id_coil,
              wcc_cut_length,
              wcc_cut_angle,
              wcc_thick,
              wcc_width,
              wcc_pack_gross_wt,
              wcc_pack_net_wt,
              wcc_prod_dur,
              wcc_first_sht_time,
              wcc_prod_set_pack,
              wcc_prod_act_pack,
              wcc_prod_set_piece,
              wcc_prod_act_piece,
              wcc_prod_stk_box1,
              wcc_prod_stk_box2,
              wcc_prod_double_mode,
              wcc_remarks,
              wcc_order,
              wcc_item_no,
              wcc_cust_desc,
              wcc_hold_flag,
              wcc_hold_code,
              wcc_tdc,
              wcc_grade_desc,
              wcc_trim,
              wcc_pack_code,
              wcc_nxt_proc,
              wcc_planned_proc,
              wcc_actl_proc,
              wcc_oil_max_qty,
              wcc_oil_min_qty,
              wcc_oil_type,
              wcc_part_number,
              wcc_edge_waviness,
              wcc_centre_buckle,
              wcc_bow,
              wcc_crossbow,
              wcc_camber,
              wcc_burr_height,
              wcc_surf_req,
              wcc_dignl_diff,
              wcc_level_entry_gap,
              wcc_level_exit_gap,
              wcc_horizontal_gap,
              wcc_vertical_gap,
              wcc_len_tol,
              wcc_width_tol,
              wcc_trap_angle_tol,
              wcc_trap_length_tol,
              wcc_plasticity,
              wcc_crown,
              wcc_wedge,
              wcc_nspr1,
              wcc_nspr2,
              wcc_nspr3,
              wcc_nspr4,
              wcc_nspr5,
              wcc_nspr6,
              wcc_nspr7,
              wcc_nspr8,
              wcc_nspr9,
              wcc_nspr10,
              wcc_cspr1,
              wcc_cspr2,
              wcc_cspr3,
              wcc_cspr4,
              wcc_cspr5,
              wcc_cspr6,
              wcc_cspr7,
              wcc_cspr8,
              wcc_cspr9,
              wcc_cspr10
          ) VALUES (
             'L3_BKP'  -- wcc_id_sor_appl,
             ,'SPIN'-- wcc_id_destn_appl,
             ,f_nannow_second_telgrm(SYSDATE) -- wcc_id_message,
             ,'N'-- wcc_reserved_1,
             ,'N'-- wcc_reserved_2,
             ,:ls_daugt_batch-- wcc_id_batch,
             ,:ls_pdi -- wcc_id_pdi,
             ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS') -- wcc_batch_start,
             ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')  -- wcc_batch_end,
             ,:ls_parent-- wcc_id_coil,
             ,:ls_coil_len-- wcc_cut_length,
             ,0-- wcc_cut_angle,
             ,:ls_thk -- wcc_thick,
             ,:ls_width -- wcc_width,
             ,:ls_grs_wt -- wcc_pack_gross_wt,
             ,:ls_net_wt -- wcc_pack_net_wt,
             ,:duration -- wcc_prod_dur,
             ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')-- wcc_first_sht_time,
             ,NULL-- wcc_prod_set_pack,
             ,NULL-- wcc_prod_act_pack,
             ,NULL-- wcc_prod_set_piece,
             ,:coilNo-- wcc_prod_act_piece,
             ,NULL-- wcc_prod_stk_box1,
             ,NULL-- wcc_prod_stk_box2,
             ,NULL-- wcc_prod_double_mode,
             ,:ls_opr_rem   -- wcc_remarks,
             ,:ls_ord-- wcc_order,
             ,:ls_item-- wcc_item_no,
             ,NULL-- wcc_cust_desc,
             ,:ls_hold_fl   -- wcc_hold_flag,
             ,:hold_cd      -- wcc_hold_code,
             ,:ls_tdc-- wcc_tdc,
             ,NULL-- wcc_grade_desc,
             ,NULL-- wcc_trim,
             ,:ls_pack_cd-- wcc_pack_code,
             ,NULL-- wcc_nxt_proc,
             ,NULL-- wcc_planned_proc,
             ,NULL-- wcc_actl_proc,
             ,NULL-- wcc_oil_max_qty,
             ,NULL-- wcc_oil_min_qty,
             ,NULL-- wcc_oil_type,
             ,NULL-- wcc_part_number,
             ,NULL-- wcc_edge_waviness,
             ,NULL-- wcc_centre_buckle,
             ,NULL-- wcc_bow,
             ,NULL-- wcc_crossbow,
             ,NULL-- wcc_camber,
             ,NULL-- wcc_burr_height,
             ,NULL-- wcc_surf_req,
             ,NULL-- wcc_dignl_diff,
             ,NULL-- wcc_level_entry_gap,
             ,NULL-- wcc_level_exit_gap,
             ,NULL-- wcc_horizontal_gap,
             ,NULL-- wcc_vertical_gap,
             ,NULL-- wcc_len_tol,
             ,NULL-- wcc_width_tol,
             ,NULL-- wcc_trap_angle_tol,
             ,NULL-- wcc_trap_length_tol,
             ,NULL-- wcc_plasticity,
             ,NULL-- wcc_crown,
             ,NULL-- wcc_wedge,
             ,NULL-- wcc_nspr1,
             ,NULL-- wcc_nspr2,
             ,NULL-- wcc_nspr3,
             ,NULL-- wcc_nspr4,
             ,NULL-- wcc_nspr5,
             ,NULL-- wcc_nspr6,
             ,NULL-- wcc_nspr7,
             ,NULL-- wcc_nspr8,
             ,NULL-- wcc_nspr9,
             ,NULL-- wcc_nspr10,
             ,NULL-- wcc_cspr1,
             ,NULL-- wcc_cspr2,
             ,NULL-- wcc_cspr3,
             ,NULL-- wcc_cspr4,
             ,NULL-- wcc_cspr5,
             ,NULL-- wcc_cspr6,
             ,NULL-- wcc_cspr7,
             ,NULL-- wcc_cspr8,
             ,NULL-- wcc_cspr9,
             ,NULL-- wcc_cspr10
  )`;
        const binds = {
          //flag: data ?.type,
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          ls_daugt_batch: data?.data.daughterCoil
            ? data?.data.daughterCoil
            : "",
          ls_ord: data?.data.order ? data?.data.order : "",
          ls_item: data?.data.ordItem ? data?.data.ordItem : "",
          ls_tdc: data?.data.fgTdc ? data?.data.fgTdc : "",
          ls_thk: data?.data.crThick ? data?.data.crThick : "",
          ls_width: data?.data.CrWidth ? data?.data.CrWidth : "",
          //ls_idia: data?.data.crIdia ? data?.data.crIdia : "",
          //ls_odia: data?.data.crOdia ? data?.data.crOdia : "",
          ls_net_wt: data?.data.netWt ? data?.data.netWt : "",
          ls_grs_wt: data?.data.grossWt ? data?.data.grossWt : "",
          ls_coil_len: data?.data.length ? data?.data.length : "",
          coilNo: data?.data.coilNo ? data?.data.coilNo : "",
          duration: data?.data.duration ? data?.data.duration : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_shift: (data ?.data.shift) ? data ?.data.shift : "",
          ls_opr_rem: data?.data.opr_rem ? data?.data.opr_rem : "",
          ls_hold_fl: data?.data.hold_fl ? data?.data.hold_fl : "",
          ls_pack_cd: data?.data.pack_cd ? data?.data.pack_cd : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : ""
          ls_pdi: data?.data.userId ? data?.data.idPdi : "",
          hold_cd: data?.data.hold_cd ? data?.data.hold_cd : "",
        };

        console.log(sql, binds);
        return await query(sql, binds);
      } else if (data?.data.actName === "NCTL") {
        var sql = `  
          INSERT INTO v_nctl_dautr_coil (
              ncc_id_sor_appl,
              ncc_id_destn_appl,
              ncc_id_message,
              ncc_reserved_1,
              ncc_reserved_2,
              ncc_id_batch,
              ncc_id_pdi,
              ncc_batch_start,
              ncc_batch_end,
              ncc_id_coil,
              ncc_cut_length,
              ncc_cut_angle,
              ncc_thick,
              ncc_width,
              ncc_pack_gross_wt,
              ncc_pack_net_wt,
              ncc_prod_dur,
              ncc_first_sht_time,
              ncc_prod_set_pack,
              ncc_prod_act_pack,
              ncc_prod_set_piece,
              ncc_prod_act_piece,
              ncc_prod_stk_box1,
              ncc_prod_stk_box2,
              ncc_prod_double_mode,
              ncc_remarks,
              ncc_order,
              ncc_item_no,
              ncc_cust_desc,
              ncc_hold_flag,
              ncc_hold_code,
              ncc_tdc,
              ncc_grade_desc,
              ncc_trim,
              ncc_pack_code,
              ncc_nxt_proc,
              ncc_planned_proc,
              ncc_actl_proc,
              ncc_oil_max_qty,
              ncc_oil_min_qty,
              ncc_oil_type,
              ncc_part_number,
              ncc_edge_waviness,
              ncc_centre_buckle,
              ncc_bow,
              ncc_crossbow,
              ncc_camber,
              ncc_burr_height,
              ncc_surf_req,
              ncc_dignl_diff,
              ncc_level_entry_gap,
              ncc_level_exit_gap,
              ncc_horizontal_gap,
              ncc_vertical_gap,
              ncc_len_tol,
              ncc_width_tol,
              ncc_trap_angle_tol,
              ncc_trap_length_tol,
              ncc_plasticity,
              ncc_crown,
              ncc_wedge,
              ncc_nspr1,
              ncc_nspr2,
              ncc_nspr3,
              ncc_nspr4,
              ncc_nspr5,
              ncc_nspr6,
              ncc_nspr7,
              ncc_nspr8,
              ncc_nspr9,
              ncc_nspr10,
              ncc_cspr1,
              ncc_cspr2,
              ncc_cspr3,
              ncc_cspr4,
              ncc_cspr5,
              ncc_cspr6,
              ncc_cspr7,
              ncc_cspr8,
              ncc_cspr9,
              ncc_cspr10
          ) VALUES (
             'L3_BKP'            -- ncc_id_sor_appl,
             ,'SPIN'          -- ncc_id_destn_appl,
             ,f_nannow_second_telgrm(SYSDATE) -- ncc_id_message,
             ,'N'-- ncc_reserved_1,
             ,'N'-- ncc_reserved_2,
             ,:ls_daugt_batch-- ncc_id_batch,
             ,:ls_pdi -- ncc_id_pdi,
             ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS') -- ncc_batch_start,
             ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')  -- ncc_batch_end,
             ,:ls_parent-- ncc_id_coil,
             ,:ls_coil_len-- ncc_cut_length,
             ,0-- ncc_cut_angle,
             ,:ls_thk -- ncc_thick,
             ,:ls_width -- ncc_width,
             ,:ls_grs_wt -- ncc_pack_gross_wt,
             ,:ls_net_wt -- ncc_pack_net_wt,
             ,:duration -- ncc_prod_dur,
             ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')-- ncc_first_sht_time,
             ,NULL-- ncc_prod_set_pack,
             ,NULL-- ncc_prod_act_pack,
             ,NULL-- ncc_prod_set_piece,
             ,:coilNo-- ncc_prod_act_piece,
             ,NULL-- ncc_prod_stk_box1,
             ,NULL-- ncc_prod_stk_box2,
             ,NULL-- ncc_prod_double_mode,
             ,:ls_opr_rem     -- ncc_remarks,
             ,:ls_ord -- ncc_order,
             ,:ls_item -- ncc_item_no,
             ,NULL-- ncc_cust_desc,
             ,:ls_hold_fl   -- ncc_hold_flag,
             ,:hold_cd      -- ncc_hold_code,
             ,NULL-- ncc_tdc,
             ,NULL-- ncc_grade_desc,
             ,NULL-- ncc_trim,
             ,:ls_pack_cd   -- ncc_pack_code,
             ,NULL -- ncc_nxt_proc,
             ,NULL-- ncc_planned_proc,
             ,NULL-- ncc_actl_proc,
             ,NULL-- ncc_oil_max_qty,
             ,NULL-- ncc_oil_min_qty,
             ,NULL-- ncc_oil_type,
             ,NULL-- ncc_part_number,
             ,NULL-- ncc_edge_waviness,
             ,NULL-- ncc_centre_buckle,
             ,NULL-- ncc_bow,
             ,NULL-- ncc_crossbow,
             ,NULL-- ncc_camber,
             ,NULL-- ncc_burr_height,
             ,NULL-- ncc_surf_req,
             ,NULL-- ncc_dignl_diff,
             ,NULL-- ncc_level_entry_gap,
             ,NULL-- ncc_level_exit_gap,
             ,NULL-- ncc_horizontal_gap,
             ,NULL-- ncc_vertical_gap,
             ,NULL-- ncc_len_tol,
             ,NULL-- ncc_width_tol,
             ,NULL-- ncc_trap_angle_tol,
             ,NULL-- ncc_trap_length_tol,
             ,NULL-- ncc_plasticity,
             ,NULL-- ncc_crown,
             ,NULL-- ncc_wedge,
             ,NULL-- ncc_nspr1,
             ,NULL-- ncc_nspr2,
             ,NULL-- ncc_nspr3,
             ,NULL-- ncc_nspr4,
             ,NULL-- ncc_nspr5,
             ,NULL-- ncc_nspr6,
             ,NULL-- ncc_nspr7,
             ,NULL-- ncc_nspr8,
             ,NULL-- ncc_nspr9,
             ,NULL-- ncc_nspr10,
             ,NULL-- ncc_cspr1,
             ,NULL-- ncc_cspr2,
             ,NULL-- ncc_cspr3,
             ,NULL-- ncc_cspr4,
             ,NULL-- ncc_cspr5,
             ,NULL-- ncc_cspr6,
             ,NULL-- ncc_cspr7,
             ,NULL-- ncc_cspr8,
             ,NULL-- ncc_cspr9,
             ,NULL-- ncc_cspr10
  )`;
        const binds = {
          //flag: data ?.type,
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          ls_daugt_batch: data?.data.daughterCoil
            ? data?.data.daughterCoil
            : "",
          ls_ord: data?.data.order ? data?.data.order : "",
          ls_item: data?.data.ordItem ? data?.data.ordItem : "",
          // ls_proc: data?.data.proc ? data?.data.proc : "",
          ls_thk: data?.data.crThick ? data?.data.crThick : "",
          ls_width: data?.data.CrWidth ? data?.data.CrWidth : "",
          coilNo: data?.data.coilNo ? data?.data.coilNo : "",
          //ls_idia: data?.data.crIdia ? data?.data.crIdia : "",
          //ls_odia: data?.data.crOdia ? data?.data.crOdia : "",
          ls_net_wt: data?.data.netWt ? data?.data.netWt : "",
          ls_grs_wt: data?.data.grossWt ? data?.data.grossWt : "",
          ls_coil_len: data?.data.length ? data?.data.length : "",
          duration: data?.data.duration ? data?.data.duration : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_shift: (data ?.data.shift) ? data ?.data.shift : "",
          ls_opr_rem: data?.data.opr_rem ? data?.data.opr_rem : "",
          ls_hold_fl: data?.data.hold_fl ? data?.data.hold_fl : "",
          ls_pack_cd: data?.data.pack_cd ? data?.data.pack_cd : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : ""
          ls_pdi: data?.data.userId ? data?.data.idPdi : "",
          hold_cd: data?.data.hold_cd ? data?.data.hold_cd : "",
        };

        console.log(sql, binds);
        return await query(sql, binds);
      }
    }
    if (data?.type === "getPageData") {
      return {
        processLine: await ResponceData(
          await query(` select EPL_CD_PROCESS, 
              EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
              FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= '131'  
              AND EPL_CD_PROCESS not in ('W', 'E', 'K')
              ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS`)
        ),
      };
    }
    //Save button on mother report
    else if (data?.type === "SL_MOTHER_REP") {
      if (data?.data?.process === "S") {
        var sql = `
        INSERT INTO v_sl_mother_coil (
          rmh_id_sor_appl,
          rmh_id_destn_appl,
          rmh_id_message,
          rmh_reserved_1,
          rmh_reserved_2,
          rmh_id_coil,
          rmh_no_slit,
          rmh_bal_mass,
          rmh_load_date,
          rmh_ts_proc_start,
          rmh_ts_proc_end,
          rmh_width,
          rmh_thick,
          rmh_max_speed,
          rmh_avg_speed,
          rmh_length,
          rmh_odia,
          rmh_no_cuts,
          rmh_tot_time,
          rmh_run_time,
          rmh_setup_time,
          rmh_stop_time,
          rmh_scrap_end,
          rmh_scrap_side_trim,
          rmh_scrap_pup_coil,
          rmh_nspr1,
          rmh_nspr2,
          rmh_nspr3,
          rmh_cspr1,
          rmh_cspr2,
          rmh_cspr3
      ) VALUES (
          'L3_BKP',	--	    rmh_id_sor_appl,
          'SPC_IS',	--	    rmh_id_destn_appl,
          f_nannow_second_telgrm(SYSDATE),	--	    rmh_id_message,
          'N',	--	    rmh_reserved_1,
          'N',	--	    rmh_reserved_2,
          :ls_parent,	--	    rmh_id_coil,
          :ln_no_of_slt,	--	    rmh_no_slit,
          0,	--	    rmh_bal_mass,
          SYSDATE,	--	    rmh_load_date,
          TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS'),	--	    rmh_ts_proc_start,
          TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS'),	--	    rmh_ts_proc_end,
          :ln_width,	--	    rmh_width,
          :ln_thick,	--	    rmh_thick,
          0,	--	    rmh_max_speed,
          0,	--	    rmh_avg_speed,
          :ln_length,	--	    rmh_length,
          0,	--	    rmh_odia,
          0,	--	    rmh_no_cuts,
          0,	--	    rmh_tot_time,
          0,	--	    rmh_run_time,
          0,	--	    rmh_setup_time,
          0,	--	    rmh_stop_time,
          :ln_end_cut,	--	    rmh_scrap_end,
          :ln_sidetrim_wt,	--	    rmh_scrap_side_trim,
          :ln_pupcoil_wt,	--	    rmh_scrap_pup_coil,
          0,	--	    rmh_nspr1,
          0,	--	    rmh_nspr2,
          0,	--	    rmh_nspr3,
          '0',	--	    rmh_cspr1,
          '0',	--	    rmh_cspr2,
          '0'	--	    rmh_cspr3
      )`;
        const binds = {
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          ln_no_of_slt: data?.data.slitNo ? data?.data.slitNo : "",
          // ln_res_wt: data?.data.residualWt ? data?.data.residualWt : "",
          ln_end_cut: data?.data.endCut ? data?.data.endCut : "",
          ln_sidetrim_wt: data?.data.sideTrim ? data?.data.sideTrim : "",
          ln_pupcoil_wt: data?.data.pupCoil ? data?.data.pupCoil : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
          //ls_out_flag: { type: oracledb.STRING, dir: oracledb.BIND_OUT, maxSize: 500 }
          ln_thick: data?.data.thick ? data?.data.thick : "",
          ln_width: data?.data.width ? data?.data.width : "",
          ln_length: data?.data.mLength ? data?.data.mLength : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
        };
        return await query(sql, binds);
      } else if (data?.data?.process === "T") {
        var sql = `
        INSERT INTO v_wctl_mother_coil (
          wch_id_sor_appl,
          WCH_ID_DESTN_APPL,
          WCH_ID_MESSAGE,
          WCH_RESERVED_1,
          WCH_RESERVED_2,
          WCH_ID_COIL,
          WCH_BAL_MASS,
          WCH_LOAD_DATE,
          WCH_TS_PROC_START,
          WCH_TS_PROC_END,
          WCH_WIDTH,
          WCH_THICK,
          WCH_MAX_SPEED,
          WCH_AVG_SPEED,
          WCH_TOT_PIECES,
          WCH_TOT_PACK,
          WCH_TOT_TIME,
          WCH_RUN_TIME,
          WCH_SETUP_TIME,
          WCH_STOP_TIME,
          WCH_SCRAP_END,
          WCH_SCRAP_SIDE_TRIM,
          WCH_SCRAP_PUP_COIL,
          WCH_NSPR1,
          WCH_NSPR2,
          WCH_NSPR3,
          WCH_CSPR1,
          WCH_CSPR2,
          WCH_CSPR3
      ) VALUES (
            'L3_BKP', -- WCH_ID_SOR_APPL
            'SPC_IS', -- WCH_ID_DESTN_APPL
            f_nannow_second_telgrm(SYSDATE), -- WCH_ID_MESSAGE
            'N', -- WCH_RESERVED_1
            'N', -- WCH_RESERVED_2
            :ls_parent, -- WCH_ID_COIL
            0, -- WCH_BAL_MASS
            SYSDATE, -- WCH_LOAD_DATE
            TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS'), -- WCH_TS_PROC_START
            TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS'), -- WCH_TS_PROC_END
            :ln_width, -- WCH_WIDTH
            :ln_thick, -- WCH_THICK
            0, -- WCH_MAX_SPEED
            0, -- WCH_AVG_SPEED
            0, -- WCH_TOT_PIECES
            '0', -- WCH_TOT_PACK
            0, -- WCH_TOT_TIME
            0, -- WCH_RUN_TIME
            0, -- WCH_SETUP_TIME
            0, -- WCH_STOP_TIME
            :ln_end_cut, -- WCH_SCRAP_END
            :ln_sidetrim_wt, -- WCH_SCRAP_SIDE_TRIM
            :ln_pupcoil_wt, -- WCH_SCRAP_PUP_COIL
            0, -- WCH_NSPR1
            0, -- WCH_NSPR2
            0, -- WCH_NSPR3
            '0', -- WCH_CSPR1
            '0', -- WCH_CSPR2
            '0' -- WCH_CSPR3
        )`;
        const binds = {
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          //pack_cd: data?.data.pack_cd ? data?.data.pack_cd : "",
          //ln_res_wt: data?.data.residualWt ? data?.data.residualWt : "",
          ln_end_cut: data?.data.endCut ? data?.data.endCut : "",
          ln_sidetrim_wt: data?.data.sideTrim ? data?.data.sideTrim : "",
          ln_pupcoil_wt: data?.data.pupCoil ? data?.data.pupCoil : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
          //ls_out_flag: { type: oracledb.STRING, dir: oracledb.BIND_OUT, maxSize: 500 }
          ln_thick: data?.data.mThick ? data?.data.mThick : "",
          ln_width: data?.data.width ? data?.data.width : "",
          //ln_length: data?.data.userId ? data?.data.mLength : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
        };
        console.log(sql, binds);
        return await query(sql, binds);
      } else if (data?.data?.process === "N") {
        var sql = `
        INSERT INTO v_nctl_mother_coil (
          nch_id_sor_appl,
          NCH_ID_DESTN_APPL,
          NCH_ID_MESSAGE,
          NCH_RESERVED_1,
          NCH_RESERVED_2,
          NCH_ID_COIL,
          NCH_BAL_MASS,
          NCH_LOAD_DATE,
          NCH_TS_PROC_START,
          NCH_TS_PROC_END,
          NCH_WIDTH,
          NCH_THICK,
          NCH_MAX_SPEED,
          NCH_AVG_SPEED,
          NCH_TOT_PIECES,
          NCH_TOT_PACK,
          NCH_TOT_TIME,
          NCH_RUN_TIME,
          NCH_SETUP_TIME,
          NCH_STOP_TIME,
          NCH_SCRAP_END,
          NCH_SCRAP_SIDE_TRIM,
          NCH_SCRAP_PUP_COIL,
          NCH_NSPR1,
          NCH_NSPR2,
          NCH_NSPR3,
          NCH_CSPR1,
          NCH_CSPR2,
          NCH_CSPR3
      ) VALUES (
          'L3_BKP', -- NCH_ID_SOR_APPL
          'SPC_IS', -- NCH_ID_DESTN_APPL
          f_nannow_second_telgrm(SYSDATE), -- NCH_ID_MESSAGE
          'N', -- NCH_RESERVED_1
          'N', -- NCH_RESERVED_2
          :ls_parent, -- NCH_ID_COIL
          0, -- NCH_BAL_MASS
          SYSDATE, -- NCH_LOAD_DATE
          TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS'), -- NCH_TS_PROC_START
          TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS'), -- NCH_TS_PROC_END
          :ln_width, -- NCH_WIDTH
          :ln_thick, -- NCH_THICK
          0, -- NCH_MAX_SPEED
          0, -- NCH_AVG_SPEED
          0, -- NCH_TOT_PIECES
          '0', -- NCH_TOT_PACK
          0, -- NCH_TOT_TIME
          0, -- NCH_RUN_TIME
          0, -- NCH_SETUP_TIME
          0, -- NCH_STOP_TIME
          :ln_end_cut, -- NCH_SCRAP_END
          :ln_sidetrim_wt, -- NCH_SCRAP_SIDE_TRIM
          :ln_pupcoil_wt, -- NCH_SCRAP_PUP_COIL
          0, -- NCH_NSPR1
          0, -- NCH_NSPR2
          0, -- NCH_NSPR3
          '0', -- NCH_CSPR1
          '0', -- NCH_CSPR2
          '0' -- NCH_CSPR3
      )`;
        const binds = {
          ls_parent: data?.data.motherCoil ? data?.data.motherCoil : "",
          //pack_cd: data?.data.pack_cd ? data?.data.pack_cd : "",
          //ln_res_wt: data?.data.residualWt ? data?.data.residualWt : "",
          ln_end_cut: data?.data.endCut ? data?.data.endCut : "",
          ln_sidetrim_wt: data?.data.sideTrim ? data?.data.sideTrim : "",
          ln_pupcoil_wt: data?.data.pupCoil ? data?.data.pupCoil : "",
          ls_prod_st_dt: data?.data.productionStart
            ? data?.data.productionStart
            : "",
          ls_prod_en_dt: data?.data.productionEnd
            ? data?.data.productionEnd
            : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
          //ls_out_flag: { type: oracledb.STRING, dir: oracledb.BIND_OUT, maxSize: 500 }
          ln_thick: data?.data.mThick ? data?.data.mThick : "",
          ln_width: data?.data.width ? data?.data.width : "",
          //ln_length: data?.data.userId ? data?.data.mLength : "",
          //ls_user: (data ?.data.userId) ? data ?.data.userId : "",
        };
        console.log(sql, binds);
        return await query(sql, binds);
      }
    } else if (data?.type === "ENT_DIVISION") {
      if (data?.data?.process === "S") {
        var sql = `INSERT INTO V_L3_SL_ENT_DIV_RPT (
        rer_id_sor_appl,
        rer_id_destn_appl,
        rer_id_message,
        rer_reserved_1,
        rer_reserved_2,
        rer_id_coil,
        rer_id_z_coil,
        rer_dt_ent_div,
        rer_ln_remn,
        rer_wt_remn,
        rer_odia,
        rer_cd_ent_div_rsn,
        rer_id_opr
    ) VALUES (
       'L3_BKP', --rer_id_sor_appl
       'SPINBKP',  --rer_id_destn_appl
        f_nannow_second_telgrm(SYSDATE), --rer_id_message
       'N',  --rer_reserved_1
       'N',  --rer_reserved_2
       :p_mcoil, --rer_id_coil
       :p_zcoil,  --rer_id_z_coil
        sysdate, --rer_dt_ent_div
       :p_rem_length,  --rer_ln_remn
       :p_rem_wt,  --rer_wt_remn
       :p_odia,  --rer_odia
       :p_reason, --rer_cd_ent_div_rsn
       '' --rer_id_opr
    )`;
        const binds = {
          p_mcoil: data?.data.mCoilId ? data?.data.mCoilId : "",
          p_zcoil: data?.data.zCoilId ? data?.data.zCoilId : "",
          p_rem_wt: data?.data.rem_wt ? data?.data.rem_wt : "",
          p_rem_length: data?.data.rem_length ? data?.data.rem_length : "",
          p_odia: data?.data.odia ? data?.data.odia : "",
          p_reason: data?.data.reason ? data?.data.reason : "",
        };
        return await query(sql, binds);
      } else if (data?.data?.process === "W") {
        var sql = `INSERT INTO V_L3_WCTL_ENT_DIV_RPT (
        wcn_id_sor_appl,
        wcn_id_destn_appl,
        wcn_id_message,
        wcn_reserved_1,
        wcn_reserved_2,
        wcn_id_coil,
        wcn_id_z_coil,
        wcn_dt_ent_div,
        wcn_ln_remn,
        wcn_wt_remn,
        wcn_odia,
        wcn_cd_ent_div_rsn,
        wcn_id_opr
    ) VALUES (
       'L3_BKP', --rer_id_sor_appl
       'SPINBKP',  --rer_id_destn_appl
        f_nannow_second_telgrm(SYSDATE), --rer_id_message
       'N',  --rer_reserved_1
       'N',  --rer_reserved_2
       :p_mcoil, --rer_id_coil
       :p_zcoil,  --rer_id_z_coil
        sysdate, --rer_dt_ent_div
       :p_rem_length,  --rer_ln_remn
       :p_rem_wt,  --rer_wt_remn
       :p_odia,  --rer_odia
       :p_reason, --rer_cd_ent_div_rsn
       '' --rer_id_opr
    )`;
        const binds = {
          p_mcoil: data?.data.mCoilId ? data?.data.mCoilId : "",
          p_zcoil: data?.data.zCoilId ? data?.data.zCoilId : "",
          p_rem_wt: data?.data.rem_wt ? data?.data.rem_wt : "",
          p_rem_length: data?.data.rem_length ? data?.data.rem_length : "",
          p_odia: data?.data.odia ? data?.data.odia : "",
          p_reason: data?.data.reason ? data?.data.reason : "",
        };
        return await query(sql, binds);
      } else if (data?.data?.process === "N") {
        var sql = `INSERT INTO V_L3_NCTL_ENT_DIV_RPT (
        ncn_id_sor_appl,
        ncn_id_destn_appl,
        ncn_id_message,
        ncn_reserved_1,
        ncn_reserved_2,
        ncn_id_coil,
        ncn_id_z_coil,
        ncn_dt_ent_div,
        ncn_ln_remn,
        ncn_wt_remn,
        ncn_odia,
        ncn_cd_ent_div_rsn,
        ncn_id_opr
    ) VALUES (
       'L3_BKP', --rer_id_sor_appl
       'SPINBKP',  --rer_id_destn_appl
        f_nannow_second_telgrm(SYSDATE), --rer_id_message
       'N',  --rer_reserved_1
       'N',  --rer_reserved_2
       :p_mcoil, --rer_id_coil
       :p_zcoil,  --rer_id_z_coil
        sysdate, --rer_dt_ent_div
       :p_rem_length,  --rer_ln_remn
       :p_rem_wt,  --rer_wt_remn
       :p_odia,  --rer_odia
       :p_reason, --rer_cd_ent_div_rsn
       '' --rer_id_opr
    )`;
        const binds = {
          p_mcoil: data?.data.mCoilId ? data?.data.mCoilId : "",
          p_zcoil: data?.data.zCoilId ? data?.data.zCoilId : "",
          p_rem_wt: data?.data.rem_wt ? data?.data.rem_wt : "",
          p_rem_length: data?.data.rem_length ? data?.data.rem_length : "",
          p_odia: data?.data.odia ? data?.data.odia : "",
          p_reason: data?.data.reason ? data?.data.reason : "",
        };
        return await query(sql, binds);
      }
    } else if (data?.type === "SL_PACKING_REP") {
      var sql = `
          INSERT INTO v_sl_pack_int (
                spp_id_sor_appl,
                spp_id_destn_appl,
                spp_id_message,
                spp_reserved_1,
                spp_reserved_2,
                spp_id_coil,
                spp_id_input_coil,
                spp_ts_proc_strt,
                spp_ts_proc_end,
                spp_net_mass,
                spp_gross_mass,
                spp_width,
                spp_thick,
                spp_odia,
                spp_idia,
                spp_remarks,
                spp_order,
                spp_item_no,
                spp_pack_code,
                spp_nspr1,
                spp_nspr2,
                spp_nspr3,
                spp_nspr4,
                spp_nspr5,
                spp_nspr6,
                spp_nspr7,
                spp_nspr8,
                spp_nspr9,
                spp_nspr10,
                spp_cspr1,
                spp_cspr2,
                spp_cspr3,
                spp_cspr4,
                spp_cspr5,
                spp_cspr6,
                spp_cspr7,
                spp_cspr8,
                spp_cspr9,
                spp_cspr10
              ) VALUES (
                'L3_BKP', -- spp_id_sor_appl,
                'SPC_IS',-- spp_id_destn_appl,
                f_nannow_second_telgrm(SYSDATE),-- spp_id_message,
                'N',-- spp_reserved_1,
                'N',-- spp_reserved_2,
                :ls_parent, -- spp_id_coil,
                :ls_parent, -- spp_id_input_coil,
                TO_DATE(:ls_p_start_dt,'DD-MM-YYYY HH24:MI:SS'), -- spp_ts_proc_strt,
                TO_DATE(:ls_p_end_dt,'DD-MM-YYYY HH24:MI:SS'), -- spp_ts_proc_end,
                :ln_NetWt,-- spp_net_mass,
                :ln_GrossWt,-- spp_gross_mass,
                :ln_Width,-- spp_width,
                :ln_Thick,-- spp_thick,
                :ln_Odia,-- spp_odia,
                :ln_Idia,-- spp_idia,
                '',-- spp_remarks,
                '',-- spp_order,
                '',-- spp_item_no,
                :ls_packingCd,-- spp_pack_code,
                null,-- spp_nspr1,
                null,-- spp_nspr2,
                null,-- spp_nspr3,
                null,-- spp_nspr4,
                null,-- spp_nspr5,
                null,-- spp_nspr6,
                null,-- spp_nspr7,
                null,-- spp_nspr8,
                null,-- spp_nspr9,
                null,-- spp_nspr10,
                null,-- spp_cspr1,
                null,-- spp_cspr2,
                null,-- spp_cspr3,
                null,-- spp_cspr4,
                null,-- spp_cspr5,
                null,-- spp_cspr6,
                null,-- spp_cspr7,
                null,-- spp_cspr8,
                null,-- spp_cspr9,
                null-- spp_cspr10
              )`;
      const binds = {
        ls_parent: data?.data.pCoilId ? data?.data.pCoilId : "",
        ln_Thick: data?.data.pThick ? data?.data.pThick : "",
        ln_Width: data?.data.pWidth ? data?.data.pWidth : "",
        ln_Odia: data?.data.pOdia ? data?.data.pOdia : "",
        ln_Idia: data?.data.pIdia ? data?.data.pIdia : "",
        ln_NetWt: data?.data.pNetWt ? data?.data.pNetWt : "",
        ln_GrossWt: data?.data.pGrossWt ? data?.data.pGrossWt : "",
        ls_packingCd: data?.data.pGrossWt ? data?.data.packingCd : "",
        ls_p_start_dt: data?.data.pStartDt ? data?.data.pStartDt : "",
        ls_p_end_dt: data?.data.pEndDt ? data?.data.pEndDt : "",
      };

      return await query(sql, binds);
    } else if (data?.type === "getMotherCoil") {
      return await ResponceData(
        await query(`SELECT PDS_ID_COIL 
              FROM V_PR_DATA_IP_SLT
              WHERE PDS_CD_EPA='131'
              AND PDS_CD_STATus IN ('WS','OS')`)
      );
    }
    // ******** LOCATION REPORT Started
    else if (data?.type === "getLocRepCoils") {
      //-- Query for coil ID for location report
      let qry = `select eom_id_batch from v_epa_prodn where 
      eom_cd_status not like '%L' 
      and eom_cd_status not in (select cd_value from v_codes where cd_type = 'TK029') `; //!= 'VG'`;

      return {
        LocRepCoils: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "LOC_REP_SAVE") {
      var sql = `Insert into V_CTTS_LOC_CHNG
        (CLC_ID_SOR_APPL, CLC_ID_DESTN_APPL, CLC_ID_MESSAGE, CLC_RESERVED_1, CLC_RESERVED_2, 
         CLC_ID_COIL, CLC_CD_YARD, CLC_LOC_X, CLC_LOC_Y, CLC_ID_POS)
         Values
        ('L3', 'SPIN', f_nannow_second_telgrm(SYSDATE), 'N', 'N', 
         :ls_coil, :yard, :locX, :locY, :pos) `;

      const binds = {
        ls_coil: data?.data.coilId ? data?.data.coilId : "",
        yard: data?.data.yard ? data?.data.yard : "",
        locX: data?.data.locX ? data?.data.locX : "",
        locY: data?.data.locY ? data?.data.locY : "",
        pos: data?.data.pos ? data?.data.pos : "",
      };
      return await query(sql, binds);
    } else if (data?.type === "getYardList") {
      var sql = `select CD_VALUE YARD from v_codes where cd_type = 'TK032' `;
      return {
        yardList: await ResponceData(await query(sql)),
      };
    } else if (data?.type === "backRecording") {
      var sql = `select cd_value hours from v_codes where cd_type = 'TK033' `;
      return {
        backRecording: await ResponceData(await query(sql)),
      };
    } else if (data?.type === "ctlLiveFlag") {
      var sql = `select cd_value flags from v_codes where cd_type = 'TK034' `;
      return {
        ctlLiveFlag: await ResponceData(await query(sql)),
      };
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getHoldRsn = async () => {
  try {
    let sql: any = `SELECT distinct  CD_HOLD, CD_HOLD || '-' || CD_DESC CD_DESC FROM  V_EPA_HOLD_RSN order by CD_HOLD`;
    return await query(sql);
  } catch (error: any) {
    // console.log("qry: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getSlitPos = async () => {
  try {
    let sql: any = `SELECT CD_VALUE, CD_DESC FROM V_CODES WHERE CD_TYPE = 'TK024'`;
    return await query(sql);
  } catch (error: any) {
    // console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
