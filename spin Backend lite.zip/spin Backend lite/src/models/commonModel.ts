const CommonQuery = require("../repository/commonQuery");
//const commonPlantQuery = require("../repository/plantQuery");

export default class CommonModel {
  getPlantData() {
    return CommonQuery.getPlantData();
  }

  getEpaCode02() {
    return CommonQuery.getEpaCode02();
  }

  // getTdcMain05(data: any) {
  //   return CommonQuery.getTdcMain05(data);
  // }
  // getQualityData05(data: any) {
  //   return CommonQuery.getQualityData05(data);
  // }
  // getSpecLimit05(data: any) {
  //   return CommonQuery.getSpecLimit05(data);
  // }
  // getData06(data: any) {
  //     return CommonQuery.getData06(data);
  // }
  //   getData07(data: any) {
  //     return CommonQuery.getData07(data);
  //   }
  getData08(data: any) {
    return CommonQuery.getData08(data);
  }
  // getTdcCode05() {
  //   return CommonQuery.getTdcCode05();
  // }
  // getQltyCode05() {
  //   return CommonQuery.getQltyCode05();
  // }
  //   getOrderId07() {
  //     return CommonQuery.getOrderId07();
  //   }
  getEpaCodeData08() {
    return CommonQuery.getEpaCodeData08();
  }
  // getTdcMainCode05() {
  //   return CommonQuery.getTdcMainCode05();
  // }
  getOrderData08() {
    return CommonQuery.getOrderData08();
  }
  //   getEpa07() {
  //     return CommonQuery.getEpa07();
  //   }
  //   getPlantData() {
  //     return CommonQuery.getPlantData();
  //   }
  // getPlantData(data: any) {
  //     return commonPlantQuery.getCommonPlantData(data);
  // }
  //   getOrderStatus07() {
  //     return CommonQuery.getOrderStatus07();
  //   }
  //   getCustomer07() {
  //     return CommonQuery.getCustomer07();
  //   }
  //   getOrderType07() {
  //     return CommonQuery.getOrderType07();
  //   }
  getEpaPlant06() {
    return CommonQuery.getEpaPlant06();
  }
  getTdcsec06() {
    return CommonQuery.getTdcsec06();
  }
  getSECONDSTdc06(data: any) {
    return CommonQuery.getSECONDSTdc06(data);
  }
  getActTdc06() {
    return CommonQuery.getActTdc06();
  }
  getEndTdc06() {
    return CommonQuery.getEndTdc06();
  }
  getTdcMap06(data: any) {
    return CommonQuery.getTdcMap06(data);
  }
  callProcedure06(data: any) {
    return CommonQuery.callProcedure06(data);
  }
}
