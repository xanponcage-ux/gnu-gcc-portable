import { Router } from "express";
import {
  getHoldRsn,
  getSlitPos,
  SPO0003Api,
} from "../controllers/SPO0003Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPO0003Route = Router();

SPO0003Route.route("/SPO0003/SPO0003Api").post(
  authenticationMiddleware.bearer,
  SPO0003Api
);

SPO0003Route.route("/SPO0003/getHoldRsn").post(
  authenticationMiddleware.bearer,
  getHoldRsn
);

SPO0003Route.route("/SPO0003/getSlitPos").post(
  authenticationMiddleware.bearer,
  getSlitPos
);

export default SPO0003Route;
