import { Router } from "express";
import { getData, confirmPacking } from "../controllers/SPO0002Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPO0002Route = Router();

SPO0002Route.route("/SPO0002/getData").post(
  authenticationMiddleware.bearer,
  getData
);
SPO0002Route.route("/SPO0002/confirmPacking").post(
  authenticationMiddleware.bearer,
  confirmPacking
);

export default SPO0002Route;
