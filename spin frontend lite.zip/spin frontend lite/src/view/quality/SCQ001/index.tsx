/* ------------------ To keep track of changes --------------------------------------
Changed on - 31.07.2026, By Ritya
Purpose   - Diversion tdc logic modified to display tdc mapped in IPD instead of old logic.
  ----------------------------------------------------------------------------------- */

import React, { useState } from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";

import alertify from "../../../components/alert";
import { GetAuthorization } from "../../../utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import NextPlanIcon from "@mui/icons-material/NextPlan";
import WarningIcon from "@mui/icons-material/Warning";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import {
  SCQ001Api,
  SCQ001GetFilterDataApi,
  SCQ001GetDataApi,
  SCQ001SaveDataApi,
  SCQ001DiversionResApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, PopupObj } from "./type";
import { useMaterialUIController } from "../../../context";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SCQ001 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [scheduleDetailsData, setScheduleDetailsData] = React.useState<
    Array<SelectType>
  >([]);

  const [secondTdcLook, setSecondTdcTableLook] = React.useState<any>({
    popUp: false,
    data: [],
  });
  // -------This page data -----------------

  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [coilId, setCoilId] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [secondTdcTableData, setSecondTdcTableData] = React.useState<any>([]);
  const [secondTdcTable, setSecondTdcTable] = React.useState<any>();
  const [tdcOptions, setTdcOptions] = React.useState<any>([]);
  const [divTdc, setDivTdc] = React.useState<any>([]);
  const [rsnCategory, setRsnCategory] = React.useState<any>([]);
  const [alertPopup, setAlertPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });

  //POP UP for Remarks
  const [remarksPopUp, setRemarksPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });
  const [remarksTable, setRemarksTable] = React.useState<any>(null);
  const [remarksTableData, setRemarksTableData] = React.useState<any>([]);

  // POP UP FOR REMARKS AGAINST HOLD COL
  const [holdNoPopUp, setHoldNoPopUp] = React.useState<PopupObj>({
    popUp: false,
    data: "",
  });
  const [holdNoTable, setHoldNoTable] = React.useState<any>(null);
  const [holdNoTableData, setHoldNoTableData] = React.useState<any>([]);

  const [selectedDecision, setSelectedDecision] = React.useState<string>("");

  const decisionList: Array<SelectType> = [
    { value: "Pass", label: "Pass", id: 1 },
    { value: "Downgrade", label: "Downgrade", id: 2 },
    { value: "Scrap", label: "Scrap", id: 3 },
    { value: "Addl Process", label: "Addl Process", id: 4 },
    { value: "Diversion", label: "Diversion", id: 5 },
    {
      value: "Release with Order Delink",
      label: "Release with Order Delink",
      id: 6,
    },
    { value: "Gross Wt Change", label: "Gross Wt Change", id: 7 },
    { value: "Sheet No Change", label: "Sheet No Change", id: 8 },
    { value: "Net Wt Change", label: "Net Wt Change", id: 9 },
  ];

  const [addlProcessList, setAddlProcessList] = React.useState<any>([]);

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ001GetFilterDataApi(token, {
        type: "SCQ001GetFilterData",
        Plant: selectedPlant,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.PlanCode?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedPlant(varData[0].value);

              const varstatusData: Array<SelectType> = [];
              res?.data?.Status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_VALUE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
              setSelectedStatus(varstatusData[0].value);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      let varData = new Tabulator("#table", {
        data: tableData,
        columns: batchInfoColumn,
        height: 300,
        layout: "fitDataFill",
        selectable: 1,
      });
      varData.on("rowSelected", function (row) {
        const selectedRow = row.getData();
        if (
          selectedRow.txtDecision === "Scrap" ||
          (selectedRow.txtDecision === "Downgrade" &&
            selectedRow.txtTdc.length > 0)
        ) {
          setSecondTdcTableLook({
            popUp: true,
            data: selectedRow?.EOM_ID_BATCH,
          });
          const secondTableData = [
            {
              Column1: "",
              Column2: "",
              Column4: selectedRow.EOM_MS_PIECE_ACTL,
              Column5: "",
            },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
          ];
          setSecondTdcTableData(secondTableData);
        }
        if (
          selectedRow.txtDecision === "Pass" ||
          selectedRow.txtDecision === "Addl Process" ||
          selectedRow.txtDecision === "Release with Order Delink"
        ) {
          setSecondTdcTableData([]);
          setSecondTdcTableLook({ popUp: false, data: "" });
        }
      });

      varData?.on("rowDeselected", function (row) {
        setSecondTdcTableData([]);
        setSecondTdcTableLook({ popUp: false, data: [] });
      });
      setTable(varData);
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData, tdcOptions, addlProcessList, divTdc]);

  const confirmDecision = (data?: any) => {
    let reasonData = [];
    if (data?.option === 5 || data?.option === 9) {
      reasonData = data?.table2Data?.map((row: any, i: number) => {
        return row._row.data;
      });
    }
    let selectedTdcData = ["", ""];
    selectedTdcData = data?.txtTdc?.split("-");
    const selectedDivTdc = data?.txtDivTdc;
    let varData = {
      p_plant: selectedPlant,
      p_radio_value: String(data?.option),
      p_batch: data?.EOM_ID_BATCH ? data?.EOM_ID_BATCH : "",
      p_status: data?.EOM_CD_STATUS ? data?.EOM_CD_STATUS : "",
      p_curr_proc: data?.EOM_CD_CURR_PROC ? data?.EOM_CD_CURR_PROC : "",
      p_next_proc: data?.EOM_CD_NEXT_PROC ? data?.EOM_CD_NEXT_PROC : "",
      p_cust_ord: data?.EOM_ID_ORDER_CUS ? data?.EOM_ID_ORDER_CUS : "",
      p_cust_item: data?.EOM_ID_ORD_ITEM_CUS ? data?.EOM_ID_ORD_ITEM_CUS : "",
      p_sec_qlty: "",
      p_sec_tdc: selectedTdcData[0] ? selectedTdcData[0] : "",
      p_proc: data?.EOM_CD_CURR_PROC ? data?.EOM_CD_CURR_PROC : "",
      p_rsn_cd: reasonData[0]?.Column2?.split("-")[0]
        ? reasonData[0]?.Column2?.split("-")[0]
        : "",
      p_rsn_cat: reasonData[0]?.Column1 ? reasonData[0]?.Column1 : "",
      p_rsn_desc: reasonData[0]?.Column2?.split("-")[1]
        ? reasonData[0]?.Column2?.split("-")[1]
        : "",
      p_gross_cal: data?.EOM_MS_PIECE_ACTL ? data?.EOM_MS_PIECE_ACTL : "",
      p_tdc: data?.EOM_TDC_ACTL ? data?.EOM_TDC_ACTL : "",
      p_sec_no_matnr: selectedTdcData[1] ? selectedTdcData[1] : "",
      p_qlty_actl: data?.EOM_CD_QLTY_ACTL ? data?.EOM_CD_QLTY_ACTL : "",
      p_param_cust: data?.ENC_CUST_NAME ? data?.ENC_CUST_NAME : "",
      p_rls_remarks: data?.REMARKS_FIELD ? data?.REMARKS_FIELD : "",
      p_rls_remarks1: data?.REMARKS_FIELD1 ? data?.REMARKS_FIELD1 : "",
      p_rls_hold_code: data?.HOLD_NO_FIELD ? data?.HOLD_NO_FIELD : "",
      p_addl_process: data?.txtAdlsProcess ? data?.txtAdlsProcess : "",
      reasonData: reasonData,
      p_gross_wt: data?.EOM_MS_GROSS_ACTL ?? "",
      p_no_sheet: data?.EOM_NO_PIECES ?? "",
      p_new_net_wt: data?.EOM_MS_PIECE_ACTL ?? "",
      p_div_tdc: selectedDivTdc ?? "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ001SaveDataApi(token, { data: varData })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.outBinds?.ls_out_flag[0] === "Y") {
              fetchData();
              setSecondTdcTableData([]);
              setSecondTdcTableLook({ popUp: false, data: [] });
              alertify.success(res?.data?.outBinds?.ls_out_flag);
              setTableData([]);
            }
            if (res?.data?.outBinds?.ls_out_flag[0] === "N") {
              alertify.error(res?.data?.outBinds?.ls_out_flag);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const batchInfoColumn: Array<any> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      //frozen: true,
      headerSort: false,
      title: "",
    },
    {
      field: "id",
      title: "id",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },

    {
      field: "EOM_ID_BATCH",
      title: "Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_SEC1",
      title: "Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "EOM_SEC2",
      title: "Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "EOM_LENGTH",
      title: "Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Batch TDC",
      field: "EOM_TDC_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_MS_PIECE_ACTL",
      title: "Net Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // bottomCalc: "sum",
      // bottomCalcParams: { precision: 3 },
      formatter: function (cell: any) {
        const value = cell.getValue();
        if (cell.getRow().getData().txtDecision === "Net Wt Change") {
          cell.getElement().style["border"] = "1.5px solid #748da6";
        }
        return value ? Number(value).toFixed(3) : value;
      },
      editable: function (cell: any) {
        return cell.getRow().getData().txtDecision === "Net Wt Change";
      },
      editor: "number",
      // formatter: function (cell: any, formatterParams: any) {
      //   var value = cell.getValue();
      //   if (value) {
      //     return value?.toFixed(3);
      //   }
      //   return value;
      // },
    },
    {
      field: "EOM_MS_GROSS_ACTL",
      title: "Gross Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        const value = cell.getValue();
        if (cell.getRow().getData().txtDecision === "Gross Wt Change") {
          cell.getElement().style["border"] = "1.5px solid #748da6";
        }
        return value ? Number(value).toFixed(3) : value;
      },
      editable: function (cell: any) {
        return cell.getRow().getData().txtDecision === "Gross Wt Change";
      },
      editor: "number",
    },
    {
      field: "EOM_NO_PIECES",
      title: "No of Sheet",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        const value = cell.getValue();
        if (cell.getRow().getData().txtDecision === "Sheet No Change") {
          cell.getElement().style["border"] = "1.5px solid #748da6";
        }
        return value ? Number(value).toFixed(3) : value;
      },
      editable: function (cell: any) {
        return cell.getRow().getData().txtDecision === "Sheet No Change";
      },
      editor: "number",
    },
    {
      title: "Decision",
      field: "txtDecision",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "list",
      formatter: (cell: any) => {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: decisionList,
      },
      cellClick: function (e, cell) {
        let table = cell.getTable();
        table.deselectRow();
        let row = cell.getRow();
        row.select();
      },
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        setSecondTdcTableLook({ popUp: false, data: [] });
        setSecondTdcTable("");
        setSecondTdcTableData([]);
        setTdcOptions([]);
        // setDivTdc([]);
        const decisionVal = cell._cell.row.data?.txtDecision;

        row.update({
          txtTdc: "",
          txtAdlsProcess: "",
          txtDivTdc: "",
          EOM_MS_PIECE_ACTL:
            decisionVal === "Net Wt Change"
              ? row.getData().EOM_MS_PIECE_ACTL
              : row.getData().ORIGINAL_NET_WT,
          EOM_MS_GROSS_ACTL:
            decisionVal === "Gross Wt Change"
              ? row.getData().EOM_MS_GROSS_ACTL
              : row.getData().ORIGINAL_GROSS_WT,
          EOM_NO_PIECES:
            decisionVal === "Sheet No Change"
              ? row.getData().EOM_NO_PIECES
              : row.getData().ORIGINAL_SHEET_NO,
        });
        const mBatch = cell._cell.row.data?.EOM_ID_FIRST_PAR;
        const batchId = cell._cell.row.data?.EOM_ID_BATCH;
        const isEntDiv = batchId?.substr(0, 2) === "GS" ? true : false;

        /*NOTE: Downgrade, net wt, gross wt, sheet no change features
                are not applicable for RM coils which includes ent division coils as well*/
        if (
          decisionVal === "Downgrade" ||
          decisionVal === "Gross Wt Change" ||
          decisionVal === "Sheet No Change" ||
          decisionVal === "Net Wt Change"
        ) {
          if (batchId === mBatch || isEntDiv) {
            alertify.error("Feature not applicable for RM coils");
            row.update({
              txtDecision: "",
            });
            return;
          } else if (decisionVal === "Downgrade") {
            let inputData = { PrimeTdc: cell._cell.row.data?.EOM_TDC_ACTL };
            SCQ001GetData("getDowngradeTdc", inputData);
          }
        } else if (decisionVal === "Scrap") {
          //Displaying 2nd grid
          setSecondTdcTableLook({
            popUp: true,
            data: row?._row?.data?.EOM_ID_BATCH,
          });
          const secondTableData = [
            {
              Column1: "",
              Column2: "",
              Column4: cell._cell.row.data.EOM_MS_PIECE_ACTL,
              Column5: "",
            },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
            { Column1: "", Column2: "", Column4: 0, Column5: "" },
          ];
          setSecondTdcTableData(secondTableData);
        } else if (decisionVal === "Addl Process") {
          SCQ001GetData("getAddlProcess", "");
        } else if (decisionVal === "Diversion") {
          let primeTdc = { PrimeTdc: cell._cell.row.data?.EOM_TDC_ACTL };
          SCQ001GetData("getDiversionTdc", primeTdc);
        }
        // else if (decisionVal === "Diversion") {
        //   let varData = {
        //     coilid: cell._cell.row.data?.EOM_ID_BATCH,
        //     qltycd: cell._cell.row.data?.EOM_CD_QLTY_ACTL,
        //     tdcno: cell._cell.row.data?.EOM_TDC_ACTL,
        //   };
        //   let data = { BatchId: cell._cell.row.data?.EOM_ID_BATCH };
        //   setLoading(true);
        //   GetAuthorization().then((token: TokenType) => {
        //     SCQ001DiversionResApi(token, { data: varData })
        //       .then((res) => {
        //         if (res.statusText !== "" && res.statusText !== "OK") {
        //           alertify.error(
        //             res?.data?.err ? res.data.err : res?.toString()
        //           );
        //         } else if (res?.data) {
        //           GetAuthorization().then((token: TokenType) => {
        //             SCQ001GetDataApi(token, {
        //               type: "getDiversionTdc",
        //               data,
        //             })
        //               .then((res1) => {
        //                 if (
        //                   res1.statusText !== "" &&
        //                   res1.statusText !== "OK"
        //                 ) {
        //                   alertify.error(
        //                     res1?.data?.err ? res1.data.err : res?.toString()
        //                   );
        //                 }
        //                 const divrnTdc = res1?.data?.DiversionTdc.map((row) => {
        //                   return row.TIC_TDC_NO;
        //                 });

        //                 row.update({
        //                   DecisionEditorParams: { values: divrnTdc },
        //                 });
        //               })
        //               .catch((e) => {
        //                 alertify.error(
        //                   e?.error?.message
        //                     ? e.error.message
        //                     : "Something Went wrong!"
        //                 );
        //               })
        //               .finally(() => {
        //                 row.select();
        //               });
        //           });
        //         }
        //       })
        //       .catch((e) => {
        //         alertify.error(
        //           e?.error?.message
        //             ? e.error.message
        //             : "Unable to fetch Diversion TDC!"
        //         );
        //       })
        //       .finally(() => {
        //         setLoading(false);
        //         row.select();
        //       });
        //   });
        // }
        else {
          row.update({
            DecisionEditorParams: { values: [] },
          });
        }

        let row1 = cell.getRow();
        row1.select();
      },
    },
    {
      title: "TDC",
      field: "txtTdc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      width: 70,
      formatter: (cell: any) => {
        var value = cell.getValue();
        if (cell._cell.row.data.txtDecision === "Downgrade") {
          cell.getElement().style["background-color"] = "#748da6";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: tdcOptions,
      },
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        if (cell._cell.row.data?.txtDecision === "Downgrade") {
          setSecondTdcTableLook({
            popUp: true,
            data: cell._cell.row.data?.EOM_ID_BATCH,
          });
          const secondTableData = [
            {
              Column1: "",
              Column2: "",
              Column4: cell._cell.row.data.EOM_MS_PIECE_ACTL,
              // Column5: "",
            },
            { Column1: "", Column2: "", Column4: 0 },
            { Column1: "", Column2: "", Column4: 0 },
            { Column1: "", Column2: "", Column4: 0 },
          ];
          setSecondTdcTableData(secondTableData);
        }
        row.select();
      },
    },
    {
      title: "Diversion TDC",
      field: "txtDivTdc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: (cell: any) => {
        var value = cell.getValue();
        if (cell._cell.row.data.txtDecision === "Diversion") {
          cell.getElement().style["background-color"] = "#748da6";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: divTdc,
      },
      // editorParams: function (cell) {
      //   return cell.getRow().getData().DecisionEditorParams || { values: [] };
      // },
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        row.select();
      },
    },
    {
      title: "Addl Process",
      field: "txtAdlsProcess",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: (cell: any) => {
        var value = cell.getValue();
        if (cell._cell.row.data.txtDecision === "Addl Process") {
          cell.getElement().style["background-color"] = "#748da6";
          cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
      editor: "list",
      editorParams: function (cell) {
        return {
          allowEmpty: false,
          showListOnEmpty: true,
          values:
            cell._cell.row.data.txtDecision === "Addl Process"
              ? addlProcessList
              : [],
        };
      },
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const status = cell._cell.row.data?.EOM_CD_STATUS;
        var addlProc = cell?.getValue();
        if (status == "WD" && addlProc === "K") {
          alertify.error("Packing process cannot be given for batches in WD");
          row.update({
            txtAdlsProcess: "",
          });
          return;
        }
        row.select();
      },
    },
    {
      field: "HOLD_NO_FIELD",
      title: "Release againt hold code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      maxWidth: 250,
      formatter: (cell: any) => {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      formatter: () => {
        return "<i class='fa-solid fa-square' style='color:#49a3f1'></i>";
      },
      width: 10,
      cellClick: function (e: any, cell: any) {
        const id = cell._cell.row.data.id;
        let batchData = { BatchNo: cell._cell.row.data?.EOM_ID_BATCH };
        SCQ001GetData("getHoldRsnCode", batchData);
        setHoldNoPopUp({ popUp: true, data: id });
      },
    },
    {
      field: "REMARKS_FIELD",
      title: "Release Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      maxWidth: 300,
      formatter: (cell: any) => {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    {
      formatter: () => {
        return "<i class='fa-solid fa-square' style='color:#49a3f1'></i>";
      },
      width: 10,
      cellClick: function (e: any, cell: any) {
        const id = cell._cell.row.data.id;
        SCQ001GetData("getRemarks");
        setRemarksPopUp({ popUp: true, data: id });
      },
    },
    {
      field: "REMARKS_FIELD1",
      title: "Addl Release Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      maxWidth: 300,
      formatter: (cell: any) => {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
      editor: "input",
    },
    {
      field: "EOM_CD_PROD",
      title: "ProdCD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_CURR_PROC",
      title: "Curr Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_NEXT_PROC",
      title: "Next Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_FIRST_PAR",
      title: "Mother Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_PAR_COIL_NO",
      title: "Parent Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_STATUS",
      title: "Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   field: "RUSH_FLAG",
    //   title: "Rush Order Flag",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "EOM_CD_QLTY_ACTL",
      title: "ActlQlty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_ORDER_CUS",
      title: "Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_ID_ORD_ITEM_CUS",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "ENC_CUST_NAME",
      title: "Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "EOM_CD_EPA",
      title: "Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const fetchData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!selectedStatus) {
      alertify.error("Please Select the Status");
      return;
    }
    if (coilId && coilId?.length != 10) {
      alertify.error("Coil Id lenght should be 10");
      return;
    }
    if (batchId && batchId?.length != 10) {
      alertify.error("Batch Id lenght should be 10");
      return;
    }
    const updatedState = {
      plant: selectedPlant,
      coilId: coilId,
      batchId: batchId,
      status: selectedStatus,
      User: user,
    };
    SCQ001GetBatchData("SCQ001getBatchData", updatedState);
  };

  const SCQ001GetBatchData = (type?: any, data?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ001GetDataApi(token, {
        type: type,
        data,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (type === "SCQ001getBatchData") {
              if (res?.data?.length > 0) {
                res?.data?.map((row: any, item: any) => {
                  row["id"] = item;
                  row.ORIGINAL_GROSS_WT = row.EOM_MS_GROSS_ACTL;
                  row.ORIGINAL_SHEET_NO = row.EOM_NO_PIECES;
                  row.ORIGINAL_NET_WT = row.EOM_MS_PIECE_ACTL;
                  return row;
                });
                setTableData(res?.data);
              } else {
                alertify.error("No Data Found!");
                return;
              }
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const SCQ001GetData = (type?: any, data?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SCQ001GetDataApi(token, {
        type: type,
        data,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (
              res?.data?.DowngradeTdc?.length > 0 &&
              type === "getDowngradeTdc"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.DowngradeTdc?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ESP_TDC_DOWNGRADE?.toString(),
                    label: x.ESP_TDC_DOWNGRADE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setTdcOptions(varData);
            }
            // Array for Addl Process
            else if (
              res?.data?.AddlProcess?.length > 0 &&
              type === "getAddlProcess"
            ) {
              const varAddlProcData: Array<SelectType> = [];
              res?.data?.AddlProcess?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varAddlProcData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setAddlProcessList(varAddlProcData);
            } else if (type === "getHoldRsnCode") {
              if (res.data?.hold_rsn_cd.length === 0) {
                setHoldNoPopUp({ popUp: false, data: id });
                alertify.error("Hold No Data not exists!");
              }
              setHoldNoTableData(res.data?.hold_rsn_cd);
            } else if (type === "getRemarks") {
              if (res.data?.RemarkLists.length === 0) {
                alertify.error("No Reason Data exists");
              }
              setRemarksTableData(res.data?.RemarkLists);
            } else if (
              res?.data?.DiversionTdc?.length > 0 &&
              type === "getDiversionTdc"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.DiversionTdc?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.DIV_TDC?.toString(),
                    label: x.DIV_TDC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              console.log("varData: ", varData);
              setDivTdc(varData);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setCoilId("");
    setSelectedStatus("");
    setBatchId("");
    setSelectedPlant("");
    setTableData([]);
    setSecondTdcTableData([]);
    setSecondTdcTableLook({ popUp: false, data: [] });
  };

  const handleConfirm = () => {
    if (table?.getSelectedRows().length === 0) {
      alertify.error("Please Select a Batch");
      return;
    }
    let selectedRow = table?.getSelectedRows()[0]._row.data;
    if (!selectedRow.txtDecision) {
      alertify.error("Please Select a Decision");
      return;
    }

    if (selectedRow?.txtDecision === "Addl Process") {
      if (selectedRow?.txtAdlsProcess?.length === 0) {
        alertify.error("Please Select Addl Process!");
        return;
      }
      if (selectedRow?.REMARKS_FIELD === undefined) {
        alertify.error("Please Select Release Remarks!");
        return;
      }
    }

    let table2Data = secondTdcTable ? secondTdcTable?.getSelectedRows() : "";

    if (
      selectedRow?.txtDecision === "Downgrade" ||
      selectedRow?.txtDecision === "Scrap"
    ) {
      if (table2Data?.length === 0) {
        alertify.error("Please Select atleast one Row from Reason Category");
        return;
      }
    }

    let netWt = selectedRow.EOM_MS_PIECE_ACTL;
    let scheduleWt = 0;
    let checkError = false;

    for (let i in table2Data) {
      if (
        !table2Data[i]._row.data.Column1 ||
        !table2Data[i]._row.data.Column2 ||
        (selectedRow?.txtDecision === "Scrap" &&
          !table2Data[i]._row.data.Column5)
      ) {
        checkError = true;
      }
      scheduleWt += Number(table2Data[i]._row.data.Column4);
    }
    if (checkError) {
      alertify.error(
        "All feilds are mandatory"
        // "Reason Category, Reason Code and Materail No are mandatory fields for Selected Rows "
      );
      return;
    }
    if (selectedRow?.txtDecision === "Pass") {
      selectedRow = { ...selectedRow, option: 1 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else if (selectedRow?.txtDecision === "Release with Order Delink") {
      selectedRow = { ...selectedRow, option: 7 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else if (selectedRow?.txtDecision === "Diversion") {
      selectedRow = { ...selectedRow, option: 3 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else if (selectedRow?.txtDecision === "Downgrade") {
      selectedRow = { ...selectedRow, option: 5, table2Data: table2Data };
    } else if (selectedRow?.txtDecision === "Scrap") {
      selectedRow = { ...selectedRow, option: 9, table2Data: table2Data };
    } else if (selectedRow?.txtDecision === "Addl Process") {
      selectedRow = { ...selectedRow, option: 0, table2Data: table2Data };
      setAlertPopUp({ popUp: true, data: selectedRow });
      // confirmDecision(selectedRow);
      return;
    } else if (selectedRow?.txtDecision === "Gross Wt Change") {
      selectedRow = { ...selectedRow, option: 10 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else if (selectedRow?.txtDecision === "Sheet No Change") {
      selectedRow = { ...selectedRow, option: 11 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else if (selectedRow?.txtDecision === "Net Wt Change") {
      selectedRow = { ...selectedRow, option: 12 };
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    }

    const newNetWt = parseFloat(netWt.toFixed(3));
    const newScheduleWt = parseFloat(scheduleWt.toFixed(3));
    if (newNetWt === newScheduleWt) {
      setAlertPopUp({ popUp: true, data: selectedRow });
      return;
    } else {
      alertify.error(
        `Sum of tonnage wt - ${newScheduleWt} is not equal to Net wt - ${newNetWt}`
      );
      return;
    }
  };

  function isColumn5Visible() {
    let selectedDec = table?.getSelectedRows()[0]?._row.data?.txtDecision;
    return selectedDec === "Scrap";
  }

  let secondTdcDesicionColumn: any = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
    },

    {
      field: "Column1",
      title: "Reason Category",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      width: isColumn5Visible() ? 130 : 130,
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: rsnCategory,
      },
      cellEdited: function (cell) {
        const value = cell.getValue();
        const row = cell.getRow();

        GetAuthorization().then((token: TokenType) => {
          SCQ001Api(token, {
            type: "getRsnCodeData",
            rsnCat: value,
          }).then((res) => {
            if (res.data?.length === 0) {
              alertify.error("No reason codes");
              return;
            }
            const reasonCodes = res?.data?.REASON_DESP.map((row) => {
              return row.ESR_RSN_CD + " - " + row.ESR_RSN_DESC;
            });

            row.update({
              Column2EditorParams: { values: reasonCodes },
            });
          });
        });
      },
      formatter: (cell: any) => {
        var value = cell.getValue();
        return value;
      },
      editorParams: {
        values: [],
      },
    },
    {
      field: "Column2",
      title: "Reason Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      width: isColumn5Visible() ? 230 : 300,
      editor: "list",
      formatter: (cell: any) => {
        return cell.getValue();
      },
      editorParams: function (cell) {
        return cell.getRow().getData().Column2EditorParams || { values: [] };
      },
    },

    {
      field: "Column4",
      title: "Tonnage",
      width: isColumn5Visible() ? 80 : 150,
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          value = Number(value)?.toFixed(3);
        }
        return value;
      },

      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      editor: function (
        cell: any,
        onRendered: any,
        success: any,
        cancel: any,
        editorParams: any
      ) {
        if (!cell.getData().Column1) {
          alertify.error("Please Select Reason Category");
          return;
        }
        if (!cell.getData().Column2) {
          alertify.error("Please Select Reason Code");
          return;
        }

        var editor = document.createElement("input");
        var value1 = cell?.getValue();
        if (value1) {
          value1 = Number(value1)?.toFixed(3);
        }
        //create and style input
        editor.style.padding = "3px";
        editor.style.width = "100%";
        editor.style.boxSizing = "border-box";
        editor.value = cell.getValue() ? value1 : 0;
        editor.type = "number";

        onRendered(function () {
          editor.focus();
        });

        //when the value has been set, trigger the cell to update
        function successFunc() {
          let row = cell.getRow();
          success(editor.value);
        }

        editor.addEventListener("change", successFunc);
        editor.addEventListener("blur", successFunc);

        return editor;
      },
    },

    {
      field: "Column5",
      title: "Material No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      width: 200,
      editor: "list",
      formatter: (cell: any) => {
        return cell.getValue();
      },
      editorParams: {
        values: [],
      },
      visible: isColumn5Visible(),
    },
  ];
  React.useEffect(() => {
    if (secondTdcTableData?.length > 0) {
      //SCQ001GetData("getReasonCategory");
      const colFunction = async () => {
        try {
          setLoading(true);
          const token = await GetAuthorization();
          let varParam = {
            // route: "getPopupData",
            type: "getReasonCategory",
          };
          const res = await SCQ001Api(token, varParam);
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            secondTdcDesicionColumn[1].editorParams.values =
              res?.data?.REASON_CATEGORY.map((row: any) => {
                return row.ESR_RSN_CAT;
              });
            secondTdcDesicionColumn[4].editorParams.values =
              res?.data?.material_no.map((row: any) => {
                return row.MATNRDESC;
              });
          }
        } catch (error) {
          alertify.error(error, "Something went Wrong");
        } finally {
          setLoading(false);
        }
      };
      colFunction();
    }
    if (secondTdcTableData?.length > 0) {
      setSecondTdcTable(
        new Tabulator("#table6", {
          data: secondTdcTableData,
          columns: secondTdcDesicionColumn,
          height: 237,
          //movableRows: true,
          layout: "fitDataFill",
        })
      );
    }
  }, [secondTdcTableData]);

  const remarksCol: any = [
    {
      title: "Remarks",
      field: "CD_DESC",
      cellClick: function (e: any, cell: any) {
        {
          handleClose(cell);
        }
      },
    },
  ];

  React.useEffect(() => {
    if (remarksTableData.length > 0) {
      setRemarksTable(
        new Tabulator("#remarksTable", {
          height: "100%",
          data: remarksTableData,
          columns: remarksCol,
        })
      );
    } else {
      setRemarksTable(null);
    }
  }, [remarksTableData]);

  const handleClose = (cell: any) => {
    const rowId = remarksPopUp?.data;
    table?.updateRow(rowId, {
      REMARKS_FIELD: cell._cell?.row?.data?.CD_DESC,
    });
    setRemarksPopUp({ popUp: false, data: "" });
  };

  const holdNoCol: any = [
    {
      title: "Hold Time",
      field: "CHR_TS_HOLD",
      cellClick: function (e: any, cell: any) {
        {
          handleCloseHold(cell);
        }
      },
    },
    {
      title: "Hold Code",
      field: "CHR_CD_RSN_HOLD",
      cellClick: function (e: any, cell: any) {
        {
          handleCloseHold(cell);
        }
      },
    },
    {
      title: "Hold Desc",
      field: "CD_DESC",
      cellClick: function (e: any, cell: any) {
        {
          handleCloseHold(cell);
        }
      },
    },
  ];

  React.useEffect(() => {
    if (holdNoTableData.length > 0) {
      setHoldNoTable(
        new Tabulator("#holdNoTable", {
          height: "100%",
          data: holdNoTableData,
          columns: holdNoCol,
        })
      );
    } else {
      setHoldNoTable(null);
    }
  }, [holdNoTableData]);

  const handleCloseHold = (cell: any) => {
    const rowId = holdNoPopUp?.data;
    table?.updateRow(rowId, {
      HOLD_NO_FIELD: cell._cell?.row?.data?.CHR_CD_RSN_HOLD,
    });
    setHoldNoPopUp({ popUp: false, data: "" });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={2} sx={{ pl: 1 }}>
            {/* ---------------------- Alert --------------------------- */}
            <Dialog open={alertPopup.popUp} onClose={() => {}}>
              <DialogTitle>
                <WarningIcon color="warning" />
                Warning
              </DialogTitle>
              <DialogContent>
                <p>
                  Do you want to confirm for Batch-
                  {alertPopup.data?.EOM_ID_BATCH}{" "}
                </p>
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={() => {
                    confirmDecision(alertPopup.data);
                    //procedureApiCall(alertPopup.data);
                    setAlertPopUp({ popUp: false, data: "" });

                    //procedure Call
                  }}
                  color="primary"
                >
                  YES
                </Button>
                <Button
                  onClick={() => {
                    setAlertPopUp({ popUp: false, data: "" });
                  }}
                  color="primary"
                >
                  NO
                </Button>
              </DialogActions>
            </Dialog>

            {/*-------------- Remarks Pop up------------ */}
            <Dialog
              open={remarksPopUp.popUp}
              onClose={() => {
                console.log("Closed Remarks");
              }}
            >
              <DialogTitle>Remarks</DialogTitle>
              <DialogContent>
                {loading ? <Loader /> : null}
                {remarksTableData?.length > 0 ? (
                  <div id="remarksTable" />
                ) : null}
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={() => {
                    setRemarksPopUp({ popUp: false, data: "" });
                  }}
                  color="primary"
                >
                  Close
                </Button>
              </DialogActions>
            </Dialog>

            {/* --------HOLD NO POP UP--------------------- */}
            <Dialog
              open={holdNoPopUp.popUp}
              onClose={() => {
                console.log("Closed Hold");
              }}
            >
              <DialogTitle>Hold No Data</DialogTitle>
              <DialogContent>
                {loading ? <Loader /> : null}
                {holdNoTableData?.length > 0 ? <div id="holdNoTable" /> : null}
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={() => {
                    setHoldNoPopUp({ popUp: false, data: "" });
                  }}
                  color="primary"
                >
                  Close
                </Button>
              </DialogActions>
            </Dialog>

            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid
                      container
                      spacing={2}
                      sx={{
                        gap: 1.5,
                      }}
                    >
                      <Grid item xs={3} sx={{ ml: 2 }}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            fetchEpaData(e);
                            setScheduleDetailsData([]);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <Input
                          label="Mother Batch Id"
                          value={coilId}
                          size={"small"}
                          onChange={(e: string) => {
                            setCoilId(e.toUpperCase().slice(0, 10));
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <Input
                          label="Batch ID"
                          value={batchId}
                          size={"small"}
                          onChange={(e: string) => {
                            setBatchId(e.toUpperCase().slice(0, 10));
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <SelectInput
                          label="Status"
                          data={statusData}
                          value={selectedStatus}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedStatus(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={1}>
                        <ButtonElement onClick={() => fetchData()}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Batch Information"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title={!table?.length ? "Decision" : ""}>
                        <IconButton
                          onClick={() => handleConfirm()}
                          disabled={restricted !== "RL_RW"}
                        >
                          {!table?.length ? (
                            <NextPlanIcon sx={{ color: "#ffffff" }} />
                          ) : (
                            ""
                          )}
                        </IconButton>
                      </Tooltip>
                    </Grid>

                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel("Batch Information", tableData, table)
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            {secondTdcLook.popUp && secondTdcTableData?.length > 0 && (
              // <Grid item xs={5.5} sx={{ ml: 40, mr: 30 }}>
              // <Grid item xs={10}>
              <Grid item xs={10} sx={{ ml: 10, mr: 20 }}>
                <TableContainer
                  title={`Reason Category Details for Batch - ${secondTdcLook.data} `}
                >
                  {secondTdcTableData?.length > 0 && <div id="table6"></div>}
                </TableContainer>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SCQ001;
