import { Router } from "express";
import { SPS0020Controller } from "../controllers/SPS0020Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0020Route = Router();

SPS0020Route.route("/SPS0020/SPS0020Api").post(
  authenticationMiddleware.bearer,
  SPS0020Controller
);

export default SPS0020Route;
