import { Request, Response } from "express";
import SPC0012Model from "../models/SPC0012Model";
import { ResponceData } from "../utils";

export const getOrderProgData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0012Model.prototype.getOrderProgData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
