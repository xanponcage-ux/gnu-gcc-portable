import { Request, Response } from "express";
import SPC0006Model from "../models/SPC0006Model";
import { ResponceData } from "../utils";

export const getData06 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;

    if (req.body.data === 0) {
      result1 = await SPC0006Model.prototype.getSECONDSTdc06(req.body);
    }
    if (req.body.data === 1) {
      result2 = await SPC0006Model.prototype.getTdcMap06(req.body);
    }

    varData = {
      ...{ SecondsTb: await ResponceData(result1) },
      ...{ TdcMapTb: await ResponceData(result2) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getEpaCode06 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0006Model.prototype.getEpaPlant06();
    const result2 = await SPC0006Model.prototype.getTdcsec06();
    const result3 = await SPC0006Model.prototype.getActTdc06();

    const varData = {
      EpaPlant: await ResponceData(result1),
      TdcSec: await ResponceData(result2),
      Acttdc: await ResponceData(result3),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const callProcedure06 = async (req: Request, res: Response) => {
  try {
    const data = req.body;
    let results: any = {};
    for (let i in data) {
      let singleData = data[i];
      let result1: any = await SPC0006Model.prototype.callProcedure06(
        singleData
      );
      let outBinds = result1.outBinds.ls_message;

      results = outBinds;
    }

    return res.status(200).json(results);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
