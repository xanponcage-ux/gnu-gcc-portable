import { Request, Response } from "express";
import SPQ001Model from "../models/SPQ001Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData01 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPQ001Model.prototype.getData01(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
