import React from "react";
import DashboardLayout from "src/components/layout/dashboardLayout";
import Tabulator from "src/components/table";
import TableContainer from "src/components/tableContainer";
import { Input, SelectInput } from "src/components/input";
//import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import alertify from "src/components/alert";
import { GetAuthorization, DateFormat } from "src/utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
// import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
//import Draggable from "react-draggable";
//import Paper, { PaperProps } from "@mui/material/Paper";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import { SPS0015Api } from "src/apiConfig/insideAuthApi";
import WarningIcon from "@mui/icons-material/Warning";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import DeleteIcon from "@mui/icons-material/Delete";
import Loader from "src/components/preloader";
import { SelectType } from "src/components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "src/theme/type";
import SaveIcon from "@mui/icons-material/Save";
import ArchitectureIcon from "@mui/icons-material/Architecture";
import { DatePickerInput } from "src/components/input";
import ButtonElement from "src/components/button";
import { TokenType } from "src/type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
//import { TableType, PopupObj, option, popuptype } from "./type";
import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "src/context";
import { Collapse } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPS0015 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [table1, setTable1] = React.useState<any>(null);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedCode, setSelectedCode] = React.useState<any>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [tableData, setTableData] = React.useState<any>([]);
  const [deletePop, setDeletePop] = React.useState<popuptype>({
    isPopUp: false,
    data: "",
  });
  const [coilData, setCoilData] = React.useState<Array<SelectType>>([]);
  const [scheduleData, setScheduleData] = React.useState<Array<option>>([]);
  const [plannedPathData, setPlannedPathData] = React.useState<Array<option>>(
    []
  );
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [processData, setProcessData] = React.useState<Array<SelectType>>([]);
  const [selectedProcess, setSelectedProcess] = React.useState<any>("");
  const [value, setValue] = React.useState<number>(0);
  const [plannedPath, setPlannedPath] = React.useState<string>("");

  // const [prodCd, setProdCd] = React.useState<any>("");
  // const [schedId, setSchedId] = React.useState<any>("");
  const [fromDt, setFromDt] = React.useState<any>("");
  const [toDt, setToDt] = React.useState<any>("");
  const [reportType, setReportType] = React.useState<any>("schedConfirmData");
  const [coilId, setCoilId] = React.useState<any>("");

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "From Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "To Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };
  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);
  const [tableCompData, setTableCompData] = React.useState<any>([]);

  function isVisibleForK() {
    // Column not visible for K
    return selectedProcess !== "K";
  }

  function isVisibleForNTEK() {
    // Column ONLY visible for S
    return selectedProcess === "S";
  }

  const columnSchedCompleted: any = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },
    {
      title: "Sch Created Date",
      field: "CRT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForK(),
    },
    {
      title: "Schedule ID",
      field: "SCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: isVisibleForK(),
    },
    {
      title: "Coil Id",
      field: "COILID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Input Thk",
      field: "TNP_THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Input Width",
      field: "INP_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Input Coil Wt.",
      field: "PLAN_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      visible: isVisibleForK(),
    },
    {
      title: "Mother Coil Edge",
      field: "INP_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Input TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plan FG Grade",
      field: "GRADE_DEC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ip. Coil Length",
      field: "FG_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Planned Qty.",
      field: "SCH_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      visible: isVisibleForK(),
    },
    {
      title: "Comb",
      field: "COMBINATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: isVisibleForNTEK(),
    },
    {
      title: "No Part",
      field: "PART",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForNTEK(),
    },

    {
      title: "Planned Path",
      field: "PALN_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Max Wt.",
      field: "PC_WT_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Min Wt.",
      field: "PC_WT_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Sch Thick",
      field: "FGTHICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Sch Width",
      field: "SLIT_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForK(),
    },
    {
      title: "Sch TDC",
      field: "SCH_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Packing Type",
      field: "PACK_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Coil Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Coil Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Order Idia",
      field: "ENC_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForNTEK(),
      // visible: false,
    },
    {
      title: "FG Order Odia",
      field: "ENC_ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForNTEK(),
    },
    {
      title: "Order Edge",
      field: "ORD_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Planned Length",
      field: "PLAN_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: !isVisibleForNTEK(), //Col visible except slit
    },
    {
      title: "Sheet/Packet",
      field: "NO_SHEETS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: !isVisibleForNTEK(),
    },
    {
      title: "No of Packet",
      field: "NO_PACKET",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: !isVisibleForNTEK(),
    },
    {
      title: "Cut Length Tolerance",
      field: "CUT_LENGTH_TOL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: !isVisibleForNTEK(),
    },
    {
      title: "Width Tolerance",
      field: "WIDTH_TOL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Name",
      field: "CUST_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mark Cust Name",
      field: "MARK_CUST_NM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Segment",
      field: "CUST_SEGMENT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Road Dest.",
      field: "ROAD_DEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail Dest.",
      field: "RAIL_DEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Addl Rls Remarks",
      field: "ADDL_RLS_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SLP Remarks",
      field: "SLP_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "LYS",
      field: "YS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Cust Order",
      field: "ORDER_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Item",
      field: "ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Oil Type",
      field: "OIL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForK(),
    },
    {
      title: "Schd Remarks",
      field: "REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Setup",
      field: "SETUP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForK(),
    },
    {
      title: "Sch Created By",
      field: "CRT_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleForK(),
    },
    {
      title: "Plant Code",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Status",
      field: "CR_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Process",
      field: "CD_PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "PDI Status",
      field: "CD_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Intended Cust",
      field: "INP_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: false,
    },
    {
      title: "Intended Cust Cd",
      field: "INP_CUSTOMER_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: false,
    },
  ];

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: tableData,
          columns: columnSchedCompleted,
          height: 250,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData]);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0015Api(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              // const varbatchData: Array<SelectType> = [];
              // res?.data?.batch?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varbatchData?.push({
              //       value: x?.EOM_ID_BATCH?.toString(),
              //       label: x?.EOM_ID_BATCH?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setCoilData(varbatchData);
              // const varorderData1: Array<SelectType> = [];
              // res?.data?.scheduleId?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varorderData1?.push({
              //       value: x?.SCHID?.toString(),
              //       label: x?.SCHID?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setScheduleData(varorderData1);

              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcessData(varprocessData);
              // const varstatusData: Array<SelectType> = [];
              // res?.data?.status?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varstatusData?.push({
              //       value: x?.VALUE?.toString(),
              //       label: x?.LABEL?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setStatusData(varstatusData);
              // var varPlannedPath: Array<SelectType> = [];
              // res?.data?.plannedPath?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varPlannedPath?.push({
              //       value: x?.PPH_CD_PROC_PATH?.toString(),
              //       label: x?.PPH_DESC?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setPlannedPathData(varPlannedPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };
  const fetchData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!(selectedProcess?.length > 0)) {
      alertify.error("Please select Process!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      var data = {
        plant: selectedCode,
        process: selectedProcess,
        status: selectedStatus,
        // prodCd: prodCd,
        // schedId: schedId,
        coilId: coilId,
        fromDt: DateFormat(inputObj.key1.value),
        toDt: DateFormat(inputObj.key2.value),
      };
      SPS0015Api(token, {
        type: reportType,
        data: data,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              setTableData(res.data);
            } else {
              if (res?.data == 1) {
                setTableData([]);
                alertify.error(
                  "Selected process data currently not available!"
                );
              } else {
                setTableData([]);
                alertify.error("No data found");
              }
            }
          }
        })
        .catch((e) => {
          console.log("e: fetchData", e);
          alertify.error(
            e?.error?.response?.data?.error
              ? e?.error?.response?.data?.error
              : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchSchedCompData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!(selectedProcess?.length > 0)) {
      alertify.error("Please select Process!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      var data = {
        plant: selectedCode,
        process: selectedProcess,
        status: selectedStatus,
        // prodCd: prodCd,
        // schedId: schedId,
        coilId: coilId,
        fromDt: DateFormat(inputObj.key1.value),
        toDt: DateFormat(inputObj.key2.value),
      };
      SPS0015Api(token, {
        type: "schedCompData",
        data: data,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              setTableCompData(res.data);
            } else {
              if (res?.data == 1) {
                setTableCompData([]);
                alertify.error(
                  "Selected process data currently not available!"
                );
              } else {
                setTableCompData([]);
                alertify.error("No data found");
              }
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedCode("");
    setTableData([]);
    setTableCompData([]);
    setSelectedProcess("");
    // setProdCd("");
    // setSchedId("");
    setCoilId("");
    setInputObj(varInput);
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }
  const deleteData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0015Api(token, {
        type: "deleteData",
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleDeleteYes = () => {
    let dataArr = table?.getSelectedRows();
    if (dataArr?.length === 0) {
      alertify.error("Please select a row");
      return;
    }
    let coilIds: Array<any> = [];
    let check = true;
    for (let i = 0; i < dataArr.length; i++) {
      if (
        !(
          dataArr[i]?._row?.getData().CD_STATUS === "WC" ||
          dataArr[i]?._row?.getData().CD_STATUS === "WS"
        )
      ) {
        check = false;
        break;
      }
      coilIds.push({
        coilId: dataArr[i]?._row?.getData().COILID,
        plant: dataArr[i]?._row?.getData()?.PLANT,
        pline: dataArr[i]?._row?.getData()?.CD_PROCESS,
      });
    }
    if (!check) {
      alertify.error("Only Coils with status ('WB','WC') can be deleted");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0015Api(token, {
        type: "deleteData",
        data: coilIds,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (res.data.N?.length > 0) {
              alertify.error(res.data.N?.join(" "));
            } else {
              alertify.success("Success Y-All Schedules Rejected");
              setTableData([]);
              //fetchData();
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
    setDeletePop({ isPopUp: false, data: "" });
  };

  const handleDeleteClick = () => {
    let dataArr = table?.getSelectedRows();
    if (dataArr?.length === 0) {
      alertify.error("Please select a row to Delete");
      return;
    }
    setDeletePop({ isPopUp: true, data: "" });
    //Api call
  };

  const handleConfirClick = () => {
    let dataArr = table?.getSelectedRows();
    if (dataArr?.length === 0) {
      alertify.error("Please select a row to Confirm");
      return;
    }
    let coilIds: Array<any> = [];
    let check = true;
    for (let i = 0; i < dataArr.length; i++) {
      if (
        !(
          dataArr[i]?._row?.getData().CD_STATUS === "WC" ||
          dataArr[i]?._row?.getData().CD_STATUS === "WS"
        )
      ) {
        check = false;
        break;
      }
      coilIds.push({
        coilId: dataArr[i]?._row?.getData().COILID,
        plant: dataArr[i]?._row?.getData()?.PLANT,
        pline: dataArr[i]?._row?.getData()?.CD_PROCESS,
      });
    }
    if (!check) {
      alertify.error("Only Coils with status ('WB','WC') can be Confirmed");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0015Api(token, {
        type: "confirmData",
        data: coilIds,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (res.data.N?.length > 0) {
              alertify.error(res.data.N?.join(" "));
            } else {
              alertify.success("Success Y-All Schedules Confirmed");
              setTableData([]);
              //fetchData();
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    if (newValue == 0) {
      setReportType("schedConfirmData");
    } else if (newValue == 1) {
      setReportType("schedRejData");
    } else if (newValue == 2) {
      setReportType("schedCompData");
    }
    setTableData([]);
    setTableCompData([]);
    setSelectedStatus("");
    //setSelectedCode("");
    // setSelectedProcess("");
    setCoilId("");
    //fetchEpaData();
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={8}>
              {deletePop.isPopUp && (
                <div>
                  <Dialog open={deletePop.isPopUp} onClose={() => {}}>
                    <DialogTitle>
                      <WarningIcon color="warning" />
                      Warning
                    </DialogTitle>
                    <DialogContent>
                      <p>Are you sure want to delete the Schedules?</p>
                    </DialogContent>
                    <DialogActions>
                      <Button
                        onClick={() => {
                          handleDeleteYes();
                        }}
                        color="primary"
                      >
                        YES
                      </Button>
                      <Button
                        onClick={() => {
                          setDeletePop({ isPopUp: false, data: "" });
                        }}
                      >
                        NO
                      </Button>
                    </DialogActions>
                  </Dialog>
                </div>
              )}
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2.5}>
                      <Grid item xs={2.25}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            fetchEpaData(e);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Process*"
                          data={processData}
                          value={selectedProcess}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProcess(e);
                            setTableData([]);
                            setTableCompData([]);
                          }}
                        />
                      </Grid>
                      {/* <Grid item xs={1}>
                      <Input
                        label="Prod Cd"
                        id={"prodCd"}
                        value={prodCd}
                        onChange={(e: string) => {
                          setProdCd(e);
                        }}
                      />
                    </Grid> */}
                      {/* <Grid item xs={1.2}>
                      <Input
                        label="Schedule Id"
                        id={"SchedId"}
                        value={schedId}
                        onChange={(e: string) => {
                          setSchedId(e);
                        }}
                      />
                    </Grid> */}
                      <Grid item xs={2}>
                        <Input
                          label="Coil Id"
                          id={"CoilId"}
                          value={coilId}
                          onChange={(e: string) => {
                            setCoilId(e);
                          }}
                        />
                      </Grid>
                      <Grid item xs={4}>
                        {/* From Date */}
                        <Box component="span">
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i < 2 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>
                      <Grid item xs={1.5}>
                        <ButtonElement onClick={() => fetchData()}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title={"Schedule Details"}
                headerContainer={
                  <Grid container>
                    {value === 1 && (
                      <Grid item>
                        <Tooltip title={"Delete Scheduling"}>
                          <IconButton
                            onClick={() => {
                              handleDeleteClick();
                            }}
                            disabled={restricted !== "RL_RW"}
                          >
                            <DeleteIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid>
                    )}
                    {value === 0 && (
                      <Grid item>
                        <Tooltip title="Schedule Confirmation">
                          <IconButton
                            onClick={() => {
                              handleConfirClick();
                            }}
                            disabled={restricted !== "RL_RW"}
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid>
                    )}
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel("Sched Data", tableData, table1)
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                    <Tabs
                      value={value}
                      onChange={handleChange}
                      aria-label="basic tabs example"
                    >
                      <Tab label="Schedule Confirmation" />
                      <Tab label="Schedule Rejection" />
                      <Tab label="Open Schedule" />
                    </Tabs>
                  </Box>
                  {value === 0 && tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                  {value === 1 && tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                  {value === 2 && tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
                {/* <Box sx={{ width: "100%" }}>
                {tableData?.length > 0 && (
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <div id="table1"></div>
                      <br />
                      <p
                        color="black"
                        style={{
                          color: "black",
                          paddingLeft: "1rem",
                          marginTop: "-1rem",
                        }}
                      >
                        Showing 1 to {tableData?.length} of {tableData?.length}{" "}
                        entries
                      </p>
                    </Grid>
                  </Grid>
                )}
              </Box> */}
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0015;
