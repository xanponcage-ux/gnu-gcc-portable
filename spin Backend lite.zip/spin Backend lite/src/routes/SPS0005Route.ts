import { Router } from "express";
import {
  scheduling,
  getOrderData,
  scheduleID,
  getToleranceLimit,
  getDiversionRes,
} from "../controllers/SPS0005Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0005Route = Router();

SPS0005Route.route("/SPS0005/scheduling").post(
  authenticationMiddleware.bearer,
  scheduling
);

SPS0005Route.route("/SPS0005/orderData").post(
  authenticationMiddleware.bearer,
  getOrderData
);

SPS0005Route.route("/SPS0005/scheduleID").post(
  authenticationMiddleware.bearer,
  scheduleID
);

SPS0005Route.route("/SPS0005/getToleranceLimit").post(
  authenticationMiddleware.bearer,
  getToleranceLimit
);

SPS0005Route.route("/SPS0005/getDiversionRes").post(
  authenticationMiddleware.bearer,
  getDiversionRes
);

export default SPS0005Route;
