import { Router } from "express";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import {
  getTroubleType,
  getData,
  getModalDetails,
  getSaveTableDetails,
  insertDetails,
  deleteDetails,
  saveDetails,
} from "../controllers/SPO0008Controller";

const SPO0008Route = Router();

SPO0008Route.route("/SPO0008/getTroubleType").post(
  authenticationMiddleware.bearer,
  getTroubleType
);
SPO0008Route.route("/SPO0008/getData").post(
  authenticationMiddleware.bearer,
  getData
);
SPO0008Route.route("/SPO0008/saveModalData").post(
  authenticationMiddleware.bearer,
  getModalDetails
);
SPO0008Route.route("/SPO0008/saveTableData").post(
  authenticationMiddleware.bearer,
  getSaveTableDetails
);
SPO0008Route.route("/SPO0008/insertTableData").post(
  authenticationMiddleware.bearer,
  insertDetails
);
SPO0008Route.route("/SPO0008/deleteData").post(
  authenticationMiddleware.bearer,
  deleteDetails
);
SPO0008Route.route("/SPO0008/saveData").post(
  authenticationMiddleware.bearer,
  saveDetails
);

export default SPO0008Route;
