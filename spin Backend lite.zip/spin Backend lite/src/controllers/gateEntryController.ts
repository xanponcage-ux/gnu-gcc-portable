import { Request, Response } from "express";
import GateEntryModel from "../models/gateEntryModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

// export const getData01 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if(req.body.data === 0) {
//         result1 = await GateEntryModel.prototype.getData01(req.body);
//     }
//     if(req.body.data === 1) {
//         result2 = await GateEntryModel.prototype.getData01(req.body);
//     }
//     varData = {
//       ... { procLine: await ResponceData(result1) },
//       ...{ procPath: await ResponceData(result2) },
//     }
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
// export const getEpaData01 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await GateEntryModel.prototype.getStatusCodeData01();
//     const result2 = await GateEntryModel.prototype.getInvoiceData01();
//     const result3 = await GateEntryModel.prototype.getMaterialData01();
//     const result4 = await GateEntryModel.prototype.getProdData01();
//     const result5 = await GateEntryModel.prototype.getQltyData01();
//     const result6 = await GateEntryModel.prototype.getTdcData01();
//     const varData = {
//       statusCode: await ResponceData(result1),
//       invoice: await ResponceData(result2),
//       material: await ResponceData(result3),
//       prod: await ResponceData(result4),
//       qlty: await ResponceData(result5),
//       tdc: await ResponceData(result6),
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
