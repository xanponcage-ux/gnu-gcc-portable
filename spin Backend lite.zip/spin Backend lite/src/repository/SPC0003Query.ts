import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getPackingCode03 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = ` SELECT TPM_CD_EPA, TPM_MARK_CUST, TPM_PACK_SEQ, TPM_TDC TDC,
       (SELECT NAME1
          FROM V_KNA1
         WHERE MANDT = '600'
           AND KUNNR = LPAD (TPM_MARK_CUST, 10, '0')) CUST_NAME,
       TPM_PACK_CD, TPM_CRT_ID, TPM_CRT_DT CRT_DT, TPM_UPD_ID, TPM_UPD_DT,
       TPM_SEC2_MIN, TPM_SEC2_MAX, TPM_PRODUCT
      FROM V_PACK_MASTER
      WHERE TPM_CD_EPA = :code `;

    return await query(sql, binds);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getOilingcode03 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 1,
    };
    let sql = `SELECT
            TOM_CD_EPA,
            TOM_MARK_CUST,
            TOM_CUST_TDC,
            TOM_OIL_CD,
            TOM_CRT_ID,
            TOM_CRT_DT CRT_DT,
            TOM_UPD_ID,
            TOM_UPD_DT,
            TOM_OIL_TYPE
          FROM
          V_OILING_MASTER
          WHERE  TOM_CD_EPA = :code`;

    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const savePackingOiling = async (data: any) => {
  try {
    const sql = `call MSTB003(
          ls_cd_epa            =>:ls_cd_epa,
          ls_mark_cust         =>:ls_mark_cust,
          ls_cust_tdc          =>:ls_cust_tdc,
          ls_pack_seq          =>:ls_pack_seq,
          ls_pack_cd           =>:ls_pack_cd,
          ls_crt_id            =>:ls_crt_id,
          ls_sec2_min          =>:ls_sec2_min,
          ls_sec2_max          =>:ls_sec2_max,
          ls_product           =>:ls_product,
          ls_ord_edge          =>:ls_ord_edge,
          ls_width_tol         =>:ls_width_tol,
          ls_flag              =>:ls_flag,
          lb_status            =>:lb_status,
          ls_oil_type          =>:ls_oil_type,
          ls_out_flag          =>:ls_out_flag)`;

    const binds = {
      ls_cd_epa: data[0]?.ls_cd_epa ?? "",
      ls_mark_cust: data[0]?.ls_mark_cust ?? "",
      ls_cust_tdc: data[0]?.ls_cust_tdc ? data[0]?.ls_cust_tdc : "",
      ls_pack_seq: data[0]?.ls_pack_seq ?? "",
      ls_pack_cd: data[0]?.ls_pack_cd ?? "",
      ls_crt_id: data[0]?.ls_crt_id ?? "",
      ls_sec2_min: data[0]?.ls_sec2_min ?? "",
      ls_sec2_max: data[0]?.ls_sec2_max ?? "",
      ls_product: data[0]?.ls_product ?? "",
      ls_ord_edge: data[0]?.ls_ord_edge ?? "",
      ls_width_tol: data[0]?.ls_width_tol ?? "",
      ls_flag: data[0].ls_flag,
      lb_status: data[0].lb_status,
      ls_oil_type: data[0]?.ls_oil_type ?? "",
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    console.log("binds====>", binds);
    return await query(sql, binds);
  } catch (error: any) {
    console.log("error====>", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getPackCdList = async () => {
  try {
    let sql: any = ` SELECT DISTINCT SPM_PKG_SUBRAN_CD, SPM_PKG_SUBRAN_DESC,
                SPM_PKG_SUBRAN_CD || ' - ' || SPM_PKG_SUBRAN_DESC PACK_CODE
              FROM V_SUBRNG_PKG_MAST
              WHERE SPM_STATUS = 'A' ORDER BY SPM_PKG_SUBRAN_DESC`;

    return await ResponceData(await query(sql));
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getPackSeq = async (data: any) => {
  try {
    let sql: any = ` SELECT MAX(TPM_PACK_SEQ) AS PACK_SEQ FROM V_PACK_MASTER WHERE TPM_MARK_CUST = '${data.custId}' `;
    return await ResponceData(await query(sql));
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getWidthTolData = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 1,
    };
    let sql = `SELECT WTM_CD_EPA, WTM_MARK_CUST_CD, WTM_ORD_EDGE, WTM_WIDTH_TOL, WTM_CRT_DT,
          WTM_CRT_BY, WTM_UPD_DT,
          WTM_UPD_BY FROM V_WIDTH_TOL_MASTER
          WHERE  WTM_CD_EPA = :code
          AND WTM_STATUS = 'A'`;

    let ress = await query(sql, binds);
    return ress;
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
