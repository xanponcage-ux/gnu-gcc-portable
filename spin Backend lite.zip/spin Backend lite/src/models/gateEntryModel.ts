// import { getData01 } from '../repository/gateEntryQuery';
const GateEntryQuery = require("../repository/gateEntryQuery");

export default class GateEntryModel {
  // getData01(data: any) {
  //     return GateEntryQuery.getData01(data);
  // }
//   getStatusCodeData01() {
//     return GateEntryQuery.getStatusCodeData01();
//   }
//   getInvoiceData01() {
//     return GateEntryQuery.getInvoiceData01();
//   }
//   getMaterialData01() {
//     return GateEntryQuery.getMaterialData01();
//   }
//   getProdData01() {
//     return GateEntryQuery.getProdData01();
//   }
//   getQltyData01() {
//     return GateEntryQuery.getQltyData01();
//   }
//   getTdcData01() {
//     return GateEntryQuery.getTdcData01();
//   }
}
