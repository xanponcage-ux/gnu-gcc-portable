import { Router } from "express";
import {
  getData06,
  getEpaCode06,
  callProcedure06,
} from "../controllers/SPC0006Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0006Route = Router();

SPC0006Route.route("/SPC0006/getData06").post(
  authenticationMiddleware.bearer,
  getData06
);
SPC0006Route.route("/SPC0006/getEpaCode06").get(
  authenticationMiddleware.bearer,
  getEpaCode06
);
SPC0006Route.route("/SPC0006/procedure06").post(
  authenticationMiddleware.bearer,
  callProcedure06
);

export default SPC0006Route;
