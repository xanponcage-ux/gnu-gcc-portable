import { getData } from "../repository/SPO0007Query";

export default class SPO0007Model {
  getData(data: any) {
    return getData(data);
  }
}
