import { Router } from "express";
import { getData08, getOrderData08 } from "../controllers/SPC0008Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0008Route = Router();

SPC0008Route.route("/SPC0008/getScoData").post(
  authenticationMiddleware.bearer,
  getData08
);

SPC0008Route.route("/SPC0008/getOrder08").get(
  authenticationMiddleware.bearer,
  getOrderData08
);

export default SPC0008Route;
