@echo off
setlocal
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
  echo Bridge environment not found. Run install.bat or install_offline.bat first.
  exit /b 1
)
if not exist .env (
  echo .env not found. Copy .env.example to .env and fill in the required values.
  exit /b 1
)

.venv\Scripts\python.exe bridge.py
endlocal
