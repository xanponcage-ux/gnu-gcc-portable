import { Router } from "express";
import {
  // getData01,
  getEpaData01,
  // SCQ001Api,
  // SCQ002Api,
  //   getRsnCodeData,
} from "../controllers/qualityController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const qualityRoute = Router();

// qualityRoute
//   .route("/quality/getData")
//   .post(authenticationMiddleware.bearer, getData01);
qualityRoute
  .route("/quality/getEpaData")
  .get(authenticationMiddleware.bearer, getEpaData01);
// qualityRoute
//   .route("/quality/SCQ001")
//   .post(authenticationMiddleware.bearer, SCQ001Api);
// qualityRoute
//   .route("/quality/SCQ002")
//   .post(authenticationMiddleware.bearer, SCQ002Api);
export default qualityRoute;
