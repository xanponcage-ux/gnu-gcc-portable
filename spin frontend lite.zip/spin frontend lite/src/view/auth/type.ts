import { SelectType } from "src/components/input/type"

interface input {
    config: {
        type: string,
        label?: string,
        sideLabel?: string,
        eIcon?: JSX.Element,
        sIcon?: JSX.Element,
        autoFocus?: boolean,
        disabled?: boolean,
        minVal?: string | number,
        maxVal?: string | number
    },
    value: string,
    data?: Array<SelectType>
    onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement>
}

export interface InputType {
    user: input,
    password: input
}
export interface InputChangeType {
    user: input,
    password: input
    nPassword: input
}

export interface FormType {
    key: string,
    data: input
}