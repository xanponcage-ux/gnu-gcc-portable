const OperationyQuery = require("../repository/operationQuery");

export default class OperationyModel {
  // getData(data: any) {
  //     return OperationyQuery.getData(data);
  // }
  // getProdData(data: any) {
  //     return OperationyQuery.getProdData(data);
  // }
  //   SPO0003Modal(data: any) {
  //     return OperationyQuery.SPO0003Query(data);
  //   }
}
