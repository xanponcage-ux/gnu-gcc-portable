import { Request, Response } from "express";
import SPO0004Model from "../models/SPO0004Model";
import { ResponceData } from "../utils";

export const getTableData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0004Model.prototype.getTableData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getMBatchList = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0004Model.prototype.getMBatchList(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const saveDataTemp = async (req: Request, res: Response) => {
  try {
    const result1 = await SPO0004Model.prototype.saveDataTemp(req.body);
    // const finRes = result1?.outBinds?.ls_out_flag;
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getMotherTableData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0004Model.prototype.getMotherTableData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
