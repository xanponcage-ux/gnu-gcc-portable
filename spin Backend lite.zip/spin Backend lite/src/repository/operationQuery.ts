import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import {getCommonPlantData} from './plantQuery'

//         var sql = ` INSERT INTO V_SL_DAUTR_COIL
//         (RDC_ID_SOR_APPL
//         ,RDC_ID_DESTN_APPL
//         ,RDC_ID_MESSAGE
//         ,RDC_RESERVED_1
//         ,RDC_RESERVED_2
//         ,RDC_ID_COIL
//         ,RDC_SLIT_POS
//         ,RDC_BATCH_START
//         ,RDC_BATCH_END
//         ,RDC_ID_INPUT_COIL
//         ,RDC_TS_PROC_STRT
//         ,RDC_TS_PROC_END
//         ,RDC_CAL_MASS
//         ,RDC_NET_MASS
//         ,RDC_GROSS_MASS
//         ,RDC_WIDTH
//         ,RDC_THICK
// --        ,RDC_MAX_SPEED
// --        ,RDC_AVG_SPEED
// --        ,RDC_LENGTH
//         ,RDC_ODIA
//         ,RDC_IDIA
// --        ,RDC_RECOILER_TENSION
// --        ,RDC_RECOILER_TAPER
// --        ,RDC_OIL_TYPE
// --        ,RDC_OIL_MAX_QTY
// --        ,RDC_OIL_MIN_QTY
//         ,RDC_REMARKS
//         ,RDC_ORDER
//         ,RDC_ITEM_NO
// --        ,RDC_CUST_DESC
// --        ,RDC_HOLD_FLAG
// --        ,RDC_HOLD_CODE
// --        ,RDC_TDC
// --        ,RDC_GRADE_DESC
// --        ,RDC_TRIM
// --        ,RDC_PACK_CODE
//         ,RDC_CURR_PROC
// --        ,RDC_NXT_PROC
// --        ,RDC_PLANNED_PROC
// --        ,RDC_ACTL_PROC_PATH
// --        ,RDC_PART_NUMBER
// --        ,RDC_EDGE_WAVINESS
// --        ,RDC_CENTRE_BUCKLE
// --        ,RDC_CROSSBOW
// --        ,RDC_BURR_HEIGHT
// --        ,RDC_SURF_REQ
// --        ,RDC_HORIZONTAL_GAP
// --        ,RDC_VERTICAL_GAP
// --        ,RDC_WIDTH_TOL
//        ,RDC_NSPR1
// --        ,RDC_NSPR2
// --        ,RDC_NSPR3
// --        ,RDC_NSPR4
// --        ,RDC_NSPR5
// --        ,RDC_NSPR6
// --        ,RDC_NSPR7
// --        ,RDC_NSPR8
// --        ,RDC_NSPR9
// --        ,RDC_NSPR10
// --        ,RDC_CSPR1
// --        ,RDC_CSPR2
// --        ,RDC_CSPR3
// --        ,RDC_CSPR4
// --        ,RDC_CSPR5
// --        ,RDC_CSPR6
// --        ,RDC_CSPR7
// --        ,RDC_CSPR8
// --        ,RDC_CSPR9
// --        ,RDC_CSPR10
//         ,RDC_ID_PDI
//         )
//         VALUES
//         (
//          'L2'                   --,RDC_ID_SOR_APPL
//          ,'SPIN'                       --,RDC_ID_DESTN_APPL
//          ,f_nannow_second_telgrm(SYSDATE)                       --,RDC_ID_MESSAGE
//          ,'N'                       --,RDC_RESERVED_1
//          ,'N'                       --,RDC_RESERVED_2
//          ,:ls_daugt_batch                       --,RDC_ID_COIL
//          ,'CE'                       --,RDC_SLIT_POS
//          ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')                      --,RDC_BATCH_START
//          ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')                      --,RDC_BATCH_END
//          ,:ls_parent                       --,RDC_ID_INPUT_COIL
//          ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')                        --,RDC_TS_PROC_STRT
//          ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')                       --,RDC_TS_PROC_END
//          ,:ls_net_wt                       --,RDC_CAL_MASS
//          ,:ls_net_wt                       --,RDC_NET_MASS
//          ,:ls_net_wt                       --,RDC_GROSS_MASS
//          ,:ls_width                       --,RDC_WIDTH
//          ,:ls_thk                       --,RDC_THICK
// --         ,0                       --,RDC_MAX_SPEED
// --         ,0                       --,RDC_AVG_SPEED
// --         ,0                       --,RDC_LENGTH
//          ,:ls_odia                       --,RDC_ODIA
//          ,:ls_idia                       --,RDC_IDIA
// --         ,0                       --,RDC_RECOILER_TENSION
// --         ,0                       --,RDC_RECOILER_TAPER
// --         ,0                       --,RDC_OIL_TYPE
// --         ,0                       --,RDC_OIL_MAX_QTY
// --         ,0                       --,RDC_OIL_MIN_QTY
//          ,:ls_opr_rem                       --,RDC_REMARKS
//          ,:ls_ord                       --,RDC_ORDER
//          ,:ls_item                       --,RDC_ITEM_NO
// --         ,''                       --,RDC_CUST_DESC
// --         ,'' --:ls_hold_fl                       --,RDC_HOLD_FLAG
// --         ,'00'                       --,RDC_HOLD_CODE
// --         , ''                 --,RDC_TDC
// --         ,''                       --,RDC_GRADE_DESC
// --         ,''                       --,RDC_TRIM
// --         ,'' --:ls_pack_cd                       --,RDC_PACK_CODE
//          ,:ls_proc                       --,RDC_CURR_PROC
// --         ,''                       --,RDC_NXT_PROC
// --         ,''                        --,RDC_PLANNED_PROC
// --         ,''                       --,RDC_ACTL_PROC_PATH
// --         ,'0'                       --,RDC_PART_NUMBER
// --         ,0                       --,RDC_EDGE_WAVINESS
// --         ,0                       --,RDC_CENTRE_BUCKLE
// --         ,0                       --,RDC_CROSSBOW
// --         ,0                       --,RDC_BURR_HEIGHT
// --         ,'0'                       --,RDC_SURF_REQ
// --         ,0                       --,RDC_HORIZONTAL_GAP
// --         ,0                       --,RDC_VERTICAL_GAP
// --         ,0                       --,RDC_WIDTH_TOL
//            ,:ls_pdi                       --,RDC_NSPR1
// --         ,0                       --,RDC_NSPR2
// --         ,0                       --,RDC_NSPR3
// --         ,0                       --,RDC_NSPR4
// --         ,0                       --,RDC_NSPR5
// --         ,0                       --,RDC_NSPR6
// --         ,0                       --,RDC_NSPR7
// --         ,0                       --,RDC_NSPR8
// --         ,0                       --,RDC_NSPR9
// --         ,0                       --,RDC_NSPR10
// --         ,'0'                       --,RDC_CSPR1
// --         ,'0'                       --,RDC_CSPR2
// --         ,'0'                       --,RDC_CSPR3
// --         ,'0'                       --,RDC_CSPR4
// --         ,'0'                       --,RDC_CSPR5
// --         ,'0'                       --,RDC_CSPR6
// --         ,'0'                       --,RDC_CSPR7
// --         ,'0'                       --,RDC_CSPR8
// --         ,'0'                       --,RDC_CSPR9
// --         ,'0'                       --,RDC_CSPR10
//          ,:ls_pdi                    -- RDC_ID_PDI
//         )`
//         const binds = {
//           //flag: data ?.type,
//           ls_parent: (data ?.data.motherCoil) ? data ?.data.motherCoil : "",
//           ls_daugt_batch: (data ?.data.daughterCoil) ? data ?.data.daughterCoil : "",
//           ls_ord: (data ?.data.order) ? data ?.data.order : "",
//           ls_item: (data ?.data.ordItem) ? data ?.data.ordItem : "",
//           ls_proc: (data ?.data.proc) ? data ?.data.proc : "",
//           ls_thk: (data ?.data.crThick) ? data ?.data.crThick : "",
//           ls_width: (data ?.data.CrWidth) ? data ?.data.CrWidth : "",
//           ls_idia: (data ?.data.crIdia) ? data ?.data.crIdia : "",
//           ls_odia: (data ?.data.crOdia) ? data ?.data.crOdia : "",
//           ls_net_wt: (data ?.data.netWt) ? data ?.data.netWt : "",
//           //ls_grs_wt: (data ?.data.grossWt) ? data ?.data.grossWt : "",
//           //ls_coil_len: (data ?.data.length1) ? data ?.data.length1 : "",
//           ls_prod_st_dt: (data ?.data.productionStart) ? data ?.data.productionStart : "",
//           ls_prod_en_dt: (data ?.data.productionEnd) ? data ?.data.productionEnd : "",
//           //ls_shift: (data ?.data.shift) ? data ?.data.shift : "",
//           ls_opr_rem: (data ?.data.opr_rem) ? data ?.data.opr_rem : "",
//           //ls_hold_fl: (data ?.data.hold_fl) ? data ?.data.hold_fl : "",
//           //ls_pack_cd: (data ?.data.pack_cd) ? data ?.data.pack_cd : "",
//           //ls_user: (data ?.data.userId) ? data ?.data.userId : ""  
//           ls_pdi: (data ?.data.userId) ? data ?.data.idPdi : ""                
//         }; 
//          return await query(sql, binds);
//       }
//       if (data ?.type === 'getPageData') {
//         return {
//           processLine: await ResponceData(await query(` select EPL_CD_PROCESS, 
//               EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
//               FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= '131' 
//               ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS`))
//         }
//       }
//       else if (data ?.type === 'SL_MOTHER_REP') {       
//         var sql = `  INSERT INTO v_sl_mother_coil_pdo (
//                       RMH_CD_EPA,
//                       RMH_ID_COIL,
//                       RMH_NO_SLIT,
//                       RMH_BAL_MASS,
//                       RMH_LOAD_DATE,
//                       RMH_TS_PROC_START,
//                       RMH_TS_PROC_END,
//                       RMH_TS_CRT_DT,
//                       RMH_SHIFT,
//                   --    RMH_WIDTH,
//                   --    RMH_THICK,
//                   --    RMH_MAX_SPEED,
//                   --    RMH_AVG_SPEED,
//                   --    RMH_LENGTH,
//                   --    RMH_ODIA,
//                   --    RMH_NO_CUTS,
//                   --    RMH_TOT_TIME,
//                   --    RMH_RUN_TIME,
//                   --    RMH_SETUP_TIME,
//                   --    RMH_STOP_TIME,
//                       RMH_SCRAP_END,
//                       RMH_SCRAP_SIDE_TRIM,
//                       RMH_SCRAP_PUP_COIL,
//                   --    RMH_NSPR1,
//                   --    RMH_NSPR2,
//                   --    RMH_NSPR3,
//                   --    RMH_CSPR1,
//                   --    RMH_CSPR2,
//                   --    RMH_CSPR3,
//                       RMH_TIMESTAMP,
//                       RMH_REC_CRT_BY,
//                       RMH_REC_CRT_DT
//                   ) VALUES (
//                       '131'                    --RMH_CD_EPA,
//                       ,:ls_parent                    --RMH_ID_COIL,
//                       ,:ln_no_of_slt                    --RMH_NO_SLIT,
//                       ,:ln_res_wt                    --RMH_BAL_MASS,
//                       ,SYSDATE                    --RMH_LOAD_DATE,
//                       ,TO_DATE(:ls_prod_st_dt,'DD-MM-YYYY HH24:MI:SS')                      --,RMH_TS_PROC_START
//                       ,TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')            --RMH_TS_PROC_END
//                       ,to_date(substr(F_TATADATE(TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')),2,11),'DD-MON-YYYY') --:ld_tata_dt -- RMH_TS_CRT_DT
//             ---- RMH_TS_CRT_DT                 
//                     ,SUBSTR(f_tatadate(TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS')),1,1) --:ls_tata_shift          ---- RMH_SHIFT
//                   --    ,0           --RMH_WIDTH,
//                   --    ,0                    --RMH_THICK,
//                   --    ,0                    --RMH_MAX_SPEED,
//                   --    ,0                    --RMH_AVG_SPEED,
//                   --    ,0                    --RMH_LENGTH,
//                   --    ,0                    --RMH_ODIA,
//                   --    ,0                    --RMH_NO_CUTS,
//                   --    ,0                    --RMH_TOT_TIME,
//                   --    ,0                    --RMH_RUN_TIME,
//                   --    ,0                    --RMH_SETUP_TIME,
//                   --    ,0                    --RMH_STOP_TIME,
//                       ,:ln_end_cut                    --RMH_SCRAP_END,
//                       ,:ln_sidetrim_wt                    --RMH_SCRAP_SIDE_TRIM,
//                       ,:ln_pupcoil_wt                    --RMH_SCRAP_PUP_COIL,
//                   --    ,0                    --RMH_NSPR1,
//                   --    ,0                    --RMH_NSPR2,
//                   --    ,0                    --RMH_NSPR3,
//                   --    ,' '                    --RMH_CSPR1,
//                   --    ,' '                    --RMH_CSPR2,
//                   --    ,' '                    --RMH_CSPR3,
//                       ,f_nannow_second_telgrm(TO_DATE(:ls_prod_en_dt,'DD-MM-YYYY HH24:MI:SS'))  --:ls_id_msg                    --RMH_TIMESTAMP,
//                       ,SUBSTR(NVL(:ls_user,USER),1,10)                    --RMH_REC_CRT_BY,
//                       ,SYSDATE                   --RMH_REC_CRT_DT
//                   )`
//         const binds = {
//             ls_parent: (data ?.data.motherCoil) ? data ?.data.motherCoil : "",            
//             ln_no_of_slt: (data ?.data.slitNo) ? data ?.data.slitNo : "",
//             ln_res_wt: (data ?.data.residualWt) ? data ?.data.residualWt : "",
//             ln_end_cut: (data ?.data.endCut) ? data ?.data.endCut : "",
//             ln_sidetrim_wt: (data ?.data.sideTrim) ? data ?.data.sideTrim : "",
//             ln_pupcoil_wt: (data ?.data.pupCoil) ? data ?.data.pupCoil : "",
//             ls_prod_st_dt: (data ?.data.productionStart) ? data ?.data.productionStart : "",
//             ls_prod_en_dt: (data ?.data.productionEnd) ? data ?.data.productionEnd : "",
//             ls_user: (data ?.data.userId) ? data ?.data.userId : "",
//             //ls_out_flag: { type: oracledb.STRING, dir: oracledb.BIND_OUT, maxSize: 500 }
//         };
//         return await query(sql, binds)
//       }
    