import query from "../infrastructure/database/querys";
import { Post } from "../typed/typed";
import Error from "../models/errors";
import oracledb from "oracledb";

// Mirrored from LD12S001Query with new module name: LD16S001Query

export const getRmList = async (status: any) => {
  try {
    let sql = ` select DISTINCT LOM_ID_PAR_COIL_NO from V_LDP_PRODN
        WHERE LOM_CD_STATUS= :status
        and LOM_CD_EPA='0780'
        AND LOM_CD_QLTY_ACTL<>'SCRP'`;
    let binds = {
      status: status,
    };
    console.log("rmlist", sql);
    console.log(binds);
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getLabTestList = async (params: any) => {
  try {
    let sql = `select CD_VALUE,CD_DESC from V_CODES t
where t.cd_type IN ('TB053')`;
    console.log("rmlist", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getFieldTestList = async (params: any) => {
  try {
    let sql = `select CD_VALUE,CD_DESC from V_CODES t
where t.cd_type IN ('TB052')`;
    console.log("rmlist", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getPipeNoList = async (rmBatch: any, status: any) => {
  try {
    console.log("rmBatch: ", rmBatch);
    console.log("status: ", status);
    let sql = `select DISTINCT LOM_ID_BATCH from V_LDP_PRODN
        WHERE LOM_CD_STATUS = '${status}'
        and LOM_CD_EPA ='0780' `;

    if (rmBatch !== "") {
      sql += ` AND LOM_ID_PAR_COIL_NO = '${rmBatch}'`;
    }
    console.log("pipeno", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertField = async (
  batchNo: string,
  prodDate: string,
  shift: string,
  labTest: string
) => {
  try {
    const testNameQuery = `SELECT CD_DESC,CD_DESC1 FROM V_CODES WHERE CD_VALUE = :labTest AND CD_TYPE = 'TB052'`;
    const testNameBinds = { labTest: labTest };
    const testNameResult = await query.executeQuery(
      testNameQuery,
      testNameBinds
    );
    console.log(testNameResult);
    const testName = testNameResult?.rows?.[0]?.[0] || "";

    const sql = `INSERT INTO LDPDBA.T_lab_field_test_EC(
      ELF_PLANT_CD,
      ELF_BATCH_NO,
      ELF_TEST_CODE,
      ELF_TEST_NAME,
      ELF_PROD_DATE,
      ELF_SHIFT,
      ELF_CREATE_DATE,
      ELF_CREATE_USER
    ) VALUES(
      :PLANT_CD,
      :BATCH_NO,
      :TEST_CODE,
      :TEST_NAME,
      TO_DATE(:PROD_DATE, 'DD-MON-YYYY'),
      :SHIFT,
      SYSDATE,
      user
    )`;

    const binds = {
      PLANT_CD: "0780",
      BATCH_NO: batchNo,
      TEST_CODE: testNameResult?.rows?.[0]?.[1] || "",
      TEST_NAME: testName,
      PROD_DATE: prodDate,
      SHIFT: shift,
    };

    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertLAB = async (
  batchNo: string,
  prodDate: string,
  shift: string,
  labTest: string
) => {
  try {
    const testNameQuery = `SELECT CD_DESC,CD_DESC1 FROM V_CODES WHERE CD_VALUE = :labTest AND CD_TYPE = 'TB053'`;
    const testNameBinds = { labTest: labTest };
    const testNameResult = await query.executeQuery(
      testNameQuery,
      testNameBinds
    );
    console.log(testNameResult);
    const testName = testNameResult?.rows?.[0]?.[0] || "";

    const sql = `INSERT INTO LDPDBA.T_lab_field_test_EC(
      ELF_PLANT_CD,
      ELF_BATCH_NO,
      ELF_TEST_CODE,
      ELF_TEST_NAME,
      ELF_PROD_DATE,
      ELF_SHIFT,
      ELF_CREATE_DATE,
      ELF_CREATE_USER
    ) VALUES(
      :PLANT_CD,
      :BATCH_NO,
      :TEST_CODE,
      :TEST_NAME,
      TO_DATE(:PROD_DATE, 'DD-MON-YYYY'),
      :SHIFT,
      SYSDATE,
      user
    )`;

    const binds = {
      PLANT_CD: "0780",
      BATCH_NO: batchNo,
      TEST_CODE: testNameResult?.rows?.[0]?.[1] || "",
      TEST_NAME: testName,
      PROD_DATE: prodDate,
      SHIFT: shift,
    };

    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertScrapTempData = async (data: any) => {
  try {
    const sql = `INSERT INTO V_BARE_PDO_TEMP (
      TBP_PLANT_CD,
      TBP_BATCH_NO,
      TBP_CD_PROC,
      TBP_NEXT_PROC,
      TBP_BATCH_PROC_NO,
      TBP_PROD_DATE,
      TBP_SHIFT,
      TBP_WEIGHT,
      TBP_CD_STATUS,
      TBP_PAR_COIL_NO,
      TBP_ID_FIRST_PAR,
      TBP_ID_ORDER_NO,
      TBP_ITEM_NO,
      TBP_QUALITY_CD,
      TBP_NO_MATNR,
      TBP_CD_FLAG,
      TBP_PROD_START_DT,
      TBP_PROD_END_DT,
      TBP_RESULT,
      TBP_REMARK,
      TBP_HEAT_NO,
      TBP_INSP_NAME,
      TBP_PIPE_OD_10,
      TBP_PIPE_THK_10,
      TBP_PIPE_LNG_10
  )
  SELECT 
      :p_plant, 
      LDPDBA.f_LDB010_scrapid (
          :p_plant,
          :p_mbatch,
          :p_prodn_dt,
          :p_proc
      ) AS scrap_batch_id,
      :p_proc,
      'D',
      1,
      :p_prodn_dt,
      :SHIFT,
      :WEIGHT,
      'DC',
      :p_mbatch,
      :ID_FIRST_PAR, 
      'SC88888888' AS order_id, 
      0 AS item, 
      'SCRP' AS qlty,
      SUBSTR(r.cd_desc, 1, 18) AS material,
      '1' AS fg_prod, 
      TO_DATE(:START_DT,'DD/MM/YYYY HH24:MI'),
      TO_DATE(:END_DT,'DD/MM/YYYY HH24:MI'),
      'OK',
      '',
      '',
      :INSP_NAME, 
      '' AS OD,
      '' AS thk, 
      '' AS length1
  FROM (
      SELECT cd_desc
      FROM v_codes
      WHERE cd_type = 'TB045'
        AND SUBSTR(cd_value, 1, 4) = '0780'
        AND SUBSTR(cd_value, 6, 1) = '8'
  ) r`;

    const binds = {
      p_plant: data.PLANT,
      p_mbatch: data.BATCH_NO,
      p_proc: data.CD_PROC,
      p_prodn_dt: data.PROD_DATE,
      SHIFT: data.SHIFT,
      WEIGHT: data.BATCH_SCRAP_WEIGHT,
      ID_FIRST_PAR: data.ID_FIRST_PAR,
      START_DT: data.START_DT,
      END_DT: data.END_DT,
      INSP_NAME: data.INSP_NAME,
    };

    console.log("binds80scrapinsert: ", binds);
    console.log("sql80scrapinsert: ", sql);
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log("LD16S001-insertScrapTempData", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertTempData = async (data: any) => {
  try {
    const sql = `INSERT INTO V_BARE_PDO_TEMP(
        TBP_PLANT_CD,
        TBP_BATCH_NO,
        TBP_CD_PROC,
        TBP_BATCH_PROC_NO,
        TBP_NEXT_PROC,
        TBP_PROD_DATE,
        TBP_SHIFT,
        TBP_WEIGHT,
        TBP_CD_STATUS,
        TBP_PAR_COIL_NO,
        TBP_ID_FIRST_PAR,
        TBP_ID_ORDER_NO,
        TBP_ITEM_NO,
        TBP_QUALITY_CD,
        TBP_NO_MATNR,
        TBP_CD_FLAG,
        TBP_PROD_START_DT,
        TBP_PROD_END_DT,
        TBP_RESULT,
        TBP_REMARK,
        TBP_HEAT_NO,
        TBP_INSP_NAME,
        TBP_PIPE_LNG_10,
        TBP_COT_THK_1_120,
        TBP_COT_THK_2_120,
        TBP_COT_THK_3_120,
        TBP_COT_THK_4_120,
        TBP_COT_THK_5_120,
        tbp_cot_thk_6_120,
        tbp_cot_thk_7_120,
        tbp_cot_thk_8_120,
        tbp_cot_thk_9_120,
        tbp_cot_thk_10_120,
        tbp_cot_thk_11_120,
        tbp_cot_thk_12_120,
        tbp_cot_wt_vs_120,
        tbp_coat_stas_120,
        tbp_test_pip_120,
        TBP_HOLD_RSN,TBP_SAMPLE_10,TBP_QTEMP_120)
        VALUES(:PLANT,:BATCH_NO,:CD_PROC,:BATCH_PROC_NO,:NEXT_PROC,:PROD_DATE,:SHIFT,
               :WEIGHT,:STATUS,:PAR_COIL_NO,:ID_FIRST_PAR,:ID_ORDER_NO,:ITEM_NO,
               :QUALITY_CD,:MATNR,:FLAG,TO_DATE(:START_DT,'DD/MM/YYYY HH24:MI'),TO_DATE(:END_DT,'DD/MM/YYYY HH24:MI'),:RESULT,:REMARK,:HEAT_NO,:INSP_NAME,
               :PIPE_LNG_10,:COT_THK_1,:COT_THK_2,:COT_THK_3,:COT_THK_4,:COT_THK_5,:cot_thk_6,:cot_thk_7,
               :cot_thk_8,:cot_thk_9,:cot_thk_10,:cot_thk_11,:cot_thk_12,:cot_wt_vs,:coat_stas,:test_pip,:HOLD_RSN,:TAG,:TBP_QTEMP_120) `;

    let binds = {
      PLANT: data.PLANT,
      BATCH_NO: data.BATCH_NO,
      CD_PROC: data.CD_PROC,
      BATCH_PROC_NO: data.BATCH_PROC_NO,
      NEXT_PROC: data.NEXT_PROC,
      PROD_DATE: data.PROD_DATE,
      SHIFT: data.SHIFT,
      WEIGHT: data.PIPE_WEIGHT,
      STATUS: data.STATUS,
      PAR_COIL_NO: data.PAR_COIL_NO,
      ID_FIRST_PAR: data.ID_FIRST_PAR,
      ID_ORDER_NO: data.ID_ORDER_NO,
      ITEM_NO: data.ITEM_NO,
      QUALITY_CD: data.QUALITY_CD,
      MATNR: data.MATNR,
      FLAG: data.FLAG,
      START_DT: data.START_DT,
      END_DT: data.END_DT,
      RESULT: data.RESULT,
      REMARK: data.REMARK,
      HEAT_NO: data.HEAT_NO,
      INSP_NAME: data.INSP_NAME,
      PIPE_LNG_10: data.LENGTH,
      COT_THK_1: data.COT_THK_1,
      COT_THK_2: data.COT_THK_2,
      COT_THK_3: data.COT_THK_3,
      COT_THK_4: data.COT_THK_4,
      COT_THK_5: data.COT_THK_5,
      cot_thk_6: data.COT_THK_6,
      cot_thk_7: data.COT_THK_7,
      cot_thk_8: data.COT_THK_8,
      cot_thk_9: data.COT_THK_9,
      cot_thk_10: data.COT_THK_10,
      cot_thk_11: data.COT_THK_11,
      cot_thk_12: data.COT_THK_12,
      cot_wt_vs: data.COT_WT_VS,
      coat_stas: data.COAT_STAS,
      test_pip: data.TEST_PIP,
      HOLD_RSN: data.HOLD_RSN,
      TAG: data.TAG,
      TBP_QTEMP_120: data.TBP_QTEMP_120,
    };
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const callproc120 = async (data: any) => {
  try {
    let resData: any[] = [];
    const sql = `call LDPDBA.LD12B001(
                    LS_BATCH_NO => :LS_BATCH_NO,
                    LS_CD_PROC => :LS_CD_PROC,
                    LS_PLANT_CD => :LS_PLANT_CD,
                    ls_out_flag => :LS_OUT_FLAG
                    )`;

    let binds = {
      LS_BATCH_NO: data.BATCH_NO ? data.BATCH_NO : "",
      LS_CD_PROC: data.CD_PROC ? data.CD_PROC : "",
      LS_PLANT_CD: data.PLANT ? data.PLANT : "",
      LS_OUT_FLAG: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };

    const result = await query.executeQuery(sql, binds);
    resData.push(result?.outBinds?.LS_OUT_FLAG);
    return resData;
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const deleteTempData = async (data: any) => {
  try {
    const deleteQuery = `DELETE FROM LDPDBA.T_lab_field_test_EC WHERE ELF_BATCH_NO = :BATCH_NO`;
    const deleteBinds = { BATCH_NO: data.BATCH_NO ? data.BATCH_NO : "" };

    console.log(
      "Deleting existing records for batch: ",
      data.BATCH_NO ? data.BATCH_NO : ""
    );
    await query.executeQuery(deleteQuery, deleteBinds);

    let sql = ` Delete V_BARE_PDO_TEMP 
                    where (tbp_batch_no= :Batchno OR TBP_PAR_COIL_NO= :Batchno)
                    and  tbp_cd_proc= :curproc
                    and tbp_plant_cd= :plant `;
    let binds = {
      Batchno: data.BATCH_NO ? data.BATCH_NO : "",
      curproc: data.CD_PROC ? data.CD_PROC : "",
      plant: data.PLANT ? data.PLANT : "",
    };

    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log("delete error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getFillData = async (
  rmBatch: any,
  pipeno: any,
  status: any,
  plant: any,
  w1: any,
  w2: any,
  w3: any,
  w4: any,
  w5: any,
  w6: any,
  w7: any,
  w8: any,
  w9: any,
  w10: any,
  w11: any,
  w12: any
) => {
  try {
    let sql = ` SELECT TBP_BATCH_NO,LOM_SEC2 TBP_PIPE_OD_10,LOM_SEC1 TBP_PIPE_THK_10,LOM_LENGTH TBP_PIPE_LNG_10,TBP_NO_MATNR,TBP_HEAT_NO,
                    TO_CHAR((select LDPDBA.f_get_coat_wt('${plant}','${w1}','${w2}','${w3}','${w4}','${w5}','${w6}','${w7}','${w8}','${w9}','${w10}','${w11}','${w12}',LOM_LENGTH,LOM_SEC2) from dual), 'FM999999990.000') COAT_WT,
                    TBP_ID_ORDER_NO ORDER_NO, TBP_ITEM_NO ITEM, ENC_CUST_NAME CUST_NAME, LOM_PLANNED_PROC PLAN_PROC,
                   (select F_GET_NEXTPROC(LOM_PLANNED_PROC, LOM_PASSED_PROC, 'D') as nxtproc from dual) NEXT_PROC,
                   (select TBP_ASL_NO_80 FROM V_BARE_PDO where TBP_BATCH_NO = LOM_ID_BATCH AND TBP_CD_PROC = '8')ASL_NO,
                 TBP_DEPTH_10 DEPTH_MM, TBP_WIDTHS_10 WIDTH_MM,LOM_MS_PIECE_ACTL,(select TBP_FLD_NO_130 FROM V_BARE_PDO where TBP_BATCH_NO = LOM_ID_BATCH AND TBP_CD_PROC = '8') TBP_FLD_NO_130
                 (SELECT GEOMETRY
                    FROM V_YMPCT_TUB_MATL
                   WHERE MANDT = '600' AND MATNR = LOM_NO_MATNR) GEO
                      FROM V_BARE_PDO, V_END_CUST_ORD_EPA, V_LDP_PRODN
                     WHERE TBP_ID_ORDER_NO = ENC_ID_ORDER  
                       AND TBP_ITEM_NO = ENC_NO_ITEM 
                       AND TBP_BATCH_NO = LOM_ID_BATCH
                       AND TBP_PLANT_CD = LOM_CD_EPA
                       AND LOM_CD_EPA = ENC_CD_EPA
                       AND LOM_ID_ORDER_CUS = ENC_ID_ORDER
                       AND LOM_ID_ORD_ITEM_CUS = ENC_NO_ITEM 
                       AND TBP_PAR_COIL_NO = '${rmBatch}' `;

    if (pipeno != "") {
      sql += ` AND TBP_BATCH_NO = '${pipeno}' AND  TBP_CD_PROC = '1'`;
    } else {
      sql += ` AND TBP_BATCH_NO IN (select t.lom_id_batch from v_ldp_prodn t where t.lom_cd_status='${status}'
                     AND t.lom_id_par_coil_no = '${rmBatch}') AND TBP_CD_PROC = '1'`;
    }

    console.log("filldataqry120", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTataDate = async (prodEndDt: any) => {
  try {
    const sql = `select substr(F_Tatadate(
              TO_DATE(:prodEndDt,'YYYY-MM-DD HH24:MI')),1,1)
               shift,substr(F_Tatadate(TO_DATE(:prodEndDt,'YYYY-MM-DD HH24:MI')),2) prod_dt from dual`;
    const binds = {
      prodEndDt: prodEndDt,
    };
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getCoatWt = async (
  W1: any,
  W2: any,
  W3: any,
  W4: any,
  W5: any,
  W6: any,
  W7: any,
  W8: any,
  W9: any,
  W10: any,
  W11: any,
  W12: any,
  LENGTH: any,
  OD: any
) => {
  try {
    const sql = `select LDPDBA.f_get_coat_wt('0780','${W1}','${W2}','${W3}','${W4}','${W5}','${W6}','${W7}','${W8}','${W9}','${W10}','${W11}','${W12}','${LENGTH}','${OD}') COAT_WT from dual `;
    console.log("coat", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
