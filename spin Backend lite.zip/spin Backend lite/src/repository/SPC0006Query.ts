import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getSECONDSTdc06 = async (data: any) => {
  try {
    let binds: any = {};

    let sql = `SELECT
      NVL (ESP_CD_EPA, '') CD_EPA,
      --NVL (ESP_QLTY_PRIME, '') QLTY_PRIME,
      --NVL (ESP_QLTY_DOWNGRADE, '') QLTY_DOWNGRADE,
      NVL (ESP_TDC_PRIME, '') TDC_PRIME,
      NVL (ESP_TDC_DOWNGRADE, '') TDC_DOWNGRADE,
      --NVL (ESP_SEC1_FROM, '') SEC1_FROM,
      --NVL (ESP_SEC1_TO, '') SEC1_TO,
      --NVL (ESP_SEC2_FROM, '') SEC2_FROM,
      --NVL (ESP_SEC2_TO, '') SEC2_TO,
      --NVL (ESP_SHEET_IND, '') SHEET_IND,
      --NVL (ESP_NO_MATNR, '') NO_MATNR,
      --NVL (ESP_WT_MIN, '') WT_MIN,
      --NVL (ESP_WT_MAX, '') WT_MAX,
      NVL (ESP_CRT_USR, '') S_CRT_USR,
      NVL (ESP_CRT_DT, '') S_CRT_DT,
      NVL (ESP_UPD_USR, '') S_UPD_USR,
      NVL (ESP_UPD_DT, '') S_UPD_DT,
      NVL (ESP_STATUS, '') STATUS
    FROM
    V_EPA_SECONDS_PRIME_TDC WHERE ESP_STATUS = 'A'`;
    if (data?.epa) {
      sql += ` AND ESP_CD_EPA = '${data?.epa}'`;
    }
    if (data.tdcsc && data.tdcsc?.length > 0) {
      sql += `AND ESP_TDC_DOWNGRADE = '${data?.tdcsc}'`;
    }
    console.log(sql);
    return await query(sql);
  } catch (error: any) {
    console.log("+>", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcMap06 = async (data: any) => {
  try {
    let binds: any = {};
    let sql = `SELECT
      TDM_ACT_TDC ACT_TDC,
      TDM_END_TDC END_TDC,
      TDM_CRT_ID CRT_ID,
      TDM_CRT_DT CRT_DATE,
      TDM_UPD_ID UPD_ID,
      TDM_UPD_DT UPD_DT,
      TDM_CD_STATUS CD_STATUS,
      TDM_CD_EPA CD_EPA,
      TDM_CD_COMP CD_COMP
      FROM
      V_TDC_MAP WHERE TDM_CD_STATUS = 'A'`;

    if (data?.acttdc) {
      sql += ` AND TDM_ACT_TDC ='${data?.acttdc}'`;
    }
    if (data.endTDC && data.endTDC?.length > 0) {
      sql += ` AND TDM_END_TDC = '${data?.endTDC}'`;
    }
    return await query(sql);
  } catch (error: any) {
    console.log("-->", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getEpaPlant06 = async () => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcsec06 = async () => {
  try {
    const sql = `SELECT
      DISTINCT ESP_TDC_DOWNGRADE
      FROM
      V_EPA_SECONDS_PRIME_TDC WHERE ESP_STATUS = 'A'`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getActTdc06 = async () => {
  try {
    const sql = `SELECT
      DISTINCT TDM_ACT_TDC
     FROM
      V_TDC_MAP WHERE TDM_CD_STATUS = 'A'`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const callProcedure06 = async (data: any) => {
  try {
    const sql = `call MSTB001(
          ls_act_tdc => :ls_act_tdc,
          ls_end_tdc => :ls_end_tdc,
          ls_flag    => :ls_flag,
          lb_status => :lb_status,
          ls_user   => :ls_user,
          ls_cd_epa => :ls_cd_epa,
          ls_tdc_prime => :ls_tdc_prime,
          ls_tdc_downgrade => :ls_tdc_downgrade,      
          ls_sec1_from => :ls_sec1_from,
          ls_sec1_to         => :ls_sec1_to,
          ls_sec2_from      => :ls_sec2_from,
          ls_sec2_to      => :ls_sec2_to,
          ls_sheet_ind      => :ls_sheet_ind,
          ls_no_matnr      => :ls_no_matnr,
          ls_wt_min          => :ls_wt_min,
          ls_wt_max        => :ls_wt_max,
          ls_qlty_prime         => :ls_qlty_prime,
          ls_qlty_downgrade      => :ls_qlty_downgrade,
          ls_message => :ls_message
          )`;
    const binds = {
      ls_act_tdc: data?.ls_Act_tdc ? data?.ls_Act_tdc : "",
      ls_end_tdc: data?.ls_end_tdc ? data?.ls_end_tdc : "",
      ls_flag: data?.ls_flag ? data?.ls_flag : "",
      lb_status: data?.lb_status ? data?.lb_status : "",
      ls_user: data?.ls_user ? data?.ls_user : "",
      ls_cd_epa: data?.ls_cd_epa ? data?.ls_cd_epa : "",
      ls_tdc_prime: data?.ls_tdc_prime ? data?.ls_tdc_prime : "",
      ls_tdc_downgrade: data?.ls_tdc_downgrade ? data?.ls_tdc_downgrade : "",
      ls_sec1_from: data?.ls_sec1_from ? data?.ls_sec1_from : "",
      ls_sec1_to: data?.ls_sec1_to ? data?.ls_sec1_to : "",
      ls_sec2_from: data?.ls_sec2_from ? data?.ls_sec2_from : "",
      ls_sec2_to: data?.ls_sec2_to ? data?.ls_sec2_to : "",
      ls_sheet_ind: data?.ls_sheet_ind ? data?.ls_sheet_ind : "",
      ls_no_matnr: data?.ls_no_matnr ? data?.ls_no_matnr : "",
      ls_wt_min: data?.ls_wt_min ? data?.ls_wt_min : "",
      ls_wt_max: data?.ls_wt_max ? data?.ls_wt_max : "",
      ls_qlty_prime: data?.ls_qlty_prime ? data?.ls_qlty_prime : "",
      ls_qlty_downgrade: data?.ls_qlty_downgrade ? data?.ls_qlty_downgrade : "",
      ls_message: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    return await query(sql, binds);
  } catch (error: any) {
    console.log("e: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
