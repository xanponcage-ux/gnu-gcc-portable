import { TabulatorFull } from "tabulator-tables";
import "tabulator-tables/dist/css/tabulator_simple.min.css"; //import Tabulator stylesheet
import "./style.css";

export default TabulatorFull;