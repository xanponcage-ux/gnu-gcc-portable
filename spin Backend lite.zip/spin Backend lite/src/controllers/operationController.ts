import { Request, Response } from "express";
import OperationModel from "../models/operationModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

// export const getData = async (req: Request, res: Response) => {
//   try {
//     let varData: any = {}
//     varData = await OperationModel.prototype.getData(req.body);
//     return res.status(200).json(await ResponceData(varData));
//   } catch (error: any) {
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };

// export const getProdData = async (req: Request, res: Response) => {
//   try {
//     let varData: any = {}
//     varData = await OperationModel.prototype.getProdData(req.body);
//     return res.status(200).json(await ResponceData(varData));
//   } catch (error: any) {
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };

// export const SPO0003Api = async (req: Request, res: Response) => {
//   try {
//     const result1 = await OperationModel.prototype.SPO0003Modal(req.body);
//     return res.status(200).json(result1);
//   }
//   catch (error: any) {
//     console.log('error:', error);
//     return res.status(400).json({ error: error ?.message ? error ?.message ?.toString() : 'Error' });
//   }
// }