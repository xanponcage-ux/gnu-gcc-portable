import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";

export const getCommonPlantData = async () => {
  try {
    const sql = `SELECT DISTINCT EPL_CD_EPA, EPL_CD_EPA || ' - ' || EPL_EPA_DESC EPL_CD_EPA_DESC
                    FROM V_EPA_PROC_LINE
                    WHERE EPL_ACTIVE_PLANT_FL='A'`;
    return await query(sql);
  } catch (error: any) {
    console.log("err",error)
    throw new Error.InternalServerError("Error");
  }
};