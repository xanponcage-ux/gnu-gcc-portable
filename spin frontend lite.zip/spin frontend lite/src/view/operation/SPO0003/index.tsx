/* ------------------------ BACKUP SCREEN INSIDE OPERATION -----------------------------------------------------

Changed on - 24.02.2026, By Ritya
Purpose - 1. To make yard in location report as dropdown, values coming from v_codes(TK032)
          2. Made start dt and end dt mandatory in packing report. 

Changed on - 09.03.26, 
Purpose - 1. Backdate production recording should not exceed hrs maintained in v_codes
          2. WCTL NCTL feature flag added indicating go live status

Chnaged on - 22.07.26,
Purpose  - 1. Thick, width field removed in mother report for wctl, nctl line.
           2. Auto pack code filled in packing report from pdi.
           3. Dg batch, GS batches removed from dropdown in ent division.
           4. Gross wt restricted to 60 kgs from net wt for wctl, nctl.
------------------------------------------------------------------------------------------------------------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import SaveIcon from "@mui/icons-material/Save";
import {
  Input,
  RadioInput,
  SelectInput,
  DatePickerInput,
} from "../../../components/input";
import DeleteIcon from "@mui/icons-material/Delete";
import { CulmnType, TokenType } from "../../../type";
import alertify from "../../../components/alert";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { MobileDateTimePicker } from "@mui/x-date-pickers/MobileDateTimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import TextField from "@mui/material/TextField";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";

import { GetAuthorization } from "../../../utils";
import ButtonElement from "../../../components/button";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPO0003Api,
  SPO0003getHoldRsn,
  SPO0003getSlitPos,
} from "../../../apiConfig/insideAuthApi";

import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, MotherForm, DaughterForm } from "./type";
import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "../../../context";
import { error } from "console";
import Alert from "@mui/material/Alert";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPO0003 = () => {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [showSaveMsgSuccess, setShowSaveMsgSuccess] = React.useState(false);
  const [showSaveMsgError, setShowSaveMsgError] = React.useState(false);
  const [saveMsg, setSaveMsg] = React.useState<any>("");

  // FOR TESTING
  // const testData : any= [
  //   {label: 'PK2694S804' ,value:'PK2694S804',id:'1'} ,
  //   {label: 'PK2694S802' ,value:'PK2694S802',id:'2'},
  //   {label: 'PK2694S803',value : 'PK2694S803' , id:'3'}
  // ]

  ////THIS PAGE DATA
  const staticData1: any = [
    { label: "PLTCM", value: "PLTCM", id: "1" },
    { label: "CAL", value: "CAL", id: "2" },
    { label: "CPL", value: "CPL", id: "3" },
  ];
  const calBackup: any = [
    { label: "PDI Request", value: "PDI", id: "1" },
    { label: "Send Coil Supply Request", value: "HRSR", id: "2" },
    { label: "Register Coil supply Completion", value: "HRSC", id: "3" },
    { label: "Register Rejection", value: "REJ", id: "4" },
    { label: "Delay", value: "Del", id: "5" },
    { label: "Daughter Report", value: "RWS", id: "6" },
    { label: "Mother Report", value: "MR-CAL", id: "7" },
    { label: "Entry Division", value: "ENT-DIV", id: "8" },
    { label: "Packing Report", value: "PR", id: "9" },
    { label: "Location Report", value: "LOC-R", id: "10" },
  ];
  const tCalBackup: any = [
    { label: "PDI Request", value: "PDI", id: "1" },
    { label: "Send Coil Supply Request", value: "HRSR", id: "2" },
    { label: "Register Coil supply Completion", value: "HRSC", id: "3" },
    { label: "Register Rejection", value: "REJ", id: "4" },
    { label: "Delay", value: "Del", id: "5" },
    { label: "Daughter Report", value: "RWS", id: "6" },
    { label: "Mother Report", value: "MR-CAL", id: "7" },
    { label: "Entry Division", value: "ENT-DIV", id: "8" },
    { label: "Location Report", value: "LOC-R", id: "9" },
  ];
  const shiftList = [
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
  ];

  const holdFlagList = [
    { value: "Y", label: "Y" },
    { value: "N", label: "N" },
  ];
  const defaultPdiRequestForm = {
    prodStartDt: null,
    prodEndDt: null,
  };
  const defaultDaughterForm = {
    daughterCoil: "",
    motherCoil: "",
    proc: "",
    order: "",
    ordItem: "",
    crThick: "",
    CrWidth: "",
    crIdia: "",
    crOdia: "",
    netWt: "",
    grossWt: "",
    length1: "",
    duration: "",
    productionStart: null,
    productionEnd: null,
    perNo: "",
    shift: "",
    hold_fl: "",
    pack_cd: "",
    opr_rem: "",
    crNoPart: "",
    plannedProc: "",
    nextProc: "",
    fgTdc: "",
    coilNo: 0,
    oil_type: "",
    recoilerTension: "",
    edgeWaviness: "",
    burrHeight: "",
    ordEdge: "",
  };
  const defaultMotherForm = {
    motherCoil: "",
    residualWt: "",
    endCut: "",
    sideTrim: "",
    pupCoil: "",
    slitNo: "",
    with: "",
    productionStart: null,
    productionEnd: null,
    userId: "",
  };
  const defaultOrderDetails = {
    ordMinThick: "",
    ordMaxThick: "",
    ordMinWidth: "",
    ordMaxWidth: "",
  };
  const defaultEntryDivision = {
    rem_wt: "",
    rem_length: "",
    odia: "",
    reason: "",
  };

  const defaultMCoilDtlsForm = {
    mThick: "",
    mWidth: "",
    mLength: "",
    mNxtProc: "",
    mPlannedProc: "",
    mOutTdc: "",
    mOutGradeDesc: "",
  };
  const defaultPackingReport = {
    pCoilId: "",
    pThick: "",
    pWidth: "",
    pOdia: "",
    pIdia: "",
    pNetWt: "",
    pGrossWt: "",
    pStartDt: null,
    pEndDt: null,
  };

  const [processLineData, setProcessLineData] =
    React.useState<Array<SelectType>>();
  const [processLine, setProcessLine] = React.useState<string>("");
  const [backupProcess, setBackupProcess] = React.useState<string>("");

  const [calPdiRequestForm, setCalPdiRequestForm] =
    React.useState<PdiRequestForm>(defaultPdiRequestForm);

  const [calDaughterForm, setCalDaughterForm] =
    React.useState<DaughterForm>(defaultDaughterForm);
  const [calMotherForm, setCalMotherForm] =
    React.useState<MotherForm>(defaultMotherForm);
  const [daughterReportCal, setDaughterReportCal] = React.useState<any>({
    daughter: [],
    mother: [],
  });
  const [suppCoilData, setSuppCoilData] = React.useState<Array<SelectType>>([]);
  const [selectedSuppCoil, setSelectedSuppCoil] = React.useState<string>("");
  const [suppCoilCompData, setSuppCoilCompData] = React.useState<
    Array<SelectType>
  >([]);
  const [selectedSuppCoilComp, setSelectedSuppCoilComp] =
    React.useState<string>("");
  const [drMotherCoilData, setDrMotherCoilData] = React.useState<
    Array<SelectType>
  >([]);
  const [mrMotherCoilData, setMrMotherCoilData] = React.useState<
    Array<SelectType>
  >([]);
  const [packingCdData, setPackingCdData] = React.useState<Array<SelectType>>(
    []
  );
  const [drDaughterCoilData, setDrDaughterCoilData] = React.useState<
    Array<SelectType>
  >([]);
  const [pdiList, setPdiList] = React.useState<Array<SelectType>>([]);
  //const [daughterParam, setDaughterParam] = React.useState<DaughterParamForm>(defaultDaughterParam);
  const [calOrderDetails, setOrderDetails] =
    React.useState<OrderForm>(defaultOrderDetails);

  const [divMotherCoilData, setDivMotherCoilData] = React.useState<
    Array<SelectType>
  >([]);
  const [selectedDivMCoil, setSelectedDivMCoil] = React.useState<string>("");

  const [divZCoilData, setDivZCoilData] = React.useState<Array<SelectType>>([]);
  const [selectedDivZCoil, setSelectedDivZCoil] = React.useState<string>("");
  const [calEntryDivision, setEntryDivision] =
    React.useState<DivisionForm>(defaultEntryDivision);
  const [radioOption, setRadioOption] = React.useState<string>("");

  const [entDivReason, setEntDivReason] = React.useState<Array<SelectType>>([]);
  const [selectedEntDivReason, setSelectedEntDivReason] =
    React.useState<string>("");
  const [selectedActName, setSelectedActName] = React.useState<string>("");
  const [outTdc, setOutTdc] = React.useState<string>("");
  const [secondsTdc, setSecondsTdc] = React.useState<boolean>(true);
  const [selectedMCoilDtls, setSelectedMCoilDtls] =
    React.useState<MCoilDtlsForm>(defaultMCoilDtlsForm);
  //Packing Report
  const [calPackingReport, setPackingReport] =
    React.useState<PackingForm>(defaultPackingReport);
  const [packingCoilList, setPackingCoilList] = React.useState<
    Array<SelectType>
  >([]);
  const [selectedPCoil, setSelectedPCoil] = React.useState<string>("");
  const [packingCdList, setPackingCdList] = React.useState<Array<SelectType>>(
    []
  );

  const YNList: Array<SelectType> = [
    { value: "N", label: "No", id: 1 },
    { value: "Y", label: "Yes", id: 2 },
  ];

  const OkList: Array<SelectType> = [
    { value: "OK", label: "OK", id: 1 },
    { value: "NOT OK", label: "NOT OK", id: 2 },
  ];

  const [holdFlag, setHoldFlag] = React.useState<string>(YNList[0].value);
  const [coilContion, setCoilContion] = React.useState<string>(OkList[0].value);
  const [zigZagWind, setZigZagWind] = React.useState<string>(OkList[0].value);
  const [tescopicity, setTescopicity] = React.useState<string>(OkList[0].value);
  const [cutrMark, setCutrMark] = React.useState<string>(OkList[0].value);
  const [oilCondn, setOilCondn] = React.useState<string>(OkList[0].value);
  const [selectedHoldRsn, setSelectedHoldRsn] = React.useState<string>("");
  const [holdRsnData, setHoldRsnData] = React.useState<Array<SelectType>>([]);
  const [selectedSlitPos, setSelectedSlitPos] = React.useState<string>("");
  const [slitPosData, setSlitPosData] = React.useState<Array<SelectType>>([]);

  const [rejCoilList, setRejCoilList] = React.useState<Array<SelectType>>([]);
  const [selectedRejCoil, setSelectedRejCoil] = React.useState<string>("");

  const [locRepCoils, setLocRepCoils] = React.useState<Array<SelectType>>([]);
  const [selectedLocRepCoil, setSelectedLocRepCoil] =
    React.useState<string>("");
  const [yard, setYard] = React.useState<string>("");
  const [locX, setLocX] = React.useState<string>("");
  const [locY, setLocY] = React.useState<string>("");
  const [pos, setPos] = React.useState<string>("");

  const [yardList, setYardList] = React.useState<Array<SelectType>>([]);
  const [backRecordingHrs, setBackRecordingHrs] = React.useState<number>(24);
  const [nctlLiveFlag, setNctlLiveFlag] = React.useState<string>("N");
  const [wctlLiveFlag, setWctlLiveFlag] = React.useState<string>("N");

  const handleClearAll = () => {
    setCalPdiRequestForm(defaultPdiRequestForm);
    setProcessLine("");
    setBackupProcess("");
    setCalDaughterForm(defaultDaughterForm);
    setCalMotherForm(defaultMotherForm);
    setOrderDetails(defaultOrderDetails);
    setEntryDivision(defaultEntryDivision);
    setSelectedEntDivReason("");
    setPdiList([]);
    setPackingReport(defaultPackingReport);
    setSelectedPCoil("");
  };
  React.useEffect(() => {
    // fetch initial page load
    SPO0003ApiCall("getPageData");
    getHoldRsn();
    getSlitPos();
  }, []);

  const getHoldRsn = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0003getHoldRsn(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.CD_HOLD?.toString(),
                  label: x?.CD_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setHoldRsnData(varData);
          }
        })
        .catch((e: any) => {
          console.log("e: getHoldRsn", e);
          // alertify.error(
          //   e?.error?.message ? e.error.message : "Something Wents wrong!"
          // );
          alertify.error(
            e?.error?.response?.data?.error
              ? e?.error?.response?.data?.error
              : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getSlitPos = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0003getSlitPos(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.CD_VALUE?.toString(),
                  label: x?.CD_VALUE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setSlitPosData(varData);
          }
        })
        .catch((e: any) => {
          // console.log("e", e);
          // alertify.error(
          //   e?.error?.message ? e.error.message : "Something Wents wrong!"
          // );
          alertify.error(
            e?.error?.response?.data?.error
              ? e?.error?.response?.data?.error
              : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // React.useEffect(()=>{
  //   // Fetch Packing list if both order and order item are available.
  //   if(calDaughterForm.order && calDaughterForm.ordItem){
  //     SPO0003ApiCall('getPackingList',calDaughterForm);
  //   }
  // },[calDaughterForm.motherCoil,calDaughterForm.order,calDaughterForm.ordItem])

  React.useEffect(() => {
    // Fetch Order Details from v_pr_data_ip_slt.
    if (calDaughterForm.idPdi) {
      SPO0003ApiCall("getOrderDetails", calDaughterForm);
    }
  }, [calDaughterForm.motherCoil, calDaughterForm.idPdi]);

  React.useEffect(() => {
    // Fetch Order Details from v_pr_data_ip_slt.
    //Commenting this cause part no is not needed here
    // if (calDaughterForm.crNoPart) {
    if (calDaughterForm.motherCoil && calDaughterForm.idPdi) {
      SPO0003ApiCall("getDautrCoilCount", calDaughterForm);
    }
  }, [
    calDaughterForm.motherCoil,
    calDaughterForm.idPdi,
    // calDaughterForm.crNoPart,
  ]);

  React.useEffect(() => {
    // Fetch Order Details from v_pr_data_ip_slt.
    if (processLine) {
      SPO0003ApiCall("getActionName", processLine);
    }
  }, [processLine]);

  React.useEffect(() => {
    // Fetch Order Details from v_pr_data_ip_slt.
    if (outTdc) {
      SPO0003ApiCall("chkSecondsTdc", outTdc);
    }
  }, [outTdc]);

  const handleBackupProcessChange = async (e: any) => {
    // Clear state data
    setCalDaughterForm(defaultDaughterForm);
    setCalMotherForm(defaultMotherForm);
    setOrderDetails(defaultOrderDetails);
    setEntryDivision(defaultEntryDivision);
    setSelectedEntDivReason("");
    setDivMotherCoilData([]);

    setPackingReport(defaultPackingReport);
    setSelectedPCoil("");

    setBackupProcess(e);
    // Trigger API to get coil list for
    if (e === "HRSR") {
      setSuppCoilData([]);
      SPO0003ApiCall("getCoilList", processLine);
    }
    // Trigger API to get coil list for
    if (e === "HRSC") {
      setSuppCoilCompData([]);
      SPO0003ApiCall("getCoilCompList", processLine);
    }

    //Trigger API to get coil list for register rejection
    if (e === "REJ") {
      setRejCoilList([]);
      SPO0003ApiCall("getRejectCoilList", processLine);
    }
    // Trigger API to get mother coil list for duaghter Report.
    if (e === "RWS") {
      setDrMotherCoilData([]);
      await SPO0003ApiCall("getDaughterReportData", processLine);
      await SPO0003ApiCall("backRecording", processLine);
      await SPO0003ApiCall("ctlLiveFlag", processLine);
    }
    if (e === "MR-CAL") {
      SPO0003ApiCall("getMotherReportData", processLine);
    }
    if (e === "ENT-DIV") {
      SPO0003ApiCall("getDivisionData", { process: processLine });
    }
    if (e === "PR") {
      SPO0003ApiCall("getPackingCoilList");
      SPO0003ApiCall("getPackingCdList");
    }
    //Trigger API to get coil list for location report
    if (e === "LOC-R") {
      setLocRepCoils([]);
      await SPO0003ApiCall("getLocRepCoils", processLine);
      await SPO0003ApiCall("getYardList", processLine);
    }
  };

  const handleMotherCoilChange = (e: any) => {
    setCalDaughterForm(defaultDaughterForm);

    setCalDaughterForm((prevState) => {
      const updatedState = {
        ...calDaughterForm,
        motherCoil: e,
        proc: processLine,
      };
      // Trigger API to get ID PDI list for duaghter Report.
      SPO0003ApiCall("getPDIList", updatedState);

      // Trigger API to get mother coil list for duaghter Report.
      SPO0003ApiCall("getDaughterCoilList", updatedState);
      return updatedState;
    });
  };
  // Change event for Mother Report coil list.
  const handleMrCoilChange = (e: any) => {
    setCalMotherForm((prevState) => {
      const updatedState = {
        ...calMotherForm,
        motherCoil: e,
        proc: processLine,
      };

      SPO0003ApiCall("getMotherCoilDetails", updatedState);

      return updatedState;
    });
  };
  // Change event for Entry Division Coil list.
  const handleChangeEntDivCoil = (e: any) => {
    setSelectedDivMCoil(e);
    const updatedState = {
      mCoilId: e,
      proc: processLine,
    };
    SPO0003ApiCall("getZCoilList", updatedState);
  };
  // Change event for Packing Coil list.
  const handleChangePackingCoil = (e: any) => {
    setSelectedPCoil(e);
    setPackingReport((prevState) => {
      const updatedState = {
        ...calPackingReport,
        pCoilId: e,
        proc: processLine,
      };
      SPO0003ApiCall("getPackingCoilDtls", updatedState);
      return updatedState;
    });
  };
  const handleItemChange = (e: any) => {
    setCalDaughterForm({
      ...calDaughterForm,
      ordItem: e,
    });
  };
  const handleOrderChange = (e: any) => {
    setCalDaughterForm({
      ...calDaughterForm,
      order: e,
    });
  };

  function convert(str) {
    var month, day, year, hours, minutes, seconds;
    var date = new Date(str),
      month = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    hours = ("0" + date.getHours()).slice(-2);
    minutes = ("0" + date.getMinutes()).slice(-2);
    seconds = ("0" + date.getSeconds()).slice(-2);

    var mySQLDate = [day, month, date.getFullYear()].join("-");
    var mySQLTime = [hours, minutes, seconds].join(":");
    return [mySQLDate, mySQLTime].join(" ");
  }
  const confirmSave = () => {
    if (backupProcess === "PDI") {
      const prodStartDt = calPdiRequestForm.prodStartDt;
      const prodEndDt = calPdiRequestForm.prodEndDt;
      // if (prodStartDt == null) {
      //   alertify.error("Start Date cannot be blank!");
      //   return;
      // }
      // if (prodEndDt == null) {
      //   alertify.error("End Date cannot be blank!");
      //   return;
      // }
      // if (prodStartDt > prodEndDt) {
      //   alertify.error("Start Date cannot be greater than End Date!");
      //   return;
      // }
      SaveData("PDI_REQ_SL", processLine);
    }
    if (backupProcess === "HRSR") {
      if (selectedSuppCoil.length == 0) {
        alertify.error("Please select coil Id!");
        return;
      }
      const updatedData = {
        proc: processLine ?? "",
        coilId: selectedSuppCoil ?? "",
      };
      SaveData("SEND_COIL_SUPP", updatedData);
    }
    if (backupProcess === "HRSC") {
      if (selectedSuppCoilComp.length == 0) {
        alertify.error("Please select coil!");
        return;
      }
      const updatedData = {
        proc: processLine ?? "",
        coilId: selectedSuppCoilComp ?? "",
      };
      SaveData("SEND_COIL_SUPP_COMP", updatedData);
    }

    if (backupProcess === "REJ") {
      if (selectedRejCoil.length == 0) {
        alertify.error("Please select coil!");
        return;
      }
      const updatedData = {
        proc: processLine ?? "",
        coilId: selectedRejCoil ?? "",
      };
      SaveData("REJECT_COIL_SAVE", updatedData);
    }

    if (backupProcess === "RWS") {
      //********* daughter report validation after save.
      console.log("nctlLiveFlag: ", nctlLiveFlag);
      console.log("wctlLiveFlag: ", wctlLiveFlag);

      if (
        calDaughterForm.order == "" ||
        calDaughterForm.ordItem == "" ||
        calDaughterForm.crThick == "" ||
        calDaughterForm.CrWidth == "" ||
        calDaughterForm.netWt == ""
      ) {
        alertify.error("Please fill all the mandatory details!");
        return;
      }
      if (processLine === "S") {
        if (calDaughterForm.crIdia == "" || calDaughterForm.crOdia == "") {
          alertify.error("Please fill all the mandatory details!");
          return;
        }
      }
      if (processLine === "T") {
        if (wctlLiveFlag === "N") {
          alertify.error("Feature not live yet");
          return;
        }
        if (
          calDaughterForm.grossWt == "" ||
          calDaughterForm.fgTdc == "" ||
          calDaughterForm.pack_cd == "" ||
          calDaughterForm.length1 == "" ||
          calDaughterForm.coilNo == ""
        ) {
          alertify.error("Please fill all the mandatory details!");
          return;
        }
        if (
          !(Number(calDaughterForm.grossWt) > 0) ||
          !(Number(calDaughterForm.netWt) > 0) ||
          !(Number(calDaughterForm.length1) > 0) ||
          !(Number(calDaughterForm.coilNo) > 0)
        ) {
          alertify.error("Value should be greter than 0");
          return;
        }
        if (calDaughterForm?.pack_cd?.length < 4) {
          alertify.error("Length of Pack Code should be 4");
          return;
        }

        if (
          Number(calDaughterForm.grossWt) >
          Number(calDaughterForm.netWt) + 0.06
        ) {
          alertify.error("Gross Wt can not be more than 60 Kgs from Net Wt!");
          return;
        }
      }
      if (processLine === "N") {
        if (nctlLiveFlag === "N") {
          alertify.error("Feature not live yet");
          return;
        }
        if (
          calDaughterForm.grossWt == "" ||
          calDaughterForm.fgTdc == "" ||
          calDaughterForm.pack_cd == "" ||
          calDaughterForm.length1 == "" ||
          calDaughterForm.coilNo == ""
        ) {
          alertify.error("Please fill all the mandatory details!");
          return;
        }
        if (
          !(Number(calDaughterForm.grossWt) > 0) ||
          !(Number(calDaughterForm.netWt) > 0) ||
          !(Number(calDaughterForm.length1) > 0) ||
          !(Number(calDaughterForm.coilNo) > 0)
        ) {
          alertify.error("Value should be greter than 0");
          return;
        }
        if (calDaughterForm?.pack_cd?.length < 4) {
          alertify.error("Length of Pack Code should be 4");
          return;
        }
        if (
          Number(calDaughterForm.grossWt) >
          Number(calDaughterForm.netWt) + 0.06
        ) {
          alertify.error("Gross Wt can not be more than 60 Kgs from Net Wt!");
          return;
        }
      }
      const startDt = convert(calDaughterForm.productionStart);
      const endDt = convert(calDaughterForm.productionEnd);
      if (startDt > endDt) {
        alertify.error("Start Date cannot be greater than End Date!");
        return;
      }

      let timeDiff = new Date(endDt)?.getTime() - new Date(startDt)?.getTime();
      const twentyFourHoursMs = 24 * 60 * 60 * 1000;

      if (timeDiff > twentyFourHoursMs) {
        alertify.error(
          "Difference between Start and End Date should not exceed 24 hours."
        );
        return;
      }

      const now = new Date();
      const backdateHrs = new Date(
        now.getTime() - backRecordingHrs * 60 * 60 * 1000
      );
      // console.log("backdateHrs: ", convert(backdateHrs));
      // console.log("new Date(endDt): ", endDt);
      // console.log("backRecording: ", backRecordingHrs);

      if (endDt < convert(backdateHrs)) {
        console.log("Inside check");
        alertify.error(
          `Back Date production recording should not exceed ${backRecordingHrs} hrs.`
        );
        return;
      }

      if (holdFlag === "Y") {
        if (selectedHoldRsn?.length === 0) {
          alertify.error("Please Select Hold Reason");
          return;
        }
        if (calDaughterForm?.opr_rem?.length === 0) {
          alertify.error("Please fill Operator Remarks");
          return;
        }
      }

      const updatedData = {
        daughterCoil: calDaughterForm.daughterCoil ?? "",
        motherCoil: calDaughterForm.motherCoil ?? "",
        idPdi: calDaughterForm.idPdi ?? "",
        proc: calDaughterForm.proc ?? "",
        order: calDaughterForm.order ?? "",
        ordItem: calDaughterForm.ordItem ?? "",
        crThick: calDaughterForm.crThick ?? "",
        CrWidth: calDaughterForm.CrWidth ?? "",
        crIdia: calDaughterForm.crIdia ?? "",
        crOdia: calDaughterForm.crOdia ?? 0,
        coilNo: calDaughterForm.coilNo ?? 0,
        netWt: calDaughterForm.netWt ?? "",
        grossWt: calDaughterForm.grossWt ?? "",
        length: calDaughterForm.length1 ?? "",
        pack_cd: calDaughterForm.pack_cd ?? "",
        duration: calDaughterForm.duration ?? "",
        userId: user,
        opr_rem: calDaughterForm.opr_rem ?? "",
        productionStart: convert(calDaughterForm.productionStart) ?? null,
        productionEnd: convert(calDaughterForm.productionEnd) ?? null,
        actName: selectedActName,
        plannedProc: calDaughterForm.plannedProc ?? "",
        nextProc: calDaughterForm.nextProc ?? "",
        fgTdc: calDaughterForm.fgTdc ?? "",
        oil_type: calDaughterForm.oil_type ?? "",
        crNoPart: calDaughterForm.crNoPart ?? "",
        hold_fl: holdFlag ?? "",
        hold_cd: selectedHoldRsn ?? "",
        recoilerTension: calDaughterForm.recoilerTension ?? "",
        edgeWaviness: calDaughterForm.edgeWaviness ?? "",
        burrHeight: calDaughterForm.burrHeight ?? "",
        slitPosition: selectedSlitPos ?? "",
        ordEdge: calDaughterForm.ordEdge ?? "",
        coilEdgeCond: coilContion ?? "",
        tescopicity: tescopicity ?? "",
        zigZagWind: zigZagWind ?? "",
        cutrMark: cutrMark ?? "",
        oilCondn: oilCondn ?? "",
      };
      SaveData("SL_DAUGHTER_REP", updatedData);
    }
    if (backupProcess === "MR-CAL") {
      //********* mother report validation after save.
      if (processLine === "T") {
        if (calMotherForm.crThick == "" || calMotherForm.CrWidth == "") {
          alertify.error("Please fill all the mandatory details!");
          return;
        }
      }
      if (calMotherForm.sideTrim == "" || calMotherForm.pupCoil == "") {
        alertify.error("Please fill all the mandatory details!");
        return;
      }
      // if (processLine === "S") {
      //   if (calMotherForm.residualWt == "" || calMotherForm.endCut == "") {
      //     alertify.error("Please fill all the mandatory details!");
      //     return;
      //   }
      // }
      // if (processLine === "T") {
      //   if (calMotherForm.crThick == "" || calMotherForm.width == "") {
      //     alertify.error("Please fill all the mandatory details!");
      //     return;
      //   }
      // }
      if (processLine === "N") {
        if (calMotherForm.crThick == "" || calMotherForm.width == "") {
          alertify.error("Please fill all the mandatory details!");
          return;
        }
      }
      const startDt = convert(calMotherForm.productionStart);
      const endDt = convert(calMotherForm.productionEnd);
      if (startDt > endDt) {
        alertify.error("Start Date cannot be greater than End Date!");
        return;
      }
      setCalMotherForm({
        ...calMotherForm,
        userId: user,
      });
      // Change event for Mother Report coil list.
      const updatedState = {
        motherCoil: calMotherForm.motherCoil ?? "",
        residualWt: calMotherForm.residualWt ?? "",
        endCut: calMotherForm?.endCut ? Number(calMotherForm?.endCut) : "",
        sideTrim: calMotherForm?.sideTrim
          ? Number(calMotherForm?.sideTrim)
          : "",
        pupCoil: calMotherForm?.pupCoil ? Number(calMotherForm?.pupCoil) : "",
        slitNo: calMotherForm?.slitNo ? Number(calMotherForm?.slitNo) : "",
        productionStart: convert(calMotherForm.productionStart) ?? null,
        productionEnd: convert(calMotherForm.productionEnd) ?? null,
        userId: user,
        process: processLine,
        mThick: selectedMCoilDtls?.mThick
          ? Number(selectedMCoilDtls.mThick)
          : 0,
        width: selectedMCoilDtls?.mWidth ? Number(selectedMCoilDtls.mWidth) : 0,
        mLength: selectedMCoilDtls?.mLength ?? 0,
        nxtProc: selectedMCoilDtls.mNxtProc ?? "",
        outGradeDesc: selectedMCoilDtls.mOutGradeDesc ?? "",
        outTdc: selectedMCoilDtls.mOutTdc ?? "",
        plannedProc: selectedMCoilDtls.mPlannedProc ?? "",
      };
      SaveData("SL_MOTHER_REP", updatedState);
    }
    if (backupProcess === "ENT-DIV") {
      //********* Entry Division validation after save.
      if (
        calEntryDivision.mCoilId == "" ||
        calEntryDivision.zCoilId == "" ||
        calEntryDivision.rem_wt == "" ||
        calEntryDivision.rem_len == "" ||
        calEntryDivision.odia == "" ||
        selectedEntDivReason == null
      ) {
        alertify.error("Please fill all the mandatory details!");
        return;
      }
      const updatedData = {
        mCoilId: selectedDivMCoil ?? "",
        zCoilId: selectedDivZCoil ?? "",
        rem_wt: calEntryDivision.rem_wt ?? "",
        rem_length: calEntryDivision.rem_length ?? "",
        odia: calEntryDivision.odia ?? "",
        reason: selectedEntDivReason ?? "",
        process: processLine ?? "",
      };
      SaveData("ENT_DIVISION", updatedData);
    }
    if (backupProcess === "PR") {
      //********* Packing Report validation after save.

      if (calPackingReport?.pGrossWt < calPackingReport?.pNetWt) {
        alertify.error("Gross Wt can not be less than Net Wt!");
        return;
      }
      if (
        Number(calPackingReport?.pGrossWt) >
        Number(calPackingReport?.pNetWt) + 0.04
      ) {
        alertify.error("Gross Wt can not be more than 40 Kgs from Net Wt!");
        return;
      }
      if (
        selectedPCoil == "" ||
        calPackingReport.pThick == "" ||
        calPackingReport.pWidth == "" ||
        calPackingReport.pOdia == "" ||
        calPackingReport.pIdia == "" ||
        calPackingReport.pNetWt == "" ||
        calPackingReport.pGrossWt == "" ||
        calPackingReport.packingCd == "" ||
        calPackingReport.pStartDt == "" ||
        calPackingReport.pEndDt == ""
      ) {
        alertify.error("Please fill all the mandatory details!");
        return;
      }
      if (
        calPackingReport?.packingCd === "" ||
        calPackingReport?.packingCd === null ||
        calPackingReport?.packingCd === undefined
      ) {
        alertify.error("Pack code is mandatory");
        return;
      }

      //  Added on 24.02.2026, To make start dt & end dt selection mandatory
      if (
        calPackingReport.pStartDt == "" ||
        calPackingReport.pStartDt == null ||
        calPackingReport.pStartDt == undefined
      ) {
        alertify.error("Please Select Start Date");
        return;
      }
      if (
        calPackingReport.pEndDt == "" ||
        calPackingReport.pEndDt == null ||
        calPackingReport.pEndDt == undefined
      ) {
        alertify.error("Please Select End Date");
        return;
      }
      const startDt = convert(calPackingReport.pStartDt);
      const endDt = convert(calPackingReport.pEndDt);
      if (startDt > endDt) {
        alertify.error("Start Date cannot be greater than End Date!");
        return;
      }
      const updatedData = {
        pCoilId: selectedPCoil ?? "",
        pThick: calPackingReport.pThick ?? "",
        pWidth: calPackingReport.pWidth ?? "",
        pOdia: calPackingReport.pOdia ?? "",
        pIdia: calPackingReport.pIdia ?? "",
        pNetWt: calPackingReport.pNetWt ?? "",
        pGrossWt: calPackingReport.pGrossWt ?? "",
        packingCd: calPackingReport.packingCd ?? "",
        pStartDt: convert(calPackingReport.pStartDt) ?? null,
        pEndDt: convert(calPackingReport.pEndDt) ?? null,
      };
      SaveData("SL_PACKING_REP", updatedData);
    }
    if (backupProcess === "LOC-R") {
      if (selectedLocRepCoil.length == 0) {
        alertify.error("Please select coil!");
        return;
      }
      if (yard === "") {
        alertify.error("Please select YARD!");
        return;
      }
      if (locX === "") {
        alertify.error("Please select Loc X!");
        return;
      }
      if (locY === "") {
        alertify.error("Please select Loc Y!");
        return;
      }
      if (pos === "") {
        alertify.error("Please select Position!");
        return;
      }
      const updatedData = {
        coilId: selectedLocRepCoil ?? "",
        yard: yard ?? "",
        locX: locX ?? "",
        locY: locY ?? "",
        pos: pos ?? "",
      };
      SaveData("LOC_REP_SAVE", updatedData);
      setSelectedLocRepCoil("");
      setYard("");
      setLocX("");
      setLocY("");
      setPos("");
    }
  };
  const displayUI = () => {
    if (backupProcess === "PDI") {
      return PDIRequestUI();
    } else if (backupProcess === "HRSR") {
      return sendCoilSupUI();
    } else if (backupProcess === "HRSC") {
      return sendCoilSupCompUI();
    } else if (backupProcess === "REJ") {
      return registerRejectionUI();
    } else if (backupProcess === "Del") {
      return delayUI();
    } else if (backupProcess === "RWS") {
      if (
        selectedActName === "SLT" ||
        selectedActName === "CTL" ||
        selectedActName === "NCTL" ||
        selectedActName === "WCTL"
      ) {
        return daughterCoilUI();
      } else {
        alertify.error(
          "Daughter Report not available for selected process line!"
        );
      }
    } else if (backupProcess === "MR-CAL") {
      return motherDetailsUI();
    } else if (backupProcess === "ENT-DIV") {
      if (processLine === "S" || processLine === "N" || processLine === "T") {
        return EntryDivisionUI();
      }
      alertify.error("Entry Division not possible for selected process line!!");
    } else if (backupProcess === "PR") {
      return PackingUI();
    } else if (backupProcess === "LOC-R") {
      return locRepUI();
    }
  };

  const SaveData = (type?: any, data?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0003Api(token, {
        data,
        type: type,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (res?.data?.outBinds?.ls_out_flag[0] === "Y") {
              setCalDaughterForm(defaultDaughterForm);
              setOrderDetails(defaultOrderDetails);
              alertify.success(res?.data?.outBinds?.ls_out_flag);
            }
            if (res?.data?.outBinds?.ls_out_flag[0] === "N") {
              alertify.error(res?.data?.outBinds?.ls_out_flag);
            }
          }
          if (res.data.rowsAffected == 1) {
            setCalDaughterForm(defaultDaughterForm);
            setOrderDetails(defaultOrderDetails);
            setEntryDivision(defaultEntryDivision);
            setCalMotherForm(defaultMotherForm);

            setSelectedDivMCoil([]);
            setSelectedDivZCoil([]);
            setSelectedEntDivReason("");

            setPackingReport(defaultPackingReport);
            setSelectedPCoil("");
            if (backupProcess === "PDI") {
              alertify.success("PDI Request Received!");
            } else if (backupProcess === "HRSR") {
              alertify.success("Coil Supply request sent for coil id!");
            } else if (backupProcess === "HRSC") {
              alertify.success("Coil Supply request completed for coil id!");
            } else {
              alertify.success("Data inserted succussfully!");
            }
          }
        })
        .catch((e) => {
          console.log("e: SaveData", e);
          // alertify.error(e?.error?.message ? e.error.message : e.error.message);
          alertify.error(
            e?.error?.response?.data?.error
              ? e?.error?.response?.data?.error
              : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const SPO0003ApiCall = (type?: any, data?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0003Api(token, {
        data,
        type: type,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else {
            if (res?.data?.processLine?.length > 0 && type === "getPageData") {
              const varData: Array<SelectType> = [];
              res.data?.processLine?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.EPL_CD_PROCESS?.toString(),
                    label: x.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcessLineData(varData);
              setProcessLine(varData[0].value);
            }
            if (res?.data?.suppCoilList?.length > 0 && type === "getCoilList") {
              const varData: Array<SelectType> = [];
              res.data?.suppCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setSuppCoilData(varData);
            }
            if (
              res?.data?.suppCoilCompList?.length > 0 &&
              type === "getCoilCompList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.suppCoilCompList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setSuppCoilCompData(varData);
            }
            if (
              res?.data?.RejectCoilList?.length > 0 &&
              type === "getRejectCoilList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.RejectCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setRejCoilList(varData);
            }
            if (
              res?.data?.drMotherCoilList?.length > 0 &&
              type === "getDaughterReportData"
            ) {
              console.log(res.data);
              const varData: Array<SelectType> = [];
              res.data?.drMotherCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setDrMotherCoilData(varData);
            }
            if (
              res?.data?.mrMotherCoilList?.length > 0 &&
              type === "getMotherReportData"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.mrMotherCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setMrMotherCoilData(varData);
            }
            if (
              res?.data?.PackingList?.length > 0 &&
              type === "getPackingList"
            ) {
              const varData1: Array<SelectType> = [];
              res.data?.PackingList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData1.push({
                    value: x.TPM_PACK_CD?.toString(),
                    label: x.TPM_PACK_CD?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPackingCdData(varData1);
            }
            if (
              res?.data?.OrderDetails?.length > 0 &&
              type === "getOrderDetails"
            ) {
              setCalDaughterForm({
                ...calDaughterForm,
                order: res.data?.OrderDetails[0].PDS_ORDER ?? 0,
                ordItem: res.data?.OrderDetails[0].PDS_ITEM_NO ?? 0,
                crThick: res.data?.OrderDetails[0].PDS_THICK?.toFixed(3) ?? 0,
                CrWidth:
                  processLine === "S"
                    ? res.data?.OrderDetails[0].PDS_SLIT_WIDTH
                    : res.data?.OrderDetails[0].PDS_WIDTH ?? 0,
                crIdia: res.data?.OrderDetails[0].PDS_IDIA ?? 0,
                crOdia: res.data?.OrderDetails[0].PDS_ODIA ?? 0,
                crNoPart: res.data?.OrderDetails[0].PDS_NO_PART ?? 0,
                plannedProc: res.data?.OrderDetails[0].PDS_PLANNED_PROC ?? 0,
                nextProc: res.data?.OrderDetails[0].PDS_NXT_PROC ?? 0,
                fgTdc: res.data?.OrderDetails[0].PDS_OUT_TDC ?? 0,
                pack_cd: res.data?.OrderDetails[0].PDS_PACK_CODE ?? 0,
                length1: res.data?.OrderDetails[0].PDS_CUT_LENGTH ?? 0,
                oil_type: res.data?.OrderDetails[0].PDS_OIL_TYPE ?? 0,
                ordEdge: res.data?.OrderDetails[0].ENC_ORDER_EDGE ?? 0,
                coilNo:
                  processLine !== "S"
                    ? res.data?.OrderDetails[0].PDC_NO_SHEETS
                    : "",
              });

              setOutTdc(res.data?.OrderDetails[0].PDS_OUT_TDC);
              setOrderDetails({
                ...calOrderDetails,
                ordMinThick: res.data?.OrderDetails[0].ENC_SEC1_MIN ?? 0,
                ordMaxThick: res.data?.OrderDetails[0].ENC_SEC1_MAX ?? 0,
                ordMinWidth: res.data?.OrderDetails[0].ENC_SEC2_MIN ?? 0,
                ordMaxWidth: res.data?.OrderDetails[0].ENC_SEC2_MAX ?? 0,
              });
            }
            // if (
            //   res?.data?.dautrCoilCount?.length > 0 &&
            //   type === "getDautrCoilCount"
            // ) {
            //   const coilCount = Number(
            //     res.data.dautrCoilCount[0]?.DAUTR_COIL_CNT
            //   );
            //   if (calDaughterForm.crNoPart !== undefined) {
            //     const crNoPart = Number(calDaughterForm.crNoPart);
            //     if (crNoPart <= coilCount) {
            //       setCalDaughterForm(defaultDaughterForm);
            //       setOrderDetails(defaultOrderDetails);
            //       setPdiList([]);
            //       alertify.error(
            //         "Batch id assigned to this PDI" +
            //           calDaughterForm.idPdi +
            //           " already recorded, please select another PDI!"
            //       );
            //       return;
            //     }
            //   }
            // }
            if (
              res?.data?.drDaughterCoilList?.length > 0 &&
              type === "getDaughterCoilList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.drDaughterCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x?.toString(),
                    label: x?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setDrDaughterCoilData(varData);
            }
            if (res?.data?.pdiList?.length > 0 && type === "getPDIList") {
              const varData: Array<SelectType> = [];
              res.data?.pdiList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.PDS_PDI?.toString(),
                    label: x.PDS_PDI?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPdiList(varData);
            }
            if (
              res?.data?.mrCoilDetails?.length > 0 &&
              type === "getMotherReportCoilDetails"
            ) {
              const CoilData = res?.data?.mrCoilDetails?.[0] ?? {};
              setCalMotherForm({
                ...calMotherForm,
                motherCoil: CoilData?.PDS_ID_COIL ?? "",
                crThick: CoilData?.THICK ?? "",
                CrWidth: CoilData?.WIDTH ?? "",
                crIdia: CoilData?.PDS_IDIA ?? "",
                crOdia: CoilData?.PDS_ODIA ?? "",
                netWt: CoilData?.PDS_MASS ?? "",
                length1: CoilData?.PDS_LENGTH ?? "",
              });
            }
            if (
              res?.data?.divMotherCoilList?.length > 0 &&
              type === "getDivisionData"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.divMotherCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ID_COIL?.toString(),
                    label: x.ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setDivMotherCoilData(varData);
            }
            if (
              res?.data?.divZCoilList?.length > 0 &&
              type === "getZCoilList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.divZCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.ZBATCH_ENTDIV?.toString(),
                    label: x.ZBATCH_ENTDIV?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setDivZCoilData(varData);
            }
            if (
              res?.data?.entDivReasonList?.length > 0 &&
              type === "getDivisionData"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.entDivReasonList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.CD_VALUE?.toString(),
                    label: x.CD_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setEntDivReason(varData);
            }
            if (type === "getActionName") {
              if (res?.data?.actionName?.length > 0) {
                setSelectedActName(res.data?.actionName[0].EPL_ACTIVITY_NM);
              } else {
                setSelectedActName("");
              }
            }
            if (
              res?.data?.secondsFlag?.length > 0 &&
              type === "chkSecondsTdc"
            ) {
              if (res.data?.secondsFlag[0] == 1) {
                setSecondsTdc(false);
              } else {
                setSecondsTdc(true);
              }
            }
            if (
              res?.data?.motherCoilDtls?.length > 0 &&
              type === "getMotherCoilDetails"
            ) {
              const mCoilData = res?.data?.motherCoilDtls?.[0] ?? {};
              setSelectedMCoilDtls({
                ...selectedMCoilDtls,
                mThick: mCoilData?.THICK?.toFixed(3) ?? "",
                mWidth: mCoilData?.WIDTH ?? mCoilData?.EOM_SEC2 ?? "",
                mLength: mCoilData?.PDS_LENGTH ?? mCoilData?.EOM_LENGTH ?? "",
                mNxtProc: mCoilData?.PDS_NXT_PROC ?? "",
                mPlannedProc: mCoilData?.PDS_PLANNED_PROC ?? "",
                mOutTdc: mCoilData?.PDS_OUT_TDC ?? "",
                mOutGradeDesc: mCoilData?.PDS_OUT_GRADE_DESC ?? "",
              });
            }
            if (
              res?.data?.packingCoilList?.length > 0 &&
              type === "getPackingCoilList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.packingCoilList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.PDC_ID_COIL?.toString(),
                    label: x.PDC_ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPackingCoilList(varData);
            }
            if (
              res?.data?.packingCoilDtls?.length > 0 &&
              type === "getPackingCoilDtls"
            ) {
              const pCoilData = res?.data?.packingCoilDtls?.[0] ?? {};
              setPackingReport({
                ...calPackingReport,
                pThick: pCoilData?.PDC_THICK?.toFixed(3) ?? "",
                pWidth: pCoilData?.PDC_WIDTH ?? "",
                pOdia: pCoilData?.PDC_ODIA ?? "",
                pIdia: pCoilData?.PDC_IDIA ?? "",
                pNetWt: pCoilData?.CID_MASS?.toFixed(3) ?? "",
                packingCd: pCoilData?.CID_PACK_CODE ?? "",
              });
            }
            if (
              res?.data?.packingCdList?.length > 0 &&
              type === "getPackingCdList"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.packingCdList?.map((x: TableType, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.TPM_PACK_CD?.toString(),
                    label: x.TPM_PACK_CD?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPackingCdList(varData);
            }

            if (
              res?.data?.LocRepCoils?.length > 0 &&
              type === "getLocRepCoils"
            ) {
              const varData: Array<SelectType> = [];
              res.data?.LocRepCoils?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.EOM_ID_BATCH?.toString(),
                    label: x.EOM_ID_BATCH?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setLocRepCoils(varData);
            }

            // Added on 24.02.26, to make as yard as dropdown instead of input
            if (res?.data?.yardList?.length > 0 && type === "getYardList") {
              const varData: Array<SelectType> = [];
              res.data?.yardList?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData.push({
                    value: x.YARD?.toString(),
                    label: x.YARD?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setYardList(varData);
            }

            // Added on 09.03.26, backdate production recording should not exceed 24 hrs
            if (
              res?.data?.backRecording?.length > 0 &&
              type === "backRecording"
            ) {
              setBackRecordingHrs(res?.data?.backRecording?.[0]?.HOURS);
            }

            // Added on 09.03.26, Tp disable wctl, nctl recording till go live
            if (res?.data?.ctlLiveFlag?.length > 0 && type === "ctlLiveFlag") {
              setNctlLiveFlag(res?.data?.ctlLiveFlag?.[0]?.FLAGS?.substr(0, 1));
              setWctlLiveFlag(res?.data?.ctlLiveFlag?.[1]?.FLAGS?.substr(0, 1));
            }
          }
        })
        .catch((e) => {
          console.log("Error:", e);
          alertify.error(
            e ? e?.toString() : "Something Wents wrong!"
            //e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const daughterCoilUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 1, pr: 3, pb: 1 }}>
          <Grid
            container
            spacing={2}
            sx={{
              p: 0.5,
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={2.5}>
              <label>Mother Coil </label>
              <SelectInput
                // label="Mother Coil"
                placeholder="Mother Coil"
                //data={daughterReportCal?.mother}
                data={drMotherCoilData}
                value={calDaughterForm?.motherCoil}
                onChange={handleMotherCoilChange}
                //value={daughterReportCal?.mother.find((v:any) => { return (v.value == calDaughterForm?.motherCoil)? calDaughterForm?.motherCoil: ""})}
              />
            </Grid>
            <Grid item xs={1.5}>
              <label>ID PDI </label>
              <SelectInput
                // label="ID PDI"
                placeholder="ID PDI"
                data={pdiList}
                value={calDaughterForm?.idPdi}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    idPdi: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2.5}>
              <label>Daughter Coil </label>
              <SelectInput
                placeholder="Daughter Coil"
                data={drDaughterCoilData}
                value={calDaughterForm?.daughterCoil}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    daughterCoil: e,
                  })
                }
              />
            </Grid>
          </Grid>
          <Grid
            container
            spacing={2}
            sx={{
              p: 0.5,
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={2}>
              <label>Order </label>
              <Input
                placeholder="Order"
                value={calDaughterForm?.order ?? ""}
                readOnly={true}
              />
            </Grid>
            <Grid item xs={1.2}>
              <label>Item </label>
              <Input
                placeholder="Item"
                value={calDaughterForm?.ordItem ?? ""}
                readOnly={true}
              />
            </Grid>
            <Grid item xs={1.2}>
              <label>Thick </label>
              <Input
                placeholder="Thick"
                size={"small"}
                readOnly={true} //for testing
                value={calDaughterForm?.crThick ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    crThick: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={1.2}>
              <label>Width </label>
              <Input
                placeholder="Width"
                size={"small"}
                readOnly={secondsTdc} //for testing
                value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    CrWidth: e,
                  })
                }
              />
            </Grid>

            {selectedActName === "SLT" && (
              <Grid item xs={1.2}>
                <label>IDIA </label>
                <Input
                  placeholder="IDIA"
                  // placeholder="IDIA"
                  size={"small"}
                  // type={"number"}
                  // readOnly={true}
                  value={calDaughterForm?.crIdia ?? 0}
                  onChange={(e: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      crIdia: e,
                    })
                  }
                />
              </Grid>
            )}
            {selectedActName !== "SLT" && (
              <Grid item xs={1.2}>
                <label>No of Pieces</label>
                <Input
                  placeholder="No of Pieces"
                  size={"small"}
                  // type={"number"}
                  value={calDaughterForm?.coilNo ?? 0}
                  onChange={(e: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      coilNo: e,
                    })
                  }
                />
              </Grid>
            )}

            {selectedActName === "SLT" && (
              <Grid item xs={1.2}>
                <label>ODIA </label>
                <Input
                  // label="ODIA"
                  placeholder="ODIA"
                  size={"small"}
                  // type={"number"}
                  value={calDaughterForm?.crOdia ?? 0}
                  onChange={(e: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      crOdia: e,
                    })
                  }
                />
              </Grid>
            )}
            {/* {(selectedActName === "WCTL" || selectedActName === "NCTL") && ( */}
            <Grid item xs={1.5}>
              <label>Coil Length(m)</label>
              <Input
                // label="ODIA"
                placeholder="Length"
                size={"small"}
                type={"number"}
                value={calDaughterForm?.length1 ?? 0}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    length1: e,
                  })
                }
              />
            </Grid>
            {/* )} */}
            {/* {(selectedActName === "WCTL" || selectedActName === "NCTL") && ( */}
            <Grid item xs={1.2}>
              <label>TDC</label>
              <Input
                // label="ODIA"
                placeholder="TDC"
                size={"small"}
                // type={"number"}
                value={calDaughterForm?.fgTdc ?? 0}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    fgTdc: e,
                  })
                }
              />
            </Grid>
            {/* )} */}
          </Grid>
          <Grid
            container
            spacing={2}
            sx={{
              p: 0.5,
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={1.5}>
              <label>Net Wt(Ton) </label>
              <Input
                placeholder="Net Wt"
                type={"number"}
                value={calDaughterForm?.netWt ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    netWt: e,
                  })
                }
              />
            </Grid>
            {(selectedActName === "WCTL" || selectedActName === "NCTL") && (
              <Grid item xs={1.5}>
                <label>Gross Wt(Ton)</label>
                <Input
                  // label="ODIA"
                  placeholder="Gross Wt."
                  size={"small"}
                  type={"number"}
                  value={calDaughterForm?.grossWt ?? 0}
                  onChange={(e: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      grossWt: e,
                    })
                  }
                />
              </Grid>
            )}

            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Production Start Date</label>
                <Input
                  //label ='Production Start Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      productionStart: date,
                      duration: (
                        (new Date(calDaughterForm?.productionEnd) -
                          new Date(date)) /
                        (60 * 1000)
                      )?.toString(),
                    })
                  }
                  value={calDaughterForm.productionStart}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Production End Date </label>
                <Input
                  //label ='Production End Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      productionEnd: date,
                      duration: (
                        (new Date(date) -
                          new Date(calDaughterForm.productionStart)) /
                        (60 * 1000)
                      )?.toString(),
                    })
                  }
                  value={calDaughterForm.productionEnd}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            {(selectedActName === "WCTL" || selectedActName === "NCTL") && (
              <Grid item xs={1.2}>
                <label>Duration</label>
                <Input
                  // label="ODIA"
                  placeholder="Duration"
                  size={"small"}
                  // type={"number"}
                  value={calDaughterForm?.duration ?? 0}
                />
              </Grid>
            )}
            {/* {(selectedActName === "WCTL" || selectedActName === "NCTL") && ( */}
            <Grid item xs={1.2}>
              <label>Pack Type</label>
              <Input
                // label="ODIA"
                placeholder="Pack Type"
                size={"small"}
                // type={"number"}
                value={calDaughterForm?.pack_cd ?? 0}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    pack_cd: e?.toUpperCase(),
                  })
                }
              />
            </Grid>
            {/* )} */}

            <Grid item xs={1.2}>
              <label>Curr Proc</label>
              <Input
                placeholder="Curr Proc"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                value={processLine}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid>

            <Grid item xs={1.2}>
              <label>Next Proc </label>
              <Input
                placeholder="Next Proc"
                size={"small"}
                // readOnly={secondsTdc}
                value={calDaughterForm?.nextProc ?? ""}
                onChange={(e: any) => {
                  setCalDaughterForm({
                    ...calDaughterForm,
                    nextProc: e,
                  });
                }}
              />
            </Grid>

            <hr style={{ width: "100%", margin: "10px 0" }} />

            <Grid item xs={1.2}>
              <label>No of Parts </label>
              <Input
                placeholder="No Parts"
                size={"small"}
                // readOnly={secondsTdc}
                value={calDaughterForm?.crNoPart ?? ""}
                onChange={(e: any) => {
                  setCalDaughterForm({
                    ...calDaughterForm,
                    crNoPart: e,
                  });
                }}
              />
            </Grid>

            {/* <Grid item xs={1.2}>
              <label>TDC </label>
              <Input
                placeholder="TDC"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                // value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid> */}

            {/* <Grid item xs={1.2}>
              <label>Coil Length </label>
              <Input
                placeholder="Coil Len"
                size={"small"}
                type={"number"}
                readOnly={secondsTdc}
                value={calDaughterForm?.length1 ?? ""}
                onChange={(e: any) => {
                  setCalDaughterForm({
                    ...calDaughterForm,
                    length1: e,
                  });
                }}
              />
            </Grid> */}

            <Grid item xs={1.2}>
              <label>Order Edge </label>
              <Input
                placeholder="Order Edge"
                value={calDaughterForm?.ordEdge ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    ordEdge: e,
                  })
                }
              />
            </Grid>

            {/* <Grid item xs={1.2}>
              <label>Pack Type </label>
              <Input
                placeholder="Pack Type"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                // value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid> */}

            {selectedActName === "SLT" && (
              <Grid item xs={1.2}>
                <label>Slit Position </label>
                <SelectInput
                  placeholder="Slit Pos"
                  data={slitPosData}
                  value={selectedSlitPos}
                  onChange={(e: any) => setSelectedSlitPos(e)}
                />
              </Grid>
            )}

            <Grid item xs={1.2}>
              <label>Hold Flag </label>
              <SelectInput
                placeholder="Hold Flag"
                data={YNList}
                value={holdFlag}
                onChange={(e: any) => setHoldFlag(e)}
              />
            </Grid>

            <Grid item xs={2}>
              <label>Hold Reason </label>
              <SelectInput
                placeholder="Hold Rsn"
                data={holdRsnData}
                value={selectedHoldRsn}
                onChange={(e: any) => setSelectedHoldRsn(e)}
              />
            </Grid>

            {/* {selectedActName === "SLT" && ( */}
            <Grid item xs={2.2}>
              <label>Operator Remarks</label>
              <Input
                // label="Operator Remarks"
                placeholder="Operator Remarks"
                value={calDaughterForm?.opr_rem ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    opr_rem: e,
                  })
                }
              />
            </Grid>
            {/* )} */}

            <Grid item xs={1.2}>
              <label>Oiling Type </label>
              <Input
                placeholder="Oiling Type"
                size={"small"}
                // readOnly={secondsTdc}
                value={calDaughterForm?.oil_type ?? ""}
                onChange={(e: any) => {
                  setCalDaughterForm({
                    ...calDaughterForm,
                    oil_type: e,
                  });
                }}
              />
            </Grid>

            {/* <Grid item xs={1.8}>
              <label>Operator Remark </label>
              <Input
                placeholder="Op Remark"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                // value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid> */}

            <Grid item xs={1.8}>
              <label>Coil edge condition</label>
              <SelectInput
                placeholder="Coil contion"
                data={OkList}
                value={coilContion}
                onChange={(e: any) => setCoilContion(e)}
              />
            </Grid>

            <Grid item xs={1.2}>
              <label>Telescopicity </label>
              <SelectInput
                placeholder="Tescopicity"
                data={OkList}
                value={tescopicity}
                onChange={(e: any) => setTescopicity(e)}
              />
            </Grid>

            <Grid item xs={1.5}>
              <label>Zig Zag Winding </label>
              <SelectInput
                placeholder="Zig Zag Winding"
                data={OkList}
                value={zigZagWind}
                onChange={(e: any) => setZigZagWind(e)}
              />
            </Grid>

            <Grid item xs={1.2}>
              <label>Cutter mark</label>
              <SelectInput
                placeholder="Cutter mark"
                data={OkList}
                value={cutrMark}
                onChange={(e: any) => setCutrMark(e)}
              />
            </Grid>

            <Grid item xs={1.2}>
              <label>Oil condition</label>
              <SelectInput
                placeholder="Oil condition"
                data={OkList}
                value={oilCondn}
                onChange={(e: any) => setOilCondn(e)}
              />
            </Grid>

            {/* <Grid item xs={1.5}>
              <label>Actual Thick</label>
              <Input
                placeholder="Act Thick"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                // value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid>

            <Grid item xs={1.5}>
              <label>Actual Width</label>
              <Input
                placeholder="Act Width"
                size={"small"}
                // type={"number"}
                // readOnly={secondsTdc}
                // value={calDaughterForm?.CrWidth ?? ""}
                onChange={(e: any) => {
                  // setCalDaughterForm({
                  //   ...calDaughterForm,
                  //   CrWidth: e,
                  // })
                }}
              />
            </Grid> */}

            <Grid item xs={2.5}>
              <label>Recoiler tension (N/mm^2) </label>
              <Input
                placeholder="Recoiler Ten"
                value={calDaughterForm?.recoilerTension ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    recoilerTension: e,
                  })
                }
              />
            </Grid>

            <Grid item xs={1.5}>
              <label>Edge waviness</label>
              <Input
                placeholder="Edge waviness"
                value={calDaughterForm?.edgeWaviness ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    edgeWaviness: e,
                  })
                }
              />
            </Grid>

            <Grid item xs={1.2}>
              <label>Burr height</label>
              <Input
                placeholder="Burr height"
                size={"small"}
                value={calDaughterForm?.burrHeight ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    burrHeight: e,
                  })
                }
              />
            </Grid>
          </Grid>

          <Grid
            container
            spacing={2}
            sx={{
              p: 0.5,
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          ></Grid>
        </Grid>
      </>
    );
  };
  const motherDetailsUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 1, pr: 3, pb: 1 }}>
          <Grid
            container
            spacing={1}
            sx={{
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={3} style={{ marginTop: "1rem" }}>
              <label>Mother Coil </label>
              <SelectInput
                placeholder="Mother Coil"
                //data={calMotherForm?.mother}
                data={mrMotherCoilData}
                value={calMotherForm?.motherCoil}
                onChange={handleMrCoilChange}
              />
            </Grid>
            {/* {selectedActName === "SLT" && (
              <Grid item xs={2} style={{ marginTop: "1rem" }}>
                <label>Residual Wt</label>
                <Input
                  placeholder="Residual Wt"
                  value={calMotherForm?.residualWt ?? ""}
                  onChange={(e: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      residualWt: e,
                    })
                  }
                />
              </Grid>
            )} */}
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>End Cut Wt</label>
              <Input
                placeholder="End Cut Wt"
                type={"number"}
                value={calMotherForm?.endCut ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    endCut: e,
                  })
                }
              />
            </Grid>
          </Grid>
          <Grid
            container
            spacing={1}
            sx={{
              pt: 2,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={1.5}>
              <label>Side Trim Wt</label>
              <Input
                placeholder="Side Trim Wt"
                type={"number"}
                value={calMotherForm?.sideTrim ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    sideTrim: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={1.5}>
              <label>Pup Coil Wt</label>
              <Input
                placeholder="Pup Coil Wt"
                value={calMotherForm?.pupCoil ?? ""}
                type={"number"}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    pupCoil: e,
                  })
                }
              />
            </Grid>
            {selectedActName === "SLT" && (
              <Grid item xs={1.5}>
                <label>No of slit</label>
                <Input
                  placeholder="No of slit"
                  value={calMotherForm?.slitNo ?? ""}
                  type={"number"}
                  onChange={(e: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      slitNo: e,
                    })
                  }
                />
              </Grid>
            )}
            {/* Commented thick width on 17.07.26, User requirement */}
            {/* {(selectedActName === "WCTL" || selectedActName === "NCTL") && (
              <Grid item xs={1.5}>
                <label>Width</label>
                <Input
                  placeholder="Width"
                  value={calMotherForm.CrWidth ?? ""}
                  type={"number"}
                  // readOnly={false}
                  onChange={(e: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      CrWidth: e,
                    })
                  }
                />
              </Grid>
            )}
            {(selectedActName === "WCTL" || selectedActName === "NCTL") && (
              <Grid item xs={1.5}>
                <label>Thick</label>
                <Input
                  placeholder="Thick"
                  value={calMotherForm.crThick ?? ""}
                  type={"number"}
                  // readOnly={false}
                  onChange={(e: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      crThick: e,
                    })
                  }
                />
              </Grid>
            )} */}

            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Production Start Date</label>
                <Input
                  //label ='Production Start Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      productionStart: date,
                    })
                  }
                  value={calMotherForm.productionStart}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2.5}>
              <label>Production End Date</label>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <Input
                  //label ='Production End Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalMotherForm({
                      ...calMotherForm,
                      productionEnd: date,
                    })
                  }
                  value={calMotherForm.productionEnd}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
          </Grid>
          <Grid
            container
            spacing={1}
            sx={{
              pt: 0.5,
              pb: 2.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          ></Grid>
        </Grid>
      </>
    );
  };
  const PDIRequestUI = () => {
    return (
      <>
        <Grid
          style={{
            margin: "1rem",
            fontSize: 15,
            textAlign: "center",
            color: "maroon",
          }}
        >
          Click on Save button to request PDI
        </Grid>
        {/* <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <ButtonElement onClick={() => fetchPDIData()} >
                  Request PDI 
                </ButtonElement>
            </Grid>
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>From Date</label>
                <Input
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalPdiRequestForm({
                      ...calPdiRequestForm,
                      prodStartDt: date,
                    })
                  }
                  value={calPdiRequestForm.prodStartDt}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>To Date </label>
                <Input
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalPdiRequestForm({
                      ...calPdiRequestForm,
                      prodEndDt: date,
                    })
                  }
                  value={calPdiRequestForm.prodEndDt}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
          </Grid>
        </Grid> */}
      </>
    );
  };
  const sendCoilSupUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            <Grid item xs={3}></Grid>
            <Grid item xs={3}>
              <label>Coil Id</label>
              <SelectInput
                placeholder="Coil Id"
                data={suppCoilData}
                onChange={(e: any) => {
                  setSelectedSuppCoil(e);
                }}
                value={selectedSuppCoil}
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };
  const sendCoilSupCompUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            <Grid item xs={3}></Grid>
            <Grid item xs={3}>
              <label>Coil Id</label>
              <SelectInput
                placeholder="Coil Id"
                data={suppCoilCompData}
                onChange={(e: any) => {
                  setSelectedSuppCoilComp(e);
                }}
                value={selectedSuppCoilComp}
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };
  const registerRejectionUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            {/* <Grid item xs={4} style={{ marginTop: "1rem" }}>
              <RadioInput
                row
                //value={radioOptions}
                data={[
                  { label: "Rejection", value: "1" },
                  { label: "Rejection With Hold ", value: "2" },
                ]}
                onChange={(e: string) => {
                  setRadioOption(e);
                }}
              />
            </Grid> */}
            <Grid item xs={3}></Grid>

            <Grid item xs={2.5}>
              <label>Coil in UP for Rejection</label>
              <SelectInput
                placeholder="Coil in UP for Rejection"
                data={rejCoilList}
                onChange={(e: any) => {
                  setSelectedRejCoil(e);
                }}
                value={selectedRejCoil}
              />
            </Grid>
            {/* <Grid item xs={2.5}>
              <label>Reason Code Rejection</label>
              <SelectInput
                placeholder="Reason Code Rejection"
                data={shiftList}
                value={calDaughterForm?.shift ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    shift: e,
                  })
                }
              />
            </Grid> */}
          </Grid>
        </Grid>
      </>
    );
  };

  const delayUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Outage Date</label>
                <Input
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      productionStart: date,
                    })
                  }
                  value={calDaughterForm.productionStart}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={1.5}>
              <label>Shift</label>
              <SelectInput
                placeholder="Shift"
                data={shiftList}
                value={calDaughterForm?.shift ?? ""}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    shift: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Delay Start Date</label>
                <Input
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      productionStart: date,
                    })
                  }
                  value={calDaughterForm.productionStart}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2.5}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Delay End Date </label>
                <Input
                  type="datetime-local"
                  onChange={(date: any) =>
                    setCalDaughterForm({
                      ...calDaughterForm,
                      productionEnd: date,
                    })
                  }
                  value={calDaughterForm.productionEnd}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2}>
              <label>Duration(mm)</label>
              <Input
                placeholder="Duration(mm)"
                value={calMotherForm?.pupCoil ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    pupCoil: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2}>
              <label>Reason Code</label>
              <SelectInput
                placeholder="Reason Code"
                data={suppCoilCompData}
                onChange={(e: any) => {
                  setSelectedSuppCoilComp(e);
                }}
                value={selectedSuppCoilComp}
              />
            </Grid>
            <Grid item xs={3}>
              <label>Reason Desc</label>
              <Input
                placeholder="Reason Desc"
                value={calMotherForm?.pupCoil ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    pupCoil: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2}>
              <label>Coil Id</label>
              <Input
                placeholder="Coil Id"
                value={calMotherForm?.pupCoil ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    pupCoil: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={4}>
              <label>Remarks</label>
              <Input
                placeholder="Remarks"
                value={calMotherForm?.pupCoil ?? ""}
                onChange={(e: any) =>
                  setCalMotherForm({
                    ...calMotherForm,
                    pupCoil: e,
                  })
                }
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };
  const sendToSAPUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={3} style={{ marginTop: "1rem" }}>
              <SelectInput
                placeholder="Mother Coil"
                data={daughterReportCal?.mother}
                onChange={(e: any) =>
                  setCalDaughterForm({
                    ...calDaughterForm,
                    motherCoil: e,
                  })
                }
                value={daughterReportCal?.mother.find((v: any) => {
                  return v.value == calDaughterForm?.daughterCoil
                    ? calDaughterForm?.daughterCoil
                    : "";
                })}
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };
  const EntryDivisionUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>Coil Id</label>
              <SelectInput
                placeholder="Coil Id"
                data={divMotherCoilData}
                // onChange={(e: any) => {
                //   setSelectedDivMCoil(e)
                //  }}
                value={selectedDivMCoil}
                onChange={handleChangeEntDivCoil}
              />
            </Grid>
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>Z Coil Id </label>
              <SelectInput
                placeholder="Z Coil Id"
                data={divZCoilData}
                onChange={(e: any) => {
                  setSelectedDivZCoil(e);
                }}
                value={selectedDivZCoil}
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>Remaining Wt </label>
              <Input
                placeholder="Remaining Wt(Ton)"
                value={calEntryDivision?.rem_wt ?? ""}
                type={"number"}
                onChange={(e: any) =>
                  setEntryDivision({
                    ...calEntryDivision,
                    rem_wt: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>Remaining Length(m)</label>
              <Input
                placeholder="Remaining Length"
                type={"number"}
                value={calEntryDivision?.rem_length ?? ""}
                onChange={(e: any) =>
                  setEntryDivision({
                    ...calEntryDivision,
                    rem_length: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>ODIA </label>
              <Input
                placeholder="ODIA"
                size={"small"}
                type={"number"}
                value={calEntryDivision?.odia ?? ""}
                onChange={(e: any) =>
                  setEntryDivision({
                    ...calEntryDivision,
                    odia: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>Reason</label>
              <SelectInput
                placeholder="Reason"
                data={entDivReason}
                onChange={(e: any) => {
                  setSelectedEntDivReason(e);
                }}
                value={selectedEntDivReason}
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };

  const PackingUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "center",
              gap: 1.5,
            }}
          >
            <Grid item xs={2.5} style={{ marginTop: "1rem" }}>
              <label>Batch Id</label>
              <SelectInput
                // label="Coil Id"
                placeholder="Batch Id"
                data={packingCoilList}
                value={selectedPCoil}
                onChange={handleChangePackingCoil}
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>Thick </label>
              <Input
                placeholder="Thick"
                size={"small"}
                readOnly={true}
                value={calPackingReport?.pThick ?? 0}
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>Width </label>
              <Input
                placeholder="Width"
                size={"small"}
                readOnly={true}
                value={calPackingReport?.pWidth ?? 0}
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>IDIA </label>
              <Input
                placeholder="IDIA"
                size={"small"}
                type={"number"}
                //readOnly = {true}
                value={calPackingReport?.pIdia ?? 0}
                onChange={(e: any) =>
                  setPackingReport({
                    ...calPackingReport,
                    pIdia: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={1.5} style={{ marginTop: "1rem" }}>
              <label>ODIA </label>
              <Input
                placeholder="ODIA"
                size={"small"}
                //readOnly = {true}
                type={"number"}
                value={calPackingReport?.pOdia ?? 0}
                onChange={(e: any) =>
                  setPackingReport({
                    ...calPackingReport,
                    pOdia: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={2} style={{ marginTop: "1rem" }}>
              <label>Net Wt(Ton) </label>
              <Input
                placeholder="Net Wt"
                // type={"number"}
                readOnly={true}
                value={calPackingReport?.pNetWt ?? ""}
                // onChange={(e: any) =>
                //   setPackingReport({
                //     ...calPackingReport,
                //     pNetWt: e,
                //   })
                // }
              />
            </Grid>
            <Grid item xs={2}>
              <label>Gross wt(Ton)</label>
              <Input
                placeholder="Gross wt"
                type={"number"}
                value={calPackingReport?.pGrossWt ?? ""}
                onChange={(e: any) =>
                  setPackingReport({
                    ...calPackingReport,
                    pGrossWt: e,
                  })
                }
              />
            </Grid>
            <Grid item xs={3}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <label>Start Date</label>
                <Input
                  //label ='Start Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setPackingReport({
                      ...calPackingReport,
                      pStartDt: date,
                    })
                  }
                  value={calPackingReport.pStartDt}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={3}>
              <label>End Date</label>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <Input
                  //label ='End Date'
                  type="datetime-local"
                  onChange={(date: any) =>
                    setPackingReport({
                      ...calPackingReport,
                      pEndDt: date,
                    })
                  }
                  value={calPackingReport.pEndDt}
                  slotProps={{ textField: { size: "small" } }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2}>
              <label>Packing Code</label>
              <SelectInput
                placeholder="Packing Code"
                value={calPackingReport?.packingCd ?? ""}
                data={packingCdList}
                onChange={(e: any) =>
                  setPackingReport({
                    ...calPackingReport,
                    packingCd: e,
                  })
                }
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };

  const locRepUI = () => {
    return (
      <>
        <Grid container spacing={2} sx={{ pt: 0.75, pl: 3, pr: 3, pb: 3 }}>
          <Grid
            container
            spacing={2}
            id="rwsp"
            sx={{
              p: 0.5,
              backgroundColor: csTheme?.palette.background.paper,
              justifyContent: "left",
              gap: 1.5,
            }}
          >
            <Grid item xs={2}></Grid>

            <Grid item xs={2.5}>
              <label>Batch Id</label>
              <SelectInput
                placeholder="Batch Id"
                data={locRepCoils}
                onChange={(e: any) => {
                  setSelectedLocRepCoil(e);
                }}
                value={selectedLocRepCoil}
              />
            </Grid>

            <Grid item xs={1.4}>
              <label>YARD</label>
              <SelectInput
                placeholder="YARD"
                data={yardList}
                onChange={(e: any) => {
                  setYard(e);
                }}
                value={yard}
              />
              {/* <Input
                placeholder="YARD"
                size={"small"}
                value={yard}
                onChange={(e: any) => setYard(e.toUpperCase().slice(0, 2))}
              /> */}
            </Grid>
            <Grid item xs={1.2}>
              <label>LOC X</label>
              <Input
                placeholder="LOC X"
                size={"small"}
                value={locX}
                onChange={(e: any) => setLocX(e.toUpperCase().slice(0, 2))}
              />
            </Grid>
            <Grid item xs={1.2}>
              <label>LOC Y</label>
              <Input
                placeholder="LOC Y"
                size={"small"}
                value={locY}
                onChange={(e: any) => setLocY(e.toUpperCase().slice(0, 2))}
              />
            </Grid>
            <Grid item xs={1.5}>
              <label>Position</label>
              <Input
                type="number"
                placeholder="Position"
                size={"small"}
                value={pos}
                onChange={(e: any) => setPos(e.toUpperCase().slice(0, 1))}
              />
            </Grid>
          </Grid>
        </Grid>
      </>
    );
  };
  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ p: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12} sx={{ pl: 0 }}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton
                    onClick={() => {
                      handleClearAll();
                    }}
                  >
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2} sx={{ p: 0.75, gap: 2 }}>
                <Grid item xs={3}>
                  <SelectInput
                    label="Process Line"
                    data={processLineData}
                    value={processLine}
                    size={"small"}
                    onChange={(e: any) => {
                      setProcessLine(e);
                      setBackupProcess("");
                      setMrMotherCoilData([]);
                      setDrDaughterCoilData([]);
                      setDivMotherCoilData([]);
                    }}
                    //onChange={handleChangeProcess}
                  />
                </Grid>
                <Grid item xs={3}>
                  <SelectInput
                    label="Backup Process*"
                    data={processLine === "S" ? calBackup : tCalBackup}
                    value={backupProcess}
                    size={"small"}
                    onChange={handleBackupProcessChange}
                    // onChange={(e: any) =>
                    // {
                    //     setBackupProcess(e)
                    // }
                    //}
                  />
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title={"Details"}
              headerContainer={
                <>
                  <Tooltip title={"Save"}>
                    <IconButton
                      onClick={() => {
                        confirmSave();
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <SaveIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              <>{backupProcess && processLine && displayUI()}</>
              {showSaveMsgError && (
                <Grid item xs={12}>
                  <Alert variant="filled" severity="error">
                    {saveMsg}
                  </Alert>
                </Grid>
              )}
              {showSaveMsgSuccess && (
                <Grid item xs={12}>
                  <Alert variant="filled" severity="success">
                    {saveMsg}
                  </Alert>
                </Grid>
              )}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPO0003;
