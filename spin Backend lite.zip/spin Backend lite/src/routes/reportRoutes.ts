import { Router } from "express";
import // SPS0020Controller,
// getData,
//   getInvData,
// getDispatchData,
//   getInvMonData,
// getOrderData08,
// getData08,
// SPS0025Controller,
// SPS0025BatchId,
// SPS0025TableApi,
"../controllers/reportController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const reportRoute = Router();
// reportRoute
//   .route("/report/SPS0020Api")
//   .post(authenticationMiddleware.bearer, SPS0020Controller);
// reportRoute.route('/report/getInvData').post(authenticationMiddleware.bearer, getInvData);
// reportRoute
//   .route("/report/getData")
//   .post(authenticationMiddleware.bearer, getData);
// reportRoute
//   .route("/report/getDispatchData")
//   .post(authenticationMiddleware.bearer, getDispatchData);
// reportRoute
//   .route("/report/getInvMonData")
//   .post(authenticationMiddleware.bearer, getInvMonData);
// reportRoute
//   .route("/report/getOrder08")
//   .get(authenticationMiddleware.bearer, getOrderData08);
// reportRoute
//   .route("/report/getScoData")
//   .post(authenticationMiddleware.bearer, getData08);
// reportRoute
//   .route("/report/SPS0025Api")
//   .post(authenticationMiddleware.bearer, SPS0025Controller);
// reportRoute
//   .route("/report/SPS0025BatchApi")
//   .post(authenticationMiddleware.bearer, SPS0025BatchId);
// reportRoute
//   .route("/report/SPS0025TableApi")
//   .post(authenticationMiddleware.bearer, SPS0025TableApi);

export default reportRoute;
