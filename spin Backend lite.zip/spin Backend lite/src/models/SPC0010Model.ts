// const SPC0010Query = require("../repository/SPC0010Query");
import * as SPC0010Query from "../repository/SPC0010Query";

export default class SPC0010Model {
  getData(data: any) {
    return SPC0010Query.getData(data);
  }
  getDispatchData(data: any) {
    return SPC0010Query.getDispatchData(data);
  }
}
