import { dateInput, input } from "../../type";
 
 
export interface InputChangeType {
    key1: input,
    key2: input,
 
}
export interface TableType {
    EGP_CD_EPA: string;
    SOI_ID_ORDER: string;
    SOI_CD_EPA: string;
    SOI_NO_END_MATNR: string;
    SOI_NO_INP_MATNR: string;
    EPL_CD_EPA : string;
    EPL_CD_EPA_DESC: string;
}