import React from "react";
import DashboardLayout from "../../components/layout/dashboardLayout";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../theme/type";
import { Grid, Card, CardContent } from "@mui/material";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";
import { Line, Pie, Doughnut } from "react-chartjs-2";
import { useMaterialUIController, setUser } from "../../context";
import routes from "../../constant/route";
import { useNavigate } from "react-router-dom";
import Auth from "../../components/layout/dashboardLayout/auth";

const Dashboard = () => {
  const navigate = useNavigate();
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;

  React.useEffect(() => {
    if (user) {
      navigate(routes.dashboard);
    }
  }, [user]);

  React.useEffect(() => {
    ChartJS.register(
      CategoryScale,
      LinearScale,
      PointElement,
      LineElement,
      ArcElement,
      Title,
      Tooltip,
      Legend
    );
  }, []);
  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={4} sx={{ p: 4 }}>
          <Grid item xs={3}>
            <Card>
              <CardContent>
                <Line
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: "top" as const,
                      },
                      title: {
                        display: false,
                        text: "Chart",
                      },
                    },
                  }}
                  data={{
                    labels: [
                      "January",
                      "February",
                      "March",
                      "April",
                      "May",
                      "June",
                      "July",
                    ],
                    datasets: [
                      {
                        label: "Dataset 1",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => -i),
                        borderColor: "rgb(255, 99, 132)",
                        backgroundColor: "rgba(255, 99, 132, 0.5)",
                      },
                      {
                        label: "Dataset 2",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => i),
                        borderColor: "rgb(53, 162, 235)",
                        backgroundColor: "rgba(53, 162, 235, 0.5)",
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card>
              <CardContent>
                <Line
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: "top" as const,
                      },
                      title: {
                        display: false,
                        text: "Chart",
                      },
                    },
                  }}
                  data={{
                    labels: [
                      "January",
                      "February",
                      "March",
                      "April",
                      "May",
                      "June",
                      "July",
                    ],
                    datasets: [
                      {
                        label: "Dataset 1",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => -i),
                        borderColor: "rgb(255, 99, 132)",
                        backgroundColor: "rgba(255, 99, 132, 0.5)",
                      },
                      {
                        label: "Dataset 2",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => i),
                        borderColor: "rgb(53, 162, 235)",
                        backgroundColor: "rgba(53, 162, 235, 0.5)",
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card>
              <CardContent>
                <Line
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: "top" as const,
                      },
                      title: {
                        display: false,
                        text: "Chart",
                      },
                    },
                  }}
                  data={{
                    labels: [
                      "January",
                      "February",
                      "March",
                      "April",
                      "May",
                      "June",
                      "July",
                    ],
                    datasets: [
                      {
                        label: "Dataset 1",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => -i),
                        borderColor: "rgb(255, 99, 132)",
                        backgroundColor: "rgba(255, 99, 132, 0.5)",
                      },
                      {
                        label: "Dataset 2",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => i),
                        borderColor: "rgb(53, 162, 235)",
                        backgroundColor: "rgba(53, 162, 235, 0.5)",
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card>
              <CardContent>
                <Line
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: "top" as const,
                      },
                      title: {
                        display: false,
                        text: "Chart",
                      },
                    },
                  }}
                  data={{
                    labels: [
                      "January",
                      "February",
                      "March",
                      "April",
                      "May",
                      "June",
                      "July",
                    ],
                    datasets: [
                      {
                        label: "Dataset 1",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => -i),
                        borderColor: "rgb(255, 99, 132)",
                        backgroundColor: "rgba(255, 99, 132, 0.5)",
                      },
                      {
                        label: "Dataset 2",
                        data: [
                          "January",
                          "February",
                          "March",
                          "April",
                          "May",
                          "June",
                          "July",
                        ].map((x, i) => i),
                        borderColor: "rgb(53, 162, 235)",
                        backgroundColor: "rgba(53, 162, 235, 0.5)",
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card>
              <CardContent style={{ height: 450 }}>
                <Pie
                  data={{
                    labels: [
                      "Red",
                      "Blue",
                      "Yellow",
                      "Green",
                      "Purple",
                      "Orange",
                    ],
                    datasets: [
                      {
                        label: "# of Votes",
                        data: [12, 19, 3, 5, 2, 3],
                        backgroundColor: [
                          "rgba(255, 99, 132, 0.2)",
                          "rgba(54, 162, 235, 0.2)",
                          "rgba(255, 206, 86, 0.2)",
                          "rgba(75, 192, 192, 0.2)",
                          "rgba(153, 102, 255, 0.2)",
                          "rgba(255, 159, 64, 0.2)",
                        ],
                        borderColor: [
                          "rgba(255, 99, 132, 1)",
                          "rgba(54, 162, 235, 1)",
                          "rgba(255, 206, 86, 1)",
                          "rgba(75, 192, 192, 1)",
                          "rgba(153, 102, 255, 1)",
                          "rgba(255, 159, 64, 1)",
                        ],
                        borderWidth: 1,
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card>
              <CardContent style={{ height: 450 }}>
                <Doughnut
                  data={{
                    labels: [
                      "Red",
                      "Blue",
                      "Yellow",
                      "Green",
                      "Purple",
                      "Orange",
                    ],
                    datasets: [
                      {
                        label: "# of Votes",
                        data: [12, 19, 3, 5, 2, 3],
                        backgroundColor: [
                          "rgba(255, 99, 132, 0.2)",
                          "rgba(54, 162, 235, 0.2)",
                          "rgba(255, 206, 86, 0.2)",
                          "rgba(75, 192, 192, 0.2)",
                          "rgba(153, 102, 255, 0.2)",
                          "rgba(255, 159, 64, 0.2)",
                        ],
                        borderColor: [
                          "rgba(255, 99, 132, 1)",
                          "rgba(54, 162, 235, 1)",
                          "rgba(255, 206, 86, 1)",
                          "rgba(75, 192, 192, 1)",
                          "rgba(153, 102, 255, 1)",
                          "rgba(255, 159, 64, 1)",
                        ],
                        borderWidth: 1,
                      },
                    ],
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default Dashboard;

// Commenting below code cause testing is pending. After testing above code can be removed and commented will be moved into prd

// import React from "react";
// import DashboardLayout from "../../components/layout/dashboardLayout";
// import { useTheme } from "@mui/material/styles";
// import { csTheme } from "../../theme/type";
// import { Grid, Card, CardContent } from "@mui/material";
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   LineElement,
//   Title,
//   Tooltip,
//   Legend,
//   ArcElement,
// } from "chart.js";
// import { Line, Pie, Doughnut } from "react-chartjs-2";
// import { useMaterialUIController, setUser } from "../../context";
// import routes from "../../constant/route";
// import { useNavigate } from "react-router-dom";
// import Auth from "../../components/layout/dashboardLayout/auth";

// import { piechart1 , piechart2} from "../../apiConfig/insideAuthApi";
// import { getFromStorage } from "../../utils";
// import { TokenType } from "../../type"

// const Dashboard = () => {
//   const navigate = useNavigate();
//   const csTheme: csTheme = useTheme();
//   const [controller, dispatch] = useMaterialUIController();
//   const { user } = controller;
//   const [pieData, setPieData] = React.useState<any>({
//      labels: [],
//      datasets: [],
//     });
//   const [doughnutData, setDoughnutData] = React.useState<any>({
//      labels: [],
//      datasets: [],
//     });

// const BRIGHT_COLORS = [
//   "#fdfd96", // Bright Yellow
//   "#ff6961", //  Red
//   "#00E5FF", // Cyan
//   "#ff964f", // Bright Blue
//   "#fdfd96", // Bright Yellow
//   "#77dd77", // Purple
//   "#a2bffe", // Orange
//   "#ff67ed", // Green
// ];

// const BRIGHT_BORDER_COLORS = [
//   "#ffff00", // Bright Yellow
//   "#f5342a", //  Red
//   "#00E5FF", // Cyan
//   "#fa6400", // Bright Blue
//   "#45de45", // Purple
//   "#3f78f4", // Orange
//   "#f100d5", // Green
// ];

// const MOCK_PIECHART2_DATA = [    // DATA FOR TESTING
//   { YRMON: "202404", PRIME_PER: 82, DOWN_PER: 11, SCRAP_PER: 7 },
//   { YRMON: "202405", PRIME_PER: 76, DOWN_PER: 14, SCRAP_PER: 10 },
//   { YRMON: "202406", PRIME_PER: 88, DOWN_PER: 7, SCRAP_PER: 5 },
//   { YRMON: "202407", PRIME_PER: 73, DOWN_PER: 16, SCRAP_PER: 11 },
//   { YRMON: "202408", PRIME_PER: 91, DOWN_PER: 6, SCRAP_PER: 3 },
//   { YRMON: "202409", PRIME_PER: 69, DOWN_PER: 18, SCRAP_PER: 13 },
//   { YRMON: "202410", PRIME_PER: 84, DOWN_PER: 9, SCRAP_PER: 7 },
//   { YRMON: "202411", PRIME_PER: 78, DOWN_PER: 12, SCRAP_PER: 10 },
//   { YRMON: "202412", PRIME_PER: 86, DOWN_PER: 8, SCRAP_PER: 6 },
//   { YRMON: "202501", PRIME_PER: 71, DOWN_PER: 17, SCRAP_PER: 12 },
//   { YRMON: "202502", PRIME_PER: 89, DOWN_PER: 6, SCRAP_PER: 5 },
//   { YRMON: "202503", PRIME_PER: 74, DOWN_PER: 15, SCRAP_PER: 11 },
// ];

//   React.useEffect(() => {
//     if (user) {
//       navigate(routes.dashboard);
//     }
//   }, [user]);

//   React.useEffect(() => {
//     ChartJS.register(
//       CategoryScale,
//       LinearScale,
//       PointElement,
//       LineElement,
//       ArcElement,
//       Title,
//       Tooltip,
//       Legend
//     );
//   }, []);
//   const [restricted, setRestricted] = React.useState(null);

//   React.useEffect(() => {
//   const loadPieChart = async () => {
//     console.log('1');
//     try {
//       const token: TokenType | null = await getFromStorage("token");
//       console.log('2');
//       if (!token) return;
//        console.log('3');
//       const response = await piechart1(token);
//       console.log('response',response.data);

//       const rows = response?.data || [];
//        console.log('3');
//         console.log('Frontend' ,rows);
//       setPieData({
//         labels: rows.map((r: any) => r.TYPE),

//         datasets: [
//           {
//             label: "Downgrade Count",
//             data: rows.map((r: any) => r.WEIGHT),

//       backgroundColor: BRIGHT_COLORS,
//       borderColor: BRIGHT_BORDER_COLORS,

//             borderWidth: 2,
//             hoverOffset: 8,
//           },
//         ],
//       });
//     } catch (err) {
//       console.error("Piechart1 API error", err);
//     }
//   };

// const loadDoughnutChart = async () => {
//   try {
//     console.log('loadDoughnutChart 1')
//     const token: TokenType | null = await getFromStorage("token");
//     if (!token) return;

//     const response = await piechart2(token);   // CHECK THE QUERY FOR DATA in FY 27
//     const rows = response?.data || [];

//     // const rows = MOCK_PIECHART2_DATA;      // DATA FOR TESTING
//     const labels = rows.map((r: any) => r.YRMON);

//     setDoughnutData({
//       labels,
//       datasets: [
//         {
//           label: "Prime %",
//           data: rows.map((r: any) => r.PRIME_PER),
//           backgroundColor: "rgb(0, 123, 255)",
//           borderColor: "rgb(102, 169, 240)",
//           borderWidth: 2,
//         },

//         // {                                            //// DO NOT    DELETE THE CODE
//         //   label: "Downgrade %",                      //// MIGHT BE REQUIRED AT LATER STAGE
//         //   data: rows.map((r: any) => r.DOWN_PER),
//         //   backgroundColor: "rgb(251, 255, 1)",
//         //   borderColor: "rgba(255, 206, 86, 1)",
//         //   borderWidth: 2,
//         // },
//         // {
//         //   label: "Scrap %",                            //// DO NOT    DELETE THE CODE
//         //   data: rows.map((r: any) => r.SCRAP_PER),     //// MIGHT BE REQUIRED AT LATER STAGE
//         //   backgroundColor: "rgb(241, 130, 154)",
//         //   borderColor: "rgba(255, 99, 132, 1)",
//         //   borderWidth: 2,
//         // },
//       ],
//     });
//   } catch (err) {
//     console.error("Piechart2 API error", err);
//   }
// };

//   loadPieChart();
//   loadDoughnutChart();
// }, []);
//   return (
//     <DashboardLayout>
//       <Auth isRestricted={restricted} setRestricted={setRestricted}>
//         <Grid container spacing={4} sx={{ p: 4 }}>
//           <Grid item xs={3}>
//             <Card>
//               <CardContent>
//                 <Line
//                   options={{
//                     responsive: true,
//                     plugins: {
//                       legend: {
//                         position: "top" as const,
//                       },
//                       title: {
//                         display: false,
//                         text: "Chart",
//                       },
//                     },
//                   }}
//                   data={{
//                     labels: [
//                       "January",
//                       "February",
//                       "March",
//                       "April",
//                       "May",
//                       "June",
//                       "July",
//                     ],
//                     datasets: [
//                       {
//                         label: "Dataset",   // FIRST LINE GRAPH
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => -i),
//                         borderColor: "rgb(255, 99, 132)",
//                         backgroundColor: "rgba(255, 99, 132, 0.5)",
//                       },
//                       {
//                         label: "Dataset 2",
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => i),
//                         borderColor: "rgb(53, 162, 235)",
//                         backgroundColor: "rgba(53, 162, 235, 0.5)",
//                       },
//                     ],
//                   }}
//                 />
//               </CardContent>
//             </Card>
//           </Grid>
//           <Grid item xs={3}>
//             <Card>
//               <CardContent>
//                 <Line
//                   options={{
//                     responsive: true,
//                     plugins: {
//                       legend: {
//                         position: "top" as const,
//                       },
//                       title: {
//                         display: false,
//                         text: "Chart",
//                       },
//                     },
//                   }}
//                   data={{
//                     labels: [
//                       "January",
//                       "February",
//                       "March",
//                       "April",
//                       "May",
//                       "June",
//                       "July",
//                     ],
//                     datasets: [
//                       {
//                         label: "Dataset 1",    // SECOND LINE GRAPH
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => -i),
//                         borderColor: "rgb(255, 99, 132)",
//                         backgroundColor: "rgba(255, 99, 132, 0.5)",
//                       },
//                       {
//                         label: "Dataset 2",
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => i),
//                         borderColor: "rgb(53, 162, 235)",
//                         backgroundColor: "rgba(53, 162, 235, 0.5)",
//                       },
//                     ],
//                   }}
//                 />
//               </CardContent>
//             </Card>
//           </Grid>
//           <Grid item xs={3}>
//             <Card>
//               <CardContent>
//                 <Line
//                   options={{
//                     responsive: true,
//                     plugins: {
//                       legend: {
//                         position: "top" as const,
//                       },
//                       title: {
//                         display: false,
//                         text: "Chart",
//                       },
//                     },
//                   }}
//                   data={{
//                     labels: [
//                       "January",
//                       "February",
//                       "March",
//                       "April",
//                       "May",
//                       "June",
//                       "July",
//                     ],
//                     datasets: [
//                       {
//                         label: "Dataset 1",    // THIRD LINE GRAPH
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => -i),
//                         borderColor: "rgb(255, 99, 132)",
//                         backgroundColor: "rgba(255, 99, 132, 0.5)",
//                       },
//                       {
//                         label: "Dataset 2",
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => i),
//                         borderColor: "rgb(53, 162, 235)",
//                         backgroundColor: "rgba(53, 162, 235, 0.5)",
//                       },
//                     ],
//                   }}
//                 />
//               </CardContent>
//             </Card>
//           </Grid>
//           <Grid item xs={3}>
//             <Card>
//               <CardContent>
//                 <Line
//                   options={{
//                     responsive: true,
//                     plugins: {
//                       legend: {
//                         position: "top" as const,
//                       },
//                       title: {
//                         display: false,
//                         text: "Chart",
//                       },
//                     },
//                   }}
//                   data={{
//                     labels: [
//                       "January",
//                       "February",
//                       "March",
//                       "April",
//                       "May",
//                       "June",
//                       "July",
//                     ],
//                     datasets: [
//                       {
//                         label: "Dataset 1",    // Fourth LINE GRAPH
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => -i),
//                         borderColor: "rgb(255, 99, 132)",
//                         backgroundColor: "rgba(255, 99, 132, 0.5)",
//                       },
//                       {
//                         label: "Dataset 2",
//                         data: [
//                           "January",
//                           "February",
//                           "March",
//                           "April",
//                           "May",
//                           "June",
//                           "July",
//                         ].map((x, i) => i),
//                         borderColor: "rgb(53, 162, 235)",
//                         backgroundColor: "rgba(53, 162, 235, 0.5)",
//                       },
//                     ],
//                   }}
//                 />
//               </CardContent>
//             </Card>
//           </Grid>
//           <Grid item xs={6}>
//   <Card
//   sx={{
//     borderRadius: 3,
//     boxShadow: "0px 8px 24px rgba(0,0,0,0.12)",
//     background: "linear-gradient(145deg, #ffffff, #f5f7fa)",
//   }}
// >
//     <CardContent style={{ height: 450,
//                    display: "flex",
//                   justifyContent: "center",
//                   alignItems: "center",}}>
// <Pie
//   data={pieData}
//   options={{
//     responsive: true,
//     plugins: {
//       legend: {
//         position: "bottom",
//         labels: {
//           font: { size: 14, weight: "bold" },
//           color: "#333",
//         },
//       },
//       title: {
//         display: true,
//         // text: "Downgrade Distribution",         //// ASK SUMAN Ma'am The Title
//         font: { size: 18, weight: "bold" },
//         color: "#111",
//       },
//     },
//   }}
// />
//     </CardContent>
//   </Card>
// </Grid>

// <Grid item xs={6}>
//   <Card
//   sx={{
//     borderRadius: 3,
//     boxShadow: "0px 8px 24px rgba(0,0,0,0.12)",
//     background: "linear-gradient(145deg, #ffffff, #f5f7fa)",
//   }}
// >
//     <CardContent style={{ height: 450,
//                    display: "flex",
//                   justifyContent: "center",
//                   alignItems: "center", }}>
// <Doughnut
//   data={doughnutData}
//   options={{
//     responsive: true,
//     cutout: "65%",
//     plugins: {
//       legend: {
//         position: "bottom",
//         labels: {
//           font: { size: 10, weight: "bold" },
//           color: "#333",
//         },
//       },
//       tooltip: {
//         callbacks: {
//           label: (ctx) =>
//             `${ctx.dataset.label}: ${ctx.raw}%`,
//         },
//       },
//       title: {
//         display: true,
//         // text: "Yield Distribution (Month-wise)",  //// ASK SUMAN Ma'am The Title
//         font: { size: 18, weight: "bold" },
//         color: "#111",
//       },
//     },
//   }}
// />
//     </CardContent>
//   </Card>
// </Grid>
//         </Grid>
//       </Auth>
//     </DashboardLayout>
//   );
// };

// export default Dashboard;
