export interface InputChangeType {
    key1: input,
    key2: input,
    key3: input,
    key4: input,
    key5: input,
    key6: input,
    key7: input,
    key8: input,
    key9: input,
    key10: input,
    key11: input,
}
interface input {
    config: {
        type: string,
        label?: string,
        sideLabel?: string,
        eIcon?: JSX.Element,
        sIcon?: JSX.Element,
        autoFocus?: boolean,
        disabled?: boolean,
        minVal?: string | number,
        maxVal?: string | number
    },
    value: string,
    data?: Array<SelectType>
    onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement>
}
export interface InputDownType {
    key1: string,
    key2: string,
    key3: string,
    key4: string,
    key5: string,
    key6: string,
    key7: string,
    key8: string,
    key9: string,
}

export interface TableType {
    EGP_CD_EPA: string;
    CIR_ID_COIL: string;
    EIC_ID_COIL: string;
}

export interface PopupObj {
    popUp: boolean,
    id: string | number,
}

export interface option {
    label: string,
    value: string,
    id: number
}

export interface popuptype {
    isPopUp: boolean,
    data: string
}


export interface FormType {
    key: string,
    data: input
}

export interface SelectType {
    value: string;
    label: string;
    id: number
}

export interface TableType {
    EGP_CD_EPA: string;
    ENC_ID_ORDER: string;
    ENC_CD_END_CUST: string;
    ENC_ORDER_TYPE: string;
    ENC_ST_ORDER: string;
}