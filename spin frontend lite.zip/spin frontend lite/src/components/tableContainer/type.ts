export interface PropType {
    title?: string,
    headerContainer?: React.ReactNode,
    children?: React.ReactNode
} 