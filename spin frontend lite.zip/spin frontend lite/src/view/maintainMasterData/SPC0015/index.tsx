import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { useMaterialUIController } from "../../../context";
import { DateFormat } from "../../../utils";
import { GetAuthorization } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
  iconButtonClasses,
} from "@mui/material";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import DeleteIcon from "@mui/icons-material/Delete";
import CreateIcon from "@mui/icons-material/Create";
import {
  SPC0015GetDataApi,
  // SPC0015 GetPlantData,
  GetPlantDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import { ColumnDefinition } from "tabulator-tables";
import Auth from "../../../components/layout/dashboardLayout/auth";

const formatDate = (date: any) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const M_SPC0015 = () => {
  const csTheme: csTheme = useTheme();
  //user id
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;
  //
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [isEditable, setIsEditable] = React.useState<boolean>(false);

  const [value, setValue] = React.useState<number>(0);

  // Tab A -  Total Activity
  const columnsTabA: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
    },
    {
      title: "Plant",
      field: "PLANT", // Changed from SSM_CD_EPA
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATED_BY = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Code",
      field: "SUBRANGE_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATED_BY = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Description",
      field: "SUBRANGE_DESC", // Changed from SSM_SUBRANGE_DESC
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATED_BY = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : false,
      validator: "string",
      editorParams: {
        elementAttributes: {
          maxlength: "1",
        },
      },
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATED_BY = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Created Date",
      field: "CREATE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },

    // {
    //   title: "Created By",
    //   field: "CREATED_BY",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "center",
    //   editor: false,

    // },
    {
      title: "Updated Date",
      field: "UPDATE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },
    {
      title: "Updated By",
      field: "UPDATED_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
    },
  ];

  // Tab B - Pakaging Activity
  const columnsTabB: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Code",
      field: "SUBRANGE_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Description",
      field: "SUBRANGE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    // {
    //   title: "Min Width",
    //   field: "MIN_WIDTH",  // Changed from SPM_SEC2_MIN
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "right",
    //   editor: isEditable ? "input" : false,
    //   validator: "numeric",
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.getData();
    //     data.UPDATE_USER = user;
    //     data.UPDATE_DT = formatDate(new Date());
    //     row.update(data);
    //   },
    // },
    // {
    //   title: "Max Width",
    //   field: "MAX_WIDTH",  // Changed from SPM_SEC2_MAX
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "right",
    //   editor: isEditable ? "input" : false,
    //   validator: "numeric",
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.getData();
    //     data.UPDATE_USER = user;
    //     data.UPDATE_DT = formatDate(new Date());
    //     row.update(data);
    //   },
    // },
    {
      title: "Status",
      field: "STATUS", // Changed from SPM_STATUS
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      editorParams: {
        elementAttributes: {
          maxlength: "1",
        },
      },
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Created User",
      field: "CREATE_USER", // Changed from SPM_CRT_USER
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
    },
    {
      title: "Created Date",
      field: "CREATE_DT", // Changed from SPM_CRT_DT
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },
    {
      title: "Updated User",
      field: "UPDATE_USER", // Changed from SPM_UPD_USER
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
    },
    {
      title: "Updated Date",
      field: "UPDATE_DT", // Changed from SPM_UPD_DT
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },
  ];

  // Tab C - Processing Activity
  const columnsTabC: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
    },
    {
      title: "Plant",
      field: "PLANT", // Changed from ERT_CD_EPA
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Process Code",
      field: "PROC_CD", // Changed from ERT_PROC_CD
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subprocess Code",
      field: "SUBPROC_CD", // Changed from ERT_SUBPROC_CD
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Code",
      field: "SUBRANGE_CD", // Changed from ERT_SUBRAN_CD
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Subrange Description",
      field: "SUBRANGE_DESC", // Changed from ERT_SUBRAN_DESC
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "left",
      editor: isEditable ? "input" : false,
      validator: "string",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Width Min",
      field: "WIDTH_MIN", // Changed from ERT_SEC2_MIN
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: isEditable ? "input" : false,
      validator: "numeric",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Width Max",
      field: "WIDTH_MAX", // Changed from ERT_SEC2_MAX
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      editor: isEditable ? "input" : false,
      validator: "numeric",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    {
      title: "Status",
      field: "STATUS", // Changed from ERT_STATUS
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : false,
      validator: "string",
      editorParams: {
        elementAttributes: {
          maxlength: "1",
        },
      },
      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.UPDATE_USER = user;
        data.UPDATE_DT = formatDate(new Date());
        row.update(data);
      },
    },
    // {
    //   title: "Created User",
    //   field: "CREATE_USER",  // Changed from ERT_CRT_USER
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "center",
    //   editor: false,
    // },
    {
      title: "Created Date",
      field: "CREATE_DT", // Changed from ERT_CRT_DT
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },
    {
      title: "Updated User",
      field: "UPDATE_USER", // Changed from ERT_UPD_USER
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
    },
    {
      title: "Updated Date",
      field: "UPDATE_DT", // Changed from ERT_UPD_DT
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: false,
      formatter: function (cell: any) {
        const date = cell.getValue();
        if (date) {
          return formatDate(new Date(date));
        }
        return "";
      },
    },
  ];

  const getActiveColumns = () => {
    switch (value) {
      case 0:
        return columnsTabA;
      case 1:
        return columnsTabB;
      case 2:
        return columnsTabC;
      default:
        return columnsTabA;
    }
  };

  // Handle tab changes
  // const handleChange = (event: React.SyntheticEvent, newValue: number) => {
  //     setValue(newValue);
  //     setSelectedCode("");
  //     // fetchEpaData(); //
  //   };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    // setSelectedCode(""); // Reset plant selection
    setTableData([]); // Clear table data when changing tabs

    if (selectedCode) {
      fetchData(newValue);
    }
  };

  // Initial data load
  React.useEffect(() => {
    fetchEpaData();
  }, []);

  // Table initialization useEffect
  // React.useEffect(() => {
  //   if (tableData?.length > 0) {
  //     let varTable = new Tabulator("#table", {
  //       data: tableData,
  //       columns: getActiveColumns(), // Using our defined function
  //       height: 600,
  //       layout: "fitDataFill",
  //     });

  //     varTable.on("rowSelected", function (row) {
  //       const data = row.getData();
  //       data.editable = !data.editable;
  //       if (data.editable) {
  //         // Update based on active tab
  //         switch(value) {
  //           case 0: // Tab A- Subrange Master
  //             data.SSM_UPD_BY = user;
  //             data.SSM_UPD_DT = formatDate(new Date());
  //             break;
  //           case 1: // Tab B - Package Subrange
  //             data.SPM_UPD_USER = user;
  //             data.SPM_UPD_DT = formatDate(new Date());
  //             break;
  //           case 2: // Tab C - Process Subrange
  //             data.ERT_UPD_USER = user;
  //             data.ERT_UPD_DT = formatDate(new Date());
  //             break;
  //         }
  //         row.update(data);
  //       }
  //     });
  //     setTable(varTable);
  //   } else {
  //     setTable(null);
  //   }
  // }, [tableData, isEditable]);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      // Destroy existing table if it exists
      if (table) {
        table.destroy();
      }

      let varTable = new Tabulator("#table", {
        data: tableData,
        columns: getActiveColumns(),
        height: 380,
        layout: "fitDataFill",
        pagination: true,
        paginationSize: 10,
        paginationSizeSelector: [10, 20, 40, 60],
        paginationCounter: "rows",
      });

      varTable.on("rowSelected", function (row) {
        const data = row.getData();
        data.editable = !data.editable;
        if (data.editable) {
          switch (value) {
            case 0:
              data.SSM_UPD_BY = user;
              data.SSM_UPD_DT = formatDate(new Date());
              break;
            case 1:
              data.SPM_UPD_USER = user;
              data.SPM_UPD_DT = formatDate(new Date());
              break;
            case 2:
              data.ERT_UPD_USER = user;
              data.ERT_UPD_DT = formatDate(new Date());
              break;
          }
          row.update(data);
        }
      });
      setTable(varTable);
    } else {
      if (table) {
        table.destroy();
        setTable(null);
      }
    }
  }, [tableData]);

  // Fetch EPA Data (Plant codes)
  //   const fetchEpaData = () => {
  //     setLoading(true);
  //     GetAuthorization().then((token: TokenType) => {
  //       GetPlantDataApi(token)
  //         .then((res) => {
  //           if (res.statusText !== "" && res.statusText !== "OK") {
  //             alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //           } else if (res?.data) {
  //             const varData: Array<SelectType> = [];
  //             res.data?.map((x: any, i: number) => (
  //               varData.push({
  //                 value: x?.EPL_CD_EPA?.toString(),
  //                 label: x?.EPL_CD_EPA_DESC?.toString(),
  //                 id: i,
  //               })
  //             ));
  //             setPlantCodeData(varData);
  //             // Removed the automatic selection
  //           }
  //         })
  //         .catch((e) => {
  //           alertify.error(
  //             e?.error?.message ? e.error.message : "Something Went Wrong!"
  //           );
  //         })
  //         .finally(() => {
  //           setLoading(false);
  //         });
  //     });
  // };

  const fetchEpaData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) =>
              varData.push({
                value: x?.EPL_CD_EPA?.toString(),
                label: x?.EPL_CD_EPA_DESC?.toString(),
                id: i,
              })
            );
            setPlantCodeData(varData);
            setSelectedCode(varData[0]?.value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went Wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // Fetch table data based on selected tab
  const fetchData = (tabValue: number) => {
    if (!selectedCode) {
      alertify.error("Please select Plant!");
      return;
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      // Fix an API endpoint for SPC0015 TASK Stage 2
      SPC0015GetDataApi(token, {
        tabIndex: tabValue,
        code: selectedCode?.split(" - ")[0],
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length === 0) {
              alertify.error("No Data Found!");
              return;
            }
            // Handle data based on tab
            switch (tabValue) {
              case 0:
                setTableData(res.data?.subrangeMaster); // V_SUBRNG_MAST data
                break;
              case 1:
                setTableData(res.data?.packageSubrange); // V_SUBRNG_PKG_MAST data
                break;
              case 2:
                setTableData(res.data?.processSubrange); // V_SUBRNG_PROC_MAST data
                break;
            }
          }
        })
        .catch((e: any) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // Download Excel function - updated for 3 tabs
  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }

    let fileName = "";
    switch (value) {
      case 0:
        fileName = "SPC0015_Total_Activity.xlsx";
        break;
      case 1:
        fileName = "SPC0015_Package_Activity.xlsx";
        break;
      case 2:
        fileName = "SPC0015_Process_Activity.xlsx";
        break;
    }

    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  // Delete function - remains similar but with updated messaging
  const Delete = () => {
    if (tableData.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = table.getSelectedRows();
    if (selectedRows.length > 0) {
      selectedRows.forEach((row: any) => {
        row.delete();
      });
      alertify.success(`${selectedRows.length} rows deleted`);
    } else {
      alertify.error("No row selected");
    }
  };

  // Edit function - remains the same
  const Edit = () => {
    setIsEditable(true);
    alertify.success("Edit mode enabled. You can now edit the table.");
  };

  // Add function - updated for different tabs
  const Add = () => {
    setIsEditable(true);
    const date = formatDate(new Date());
    let arr = [...tableData];

    let newRow = {};
    switch (value) {
      case 0: // Tab A (Total Activity)
        newRow = {
          SSM_CD_EPA: "",
          SSM_SUBRANGE_CD: "",
          SSM_SUBRANGE_DESC: "",
          SSM_CD_STATUS: "",
          SSM_CRT_BY: user,
          SSM_CRT_DT: date,
          SSM_UPD_BY: "",
          SSM_UPD_DT: "",
        };
        break;

      case 1: // Tab B (Packaging Activity)
        newRow = {
          SPM_CD_EPA: "",
          SPM_PKG_SUBRAN_CD: "",
          SPM_PKG_SUBRAN_DESC: "",
          // SPM_SEC2_MIN: "",
          // SPM_SEC2_MAX: "",
          SPM_STATUS: "",
          SPM_CRT_USER: user,
          SPM_CRT_DT: date,
          SPM_UPD_USER: "",
          SPM_UPD_DT: "",
        };
        break;

      case 2: // Tab C (Processsing Activity)
        newRow = {
          ERT_CD_EPA: "",
          ERT_PROC_CD: "",
          ERT_SUBPROC_CD: "",
          ERT_SUBRAN_CD: "",
          ERT_SUBRAN_DESC: "",
          ERT_SEC2_MIN: "",
          ERT_SEC2_MAX: "",
          ERT_STATUS: "",
          ERT_CRT_USER: user,
          ERT_CRT_DT: date,
          ERT_UPD_USER: "",
          ERT_UPD_DT: "",
        };
        break;
    }

    arr.push(newRow);
    setTableData(arr);
  };

  // Save function - remains the same
  const Save = () => {
    setIsEditable(false);
    alertify.success("Saved successfully!");
  };

  // Clear All function - updated to only clear relevant states
  const handleClearAll = () => {
    setSelectedCode("");
    setTableData([]);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={10}>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <SelectInput
                        label="Plant*"
                        data={plantCodeData}
                        id={"id"}
                        value={selectedCode}
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedCode(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <ButtonElement onClick={() => fetchData(value)}>
                        Search
                      </ButtonElement>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <>
                  <Tooltip title="Download">
                    <IconButton onClick={downloadExcel}>
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Total Activity" />
                    <Tab label="Packaging Activity" />
                    <Tab label="Processing Activity" />
                  </Tabs>
                </Box>
                {value === 0 && tableData?.length > 0 && <div id="table"></div>}
                {value === 1 && tableData?.length > 0 && <div id="table"></div>}
                {value === 2 && tableData?.length > 0 && <div id="table"></div>}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default M_SPC0015;
