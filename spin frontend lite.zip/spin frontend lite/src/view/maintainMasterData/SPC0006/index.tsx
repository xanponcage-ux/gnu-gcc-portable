import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0006GetDataApi,
  SPC0006GetEpaCodeApi,
  SPC0006ProcedureCall,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import Page from "tabulator-tables";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ClearIcon from "@mui/icons-material/Clear";
import AddIcon from "@mui/icons-material/Add";
import { useMaterialUIController } from "../../../context";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import { Console } from "console";
import Auth from "../../../components/layout/dashboardLayout/auth";

// Date - 30.07.2025
// Removed add, insert, save button - no longer needed
// Screen converted to display screen

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  // const [table, setTable] = React.useState<any>(null);

  const [tableSc, setTableSc] = React.useState<any>(null);
  const [tableTdc, setTableTdc] = React.useState<any>(null);

  const [tableDataSc, setTableDataSc] = React.useState<any>([]);
  const [tableDataTdc, setTableDataTdc] = React.useState<any>([]);

  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedLine, setSelectedLine] = React.useState<string>("");
  const [selectedacttdc, setselectedacttdc] = React.useState<string>("");
  const [selectedActtdc, setSelectedActtdc] = React.useState<string>("");
  const [selectedTdcsc, setSelectedTdcsc] = React.useState<string>("");
  const [selectedendTDC, setSelectedendTDC] = React.useState<string>("");
  const [selectedEpa, setSelectedEpa] = React.useState<string>("");
  const [selQltyCode, setSelQltyCode] = React.useState<string>("");
  const [plantEpaData, setPlantEpaData] = React.useState<Array<SelectType>>([]);
  const [ActtdcData, setActtdcData] = React.useState<Array<SelectType>>([]);
  const [tdcMainData, setTdcMainData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);
  const [secondsTdcData, setsecondsTdcData] = React.useState<Array<SelectType>>(
    []
  );
  const [isEditable, setIsEditable] = React.useState(false);
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;
  const formatDate = (date: any) => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const columnseconds: Array<CulmnType> = [
    // {
    //   title: "",
    //   // formatter: "rowSelection",
    //   // titleFormatter: "rowSelection",
    //   hozAlign: "center",
    //   download: false,
    //   headerSort: false,
    // },
    {
      title: "Plant",
      field: "CD_EPA",
      headerFilter: "input",
      frozen: true,
      width: 100,
      headerFilterPlaceholder: "search...",
      // editor: isEditable ? "input" : true,
      // //validator: "string",
      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "4",
      //   },
      // },
      // cellEdited: (cell: any) => {
      //   const value = cell.getValue().toUpperCase();
      //   cell.setValue(value);
      //   let row = cell.getRow();
      // },
    },
    {
      title: "Prime TDC",
      field: "TDC_PRIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // editor: isEditable ? "input" : true,
      // //validator: "string",
      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "5",
      //   },
      // },
      // cellEdited: (cell: any) => {
      //   const value = cell.getValue().toUpperCase();
      //   cell.setValue(value);
      //   let row = cell.getRow();
      // },
    },
    {
      title: "Downgrade TDC",
      field: "TDC_DOWNGRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // editor: isEditable ? "input" : true,

      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "5",
      //   },
      // },
      // cellEdited: (cell: any) => {
      //   const value = cell.getValue().toUpperCase();
      //   cell.setValue(value);
      //   let row = cell.getRow();
      // },
    },
    // {
    //   title: "Thickness From",
    //   field: "SEC1_FROM",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Thickness To",
    //   field: "SEC1_TO",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Width From",
    //   field: "SEC2_FROM",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Width To",
    //   field: "SEC2_TO",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Sheet Ind",
    //   field: "SHEET_IND",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "string",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "1",
    //     },
    //   },
    //   cellEdited: (cell: any) => {
    //     const value = cell.getValue().toUpperCase();
    //     cell.setValue(value);
    //     let row = cell.getRow();
    //   },
    // },
    // {
    //   title: "Material No.",
    //   field: "NO_MATNR",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "18",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Min Weight",
    //   field: "WT_MIN",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Max Weight",
    //   field: "WT_MAX",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,
    //   validator: "integer",
    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "8",
    //     },
    //   },
    //   cellEdited: function (cell: any) {
    //     let row = cell.getRow();
    //     const data = row.get;
    //   },
    // },
    // {
    //   title: "Quality Prime",
    //   field: "QLTY_PRIME",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,

    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "6",
    //     },
    //   },
    //   cellEdited: (cell: any) => {
    //     const value = cell.getValue().toUpperCase();
    //     cell.setValue(value);
    //     let row = cell.getRow();
    //   },
    // },
    // {
    //   title: "Quality Downgrade",
    //   field: "QLTY_DOWNGRADE",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   editor: isEditable ? "input" : true,

    //   editorParams: {
    //     elementAttributes: {
    //       maxlength: "6",
    //     },
    //   },
    //   cellEdited: (cell: any) => {
    //     const value = cell.getValue().toUpperCase();
    //     cell.setValue(value);
    //     let row = cell.getRow();
    //   },
    // },
    {
      title: "Created by",
      field: "S_CRT_USR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Created on",
      field: "S_CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Update by",
      field: "S_UPD_USR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Update on",
      field: "S_UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Flag",
      field: "ls_flag",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
  ];
  const columntdcmap: Array<CulmnType> = [
    // {
    //   title: "",
    //   // formatter: "rowSelection",
    //   // titleFormatter: "rowSelection",
    //   hozAlign: "center",
    //   download: false,
    //   headerSort: false,
    // },
    {
      title: "Actual TDC",
      field: "ACT_TDC",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
      // editor: isEditable ? "input" : true,
      // validator: "string",
      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "6",
      //   },
      // },

      // cellEdited: function (cell: any) {
      //   const value = cell.getValue().toUpperCase();
      //   cell.setValue(value);
      //   let row = cell.getRow();
      //   const data = row.getData();
      //   data.CRT_ID = user;
      //   data.CRT_DATE = formatDate(new Date());
      //   data.UPD_ID = user;
      //   data.UPD_DT = formatDate(new Date());
      //   row.update(data);
      //   return value;
      // },
    },
    {
      title: "END TDC",
      field: "END_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // editor: isEditable ? "input" : true,
      // validator: "string",
      // editorParams: {
      //   elementAttributes: {
      //     maxlength: "6",
      //   },
      // },

      // cellEdited: function (cell: any) {
      //   const value = cell.getValue().toUpperCase();
      //   cell.setValue(value);
      //   let row = cell.getRow();
      //   const data = row.getData();
      //   data.CRT_ID = user;
      //   data.CRT_DATE = formatDate(new Date());
      //   data.UPD_ID = user;
      //   data.UPD_DT = formatDate(new Date());
      //   row.update(data);
      //   return value;
      // },
    },
    {
      title: "Created By",
      field: "CRT_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Created On",
      field: "CRT_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Update by",
      field: "UPD_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Update on",
      field: "UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Status",
      field: "CD_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Flag",
      field: "ls_flag",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
  ];
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    fetchEpaData();
    setSelectedEpa("");
    setSelectedTdcsc("");
    setSelectedActtdc("");
    setselectedacttdc("");
    setSelectedendTDC("");
    //fetchData();
  };

  React.useEffect(() => {
    //setLoading(true);
    alertify.error("Click on Search to View Table");
    fetchEpaData();
    fetchData();
    setIsEditable(isEditable);
    //fetchSecondsTdcData();
  }, []);

  React.useEffect(() => {
    if (tableDataSc?.length > 0) {
      setTableSc(
        new Tabulator("#table", {
          data: tableDataSc,
          columns: columnseconds,
          height: 380,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTableSc(null);
    }
  }, [tableDataSc]);

  React.useEffect(() => {
    if (tableDataTdc?.length > 0) {
      setTableTdc(
        new Tabulator("#table", {
          data: tableDataTdc,
          columns: columntdcmap,
          height: 380,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTableTdc(null);
    }
  }, [tableDataTdc]);

  const Edit = (process: string) => {
    setIsEditable(true);
    alertify.success("Edit mode enabled. You can now edit the table.");
  };
  let isInsert = false;

  const AddSc = () => {
    setIsEditable(true);
    const date = formatDate(new Date());
    let arr = [...tableDataSc];

    arr.push({
      CD_EPA: "",
      QLTY_PRIME: "",
      QLTY_DOWNGRADE: "",
      TDC_PRIME: "",
      TDC_DOWNGRADE: "",
      SEC1_FROM: "",
      SEC1_TO: "",
      SEC2_FROM: "",
      SEC2_TO: "",
      SHEET_IND: "",
      NO_MATNR: "",
      WT_MIN: "",
      WT_MAX: "",
      S_UPD_DT: date,
      STATUS: "",
      S_UPD_USR: user,
      ls_flag: "I",
    });

    setTableDataSc(arr);
  };

  const Addtdc = (process: string) => {
    setIsEditable(true);
    const date = formatDate(new Date());
    let arr = [...tableDataTdc];

    arr.push({
      ACT_TDC: "",
      END_TDC: "",
      CRT_ID: user,
      CRT_DATE: date,
      UPD_ID: "",
      UPD_DT: "",
      CD_STATUS: "",
      ls_flag: "I",
    });

    setTableDataTdc(arr);
  };

  const SaveSC = () => {
    setIsEditable(true);
    if (tableDataSc.length === 0) {
      alertify.error("No data to inserted");
      return;
    }
    const selectedRows = tableSc.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableSc.getSelectedRows()?.map((row: any) => {
      let varData: any = {};
      varData["ls_cd_epa"] = row._row.data.CD_EPA;
      varData["ls_tdc_downgrade"] = row._row.data.TDC_DOWNGRADE;
      varData["ls_tdc_prime"] = row._row.data.TDC_PRIME;
      varData["ls_sec1_from"] = row._row.data.SEC1_FROM;
      varData["ls_sec1_to"] = row._row.data.SEC1_TO;
      varData["ls_sec2_from"] = row._row.data.SEC2_FROM;
      varData["ls_sec2_to"] = row._row.data.SEC2_TO;
      varData["ls_sheet_ind"] = row._row.data.SHEET_IND;
      varData["ls_no_matnr"] = row._row.data.NO_MATNR;
      varData["ls_wt_min"] = row._row.data.WT_MIN;
      varData["ls_wt_max"] = row._row.data.WT_MAX;
      varData["ls_qlty_prime"] = row._row.data.QLTY_PRIME;
      varData["ls_qlty_downgrade"] = row._row.data.QLTY_DOWNGRADE;
      varData["ls_user"] = user;
      varData["ls_flag"] = row._row.data.ls_flag ? row._row.data.ls_flag : "I";
      varData["lb_status"] = "SECONDS";

      return varData;
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006ProcedureCall(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const numRowsDeleted = selectedRows.length;
            alertify.success(
              `${numRowsDeleted} ${
                numRowsDeleted === 1 ? "row" : "rows"
              } inserted successfully!`
            );
            fetchData(value);
          } else if (selectedData[0].ls_flag === "I") {
            alertify.success("Insert data successfully!");
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const Save = (process: string) => {
    setIsEditable(true);

    if (tableDataTdc.length === 0) {
      alertify.error("No data to inserted");
      return;
    }
    const selectedRows = tableTdc.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableTdc.getSelectedRows()?.map((row: any) => {
      let varData: any = {};
      varData["ls_Act_tdc"] = row._row.data.ACT_TDC;
      varData["ls_end_tdc"] = row._row.data.END_TDC;
      varData["ls_flag"] = row._row.data.ls_flag ? row._row.data.ls_flag : "I";
      varData["lb_status"] = "TDCMAP";
      varData["ls_user"] = user;

      return varData;
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006ProcedureCall(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const numRowsDeleted = selectedRows.length;
            alertify.success(
              `${numRowsDeleted} ${
                numRowsDeleted === 1 ? "row" : "rows"
              } inserted successfully!`
            );
            fetchData(value);
          } else if (selectedData[0].ls_flag === "I") {
            alertify.success("Insert data successfully!");
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const DeleteSc = () => {
    if (tableDataSc.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = tableSc.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableSc.getSelectedRows()?.map((row: any) => {
      if (value === 0) {
        let varData: any = {};
        varData["ls_cd_epa"] = row._row.data.CD_EPA;
        varData["ls_tdc_downgrade"] = row._row.data.TDC_DOWNGRADE;
        varData["ls_tdc_prime"] = row._row.data.TDC_PRIME;
        varData["ls_sec1_from"] = row._row.data.SEC1_FROM;
        varData["ls_sec1_to"] = row._row.data.SEC1_TO;
        varData["ls_sec2_from"] = row._row.data.SEC2_FROM;
        varData["ls_sec2_to"] = row._row.data.SEC2_TO;
        varData["ls_sheet_ind"] = row._row.data.SHEET_IND;
        varData["ls_no_matnr"] = row._row.data.NO_MATNR;
        varData["ls_wt_min"] = row._row.data.WT_MIN;
        varData["ls_wt_max"] = row._row.data.WT_MAX;
        varData["ls_qlty_prime"] = row._row.data.QLTY_PRIME;
        varData["ls_qlty_downgrade"] = row._row.data.QLTY_DOWNGRADE;
        varData["ls_user"] = user;
        varData["ls_flag"] = "D";
        varData["lb_status"] = "SECONDS";
        return varData;
      }
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006ProcedureCall(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const numRowsDeleted = selectedRows.length;
            alertify.success(
              `Deleted ${numRowsDeleted} ${
                numRowsDeleted === 1 ? "row" : "rows"
              } successfully!`
            );
            fetchData(value);
          } else if (selectedData[0].ls_flag === "I") {
            alertify.success("Insert data successfully!");
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const DeleteTdc = (process: any) => {
    if (tableDataTdc.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = tableTdc.getSelectedRows();
    if (selectedRows?.length === 0) {
      alertify.error("No row selected");
      return;
    }
    const selectedData = tableTdc.getSelectedRows()?.map((row: any) => {
      if (value === 1) {
        let varData2: any = {};
        varData2["ls_Act_tdc"] = row._row.data.ACT_TDC;
        varData2["ls_end_tdc"] = row._row.data.END_TDC;
        varData2["ls_flag"] = "D";
        varData2["lb_status"] = "TDCMAP";
        varData2["ls_user"] = user;
        return varData2;
      }
    });
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006ProcedureCall(token, selectedData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const numRowsDeleted = selectedRows.length;
            alertify.success(
              `Deleted ${numRowsDeleted} ${
                numRowsDeleted === 1 ? "row" : "rows"
              } successfully!`
            );
            fetchData(value);
          } else if (selectedData[0].ls_flag === "I") {
            alertify.success("Insert data successfully!");
            fetchData(value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const downloadExcelSc = () => {
    if (tableDataSc.length === 0) {
      alertify.error("No Data exists in the table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0006_" + "SECONDS_TDC" + ".xlsx";
    tableSc.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const downloadExcelTdc = () => {
    if (tableDataTdc.length === 0) {
      alertify.error("No Data exists in the table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0006_" + "TDC_MAP" + ".xlsx";
    tableTdc.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const fetchEpaData = (data?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006GetEpaCodeApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.EpaPlant?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantEpaData(varData);
            setSelectedEpa(varData[0].value);
            const varData1: Array<SelectType> = [];
            res.data?.Acttdc?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.TDM_ACT_TDC?.toString(),
                  label: x.TDM_ACT_TDC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setActtdcData(varData1);
            //setselectedacttdc(varData1[0].value);
            const varData3: Array<SelectType> = [];
            res.data?.TdcSec?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData3.push({
                  value: x.ESP_TDC_DOWNGRADE?.toString(),
                  label: x.ESP_TDC_DOWNGRADE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setsecondsTdcData(varData3);
            //setsecondsTdcData(varData3[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data?: any) => {
    let varData = {};
    if (data === 0) {
      // if(!(selectedEpa?.length > 0)) {
      //   alertify.error("Please select Plant!");
      //   return;
      // }
      varData = {
        data: data,
        epa: selectedEpa,
        tdcsc: selectedTdcsc?.toUpperCase(),
      };
    }
    if (data === 1) {
      // if(!(selectedendTDC?.length > 0)) {
      //   alertify.error("Please select Actual TDC!");
      //   return;
      // }
      varData = { data: data, acttdc: selectedacttdc, endTDC: selectedendTDC };
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0006GetDataApi(token, varData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0) {
              setTableDataSc(res.data.SecondsTb);
            } else if (data === 1) {
              setTableDataTdc(res.data.TdcMapTb);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleClearAll = () => {
    setSelectedEpa("");
    setSelectedTdcsc("");
    setSelectedActtdc("");
    setselectedacttdc("");
    setTableDataSc([]);
    setTableDataTdc([]);
    setSelectedendTDC("");
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                {value === 0 ? (
                  <>
                    <Grid item xs={3}>
                      <SelectInput
                        id={"id"}
                        data={plantEpaData}
                        value={selectedEpa}
                        label="Plant*"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedEpa(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <SelectInput
                        id={"id"}
                        data={secondsTdcData}
                        value={selectedTdcsc}
                        label="Downgrade TDC"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedTdcsc(e);
                        }}
                      />
                    </Grid>
                  </>
                ) : (
                  value === 1 && (
                    <>
                      <Grid item xs={3}>
                        <SelectInput
                          id={"id"}
                          data={ActtdcData}
                          value={selectedacttdc}
                          label="Actual TDC"
                          size={"small"}
                          onChange={(e: string) => {
                            setselectedacttdc(e);
                          }}
                        />
                      </Grid>
                      <Grid item xs={3}>
                        <Input
                          id={"id"}
                          value={selectedendTDC}
                          label="End TDC"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedendTDC(e);
                          }}
                        />
                      </Grid>
                    </>
                  )
                )}
                <Grid item xs={2}>
                  <ButtonElement onClick={() => fetchData(value)}>
                    Search
                  </ButtonElement>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <>
                  {/* <Tooltip title="Add">
                    <IconButton
                      onClick={() => {
                        value === 0 ? AddSc() : Addtdc("Add");
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <LibraryAddIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Save">
                    <IconButton
                      onClick={() => {
                        value === 0 ? SaveSC() : Save("insert");
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <SaveIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton
                      onClick={() => {
                        value === 0 ? DeleteSc() : DeleteTdc("deleteTdc");
                      }}
                      disabled={restricted !== "RL_RW"}
                    >
                      <DeleteIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip> */}
                  <Tooltip title="Download">
                    <IconButton
                      onClick={() => {
                        value === 0 ? downloadExcelSc() : downloadExcelTdc();
                      }}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Downgrade TDC" />
                    <Tab label="Diverted TDC" />
                  </Tabs>
                </Box>
                {value === 0 && tableDataSc?.length > 0 && (
                  <div id="table"></div>
                )}
                {value === 1 && tableDataTdc?.length > 0 && (
                  <div id="table"></div>
                )}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};
export default P_B1COS002;
