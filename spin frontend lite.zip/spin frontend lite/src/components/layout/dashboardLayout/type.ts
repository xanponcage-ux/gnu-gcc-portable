import { ReactElement, ReactNode } from "react"

export interface NavbarProps {
    children: JSX.Element
}

export interface RouteProps {
    path: string,
    element?: JSX.Element,
    label?: string,
    icon?: React.ReactNode,
}

interface RoutesProps {
    path: string,
    element?: JSX.Element,
    label?: string,
    icon?: React.ReactNode,
    children?: Array<RouteProps>,
}
export interface RouteNestedProps {
    path?: string,
    element?: JSX.Element,
    label?: string,
    icon?: React.ReactNode,
    children?: Array<RoutesProps> | Array<RouteProps>,
}

export interface DashboardProps {
    children: JSX.Element
}

