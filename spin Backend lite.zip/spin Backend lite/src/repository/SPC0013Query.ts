import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";

export const getCastDetails = async (data: any) => {
  try {
    let sql = `SELECT tca_cast_no, tca_lab_test_cd, tca_test_para, tca_test_para_val
                FROM v_tc_cast_test
                WHERE tca_cast_no = '${data?.castNo}'`;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getCoilDetails = async (data: any) => {
  try {
    let sql = `SELECT tco_prod_no, tco_cast_no, tco_lab_test_cd, tco_test_para,
                 tco_test_para_val, tco_test_para_rem
                 FROM v_tc_coil_test
                 WHERE tco_prod_no = '${data?.coilId}' `;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getFittingDetails = async (data: any) => {
  try {
    let sql = `SELECT TSL_TDC_NO, TSL_CD_TEST, TSL_TEST_PARA, NVL(TSL_PARA_MIN,0) TSL_PARA_MIN, NVL(TSL_PARA_MAX,999.999) TSL_PARA_MAX
                ,(SELECT F_PARA_VAL_ACUAL ('${data?.castNo}','${data?.coilNo}', A.TSL_CD_TEST, A.TSL_TEST_PARA) FROM DUAL ) PARA_VAL 
                FROM V_TDC_SPEC_LIMIT A
                WHERE TSL_TDC_NO='${data?.fittingTdc}'
                ORDER BY DECODE(TSL_CD_TEST,'LSA',1,2)`;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};
