import json
import os
import time
import uuid
from typing import Any, Dict, Iterable

import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI(title="CodeGenie OpenAI-Compatible Bridge")

CODEGENIE_URL = os.getenv(
    "CODEGENIE_URL",
    "https://asia-south1-tsl-generative-ai.cloudfunctions.net/code_genie_api_calls",
)
CODEGENIE_PROXY = os.getenv("CODEGENIE_PROXY", "http://127.0.0.1:13124").strip()
DEFAULT_MODEL = os.getenv("CODEGENIE_MODEL", "gpt-4o-mini").strip()
APPLICATION_NAME = os.getenv("CODEGENIE_APPLICATION_NAME", "Code Genie").strip()
REQUEST_TIMEOUT = float(os.getenv("CODEGENIE_TIMEOUT", "180"))


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _json_text(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def build_form(body: Dict[str, Any]) -> Dict[str, str]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        raise HTTPException(status_code=400, detail="messages must be a non-empty array")

    requested_model = str(body.get("model") or "").strip()
    deployment_name = DEFAULT_MODEL
    # If Continue sends a real CodeGenie deployment name, allow it. Ignore
    # generic aliases such as 'codegenie' and use CODEGENIE_MODEL instead.
    if requested_model and requested_model.lower() not in {
        "codegenie", "codegenie-cloud", "company-ai", "company-genai"
    }:
        deployment_name = requested_model

    max_tokens = (
        body.get("max_tokens")
        or body.get("max_completion_tokens")
        or int(os.getenv("CODEGENIE_MAX_TOKENS", "4096"))
    )

    form: Dict[str, str] = {
        "adid": required_env("CODEGENIE_ADID"),
        "messages": _json_text(messages),
        "deployment_name": deployment_name,
        "temperature": str(body.get("temperature", 0.1)),
        "apikey": required_env("CODEGENIE_APIKEY"),
        "max_tokens": str(max_tokens),
        "application_name": APPLICATION_NAME,
    }

    # Continue Agent sends OpenAI-compatible tools. The CodeGenie endpoint was
    # verified to accept them and return choices[0].message.tool_calls.
    if "tools" in body:
        form["tools"] = _json_text(body.get("tools") or [])
    if "tool_choice" in body:
        tc = body.get("tool_choice")
        form["tool_choice"] = tc if isinstance(tc, str) else _json_text(tc)

    # Forward a few common OpenAI-compatible options only when supplied.
    for key in ("top_p", "frequency_penalty", "presence_penalty", "seed"):
        if key in body and body[key] is not None:
            form[key] = str(body[key])

    return form


def call_codegenie(form: Dict[str, str]) -> Dict[str, Any]:
    session = requests.Session()
    # The browser reaches the Cloud Function through the local company proxy.
    if CODEGENIE_PROXY:
        session.proxies.update({"http": CODEGENIE_PROXY, "https": CODEGENIE_PROXY})

    # Passing text fields as (None, value) forces multipart/form-data, matching
    # the working CodeGenie browser request and the successful curl -F test.
    multipart = [(key, (None, value)) for key, value in form.items()]

    try:
        response = session.post(
            CODEGENIE_URL,
            files=multipart,
            timeout=REQUEST_TIMEOUT,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"CodeGenie connection failed: {exc}")

    if not response.ok:
        # Never echo the local API key or ADID. Only return the upstream body.
        detail = response.text[:3000]
        raise HTTPException(
            status_code=502,
            detail=f"CodeGenie HTTP {response.status_code}: {detail}",
        )

    try:
        data = response.json()
    except Exception:
        raise HTTPException(status_code=502, detail="CodeGenie returned non-JSON data")

    if not isinstance(data, dict) or "choices" not in data:
        raise HTTPException(status_code=502, detail="CodeGenie returned an unexpected response shape")
    return data


def _normalize_tool_calls(tool_calls: Any) -> Any:
    if not isinstance(tool_calls, list):
        return tool_calls
    normalized = []
    for i, tc in enumerate(tool_calls):
        if not isinstance(tc, dict):
            continue
        item = dict(tc)
        item.setdefault("index", i)
        normalized.append(item)
    return normalized


def as_sse(data: Dict[str, Any]) -> StreamingResponse:
    """Convert CodeGenie's complete Chat Completions response to OpenAI SSE."""
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    model = data.get("model") or DEFAULT_MODEL
    response_id = data.get("id") or f"chatcmpl-{uuid.uuid4().hex}"
    created = data.get("created") or int(time.time())
    finish_reason = choice.get("finish_reason")

    def chunks() -> Iterable[str]:
        # Initial assistant role chunk.
        first = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
        }
        yield "data: " + json.dumps(first, separators=(",", ":")) + "\n\n"

        content = message.get("content")
        if content is not None and content != "":
            content_chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"content": content}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(content_chunk, separators=(",", ":")) + "\n\n"

        tool_calls = _normalize_tool_calls(message.get("tool_calls"))
        if tool_calls:
            tool_chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"tool_calls": tool_calls}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(tool_chunk, separators=(",", ":")) + "\n\n"

        final_chunk = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
        }
        yield "data: " + json.dumps(final_chunk, separators=(",", ":")) + "\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(chunks(), media_type="text/event-stream")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model": DEFAULT_MODEL,
        "gateway": CODEGENIE_URL,
        "proxy": CODEGENIE_PROXY or "DIRECT",
        "credentials_configured": bool(os.getenv("CODEGENIE_ADID") and os.getenv("CODEGENIE_APIKEY")),
    }


@app.get("/v1/models")
def models():
    return {
        "object": "list",
        "data": [{"id": DEFAULT_MODEL, "object": "model", "owned_by": "codegenie"}],
    }


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Request body must be JSON")

    form = build_form(body)
    data = call_codegenie(form)

    if body.get("stream"):
        return as_sse(data)
    return JSONResponse(content=data)
