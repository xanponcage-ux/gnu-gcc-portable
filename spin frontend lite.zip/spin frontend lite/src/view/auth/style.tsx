import { styled } from "@mui/material/styles";
import { Box } from "@mui/material";
import { Theme } from "src/theme/type";

export const BannerContainer = styled(Box)(({ theme }: Theme) => ({
  width: "85%",
  maxWidth: "350px",
  margin: "auto",
  position: "absolute",
  left: "50%",
  top: "50%",
  transform: "translate(-50%, -50%)",
  backgroundColor: theme?.palette.background.default,
  "& .banner": {
    textAlign: "center",
    backgroundColor: theme?.palette.primary.main,
    padding: "30px 10px",
  },
  "& h3": {
    color: theme?.palette.primary.contrastText,
  },
  "& .container": {
    padding: "30px",
  },
}));
