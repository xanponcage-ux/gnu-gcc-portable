import { Request, Response } from "express";
import SPO0008Model from "../models/SPO0008Model";
import { ResponceData } from "../utils";
import moment from "moment";

interface KeyValue {
  [key: string]: any;
}

interface Column {
  name: string;
}

interface Tables {
  metaData: Array<Column>;

  rows: Array<Array<any>>;
}

export const getTroubleType = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0008Model.prototype.getTroubleType();

    // const { rows }: any = await SPO0008Model.prototype.getTroubleType();
    // const troubleData: any = [];
    // rows.map(function (x: any) {
    //   troubleData.push(x[0] + ":" + x[1]);
    // });

    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getEqpCode = async (req: Request, res: Response) => {
  try {
    const { rows }: any = await SPO0008Model.prototype.eqpCode();

    const eqpData: any = [];

    rows.map(function (x: any) {
      eqpData.push(x[0]);
    });

    return res.status(200).json({ eqpData });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getDelUser = async (req: Request, res: Response) => {
  try {
    const user = req.user;
    const { rows }: any = await SPO0008Model.prototype.delUsr(user);

    var delUserData: number = rows.length;
    //delUserData = rows.length;
    // rows.map(function (x: any) {
    //   delUserData.push(x[0]);
    // });

    return res.status(200).json({ delUserData });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getData = async (req: Request, res: Response) => {
  try {
    /////
    var agencyList: KeyValue[] = [];
    const { metaData: agMeta, rows: agRows } =
      await SPO0008Model.prototype.getAgencyList();
    const column = agMeta.map(
      (column: Column) => column.name //.replace(/ |-/g, "")
    );
    agencyList = agRows.map((values: any, row: number) => {
      const result: KeyValue = {};
      column.forEach(
        (key: string, i: any) =>
          (result[key] =
            typeof values[i] === "number"
              ? parseFloat(values[i].toFixed(3))
              : values[i])
      );
      return result;
    });
    ///

    //Equip Master
    const { metaData: eqpCol, rows: eqpRow }: any =
      await SPO0008Model.prototype.eqpMast();

    const eqpColumn = eqpCol.map((column: Column) => ({
      title: column.name,
      field: column.name.replace(/ |-|-/g, ""),
    }));

    const eqpColm = eqpCol.map((column: Column) =>
      column.name.replace(/ |-/g, "")
    );
    const eqpData = eqpRow.map((values: any, row: number) => {
      const result: KeyValue = {};
      eqpColm.forEach((key: string, i: any) => (result[key] = values[i]));
      return result;
    });

    //Facility Code
    const { metaData: facCol, rows: facRow }: any =
      await SPO0008Model.prototype.facCode();

    const facColumn = facCol.map((column: Column) => ({
      title: column.name,
      field: column.name.replace(/ |-|-/g, ""),
    }));

    const facColm = facCol.map((column: Column) =>
      column.name.replace(/ |-/g, "")
    );
    const facData = facRow.map((values: any, row: number) => {
      const result: KeyValue = {};
      facColm.forEach((key: string, i: any) => (result[key] = values[i]));
      return result;
    });

    //Reason Data
    const { rows }: any = await SPO0008Model.prototype.reason();
    const reasonData: any = [];
    rows.map(function (x: any) {
      reasonData.push(x[0]);
    });

    // Eqp Code
    const { rows: xyz }: any = await SPO0008Model.prototype.eqpCode();
    const eqpCodeData: any = [];
    xyz.map(function (x: any) {
      eqpCodeData.push(x[0]);
    });

    //Delay Data
    const {
      dateFrom,
      dateTo,
      selectBy,
      selectShift,
      EqpCD,
      FaqCD,
      troubleType,
      process,
    } = req.body;
    const { metaData: delayCol, rows: delayRow }: any =
      await SPO0008Model.prototype.delay(
        dateFrom,
        dateTo,
        selectBy,
        selectShift,
        EqpCD,
        FaqCD,
        troubleType,
        process
      );

    const delayColumn = delayCol.map((column: Column) => ({
      title: column.name,
      field: column.name.replace(/ |-|-/g, ""),
    }));

    let totalDelay = 0,
      totalRows,
      noOfDays,
      cnt = 0,
      mtbf = 0,
      ts = 0,
      mttr = 0;
    var spnMtbf = 0,
      spnMttr,
      delay = 0,
      workHrs,
      delay_count = 0,
      date_diff = 0;

    const delayColm = delayCol.map((column: Column) =>
      column.name.replace(/ |-/g, "")
    );

    const delayData = delayRow.map((values: any, row: number) => {
      const result: KeyValue = {};
      delayColm.forEach((key: string, i: any) => (result[key] = values[i]));

      totalDelay += result?.DURATION ?? 0;

      if (
        parseInt(result.FAO_CD_TRBL_TYP) == 1 &&
        parseInt(result.FAO_CD_TRBL_TYP) == 6
      )
        cnt = cnt + result?.DURATION;

      //if (parseInt(result.FAO_CD_TRBL_TYP) > 1 && parseInt(result.FAO_CD_TRBL_TYP) < 6)
      //                delay_count;

      if (
        parseInt(result.FAO_CD_TRBL_TYP) !== 1 &&
        parseInt(result.FAO_CD_TRBL_TYP) !== 6
      )
        delay_count++;

      if (cnt > 0) {
        if (
          parseInt(result.FAO_CD_TRBL_TYP) == 1 &&
          parseInt(result.FAO_CD_TRBL_TYP) == 6
        ) {
          mtbf += result.DURATION;
        }
      }

      if ((dateTo || dateFrom) != "" && result.FAO_CD_SH_OUTAGE !== "All") {
        ts =
          dateTo && dateFrom
            ? moment(dateTo).diff(moment(dateFrom), "days")
            : 0;
        date_diff = ts * 24;
        spnMtbf = (date_diff - mtbf) / delay_count;
      } else if (
        (dateTo || dateFrom) != "" &&
        result.FAO_CD_SH_OUTAGE === "All"
      ) {
        spnMtbf = (8.0 - mtbf) / delay_count;
      }

      //mttr result

      if (result?.DURATION !== 0) delay += result?.DURATION;

      if (cnt > 0)
        if (
          parseInt(result.FAO_CD_TRBL_TYP) == 1 &&
          parseInt(result.FAO_CD_TRBL_TYP) == 6
        )
          mttr += result.DURATION;

      spnMttr = ((delay - mttr) / delay_count).toFixed(2);
      console.log("spnMttr: ", spnMttr);

      result.FAO_TM_STOP_EN = moment(result?.FAO_TM_STOP_EN).format(
        "DD-MM-YYYY HH:mm:ss"
      );
      result.FAO_TM_STOP_ST = moment(result?.FAO_TM_STOP_ST).format(
        "DD-MM-YYYY HH:mm:ss"
      );
      result.FAO_TM_STOP_ST_REV = moment(
        result?.FAO_TM_STOP_ST,
        "DD-MM-YYYY HH:mm:ss"
      ).format("MM-DD-YYYY HH:mm:ss");
      result.FAO_TS_REC_CREATE = moment(result?.FAO_TS_REC_CREATE).format(
        "DD-MM-YYYY HH:mm:ss"
      );
      result.agency_description =
        agencyList.find((i) => i.CD_VALUE == result?.FAO_CD_FAC_MAST)
          ?.CD_DESC ?? "";
      result.DESCP =
        result?.DESCP ??
        reasonData.find((i: any) => i.split("-")[0] == result?.FAO_CD_OUTAGE) ??
        "";
      result.equip_description =
        eqpCodeData.find(
          (i: any) => i.split("-")[0] == result?.FAO_CD_EQP_MAST
        ) ?? "";

      return result;
    });

    totalRows = delayRow.length;
    noOfDays =
      dateTo && dateFrom
        ? moment(dateTo).diff(moment(dateFrom), "days") + 1
        : 0;
    workHrs = parseFloat((noOfDays * 24 - totalDelay / 60).toFixed(2));
    let milUtility = (workHrs / (noOfDays * 24)) * 100;

    return res.status(200).json({
      agencyList: agencyList.map((item) => ({
        label: `${item.CD_VALUE}-${item.CD_DESC}`,
        value: item.CD_VALUE,
      })),
      eqpData,
      eqpColumn,
      facData,
      facColumn,
      delayData,
      delayColumn,
      totalDelay,
      totalRows,
      noOfDays,
      workHrs,
      spnMtbf,
      spnMttr,
      milUtility,
      reasonData,
      eqpCodeData,
    });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getModalDetails = async (req: Request, res: Response) => {
  try {
    //Reason Data

    const { rows }: any = await SPO0008Model.prototype.reason();

    const reasonData: any = [];

    rows.map(function (x: any) {
      reasonData.push(x[0]);
    });

    return res.status(200).json({ reasonData });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getSaveTableDetails = async (req: Request, res: Response) => {
  try {
    //Equip Fac
    const { reason, Reason } = req.body;
    const { metaData: eqpFacCol, rows: eqpFacRow }: any =
      await SPO0008Model.prototype.eqpFac(reason, Reason);

    const eqpFacColumn = eqpFacCol.map((column: Column) => ({
      title: column.name,
      field: column.name.replace(/ |-|-/g, ""),
    }));

    const eqpFacColm = eqpFacCol.map((column: Column) =>
      column.name.replace(/ |-/g, "")
    );
    const eqpFacData = eqpFacRow.map((values: any, row: number) => {
      const result: KeyValue = {};
      eqpFacColm.forEach((key: string, i: any) => (result[key] = values[i]));
      return result;
    });

    //Update Break
    const {
      endDate,
      remarks,
      Remarks,
      FaqCD,
      EquipCD,
      OutageRsnDesc,
      p_line,
      outDt,
      startDate,
      Shift,
    } = req.body;

    const updateData: any = await SPO0008Model.prototype.updbrk(
      endDate,
      reason,
      Reason,
      remarks,
      Remarks,
      FaqCD,
      EquipCD,
      OutageRsnDesc,
      p_line,
      outDt,
      startDate,
      Shift
    );

    return res.status(200).json({ eqpFacColumn, eqpFacData, updateData });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const insertDetails = async (req: Request, res: Response) => {
  try {
    //Insert Break
    const {
      endDate,
      reason,
      Reason,
      remarks,
      Remarks,
      FaqCD,
      EquipCD,
      OutageRsnDesc,
      p_line,
      outDt,
      startDate,
      Shift,
    } = req.body;

    const { PersonalNo } = req.body;
    const t1: any = await SPO0008Model.prototype.insertbrk(
      endDate,
      reason,
      Reason,
      remarks,
      Remarks,
      FaqCD,
      EquipCD,
      OutageRsnDesc,
      p_line,
      outDt,
      PersonalNo,
      startDate,
      Shift
    );

    // const insrtbrkColumn = insrtbrkCol.map((column: Column) => ({
    //   title: column.name,
    //   field: column.name.replace(/ |-|-/g, ""),
    // }));

    // const insrtbrkColm = insrtbrkCol.map((column: Column) =>
    //   column.name.replace(/ |-/g, "")
    // );
    // const insrtbrkData = insrtbrkFacRow.map((values: any, row: number) => {
    //   const result: KeyValue = {};
    //   insrtbrkColm.forEach((key: string, i: any) => (result[key] = values[i]));
    //   return result;
    // });

    return res.status(200).json({ t1 });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const deleteDetails = async (req: Request, res: Response) => {
  try {
    // var stDate = moment(req.body.cellData.FAO_TM_STOP_ST).format("DD-MM-YYYY HH:mm:ss");
    // var outageDt = req.body.cellData.OUTAGE_DT;
    // var eqpMast = req.body.cellData.FAO_CD_EQP_MAST;
    // var faqMast = req.body.cellData.FAO_CD_FAC_MAST;
    const { stDate, outageDt, p_line, eqpMast, faqMast } = req.body;
    var status = false;
    const user = req.user;
    const { rows }: any = await SPO0008Model.prototype.delUsr(user);
    var delUserData: number = rows.length;
    //Delete
    if (delUserData > 0) {
      const del: any = await SPO0008Model.prototype.deletebrk(
        stDate,
        outageDt,
        p_line,
        eqpMast
        //faqMast
      );
      status = true;
      return res.status(200).json({ del, status });
    } else {
      status = false;
      return res.status(200).json({ rows, status });
    }
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const saveDetails = async (req: Request, res: Response) => {
  try {
    // const { remarks, reason, stDate, outageDt, p_line, eqpMast, faqMast } =
    //   req.body;
    let data = req.body;
    console.log("data1: ", data);
    //Delete
    const updRsn: any = await SPO0008Model.prototype.updRsn(
      data
      //   remarks,
      //   reason,
      //   stDate,
      //   outageDt,
      //   p_line,
      //   eqpMast,
      //   faqMast
    );

    return res.status(200).json({ updRsn });
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
