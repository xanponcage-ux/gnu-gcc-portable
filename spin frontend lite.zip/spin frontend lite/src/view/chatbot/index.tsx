import image from "../../assets/images/bot.png";
import Close from "@mui/icons-material/Close";
import "./index.css";
import { useEffect, useState } from "react";
import React from "react";
import Upload from "./upload";

const Chatbot = () => {
  const [onShow, setOnShow] = useState(false);
  return (
    <div>
      {onShow && (
        <div className="chat-container">
          <div style={{ position: "relative" }} className="chat-container-div">
            <div className="chat-header">
              <h4
                style={{
                  margin: "5px",
                  fontSize: "1.125rem",
                  lineHeight: "1.5em",
                  fontWeight: 100,
                }}
              >
                Deffect Analyzer{" "}
                <img
                  style={{ width: "30px", marginBottom: "-8px" }}
                  src={image}
                />
              </h4>
            </div>
            <div className="chat-messages" id="chat-messages">
              <Upload />
            </div>
          </div>
        </div>
      )}
      <button
        className={onShow ? "show chatbot" : "chatbot"}
        onClick={() => setOnShow(!onShow)}
      >
        <img src={image} />
        <Close />
      </button>
    </div>
  );
};

export default Chatbot;
