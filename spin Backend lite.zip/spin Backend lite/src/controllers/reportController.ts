import { Request, Response } from "express";
import reportModel from "../models/reportModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

// export const SPS0020Controller = async (req: Request, res: Response) => {
//   try {
//     if (req.body.type === "pageData") {
//       const results1 = await ResponceData(
//         await reportModel.prototype.getPlantCode(req.body)
//       );
//       const results2 = await ResponceData(
//         await reportModel.prototype.getReportType(req.body)
//       );
//       let plantData = results1[0]?.TCY_CD_EPA;
//       const results3 = await ResponceData(
//         await reportModel.prototype.getSourcePlant({ plant: plantData })
//       );
//       return res
//         .status(200)
//         .json({ plant: results1, report: results2, sourcePlant: results3 });
//     } else if (req.body.type === "getTableData") {
//       //api
//       const result4 = await ResponceData(
//         await reportModel.prototype.getTableData(req.body)
//       );
//       //console.log('cont', result4)
//       return res.status(200).json(result4);
//     } else if (req.body.type === "sourcePlant") {
//       const results = await ResponceData(
//         await reportModel.prototype.getSourcePlant(req.body)
//       );
//       return res.status(200).json(results);
//     } else if (req.body.type === "yieldWiseData") {
//       const results5 = await ResponceData(
//         await reportModel.prototype.getyieldwisedata(req.body)
//       );
//       return res.status(200).json(results5);
//     } else if (req.body.type === "secondsData") {
//       const results6 = await ResponceData(
//         await reportModel.prototype.getSecondsData(req.body)
//       );
//       return res.status(200).json(results6);
//     } else if (req.body.type === "scrapData") {
//       const results7 = await ResponceData(
//         await reportModel.prototype.getScrapData(req.body)
//       );
//       return res.status(200).json(results7);
//     }
//     return res.status(200).json();
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const getOrderData08 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await reportModel.prototype.getEpa08();
//     const result2 = await reportModel.prototype.getOrderData08();
//     const result3 = await reportModel.prototype.getNoEnd08();
//     const result4 = await reportModel.prototype.getNoInp08();
//     const varData = {
//       epa: await ResponceData(result1),
//       order: await ResponceData(result2),
//       endmaterialNo: await ResponceData(result3),
//       inpmaterialNo: await ResponceData(result4),
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const getData08 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await reportModel.prototype.getData08(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getInvData = async (req: Request, res: Response) => {
//   try {
//     const  result1 = await reportModel.prototype.getInvData(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
// export const getInvMonData = async (req: Request, res: Response) => {
//   try {
//     const result1 = await reportModel.prototype.getInvMonData(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getData = async (req: Request, res: Response) => {
//   try {
//     const result1 = await reportModel.prototype.getData(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getDispatchData = async (req: Request, res: Response) => {
//   try {
//     const result1 = await reportModel.prototype.getDispatchData(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const SPS0025Controller = async (req: Request, res: Response) => {
//   try {
//     if (req.body?.type === "pageData") {
//       const results1 = await ResponceData(
//         await reportModel.prototype.getPlantData(req.body)
//       );
//       // const results2 = await ResponceData(await reportModel.prototype.getBatchData(req.body));
//       // const results3 = await ResponceData(await reportModel.prototype.getOrderData(req.body));
//       console.log("cont1", results1);
//       return res.status(200).json({ plant: results1 });
//     }
//     return res.status(200).json();
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const SPS0025BatchId = async (req: Request, res: Response) => {
//   try {
//     if (req.body.type === "01") {
//       const results1 = await ResponceData(
//         await reportModel.prototype.getBatchData(req.body)
//       );
//       return res.status(200).json(results1);
//     } else if (req.body.type === "02") {
//       //api
//       const result2 = await ResponceData(
//         await reportModel.prototype.getBatchData2(req.body)
//       );

//       return res.status(200).json(result2);
//     }
//     return res.status(200).json();
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const SPS0025TableApi = async (req: Request, res: Response) => {
//   try {
//     if (req.body.type === "01") {
//       const results1 = await ResponceData(
//         await reportModel.prototype.getInputCoilAudit(req.body)
//       );
//       console.log(results1);
//       return res.status(200).json(results1);
//     } else if (req.body.type === "02") {
//       const result2 = await ResponceData(
//         await reportModel.prototype.getProductionAudit(req.body)
//       );
//       return res.status(200).json(result2);
//     } else if (req.body.type === "03") {
//       const result3 = await ResponceData(
//         await reportModel.prototype.getCustOrdAudit(req.body)
//       );
//       return res.status(200).json(result3);
//     }

//     return res.status(200).json();
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
