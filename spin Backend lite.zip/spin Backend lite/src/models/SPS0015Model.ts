// const SPS0015Query = require("../repository/SPS0015Query");
import * as repo from "../repository/SPS0015Query";

export default class PlanningModel {
  // getData01(data: any) {
  //   return PlanningQuery.getData01(data);
  // }
  scheduleDeletion(data: any) {
    let route = data?.type;
    if (route === "getData") {
      return repo.getScreenData(data);
    } else if (route === "schedConfirmData") {
      return repo.getSchdConfTabData(data);
    } else if (route === "schedRejData") {
      return repo.getSchdConfTabData(data);
    } else if (route === "schedCompData") {
      return repo.getOpenSchdTabData(data);
    } else if (route === "deleteData") {
      return repo.rejectCoilPlan(data);
    } else if (route === "confirmData") {
      return repo.saveCoilPlan(data);
    }
    // else return repo.scheduleDeletion(data);
  }
}
