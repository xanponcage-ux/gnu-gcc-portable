import { getData, getStatusData, getScDwnData } from "../repository/SPC0021Query";

export default class SPC0021Model {
  getData(data: any) {
    return getData(data);
  }
  getStatusData(data: any) {
    return getStatusData(data);
  }

  getScDwnData(data : any) {
    return getScDwnData(data);
  }
}
