import styled from "@emotion/styled";
import { OutlinedInput, Autocomplete, RadioGroup, InputLabel } from "@mui/material";
import { Theme } from "src/theme/type";
import Input from '@mui/material/Input';

export const InputLabelField = styled(InputLabel)(({ theme }: Theme) => ({
    top: "-7px",
    "&.Mui-focused, &.MuiInputLabel-shrink": {
        top: 0,
    },
}));

export const OutlinedInputField = styled(OutlinedInput)(({ theme }: Theme) => ({
    "&.Mui-focused": {
        borderColor: "transparent",
    },
    "& svg": {
        color: theme?.palette.primary.main
    },
    "&:hover": {
        borderColor: "transparent",
        "& .MuiOutlinedInput-notchedOutline": {
            borderColor: theme?.palette.primary.main
        }
    },
}));

export const InputField = styled(Input)(({ theme }: Theme) => ({
    width: '100%',
    "&.Mui-focused": {
        borderColor: "transparent",
    },
    "&.MuiInput-underline": {
        color: theme?.palette.primary.main,
        "&:after": {
            borderBottom: `1px solid ${theme?.palette.primary.main}`            
        },
        "&:after, :hover:not(.Mui-disabled, .Mui-error):before": {
            borderBottom: `1.5px solid ${theme?.palette.primary.main}`
        }
    },
    "&:hover": {
        borderColor: "transparent",
        "& .MuiOutlinedInput-notchedOutline": {
            borderColor: theme?.palette.primary.main
        }
    },
}));

export const SelectField = styled(Autocomplete)(({ theme }: Theme) => ({
    width: '100%',
    "&.Mui-focused": {
        borderColor: "transparent",
    },
    "&.MuiInput-underline": {
        color: theme?.palette.primary.main,
        "&:after": {
            borderBottom: `1px solid ${theme?.palette.primary.main}`
        },
        "&:after, :hover:not(.Mui-disabled, .Mui-error):before": {
            borderBottom: `1.5px solid ${theme?.palette.primary.main}`
        },
        marginRight: "1px",
    },
    "&:hover": {
        borderColor: "transparent",
        "& .MuiOutlinedInput-notchedOutline": {
            borderColor: theme?.palette.primary.main
        }
    },
}));


export const RadioField = styled(RadioGroup)(({ theme }: Theme) => ({
    width: '100%',
    "&.Mui-focused": {
        borderColor: "transparent",
    },
    "&.MuiInput-underline": {
        color: theme?.palette.primary.main,
        "&:after": {
            borderBottom: `1px solid ${theme?.palette.primary.main}`
        },
        "&:after, :hover:not(.Mui-disabled, .Mui-error):before": {
            borderBottom: `1.5px solid ${theme?.palette.primary.main}`
        }
    },
    "&:hover": {
        borderColor: "transparent",
        "& .MuiOutlinedInput-notchedOutline": {
            borderColor: theme?.palette.primary.main
        }
    },
}));