import { Router } from "express";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import {
  getCastDetails,
  getCoilDetails,
  getFittingDetails,
} from "../controllers/SPC0013Controller";
import { Post } from "../typed/typed";

const SPC0013Route = Router();

SPC0013Route.route("/SPC0013/getCastDetails").post(
  authenticationMiddleware.bearer,
  getCastDetails
);

SPC0013Route.route("/SPC0013/getCoilDetails").post(
  authenticationMiddleware.bearer,
  getCoilDetails
);

SPC0013Route.route("/SPC0013/getFittingDetails").post(
  authenticationMiddleware.bearer,
  getFittingDetails
);
export default SPC0013Route;
