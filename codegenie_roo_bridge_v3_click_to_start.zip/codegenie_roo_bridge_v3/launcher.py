import json
import os
import sys
from pathlib import Path

try:
    import msvcrt
except ImportError:
    print("This launcher is intended for Windows.")
    raise

BASE_DIR = Path(__file__).resolve().parent
MODEL_FILE = BASE_DIR / "models.json"


def cls():
    os.system("cls")


def read_key():
    ch = msvcrt.getwch()
    if ch in ("\x00", "\xe0"):
        code = ord(msvcrt.getwch())
        return {
            72: "UP",
            80: "DOWN",
            75: "LEFT",
            77: "RIGHT",
            71: "HOME",
            79: "END",
        }.get(code, "SPECIAL")
    if ch == "\r":
        return "ENTER"
    if ch == "\x1b":
        return "ESC"
    return ch


def load_models():
    raw = json.loads(MODEL_FILE.read_text(encoding="utf-8"))
    rows = raw.get("models", raw)
    configured = [
        m for m in rows
        if isinstance(m, dict) and str(m.get("deployment_name") or "").strip()
    ]
    return configured


def choose_model(models):
    # Default: Claude 4.5 Sonnet
    idx = next(
        (i for i, m in enumerate(models) if m.get("id") == "claude-4.5-sonnet"),
        0,
    )

    while True:
        cls()
        print("=" * 68)
        print(" CODEGENIE BRIDGE - MODEL")
        print("=" * 68)
        print("Use UP/DOWN arrows. ENTER selects. ESC cancels.\n")

        for i, model in enumerate(models):
            marker = ">" if i == idx else " "
            default = "  [DEFAULT]" if model.get("id") == "claude-4.5-sonnet" else ""
            print(f"{marker} {model.get('name', model.get('id'))}{default}")

        print("\n  Other / exact CodeGenie deployment ID")

        key = read_key()
        if key == "UP":
            idx = (idx - 1) % (len(models) + 1)
        elif key == "DOWN":
            idx = (idx + 1) % (len(models) + 1)
        elif key == "ENTER":
            if idx == len(models):
                cls()
                print("Enter the exact CodeGenie deployment_name.")
                print("Example: claude-4.5-sonnet\n")
                value = input("Deployment ID: ").strip()
                if value:
                    return value, value
            else:
                m = models[idx]
                return str(m["id"]), str(m.get("name") or m["id"])
        elif key == "ESC":
            sys.exit(0)


def draw_slider(label, value_text, position, maximum, help_text):
    cls()
    width = 40
    if maximum <= 0:
        filled = width
    else:
        filled = round(position / maximum * width)
    filled = max(0, min(width, filled))
    bar = "#" * filled + "-" * (width - filled)

    print("=" * 68)
    print(f" CODEGENIE BRIDGE - {label}")
    print("=" * 68)
    print(f"\n[{bar}]  {value_text}\n")
    print(help_text)
    print("\nLEFT/RIGHT = adjust   HOME = minimum   END = maximum")
    print("ENTER = confirm       ESC = cancel")


def choose_temperature():
    values = [round(i / 10, 1) for i in range(0, 11)]
    idx = len(values) - 1  # default 1.0 / maximum

    while True:
        draw_slider(
            "TEMPERATURE",
            f"{values[idx]:.1f}",
            idx,
            len(values) - 1,
            "0.0 = deterministic   |   1.0 = maximum creativity/variation\nDEFAULT: 1.0",
        )
        key = read_key()
        if key == "LEFT":
            idx = max(0, idx - 1)
        elif key == "RIGHT":
            idx = min(len(values) - 1, idx + 1)
        elif key == "HOME":
            idx = 0
        elif key == "END":
            idx = len(values) - 1
        elif key == "ENTER":
            return values[idx]
        elif key == "ESC":
            sys.exit(0)


def choose_tokens():
    # MAX deliberately means the bridge does NOT send max_tokens.
    # Numeric presets are provided if the user wants a hard cap.
    values = [
        ("500", "500"),
        ("1K", "1000"),
        ("2K", "2000"),
        ("4K", "4000"),
        ("8K", "8000"),
        ("16K", "16000"),
        ("32K", "32000"),
        ("64K", "64000"),
        ("MAX", "MAX"),
    ]
    idx = len(values) - 1  # MAX by default

    while True:
        label, env_value = values[idx]
        draw_slider(
            "MAX OUTPUT TOKENS",
            label,
            idx,
            len(values) - 1,
            "MAX = no bridge-side output-token limit; CodeGenie/provider controls it.\n"
            "Numeric choices deliberately impose that hard cap.\nDEFAULT: MAX",
        )
        key = read_key()
        if key == "LEFT":
            idx = max(0, idx - 1)
        elif key == "RIGHT":
            idx = min(len(values) - 1, idx + 1)
        elif key == "HOME":
            idx = 0
        elif key == "END":
            idx = len(values) - 1
        elif key == "ENTER":
            return env_value, label
        elif key == "ESC":
            sys.exit(0)


def confirmation(model_id, model_name, temperature, token_env, token_label):
    while True:
        cls()
        print("=" * 68)
        print(" CODEGENIE BRIDGE - READY")
        print("=" * 68)
        print(f"\nModel              : {model_name}")
        print(f"Deployment / ID    : {model_id}")
        print(f"Temperature        : {temperature:.1f}")
        print(f"Max output tokens  : {token_label}")
        if token_env == "MAX":
            print("Token behavior     : no bridge cap (max_tokens omitted)")
        print("\nThe launcher will FORCE these settings for Roo requests.")
        print("Roo can stay configured with any model name; the launcher selection wins.")
        print("\nENTER = START BRIDGE")
        print("E     = edit selections")
        print("ESC   = cancel")

        key = read_key()
        if key == "ENTER":
            return True
        if isinstance(key, str) and key.lower() == "e":
            return False
        if key == "ESC":
            sys.exit(0)


def main():
    models = load_models()
    if not models:
        print("No configured models found in models.json")
        input("Press Enter to exit...")
        return

    while True:
        model_id, model_name = choose_model(models)
        temperature = choose_temperature()
        token_env, token_label = choose_tokens()

        if confirmation(model_id, model_name, temperature, token_env, token_label):
            break

    os.environ["CODEGENIE_MODEL"] = model_id
    os.environ["CODEGENIE_FORCE_MODEL"] = "1"

    os.environ["CODEGENIE_TEMPERATURE"] = str(temperature)
    os.environ["CODEGENIE_FORCE_TEMPERATURE"] = "1"

    os.environ["CODEGENIE_MAX_TOKENS"] = token_env
    os.environ["CODEGENIE_FORCE_MAX_TOKENS"] = "1"

    cls()
    print("=" * 68)
    print(" CODEGENIE BRIDGE RUNNING")
    print("=" * 68)
    print(f"Model       : {model_name} ({model_id})")
    print(f"Temperature : {temperature:.1f}")
    print(f"Tokens      : {token_label}")
    print("Endpoint    : http://127.0.0.1:8765")
    print("\nKeep this window open while using Roo.")
    print("Press CTRL+C to stop the bridge.\n")

    import uvicorn
    uvicorn.run(
        "codegenie_bridge:app",
        host="127.0.0.1",
        port=8765,
        log_level="info",
    )


if __name__ == "__main__":
    main()
