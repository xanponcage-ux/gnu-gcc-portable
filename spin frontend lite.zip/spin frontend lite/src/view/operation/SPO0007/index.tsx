import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, SelectInput } from "../../../components/input";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import PrintIcon from "@mui/icons-material/Print";
import {
  SPO0002GetDataApi,
  SPO0007GetData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { useMaterialUIController } from "../../../context";

import { useReactToPrint } from "react-to-print";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPO0002 = () => {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [statusData, setStatusData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  //const [selectedCoil, setSelectedCoil] = React.useState<string>("");
  const [value, setValue] = React.useState<number>(0);
  const [open, setOpen] = React.useState<boolean>(false);
  const [textValue, setTextValue] = React.useState("");
  const contentRef = React.useRef<HTMLDivElement>(null);
  const reactToPrintFn = useReactToPrint({ contentRef });

  const printerOp: Array<SelectType> = [
    { value: "ZPL", label: "ZPL", id: 1 },
    { value: "HW", label: "Honeywell", id: 2 },
  ];

  const [selectedPrinter, setSelectedPrinter] = React.useState<string>("");

  const column: Array<any> = [
    {
      title: "",
      formatter: "rowSelection",
      // titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      headerSort: false,
      frozen: true,
    },
    {
      field: "BATCH_ID",
      title: "Batch ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      frozen: true,
    },

    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Length",
      field: "EOM_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "No Pcs",
      field: "NO_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      //   editor: "number",
      //   formatter: function (cell: any) {
      //     var value = cell.getValue().toFixed(3);
      //     cell.getElement().style["border"] = "1.5px solid #748da6";
      //     return value;
      //   },
      //   cellEdited: function (cell: any) {
      //     let txtNoPcs = cell?._cell?.row?.data?.EOM_NO_PIECES1;
      //     let editNoPcs = cell?._cell?.row?.data?.EOM_NO_PIECES;
      //     if (txtNoPcs < editNoPcs) {
      //       alertify.error("Modify Pcs cannot be greater than current Pcs!");
      //       let row = cell.getRow();
      //       row.update({
      //         EOM_NO_PIECES: txtNoPcs,
      //       });
      //       return;
      //     }
      //     let row = cell.getRow();
      //     row.update({
      //       EOM_NO_PIECES: editNoPcs,
      //     });
      //   },
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      field: "CUST_NAME",
      title: "Customer",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "STATUS",
      title: "Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "MOTHER_BATCH",
      title: "Mother Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   field: "GRADE_DESC",
    //   title: "Grade",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // }
    {
      field: "GRADE",
      title: "Grade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    ,
    {
      field: "CURR_PROC",
      title: "Current Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PREV_PROC",
      title: "Prev Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "NEXT_PROC",
      title: "Next Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "IDIA",
      title: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "ODIA",
      title: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "EOM_TS_CREATION",
      title: "Production Date",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      field: "CUS_ORDER",
      title: "Customer Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CUS_ITEM",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PLANT",
      title: "Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  //Page Load
  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: column,
          height: 480,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
          selectable: 1,
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0007GetData(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varstatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
              //   setSelectedStatus("KB");
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0007GetData(token, {
        type: "coilData",
        Plant: selectedCode,
        Status: selectedStatus,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0 && res?.data?.length > 0) {
              setTableData(res.data);
            } else if (res?.data?.Length === 0) {
              alertify.error("No data found");
            } else {
              alertify.error("No data found");
              setTableData(res.data?.procPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const formatDate = (date) => {
    // Get the components of the date
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
    const year = String(date.getFullYear()).slice(-2); // Get last two digits of the year
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");

    // Format the date and time
    return `${day}.${month}.${year} : ${hours}.${minutes}`;
  };

  const handleDownloadLabel = async () => {
    if (
      selectedPrinter === null ||
      selectedPrinter === "" ||
      selectedPrinter === undefined
    ) {
      alertify.error("Please Select Printer Type!");
      return;
    }

    var selectedRows = table?.getSelectedRows();
    if (selectedRows.length != 1) {
      alertify.error("Please select one rows");
      return;
    }

    var newData: any[] = [];
    selectedRows.forEach(function (item: any) {
      newData.push(item.getData());
    });

    console.log("newData: ", newData);

    let labelZPL, labelHW, labelHwCTL;
    let c;

    for (var i = 0; i < newData.length; i++) {
      var a = document.body.appendChild(document.createElement("a"));

      let batchId = newData?.[i]?.BATCH_ID;
      // console.log("batchId: ", batchId, batchId.substr(6, 1));
      let isCtl = false;
      if (batchId.substr(6, 1) === "T") {
        isCtl = true;
      }
      // console.log("isCtl: ", isCtl);

      let grade = newData?.[i]?.GRADE;
      if (grade === null || grade === "" || grade === "N.A") {
        alertify.error("Grade not found. Label cannot be generated!");
        return;
      }
      let castNo = newData?.[i]?.CAST_NO;
      if (castNo === null || castNo === "") {
        alertify.error("Cast No not found. Label cannot be generated!");
        return;
      }

      let netWt = newData?.[i]?.NET_WT?.toFixed(3);
      let thick = newData?.[i]?.THICK?.toFixed(3);
      let width = newData?.[i]?.WIDTH?.toFixed(1);
      let noPcs = newData?.[i]?.NO_PCS;
      let length = parseInt(newData?.[i]?.EOM_LENGTH);

      const seqNo = await getSeqNo();
      // console.log("seqNo: ", seqNo);

      let isSaved: any = await saveLabelInfo();
      if (!isSaved) {
        return;
      }

      labelZPL = [
        "^XA",
        "~TA000",
        "~JSN",
        "^LT0",
        "^MNW",
        "^MTT",
        "^PON",
        "^PMN",
        "^LH0,0",
        "^JMA",
        "^PR6,6",
        "~SD15",
        "^JUS",
        "^LRN",
        "^CI27",
        "^PA0,1,1,0",
        "^XZ",
        "^XA",
        "^MMT",
        "^PW1181",
        "^LL1772",
        "^LS0",
        "^FT375,454^A0N,37,51^FH\\^CI28^FDProcessing Agent Of^FS^CI27",
        "^FT345,497^A0N,43,104^FH\\^CI28^FDTATA STEEL^FS^CI27",
        "^FT375,528^A0N,28,41^FH\\^CI28^FDTSDPL CR, Kalinganagar^FS^CI27",
        "^FT109,600^A0N,46,51^FH\\^CI28^FDBatch Id: ^FS^CI27",
        "^FT109,659^A0N,46,51^FH\\^CI28^FD" +
          `${newData?.[i]?.BATCH_ID}` +
          "^FS^CI27",
        "^FT109,721^A0N,46,51^FH\\^CI28^FDCoil Id: ^FS^CI27",
        "^FT109,780^A0N,46,51^FH\\^CI28^FD" +
          `${newData?.[i]?.MOTHER_BATCH || ""}` +
          "^FS^CI27",
        "^FT109,837^A0N,46,51^FH\\^CI28^FDGrade / Specification^FS^CI27",
        "^FT109,896^A0N,46,51^FH\\^CI28^FD" +
          `${newData?.[i]?.GRADE || ""}` +
          "^FS^CI27",
        "^FT647,593^A0N,47,51^FH\\^CI28^FDSection: ^FS^CI27",
        "^FT647,652^A0N,47,51^FH\\^CI28^FD" +
          `${thick + " X " + width + "(mm)"}` +
          "^FS^CI27",
        "^FT653,709^A0N,47,51^FH\\^CI28^FDNet Weight (MT): ^FS^CI27",
        "^FT653,768^A0N,47,51^FH\\^CI28^FD" + `${netWt || ""}` + "^FS^CI27",
        "^FT653,830^A0N,47,51^FH\\^CI28^FDNo Of Pieces: " +
          `${noPcs || ""}` +
          " ^FS^CI27",
        "^FT647,956^A0N,47,51^FH\\^CI28^FDCast No: ^FS^CI27",
        "^FT647,1015^A0N,47,51^FH\\^CI28^FD" +
          `${newData?.[i]?.CAST_NO || ""}` +
          "^FS^CI27",
        "^FT109,964^A0N,46,41^FH\\^CI28^FDSticker Printing Time: ^FS^CI27",
        "^FT109,1023^A0N,46,51^FH\\^CI28^FD" +
          `${formatDate(new Date())}` +
          "^FS^CI27",
        "^FT109,1070^A0N,46,41^FH\\^CI28^FDCustomer: ^FS^CI27",
        "^FT109,1130^A0N,47,41^FH\\^CI28^FD" +
          `${newData?.[i]?.CUST_NAME || ""}` +
          "^FS^CI27",
        "^FO-22,542^GB1100,0,4^FS",
        "^BY7,3,97^FT128,1239^BCN,,N,N",
        // "^FH\\^FD>:D3>552356585^FS",
        "^FH\\^FD>:D3>" + `${newData?.[i]?.BATCH_ID || ""}` + "^FS",
        "^FT878,1064^BQN,2,6",
        "^FH\\^FDLA," +
          `${
            newData?.[i]?.BATCH_ID +
            "," +
            newData?.[i]?.MOTHER_BATCH +
            "," +
            (newData?.[i]?.GRADE || "") +
            "," +
            (thick || "") +
            "," +
            (width || "") +
            "," +
            (netWt || "") +
            "," +
            (noPcs || "") +
            "," +
            (newData?.[i]?.CAST_NO || "")
          }` +
          // `"${newData?.[i]?.MOTHER_BATCH}"`,
          // `"${newData?.[i]?.GRADE}"`,
          // `"${newData?.[i]?.WIDTH}"`,
          // `"${newData?.[i]?.NET_WT}"`,
          // `"${newData?.[i]?.NO_PCS}"`,
          // `"${newData?.[i]?.CAST_NO}"`
          "^FS",
        "^FT230,1300^A0N,43,104^FH\\^CI28^FDWIP PACKAGING^FS^CI27",
        "^PQ1,0,1,Y",
        "^XZ",
      ];

      labelHW = [
        "INPUT OFF",
        "VERBOFF",
        "INPUT ON",
        "SYSVAR(48) = 0",
        'ERROR 15,"FONT Not FOUND"',
        'ERROR 18,"DISK FULL"',
        'ERROR 26,"PARAMETER TOO LARGE"',
        'ERROR 27,"PARAMETER TOO SMALL"',
        'ERROR 37,"CUTTER DEVICE Not FOUND"',
        'ERROR 1003,"FIELD OUT Of LABEL"',
        "SYSVAR(35)=0",
        'OPEN "tmp:setup.sys" FOR OUTPUT AS #1',
        'PRINT#1,"Printing,Media,Print Area,Media Margin (X),0"',
        'PRINT#1,"Printing,Media,Clip Default,On"',
        "CLOSE #1",
        'SETUP "tmp:setup.sys"',
        'KILL "tmp:setup.sys"',
        "CLIP ON",
        "CLIP BARCODE ON",
        "LBLCOND 3,2",
        "CLL",
        'OPTIMIZE "BATCH" ON',
        "PP75,430",
        'PRIMAGE "HSMTATASTEEL.PCX"',
        "PP243,56:AN7",
        "DIR4",
        "NASC 8",
        'FT "Inter SemiBold",10,0,104',
        'PT "Batch ID"',
        'PP266,56:FT "Inter Black",22,0,82',
        "PT " + `"${newData?.[i]?.BATCH_ID}"`, //"PK2165S003"',
        'PP160,498:FT "Inter SemiBold",11,0,79',
        'PT "TSDPL CR KALINGANAGAR"',
        'PP651,55:BARSET "CODE128B",2,1,3,61',
        "PB " +
          `"${
            newData?.[i]?.BATCH_ID + ";" + (netWt || "")
            // + ";" + seqNo
          }`, //"PK2165S003;4.144"',
        'PP707,56:FT "Univers Bold"',
        "FONTSIZE 10",
        "FONTSLANT 0",
        "PT " +
          `"${
            newData?.[i]?.BATCH_ID + ";" + (netWt || "")
            //  + ";" + seqNo
          }`, //"PK2165S003;4.144"',
        'PP56,493:FT "Inter SemiBold",11,0,79',
        'PT "Processing Agent Of"',
        "PP570,1160:DIR1",
        'BARSET "QRCODE",1,1,4,2,1',
        "PB " +
          `"${
            newData?.[i]?.BATCH_ID +
            "," +
            newData?.[i]?.MOTHER_BATCH +
            "," +
            (newData?.[i]?.GRADE || "") +
            "," +
            (newData?.[i]?.CUST_NAME || "") +
            "," +
            (thick || "") +
            "X" +
            (width || "") +
            "," +
            (netWt || "") +
            "," +
            (newData?.[i]?.CAST_NO || "") +
            "," +
            (noPcs || "")
          }`, //"PK2165S003,D541844000,DQ CL04,TSDPL PUNE,1.200x525.0,4.144,A191445,1"',
        "PP211,1208:AN1",
        "DIR2",
        "PL1180,3",
        "PP348,56:AN7",
        "DIR4",
        'FT "Inter SemiBold",10,0,104',
        'PT "Coil No"',
        'PP370,56:FT "Inter Black",20,0,82',
        "PT " + `"${newData?.[i]?.MOTHER_BATCH}"`, //"D541844000"',
        'PP456,56:FT "Inter SemiBold",10,0,104',
        'PT "Grade / Specification"',
        'PP479,56:FT "Inter Black",20,0,37',
        "PT " + `"${newData?.[i]?.GRADE || ""}"`, //" DQ CL04 "',
        'PP226,593:FT "Inter SemiBold",10,0,104',
        'PT "Section"',
        'PP248,588:FT "Inter Black",20,0,82',
        "PT " + `"${thick + " X " + width + "(mm)"}"`, //"1.200x525.0 (mm)"',
        'PP348,593:FT "Inter SemiBold",10,0,104',
        'PT "Net Weight"',
        'PP370,588:FT "Inter Black",20,0,82',
        "PT " + `"${netWt || ""}"`, //"4.144"',
        'PP348,814:FT "Inter SemiBold",10,0,104',
        'PT "Cast No"',
        'PP370,814:FT "Inter Black",20,0,82',
        "PT " + `"${newData?.[i]?.CAST_NO || ""}"`, //"A191445"',
        'PP553,56:FT "Inter SemiBold",10,0,104',
        'PT "Customer"',
        'PP576,56:FT "Inter Black",18,0,81',
        "PT " + `"${newData?.[i]?.CUST_NAME || ""}"`, // "TSDPL PUNE"',
        'PP734,148:FT "Inter Black",20,0,159',
        'PT "WIP PACKAGING"',
        'PP466,814:FT "Inter SemiBold",10,0,104',
        'PT "Sticker Printing Time"',
        'PP497,814:FT "Inter Black",14,0,82',
        "PT " + `"${formatDate(new Date())}"`, //"24.06.2025 14.52"',
        'LAYOUT RUN "',
        "PF",
        "PRINT KEY OFF",
      ];

      labelHwCTL = [
        "INPUT OFF",
        "VERBOFF",
        "INPUT ON",
        "SYSVAR(48) = 0",
        'ERROR 15,"FONT Not FOUND"',
        'ERROR 18,"DISK FULL"',
        'ERROR 26,"PARAMETER TOO LARGE"',
        'ERROR 27,"PARAMETER TOO SMALL"',
        'ERROR 37,"CUTTER DEVICE Not FOUND"',
        'ERROR 1003,"FIELD OUT Of LABEL"',
        "SYSVAR(35)=0",
        'OPEN "tmp:setup.sys" FOR OUTPUT AS #1',
        'PRINT#1,"Printing,Media,Print Area,Media Margin (X),0"',
        'PRINT#1,"Printing,Media,Clip Default,On"',
        "CLOSE #1",
        'SETUP "tmp:setup.sys"',
        'KILL "tmp:setup.sys"',
        "CLIP ON",
        "CLIP BARCODE ON",
        "LBLCOND 3,2",
        "CLL",
        'OPTIMIZE "BATCH" ON',
        "PP75,430",
        'PRIMAGE "HSMTATASTEEL.PCX"',
        "PP243,56:AN7",
        "DIR4",
        "NASC 8",
        'FT "Inter SemiBold",9,0,104',
        'PT "Batch ID"',
        'PP266,56:FT "Inter Black",21,0,82',
        "PT " + `"${newData?.[i]?.BATCH_ID}"`, //"PK2165S003"',
        'PP160,498:FT "Inter SemiBold",10,0,79',
        'PT "TSDPL CR KALINGANAGAR"',
        'PP651,55:BARSET "CODE128B",2,1,3,61',
        "PB " + `"${newData?.[i]?.BATCH_ID + ";" + (netWt || "")}`, //"PK2165S003;4.144"',
        'PP707,56:FT "Univers Bold"',
        "FONTSIZE 10",
        "FONTSLANT 0",
        "PT " + `"${newData?.[i]?.BATCH_ID + ";" + (netWt || "")}`, //"PK2165S003;4.144"',
        'PP56,493:FT "Inter SemiBold",10,0,79',
        'PT "Processing Agent Of"',
        "PP570,1160:DIR1",
        'BARSET "QRCODE",1,1,4,2,1',
        "PB " +
          `"${
            newData?.[i]?.BATCH_ID +
            "," +
            newData?.[i]?.MOTHER_BATCH +
            "," +
            (newData?.[i]?.GRADE || "") +
            "," +
            (newData?.[i]?.CUST_NAME || "") +
            "," +
            (thick || "") +
            "X" +
            (width || "") +
            "X" +
            (length || "") +
            "," +
            (netWt || "") +
            "," +
            (newData?.[i]?.CAST_NO || "") +
            "," +
            (noPcs || "")
          }`, //"PK2165S003,D541844000,DQ CL04,TSDPL PUNE,1.200x525.0,4.144,A191445,1"',
        "PP211,1208:AN1",
        "DIR2",
        "PL1180,3",
        "PP348,56:AN7",
        "DIR4",
        'FT "Inter SemiBold",10,0,104',
        'PT "Coil No"',
        'PP370,56:FT "Inter Black",20,0,82',
        "PT " + `"${newData?.[i]?.MOTHER_BATCH}"`, //"D541844000"',
        'PP456,56:FT "Inter SemiBold",10,0,104',
        'PT "Grade / Specification"',
        'PP479,56:FT "Inter Black",20,0,37',
        "PT " + `"${newData?.[i]?.GRADE || ""}"`, //" DQ CL04 "',
        'PP243,593:FT "Inter SemiBold",10,0,104',
        'PT "Section"',
        'PP266,545:FT "Inter Black",19,0,82',
        "PT " + `"${thick + " X " + width + " X " + length + "(mm)"}"`, //"1.200x525.0 (mm)"',
        'PP348,593:FT "Inter SemiBold",10,0,104',
        'PT "Net Weight"',
        'PP370,588:FT "Inter Black",20,0,82',
        "PT " + `"${netWt || ""}"`, //"4.144"',
        'PP466,590:FT "Inter SemiBold",10,0,104',
        'PT "No Of Pieces"',
        'PP489,588:FT "Inter Black",20,0,82',
        "PT " + `"${noPcs}"`,
        'PP348,814:FT "Inter SemiBold",10,0,104',
        'PT "Cast No"',
        'PP370,814:FT "Inter Black",20,0,82',
        "PT " + `"${newData?.[i]?.CAST_NO || ""}"`, //"A191445"',
        'PP553,56:FT "Inter SemiBold",10,0,104',
        'PT "Customer"',
        'PP576,56:FT "Inter Black",18,0,81',
        "PT " + `"${newData?.[i]?.CUST_NAME || ""}"`, // "TSDPL PUNE"',
        'PP734,148:FT "Inter Black",20,0,159',
        'PT "WIP PACKAGING"',
        'PP466,814:FT "Inter SemiBold",10,0,104',
        'PT "Sticker Printing Time"',
        'PP497,814:FT "Inter Black",14,0,82',
        "PT " + `"${formatDate(new Date())}"`, //"24.06.2025 14.52"',
        'LAYOUT RUN "',
        "PF",
        "PRINT KEY OFF",
      ];

      let labelData = [];

      if (selectedPrinter === "HW" && !isCtl) labelData = labelHW;
      else if (selectedPrinter === "HW" && isCtl) {
        labelData = labelHwCTL;
      } else if (selectedPrinter === "ZPL") labelData = labelZPL;

      var b = "";
      for (var i = 0; i < labelData.length; i++) {
        b += labelData?.[i] + "\r\n";
      }

      const newWindow = window.open("", "_blank");
      newWindow?.document.write(
        "<html><head><title>Label Data</title></head><body><pre>"
      );
      newWindow?.document.write(b);
      newWindow?.document.write("</pre></body></html>");
      newWindow?.document.close();
      // b = encodeURIComponent(b);
      // a.href = "data:text/html," + b;
      // a.click();
    }
    // setOpen(true);
    // setTextValue(c);
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }

    var date = new Date();
    var fileName = "SPS0005_" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    setSelectedCode("");
    setTableData([]);
    setSelectedStatus("");
    setSelectedPrinter("");
  };

  const handlePrinterChange = (event: any) => {
    setSelectedPrinter(event);
  };

  const saveLabelInfo = async (): Promise<boolean> => {
    try {
      if (!(selectedCode?.length > 0)) {
        alertify.error("Please select Plant!");
        return false;
      }

      const selectedRow = table?.getSelectedRows()?.[0]?.getData();

      if (!selectedRow) {
        alertify.error("Please select a row");
        return false;
      }

      const batchId = selectedRow.BATCH_ID;
      const mBatch = selectedRow.MOTHER_BATCH;
      const status = selectedRow.STATUS;

      setLoading(true);

      const token = await GetAuthorization();

      const res = await SPO0007GetData(token, {
        type: "saveLabelInfo",
        plant: selectedCode ?? "",
        batchStatus: status ?? "",
        batchId: batchId ?? "",
        firstPar: mBatch ?? "",
        user: user,
        printer: selectedPrinter,
      });

      if (res?.statusText && res.statusText !== "OK") {
        alertify.error(res?.data?.err || res?.toString());
        return false;
      }

      if (res?.data?.startsWith("N")) {
        const errorMsg = res.data.substring(2); // removes "N-"
        alertify.error(errorMsg);

        return false;
      }

      return true;
    } catch (error: any) {
      alertify.error(error?.message || "Something went wrong!");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const getSeqNo = async () => {
    try {
      if (!(selectedCode?.length > 0)) {
        alertify.error("Please select Plant!");
        return false;
      }

      const selectedRow = table?.getSelectedRows()?.[0]?.getData();

      if (!selectedRow) {
        alertify.error("Please select a row");
        return false;
      }

      const batchId = selectedRow.BATCH_ID;

      setLoading(true);

      const token = await GetAuthorization();

      const res = await SPO0007GetData(token, {
        type: "getLabelCount",
        plant: selectedCode ?? "",
        batchId: batchId ?? "",
        user: user,
      });

      if (res?.statusText && res.statusText !== "OK") {
        alertify.error(res?.data?.err || res?.toString());
        return false;
      }
      console.log("res?.data: ", res?.data);

      const labelCount = res?.data;
      const seqNo = labelCount + 2;
      return seqNo;
    } catch (error: any) {
      alertify.error(error?.message || "Something went wrong!");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Dialog
            open={open}
            maxWidth="lg"
            onClose={() => {
              setOpen(false);
            }}
          >
            <DialogTitle>Print made in india WIP Label</DialogTitle>
            <DialogContent>
              <Grid item xs={12}>
                <div ref={contentRef}>
                  <Grid container spacing={1} sx={{ pl: 5 }}>
                    <div>{textValue}</div>
                  </Grid>
                </div>
              </Grid>
            </DialogContent>
            <DialogActions>
              <ButtonElement
                onClick={() => {
                  setOpen(false);
                }}
                color="secondary"
              >
                Close
              </ButtonElement>
              <ButtonElement color="secondary" onClick={reactToPrintFn}>
                Print
              </ButtonElement>
            </DialogActions>
          </Dialog>
          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              {loading ? <Loader /> : null}
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Status"
                          data={statusData}
                          value={selectedStatus}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedStatus(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={2.5}>
                        <SelectInput
                          label="Printer Type*"
                          data={printerOp}
                          value={selectedPrinter}
                          onChange={handlePrinterChange}
                        />
                      </Grid>

                      <Grid item xs={1}>
                        {/* <Box component="span">
                          {" "}
                          &nbsp; */}
                        <Grid container>
                          <ButtonElement onClick={() => fetchData(value)}>
                            Search
                          </ButtonElement>
                        </Grid>
                        {/* </Box> */}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Package Material & Declare WIP"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Generate Label">
                        <IconButton
                          onClick={handleDownloadLabel}
                          disabled={restricted !== "RL_RW"}
                        >
                          <PrintIcon sx={{ color: "#ffffff" }} />
                          {/* <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                          </PrintIcon> */}
                        </IconButton>
                      </Tooltip>
                    </Grid>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPO0002;
