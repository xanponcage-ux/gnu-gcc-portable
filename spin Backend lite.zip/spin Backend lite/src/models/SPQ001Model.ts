// const SPQ001Query = require("../repository/SPQ001Query");
import { getData01 } from "../repository/SPQ001Query";

export default class SPQ001Model {
  getData01(data: any) {
    return getData01(data);
  }
}
