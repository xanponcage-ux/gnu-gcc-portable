import { Dayjs } from "dayjs";

export interface InputType {
    sIcon?: JSX.Element,
    eIcon?: JSX.Element,
    label?: string,
    sideLabel?: string,
    id?: string,
    type?: string,
    autoFocus?: boolean,
    readOnly?: boolean,
    disabled?: boolean,
    onChange: any,  //multiple input type
    data?: any,
    row?: boolean,
    OptionEqualToValue?: any,
    value: string,
    placeholder?: string,
    onKeyDown?: any,
    size?: "small" | "medium",
    style?:any
}

export interface InputDateType {
    sIcon?: JSX.Element,
    eIcon?: JSX.Element,
    label?: string,
    sideLabel?: string,
    id?: string,
    type?: string,
    autoFocus?: boolean,
    readOnly?: boolean,
    disabled?: boolean,
    onChange: any,  //multiple input type
    data?: Array<SelectType>,
    value: any,
    placeholder?: string,
    size?: "small" | "medium",
    time?: boolean,
    format?: string,
    defaultValue?: string | null | Dayjs,
}

export interface SelectType {
    value: string;
    label: string;
    id: number
}

export interface RadioType {
    value: string;
    label: string;
}