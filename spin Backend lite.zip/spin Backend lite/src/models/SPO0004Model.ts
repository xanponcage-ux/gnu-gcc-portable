// const SPO0004Query = require("../repository/SPO0004Query");

import {
  getTableData,
  getMBatchList,
  saveDataTemp,
  getMotherTableData,
} from "../repository/SPO0004Query";

export default class SPO0004Model {
  getTableData(data: any) {
    return getTableData(data);
  }
  getMBatchList(data: any) {
    return getMBatchList();
  }
  saveDataTemp(data: any) {
    return saveDataTemp(data);
  }
  getMotherTableData(data: any) {
    return getMotherTableData(data);
  }
}
