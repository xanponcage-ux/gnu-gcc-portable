import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0008GetDataApi,
  SPC0008GetOrderData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, InputChangeType } from "./type";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedOrderId, setSelectedOrderId] = React.useState<string>("");
  const [selectedendmaterialNo, setselectedendmaterialNo] =
    React.useState<string>("");
  const [selectedinpmaterialNo, setselectedinpmaterialNo] =
    React.useState<string>("");

  const [selectedItem, setselectedItem] = React.useState<string>("");
  const [selectedEpaCode, setEpaCode] = React.useState<string>("");
  const [epaData, setEpaData] = React.useState<Array<SelectType>>([]);
  const [OrderId, setOrderId] = React.useState<Array<SelectType>>([]);
  const [endmaterialNo, setendmaterialNo] = React.useState<Array<SelectType>>(
    []
  );
  const [inpmaterialNo, setinpmaterialNo] = React.useState<Array<SelectType>>(
    []
  );
  const [value, setValue] = React.useState<number>(0);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "select",
        label: "RM MAterial No",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },

    key2: {
      config: {
        type: "select",
        label: "FG MAterial No",
      },
      value: "",
      data: [],
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };
  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const column: Array<CulmnType> = [
    {
      title: "Plant",
      field: "CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      frozen: true,
    },
    {
      title: "Order Id",
      field: "ORDER_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Item No",
      field: "ITEM_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },

    {
      title: "RM Material No",
      field: "NO_INP_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Material No",
      field: "END_MATNR_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Base Qlty",
      field: "CD_BASE_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },

    {
      title: "Thickness Min",
      field: "THICKNESS_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",

      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Thickness Max",
      field: "THICKNESS_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Width Min",
      field: "WIDTH_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Width Max",
      field: "WIDTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },

    {
      title: "Prod Code",
      field: "CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Purchase Group",
      field: "CD_PUR_GRP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Qlty Code",
      field: "CD_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status Code",
      field: "CD_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Order Type",
      field: "CD_TYPE_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Delivery Date",
      field: "DELIVERY_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "Order Date",
      field: "ORDER_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "End Prod Desc",
      field: "END_PROD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "User Id",
      field: "ID_USER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Min Length",
      field: "LENGTH_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Max Length",
      field: "LENGTH_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },

    {
      title: "Tracking No",
      field: "TRACKING_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Price",
      field: "PRICE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "Quantity",
      field: "QUANTITY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",

      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },

    {
      title: "Tdc No",
      field: "TDC_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
    },
    {
      title: "UOM",
      field: "UOM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Component Code",
      field: "CD_COMP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Start Date",
      field: "VAL_START_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
    {
      title: "End Date",
      field: "VAL_END_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return DateFormat(value);
        }
        return value;
      },
    },
  ];

  const downloadExcel = () => {
    if (tableData == null || tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0008 " + "SCO_ORDER_BOOK" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  let arr_select = [[], endmaterialNo, [], inpmaterialNo];
  React.useEffect(() => {
    setLoading(true);
    // fetchData();
    fetchPlantData();
    fetchOrderData();
    alertify.error("Click on Search to View Table");
  }, []);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    fetchPlantData();
    fetchOrderData();
    fetchData();
    setInputObj(varInput);
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: column,
          height: 360,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);
  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0008GetOrderData(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.epa?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setEpaData(varData);
            setselectedItem(varData[0]?.value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchOrderData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0008GetOrderData(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData1: Array<SelectType> = [];
            res.data?.order?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.SOI_ID_ORDER?.toString(),
                  label: x.SOI_ID_ORDER?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setOrderId(varData1);
            const varData2: Array<SelectType> = [];
            res.data?.endmaterialNo?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData2.push({
                  value: x.SOI_NO_END_MATNR?.toString(),
                  label: x.SOI_NO_END_MATNR?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setendmaterialNo(varData2);
            const varData3: Array<SelectType> = [];
            res.data?.inpmaterialNo?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData3.push({
                  value: x.SOI_NO_INP_MATNR?.toString(),
                  label: x.SOI_NO_INP_MATNR?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setinpmaterialNo(varData3);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = () => {
    const data = {
      epa: selectedItem,
      order: selectedOrderId,
      inpmaterialNo: selectedinpmaterialNo,
      endmaterialNo: selectedendmaterialNo,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0008GetDataApi(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length === 0) {
              alertify.error("No Data Found!");
              return;
            } else setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleClearAll = () => {
    setEpaCode("");
    setSelectedOrderId("");
    setselectedendmaterialNo("");
    setselectedinpmaterialNo("");
    setselectedItem("");
    setTableData([]);
    setInputObj(varInput);
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }
  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={2}>
                      <SelectInput
                        id={"id"}
                        data={epaData}
                        value={selectedItem}
                        label="Plant*"
                        size={"small"}
                        onChange={(e: string) => {
                          setselectedItem(e);
                          setTable(null);
                          setTableData([]);
                        }}
                      />
                    </Grid>
                    <Grid item xs={2.5}>
                      <SelectInput
                        id={"id"}
                        data={OrderId}
                        value={selectedOrderId}
                        label="Order Id"
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedOrderId(e);
                          setTable(null);
                          setTableData([]);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3.1}>
                      <SelectInput
                        id={"id"}
                        data={inpmaterialNo}
                        value={selectedinpmaterialNo}
                        label="RM Material No"
                        size={"small"}
                        onChange={(e: any) => {
                          setselectedinpmaterialNo(e);
                          setTable(null);
                          setTableData([]);
                        }}
                      />
                    </Grid>
                    <Grid item xs={3.1}>
                      <SelectInput
                        id={"id"}
                        data={endmaterialNo}
                        value={selectedendmaterialNo}
                        label="FG Material No"
                        size={"small"}
                        onChange={(e: any) => {
                          setselectedendmaterialNo(e);
                          setTable(null);
                          setTableData([]);
                        }}
                      />
                    </Grid>
                    <Grid item xs={0.2}>
                      <ButtonElement onClick={fetchData}>Search</ButtonElement>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="SCO Order Item" />
                  </Tabs>
                </Box>
                {tableData?.length > 0 && <div id="table"></div>}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
