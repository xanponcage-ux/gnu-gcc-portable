import { TokenType } from "./type";
import { RefreshApi } from "./apiConfig/insideAuthApi";
import alertify from "./components/alert";
import routes from "./constant/route";

export const GetAuthorization = () => {
  return new Promise<any>((resolve, reject) => {
    RefreshApi()
      .then((response) => {
        if (
          response?.data?.accessToken &&
          response?.data?.refreshToken
          // response?.data?.user
        ) {
          setInStorage("token", {
            accessToken: response.data.accessToken,
            refreshToken: response.data.refreshToken,
            // user: response.data.user,
          });
          resolve({
            accessToken: response.data.accessToken,
            refreshToken: response.data.refreshToken,
            // user: response.data.user,
          });
        } else {
          localStorage.clear();
          alertify.error(
            response?.data?.error
              ? response.data.error?.toString()
              : response?.toString()
          );
          reject(response?.toString());
          // window.location.href = routes.login;
        }
      })
      .catch((e) => {
        localStorage.clear();
        alertify.error(e?.error?.message ? e.error.message : e?.toString());
        // window.location.href = routes.login;
      });
  });
};

const setInStorage = async (
  key: string,
  value: object | string | Array<object>
) => {
  return await localStorage.setItem(key, JSON.stringify(value));
};
const getFromStorage = async (key: string) => {
  return await JSON.parse(localStorage.getItem(key) || "null");
};
const removeFromStorage = async (key: string) => {
  return await localStorage.removeItem(key);
};

export const DateFormat = (
  date: string,
  isFullTime?: boolean,
  isTranc?: boolean
) => {
  try {
    const varDate = new Date(date);
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const day =
      varDate.getDate().toString()?.length === 1
        ? "0" + varDate.getDate()
        : varDate.getDate();

    const monthIndex = varDate.getMonth();
    const monthName = monthNames[monthIndex];
    const hr =
      varDate?.getHours()?.toString()?.length === 1
        ? "0" + varDate.getHours()
        : varDate.getHours();
    const mnt =
      varDate?.getMinutes()?.toString()?.length === 1
        ? "0" + varDate.getMinutes()
        : varDate.getMinutes();
    const sec =
      varDate?.getSeconds()?.toString()?.length === 1
        ? "0" + varDate.getSeconds()
        : varDate.getSeconds();
    const year = varDate
      .getFullYear()
      ?.toString()
      ?.slice(isTranc ? 0 : 2);

    if (day && monthName && year) {
      let date = `${day}-${monthName}-${year}`;
      if (isFullTime) {
        date += ` ${hr}:${mnt}:${sec}`;
      }
      return date;
    } else {
      return "";
    }
  } catch (e) {
    return "";
  }
};

export const dateDuration = (date1: string, date2: string) => {
  // @ts-ignore
  const diff = new Date(date1) - new Date(date2);
  if (diff) {
    return Number(diff);
  }
  return 0;
};

export const isFloat = (value: any) => {
  return !isNaN(value) && Number(value) % 1 !== 0;
};

export const openInNewTab = (url: string) => {
  const tempUrl = url[0] === "/" ? url : "/" + url;
  console.log(tempUrl);
  window.open(
    window.location.href.substring(0, window.location.href.indexOf("#") + 1) +
      tempUrl,
    "_blank"
  );
};

export { getFromStorage, removeFromStorage, setInStorage };
