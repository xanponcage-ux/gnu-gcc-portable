import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPC0010GetDataApi,
  SPC0010GetDispatchData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, InputChangeType } from "./type";
import { setTheme, useMaterialUIController } from "../../../context";
import { FormType } from "../../../view/auth/type";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import LibraryArrowCircle from "@mui/icons-material/ArrowDropDownCircle";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0010 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [summaryTable, setSummaryTable] = React.useState<any>(null);
  const [disTable, setDisTable] = React.useState<any>(null);
  const [batchTable, setBatchTable] = React.useState<any>(null);

  const [summaryData, setSummaryData] = React.useState<any>([]);
  const [dispatchData, setDispatchData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedMaterialNo, setSelectedMaterialNo] =
    React.useState<string>("");
  // const [selectedItem, setSelectedItem] = React.useState<string>("");
  const [selectedDate, setSelectedDate] = React.useState<string>("");
  const [batchData, setBatchData] = React.useState<any>([]);

  const [selectedEpaCode, setEpaCode] = React.useState<string>("");
  const [epaData, setEpaData] = React.useState<Array<SelectType>>([]);
  const [statusCodeData, setStatusCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [qltyData, setQltyData] = React.useState<Array<SelectType>>([]);
  const [orderStatusData, setOrderStatusData] = React.useState<
    Array<SelectType>
  >([]);
  const [customerData, setCustomerData] = React.useState<Array<SelectType>>([]);
  const [orderTypeData, setOrderTypeData] = React.useState<Array<SelectType>>(
    []
  );
  const [tdcData, setTdcData] = React.useState<Array<SelectType>>([]);
  const [value, setValue] = React.useState<number>(0);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedBatch, setSelectedBatch] = React.useState<string>("");
  const [selectedMBatch, setSelectedMBatch] = React.useState<string>("");
  const [yearMon, setYearMon] = React.useState<string>("");
  const [ordTypeData, setOrdTypeData] = React.useState<Array<SelectType>>([]);
  const [selectedOrdType, setSelectedOrdType] = React.useState<string>("");

  const [invoiceNo, setInvoiceNo] = React.useState<string>("");
  const [invoiceDtFrom, setInvoiceDtFrom] = React.useState<any>();
  const [invoiceDtTo, setInvoiceDtTo] = React.useState<any>();
  const [order, setOrder] = React.useState<string>("");
  const [item, setItem] = React.useState<string>("");

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Thick From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "Thick To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key3"),
    },
    key4: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "Width From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "input",
        label: "Width To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    key7: {
      config: {
        type: "input",
        label: "Prod",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    },
    // key8: {
    //   config: {
    //     type: "input",
    //     label: "Qlty",
    //   },
    //   value: "",
    //   onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    // },
    key9: {
      config: {
        type: "input",
        label: "TDC",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key9"),
    },
    // key10: {
    //   config: {
    //     type: "input",
    //     label: "Material",
    //   },
    //   value: "",
    //   onChange: (e: any) => onInputChange(e?.toString(), "key10"),
    // },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const columnSummary: Array<CulmnType> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Dispatch Date",
      field: "DT_LOAD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["background-color"] = "#DA8EE7";
        cell.getElement().style["color"] = "#FFFFFF";
        return value;
      },
    },
    {
      title: "Net Wt",
      field: "MS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Scrap",
      field: "SCRAP_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
  ];

  const columnDispatch: Array<CulmnType> = [
    {
      title: "Dispatch Date",
      field: "DISP_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
    },
    {
      title: "Length",
      field: "LEN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC Grade Desc",
      field: "TDC_GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Code",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Order",
      field: "ORD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Gross Wt",
      field: "GROSS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Ship to Party Desc",
      field: "SHIP_TO_PARTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Road Dest Description",
      field: "ROAD_DEST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice No",
      field: "INV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice Date",
      field: "INV_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Batch Creation Dt",
      field: "BTCH_CRT_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Batch Age Days",
      field: "BATCH_AGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
    },
    {
      title: "Order Type",
      field: "ORD_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Created",
      field: "ORD_CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Despatch Week",
      field: "DESP_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Code",
      field: "CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Name",
      field: "CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mark Cust Name",
      field: "MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "No Pieces",
      field: "NO_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ship to Party CD",
      field: "PARTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Fret Indicator",
      field: "FRT_IND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Delivery No.",
      field: "DELV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Service Centre",
      field: "SERVICE_CNTR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "FG Material No",
      field: "DISP_MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Material Desc",
      field: "DISP_MAT_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SLP Remark",
      field: "SLP_REMARK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      width: 150,
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Coil Mass",
      field: "MOTHER_COIL_MASS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        const v = cell.getValue();
        return v !== null && v !== undefined && !isNaN(v)
          ? Number(v).toFixed(3)
          : v;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Yard",
      field: "YARD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc X",
      field: "LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Y",
      field: "LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Z",
      field: "LOC_Z",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Source Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  // const columnDispatch: Array<CulmnType> = [
  //   {
  //     title: "Dispatch Date",
  //     field: "DT_LOAD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Batch Id",
  //     field: "EOM_ID_BATCH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Thickness",
  //     field: "THICK",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Width",
  //     field: "WIDTH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Length",
  //     field: "LENGTH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "TDC",
  //     field: "TDC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Prod Code",
  //     field: "PROD_CD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Order",
  //     field: "EOM_ID_ORDER_CUS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Item",
  //     field: "EOM_ID_ORD_ITEM_CUS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Net Wt",
  //     field: "NET_WT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     formatter: function (cell: any, formatterParams: any) {
  //       var value = cell.getValue();
  //       if (value) {
  //         return value.toFixed(3);
  //       }
  //       return value;
  //     },
  //   },
  //   {
  //     title: "Gross Wt",
  //     field: "GROSS_WT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     formatter: function (cell: any, formatterParams: any) {
  //       var value = cell.getValue();
  //       if (value) {
  //         return value.toFixed(3);
  //       }
  //       return value;
  //     },
  //   },
  //   {
  //     title: "Ship to Party",
  //     field: "ENC_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Invoice No",
  //     field: "EOM_NO_INVOICE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Invoice Dt",
  //     field: "EOM_DT_INVOICE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Batch Creation Date",
  //     field: "BTCH_CRT_DATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Order Desc",
  //     field: "ENC_ORD_DESC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Order Date",
  //     field: "ENC_DT_ORD_CREATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Despatch Week",
  //     field: "ENC_DESPATCH_WK",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Customer Name",
  //     field: "ENC_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mark Cust Name",
  //     field: "ENC_MARK_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "No of Pcs",
  //     field: "EOM_NO_PIECES",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Party Cd",
  //     field: "ENC_ORDER_TYPE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "I-Dia",
  //     field: "ENC_IDIA",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Lead Time",
  //     field: "ENC_DT_ORD_CREATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Feight Indicator",
  //     field: "ENC_FRT_IND",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Delivery No",
  //     field: "EOM_DELV_NO",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Service Center",
  //     field: "SERVICE_CETR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dispatch Mat No",
  //     field: "EOM_NO_MATNR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dispatch Mat Desc",
  //     field: "MATNR_DESC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Parent Batch",
  //     field: "EOM_ID_PARENT_BATCH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Batch",
  //     field: "EOM_ID_FIRST_PAR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Plant",
  //     field: "EOM_CD_EPA",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   // {
  //   //   title: "Despatch Month",
  //   //   field: "EOM_CD_QLTY_ACTL",
  //   //   headerFilter: "input",
  //   //   headerFilterPlaceholder: "search...",
  //   // },
  // ];

  // const columnDispatch: Array<CulmnType> = [
  //   {
  //     title: "Dispatch Date",
  //     field: "DT_LOAD",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Order",
  //     field: "EOM_ID_ORDER_CUS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Item",
  //     field: "EOM_ID_ORD_ITEM_CUS",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Party Cd",
  //     field: "ENC_ORDER_TYPE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Net Wt",
  //     field: "NET_WT",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     formatter: function (cell: any, formatterParams: any) {
  //       var value = cell.getValue();
  //       if (value) {
  //         return value.toFixed(3);
  //       }
  //       return value;
  //     },
  //   },
  //   {
  //     title: "No of Pcs",
  //     field: "EOM_NO_PIECES",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Ship to Party",
  //     field: "ENC_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Order Desc",
  //     field: "ENC_ORD_DESC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Order Date",
  //     field: "ENC_DT_ORD_CREATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Despatch Week",
  //     field: "ENC_DESPATCH_WK",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Customer Name",
  //     field: "ENC_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mark Cust Name",
  //     field: "ENC_MARK_CUST_NAME",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "I-Dia",
  //     field: "ENC_IDIA",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Lead Time",
  //     field: "ENC_DT_ORD_CREATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Feight Indicator",
  //     field: "ENC_FRT_IND",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   // {
  //   //   title: "Despatch Month",
  //   //   field: "EOM_CD_QLTY_ACTL",
  //   //   headerFilter: "input",
  //   //   headerFilterPlaceholder: "search...",
  //   // },
  //   {
  //     title: "Delivery No",
  //     field: "EOM_DELV_NO",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Service Center",
  //     field: "SERVICE_CETR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Batch Creation Date",
  //     field: "BTCH_CRT_DATE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Invoice No",
  //     field: "EOM_NO_INVOICE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Invoice Dt",
  //     field: "EOM_DT_INVOICE",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dispatch Mat No",
  //     field: "EOM_NO_MATNR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dispatch Mat Desc",
  //     field: "MATNR_DESC",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Batch Id",
  //     field: "EOM_ID_BATCH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Parent Batch",
  //     field: "EOM_ID_PARENT_BATCH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Mother Batch",
  //     field: "EOM_ID_FIRST_PAR",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Plant",
  //     field: "EOM_CD_EPA",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  // ];

  const column: Array<CulmnType> = [
    {
      title: "Batch Id",
      field: "EOM_ID_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice No",
      field: "EOM_NO_INVOICE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice Dt",
      field: "EOM_DT_INVOICE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Dispatch Dt",
      field: "DT_LOAD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material No",
      field: "EOM_NO_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod",
      field: "EOM_CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty",
      field: "EOM_CD_QLTY_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "EOM_SEC1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "EOM_SEC2",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Length",
      field: "EOM_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC",
      field: "EOM_TDC_ACTL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pieces",
      field: "EOM_NO_PIECES",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Net Wt",
      field: "MASS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Gross Wt",
      field: "GROSS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Mark Customer",
      field: "EOM_MK_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Type",
      field: "ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Customer Code",
      field: "CUSTOMER_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const downloadSummaryExcel = () => {
    if (summaryData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0010_SummaryReport" + ".xlsx";
    summaryTable.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const downloadDispatchExcel = () => {
    if (dispatchData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0010_DispatchDetails" + ".xlsx";
    disTable.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const downloadBatchExcel = () => {
    if (batchData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0010_BatchDetails" + ".xlsx";
    batchTable.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const getBatchDetails = () => {
    const data = {
      type: "batchDetails",
      epa: selectedEpaCode?.split(" - ")[0],
      dt_load: selectedDate,
    };
    setLoading(true);
    GetAuthorization().then((token: any) => {
      SPC0010GetDispatchData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            setBatchData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  let arr_select = [
    [],
    orderStatusData,
    [],
    customerData,
    [],
    orderTypeData,
    tdcData,
    // prodData,
    qltyData,
  ];
  // Page Load
  React.useEffect(() => {
    setLoading(true);
    //fetchOrderIdData();
    fetchPlantData();
  }, []);

  // React.useEffect(() => {
  //   if (summaryData?.length > 0) {
  //     setSummaryTable(
  //       new Tabulator("#summaryTable", {
  //         data: summaryData,
  //         columns: columnSummary,
  //         height: 350,
  //         layout: "fitDataFill",
  //         // pagination: true,
  //         // paginationSize: 10,
  //         // paginationSizeSelector: [10, 20, 40, 60],
  //         // paginationCounter: "rows",
  //         selectable: 1,
  //       })
  //     );
  //   } else {
  //     setSummaryTable(null);
  //   }
  // }, [summaryData]);

  // summaryTable?.on("rowSelected", async function (selectedData: any) {
  //   setDispatchData([]);
  //   setBatchData([]);
  //   await fetchDispDetails();
  //   // let cell: any = selectedData._row;
  //   // setSelectedDate(cell.getData().DT_LOAD);
  //   // const data = {
  //   //   type: "dispatchDetails",
  //   //   epa: selectedEpaCode?.split(" - ")[0],
  //   //   dt_load: cell.getData().DT_LOAD,
  //   // };
  //   // setLoading(true);
  //   // GetAuthorization().then((token: any) => {
  //   //   SPC0010GetDispatchData(token, data)
  //   //     .then((res) => {
  //   //       if (res.statusText !== "" && res.statusText !== "OK") {
  //   //         alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //   //       } else if (res?.data) {
  //   //         setDispatchData(res.data);
  //   //       }
  //   //     })
  //   //     .catch((e) => {
  //   //       alertify.error(
  //   //         e?.error?.message ? e.error.message : "Something Wents wrong!"
  //   //       );
  //   //     })
  //   //     .finally(() => {
  //   //       setLoading(false);
  //   //     });
  //   // });
  // });

  React.useEffect(() => {
    if (dispatchData?.length > 0) {
      setDisTable(
        new Tabulator("#dispatchTable", {
          data: dispatchData,
          columns: columnDispatch,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setDisTable(null);
    }
  }, [dispatchData]);

  React.useEffect(() => {
    if (batchData?.length > 0) {
      setBatchTable(
        new Tabulator("#batchTable", {
          data: batchData,
          columns: column,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setBatchTable(null);
    }
  }, [batchData]);

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchPlantData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0010GetDataApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setEpaData(varData);
              setEpaCode(varData[0].value);
              fetchPlantData(varData[0].value);
            } else {
              const varordTypeData: Array<SelectType> = [];
              res?.data?.ordTypeData?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varordTypeData?.push({
                    value: x?.ENC_ORDER_TYPE?.toString(),
                    label: x?.ENC_ORDER_TYPE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setOrdTypeData(varordTypeData);

              // const varcustData: Array<SelectType> = [];
              // res?.data?.custData?.map((x: any, i: number) => (
              //   <React.Fragment key={i}>
              //     {varcustData?.push({
              //       value: x?.ENC_CD_END_CUST?.toString(),
              //       label: x?.ENC_CUST_NAME?.toString(),
              //       id: i,
              //     })}
              //   </React.Fragment>
              // ));
              // setCustData(varcustData);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchDispSummary = async () => {
    const data = {
      type: "dispatchSummary",
      plant: selectedEpaCode?.split(" - ")[0],
      ThickFr: inputObj.key1.value,
      ThickTo: inputObj.key2.value,
      qltyCd: inputObj.key8.value,
      tdc: inputObj.key9.value,
      widthFr: inputObj.key5.value,
      widthTo: inputObj.key6.value,
      dispatchDateFr: DateFormat(inputObj.key3.value),
      dispatchDateTo: DateFormat(inputObj.key4.value),
      invoiceNo: invoiceNo ?? "",
      order: order ?? "",
      item: item ?? "",
      invoiceDtFrom: invoiceDtFrom ?? "",
      invoiceDtTo: invoiceDtTo ?? "",
    };

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0010GetDispatchData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            setSummaryData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchDispDetails = async () => {
    console.log("==> ", inputObj.key3.value, inputObj.key4.value);
    if (
      inputObj.key3.value === null ||
      inputObj.key3.value === "" ||
      inputObj.key3.value === undefined
    ) {
      alertify.error("Please Select Dispatch Date From.");
      return;
    }
    // let cell: any = selectedData._row;
    // setSelectedDate(cell.getData().DT_LOAD);
    const data = {
      type: "dispatchDetails",
      epa: selectedEpaCode?.split(" - ")[0],
      ThickFr: inputObj.key1.value,
      ThickTo: inputObj.key2.value,
      // qltyCd: inputObj.key8.value,
      tdc: inputObj.key9.value,
      widthFr: inputObj.key5.value,
      widthTo: inputObj.key6.value,
      dispatchDateFr: DateFormat(inputObj.key3.value),
      dispatchDateTo: DateFormat(inputObj.key4.value),

      ordType: selectedOrdType ?? "",
      invoiceNo: invoiceNo ?? "",
      invoiceDtFrom: DateFormat(invoiceDtFrom) ?? "",
      invoiceDtTo: DateFormat(invoiceDtTo) ?? "",
      order: order ?? "",
      item: item ?? "",
      // dt_load: cell.getData().DT_LOAD,
    };
    setLoading(true);
    GetAuthorization().then((token: any) => {
      SPC0010GetDispatchData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length == 0) {
              alertify.error("No Data Found!");
              setLoading(false);
              return;
            }
            setDispatchData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = async () => {
    if (!(selectedEpaCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setSummaryData([]);
    setDispatchData([]);
    setBatchData([]);

    // await fetchDispSummary();
    await fetchDispDetails();
    // const data = {
    //   type: "dispatchSummary",
    //   plant: selectedEpaCode?.split(" - ")[0],
    //   ThickFr: inputObj.key1.value,
    //   ThickTo: inputObj.key2.value,
    //   qltyCd: inputObj.key8.value,
    //   tdc: inputObj.key9.value,
    //   widthFr: inputObj.key5.value,
    //   widthTo: inputObj.key6.value,
    //   dispatchDateFr: DateFormat(inputObj.key3.value),
    //   dispatchDateTo: DateFormat(inputObj.key4.value),
    // };
    // setLoading(true);
    // GetAuthorization().then((token: TokenType) => {
    //   SPC0010GetDispatchData(token, data)
    //     .then((res) => {
    //       if (res.statusText !== "" && res.statusText !== "OK") {
    //         alertify.error(res?.data?.err ? res.data.err : res?.toString());
    //       } else if (res?.data) {
    //         setSummaryData(res.data);
    //       }
    //     })
    //     .catch((e) => {
    //       alertify.error(
    //         e?.error?.message ? e.error.message : "Something Wents wrong!"
    //       );
    //     })
    //     .finally(() => {
    //       setLoading(false);
    //     });
    // });
  };
  const handleClearAll = () => {
    setSelectedMaterialNo("");
    setInputObj(varInput);
    setSummaryData([]);
    setDispatchData([]);
    setBatchData([]);
    setInvoiceNo("");
    setInvoiceDtFrom(null);
    setInvoiceDtTo(null);
    setOrder("");
    setItem("");
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedEpaCode}
                            data={epaData}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setEpaCode(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5}>
                          <SelectInput
                            label="Order Type"
                            data={ordTypeData}
                            id={"OrdType"}
                            value={selectedOrdType}
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedOrdType(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={2.5}>
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i <= 1 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <Input
                                      id={x?.key}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Grid>
                        {formData?.map(
                          (x: FormType, i: number) =>
                            i >= 7 &&
                            i <= 8 && (
                              <React.Fragment key={i}>
                                <Grid item xs={i === 0 ? 1.6 : 1.4}>
                                  {x?.data?.config?.type === "select" ? (
                                    <SelectInput
                                      id={x?.key}
                                      data={arr_select[i]}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  ) : (
                                    <Input
                                      id={x?.key}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  )}
                                </Grid>
                              </React.Fragment>
                            )
                        )}
                        <Grid item xs={2.5}>
                          {/* <Box component="span" > Width */}
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 4 &&
                                i <= 5 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <Input
                                      id={x?.key}
                                      value={x?.data?.value}
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                          {/* </Box> */}
                        </Grid>
                        <Grid item xs={2}>
                          <Input
                            id={"invoiceNo"}
                            value={invoiceNo}
                            label="Invoice No"
                            size={"small"}
                            onChange={(e: string) => {
                              setInvoiceNo(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={2} sx={{ mt: 2 }}>
                          <Input
                            id={"order"}
                            value={order}
                            label="Order"
                            size={"small"}
                            onChange={(e: string) => {
                              setOrder(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1} sx={{ mt: 2 }}>
                          <Input
                            id={"item"}
                            value={item}
                            label="Item"
                            size={"small"}
                            onChange={(e: string) => {
                              setItem(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5} sx={{ mt: 2 }}>
                          <DatePickerInput
                            id={invoiceDtFrom}
                            value={invoiceDtFrom}
                            label="Inv Dt Frm"
                            onChange={(e: string) => {
                              setInvoiceDtFrom(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={1.5} sx={{ mt: 2 }}>
                          <DatePickerInput
                            id={invoiceDtTo}
                            value={invoiceDtTo}
                            label="Inv Dt To"
                            onChange={(e: string) => {
                              setInvoiceDtTo(e);
                            }}
                          />
                        </Grid>
                        <Grid item xs={3}>
                          <Box component="span">
                            {" "}
                            Dispatch Date
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 2 &&
                                  i <= 3 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        onChange={x?.data?.onChange}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>

                        {/* <Grid item xs={6}></Grid> */}
                        <Grid item xs={1} sx={{ mt: 2 }}>
                          <ButtonElement onClick={fetchData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          {/* 
          <Grid item xs={4}>
            <TableContainer
              title="Summary Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadSummaryExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {summaryData?.length > 0 && <div id="summaryTable"></div>}
            </TableContainer>
          </Grid> */}
          <Grid item xs={12}>
            <TableContainer
              title="Dispatch Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadDispatchExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {dispatchData?.length > 0 && <div id="dispatchTable"></div>}
            </TableContainer>
          </Grid>

          {/* This Grid id not needed */}
          {/* <Grid item xs={12}>
            <TableContainer
              title="Batch Details"
              headerContainer={
                <Grid container>
                  <Grid item>
                    <Tooltip title="Batch Details">
                      <IconButton onClick={getBatchDetails}>
                        <LibraryArrowCircle sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                  <Grid item>
                    <Tooltip title="Download">
                      <IconButton onClick={downloadBatchExcel}>
                        <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                </Grid>
              }
            >
              {batchData?.length > 0 && <div id="batchTable"></div>}
            </TableContainer>
          </Grid> */}
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0010;
