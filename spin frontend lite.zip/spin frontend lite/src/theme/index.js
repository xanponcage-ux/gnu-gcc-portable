/**
=========================================================
* Material Dashboard 2 React - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// @mui material components
import { createTheme } from "@mui/material/styles";

export const lightTheme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#1e88e5",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#4caf50",
      contrastText: "#ffffff",
    },
    divider: "#d3d3d3",
    background: {
      default: "#f0f2f5",
      paper: "#ffffff",
    },
    text: {
      primary: "#000000",
      secondary: "#d3d3d3",
      error: 'red',
    },
    },
  typography: {
      fontSize: 11, // Default font size in pixels
      fontFamily: 'Verdana',
      //fontWeight: 'bold',
      h1: {
          fontSize: '0.7rem',
      },
      body1: {
          fontSize: '0.7rem',
      },
      textField: {
          fontSize: '0.7rem',
      }
      // Add custom font sizes or other typography styles as needed
  },
  components: {
      // Example: Overrid styles for specific components
      MuiButton: {
          styleOverrides: {
              root: {
                  fontSize: '0.7rem', // Adjust button font size
              },
          },
      },
  },
});

export const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#0A4D68",
      light: "#CFD8DC",
      dark: "#455A64",
      contrastText: "#FFFFFF",
    },
    secondary: {
      main: "#fb641b",
      contrastText: "#212121",
    },
    divider: "#2f2f2f2",
    background: {
      default: "#000000",
      paper: "#000000",
    },
    text: {
      primary: "#ffffff",
      primaryRev: "#ffffff",
      secondary: "#d3d3d3",
      error: 'red'
    },
  },
  typography: {
    fontSize: 10, // Default font size in pixels
    //fontFamily: 'Verdana',
    //fontWeight: 'bold',
    h1: {
      fontSize: '.7rem',
    },
    body1: {
      fontSize: '.7rem',
    },
    textField: {
      fontSize: '0.7rem',
    }
    // Add custom font sizes or other typography styles as needed
  },
  custom: {
    fonts: {
      small: ".7rem",
    },
  },
  components: {
    // Example: Overrid styles for specific components
    MuiButton: {
      styleOverrides: {
        root: {
          fontSize: '0.7rem', // Adjust button font size
        },
      },
    },
  },
});
