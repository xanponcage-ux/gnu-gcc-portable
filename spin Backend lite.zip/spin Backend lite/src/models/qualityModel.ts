// import { getData01 } from "../repository/qualityQuery";
const QualityQuery = require("../repository/qualityQuery");

export default class QualityModel {
  // getData01(data: any) {
  //   return QualityQuery.getData01(data);
  // }
  getEpaCodeData01() {
    return QualityQuery.getEpaCodeData01();
  }
  // SCQ001Modal(data: any) {
  //   if (data?.route === "SCQ001getfetchData") {
  //     return QualityQuery.getFetchData(data);
  //   } else if (data?.route === "SCQ001getBatchInformation") {
  //     return QualityQuery.SCQ001getBatchInformation(data);
  //   } else if (data?.route === "getPopupData") {
  //     return QualityQuery.SCQ001GetPopUpData(data);
  //   } else if (data?.route === "saveData") {
  //     return QualityQuery.SCQ001SaveData(data);
  //   } else if (data?.route === "procedureCall") {
  //     return QualityQuery.SCQ001Procedure(data);
  //   } else if (data?.route === "getRsnCodeData") {
  //     return QualityQuery.getRsnCodeData(data);
  //   }
  // }

  // SCQ002Modal(data: any) {
  //   if (data?.route === "getPageData") {
  //     if (!data?.plant) {
  //       return QualityQuery.SCQ002getPlantData(data);
  //     } else {
  //       return QualityQuery.SCQ002getBatchData(data);
  //     }
  //   } else if (data?.route === "batchChange") {
  //     return QualityQuery.SCQ002getBatchData(data);
  //   } else if (data?.route === "SCQ002getBatchInformation") {
  //     return QualityQuery.SCQ002getTableData(data);
  //   } else if (data?.route === "getRsnData") {
  //     return QualityQuery.SCQ002getRsnData(data);
  //   } else if (data?.route === "holdProcedure") {
  //     return QualityQuery.SCQ002Procedure(data?.data);
  //   } else if (data?.route === "updateHoldRemarks") {
  //     return QualityQuery.SCQ002updateHoldRemarks(data);
  //   }
  // }
}
