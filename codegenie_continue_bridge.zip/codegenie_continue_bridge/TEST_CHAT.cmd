@echo off

echo ===== HEALTH =====
curl.exe -sS http://127.0.0.1:8765/health
echo.
echo.

echo ===== CHAT =====
curl.exe -sS -X POST http://127.0.0.1:8765/v1/chat/completions ^
  -H "Content-Type: application/json" ^
  -d "{\"model\":\"gpt-4o-mini\",\"messages\":[{\"role\":\"user\",\"content\":\"Reply only with BRIDGE_CHAT_OK\"}],\"temperature\":0.1,\"max_tokens\":50,\"stream\":false}"
echo.
echo.
pause
