import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";

export const getOrderProgData = async (data: any) => {
  try {
    let binds: any = {};
    let sql: any = `SELECT ENC_ID_ORDER , ENC_NO_ITEM,ENC_ORD_QUANTITY ORD_QTY, ENC_ORDER_TYPE ORDER_TYPE
,NVL(TOP_ORD_TOL,0)ORD_TOL,(ENC_ORD_QUANTITY+NVL(TOP_ORD_TOL,0))ORD_QTY_WITH_TOLERANCE,NVL(TOP_DISPATCHED,0) DISPTCHED,NVL(TOP_DISPATCHABLE,0) DISPBL,NVL(TOP_FG_READY,0) FG_READY,NVL(TOP_WIP,0) WIP
,NVL(TOP_QA_HOLD,0) HOLD,NVL(TOP_BAL_TO_ROLL,0) BTR
,TO_CHAR(ENC_DT_ORD_CREATE,'DD-MON-YYYY') ORD_CRT_DT , ENC_ST_ORDER
,ENC_NO_MATNR,ENC_ORD_DESC ORD_DESC,ENC_CD_PROD,ENC_CD_QLTY,ENC_SEC1_MIN,ENC_SEC1_MAX,ENC_SEC2_MIN,ENC_SEC2_MAX,ENC_LENGTH_MIN,ENC_LENGTH_MAX
,ENC_NO_TDC,ENC_CD_GRADE,ENC_CUST_NAME,(ENC_CD_SHIP_TO_PRTY||'-'||ENC_SHIP_TO_PRTY_DESC) SHIP_TO_PARTY
,ENC_ODIA,ENC_IDIA,ENC_ROADDEST_DESC,ENC_RAILDEST_DESC,TO_CHAR(ENC_LAST_ORD_DWNLD,'DD-MM-YYYY HH24:MI:SS')ORD_LAST_DOWNLD,(ENC_MARK_CUST||'-'||ENC_MARK_CUST_NAME) MARK_CUST,ENC_ORDER_EDGE ORD_EDGE
,ENC_DESPATCH_WK DISP_WK, ENC_POST_TREAT
FROM V_END_CUST_ORD_EPA A , V_TSKEPA_ORDER_PROG B
WHERE A.ENC_CD_EPA = B.TOP_CD_EPA (+)
AND A.ENC_ID_ORDER = B.TOP_ID_ORDER(+)
AND A.ENC_NO_ITEM  = B.TOP_NO_ITEM(+)
`;
    if (data.order && data.order?.length > 0) {
      sql += ` and ENC_ID_ORDER='${data?.order}'`;
      binds["order"] = data?.order;
    }
    if (data.item && data.item?.length > 0) {
      sql += ` and ENC_NO_ITEM='${data?.item}'`;
      binds["item"] = data?.item;
    }
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
