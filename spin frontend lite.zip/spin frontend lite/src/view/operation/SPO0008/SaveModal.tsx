import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Slide,
  makeStyles,
} from "@mui/material";
import alertify from "../../../components/alert";
import { Card } from "@mui/material";
import Button from "@mui/material";
import React, { useEffect } from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip, Typography } from "@mui/material";
import { reactFormatter, ReactTabulator } from "react-tabulator";
import {
  GetPlantDataApi,
  SPC0011GetDataApi,
  SPC0011GetTableDataApi,
  SPO0008GetTroubleType,
  SPO0008GetData,
  SPO0008UpdData,
  SPO0008InsertTableData,
  SPO0008SaveModalData,
  SPO0008SaveTableData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { setTheme, useMaterialUIController } from "../../../context";
import { SelectType } from "../../../components/input/type";
import { DatePickerInput } from "../../../components/input";
// import { InputChangeType } from "./type";
import { InputChangeType } from "./type";
import { FormType } from "../../auth/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import Auth from "../../../components/layout/dashboardLayout/auth";
import "bootstrap-daterangepicker/daterangepicker.css";
import DateRangePicker from "react-bootstrap-daterangepicker";
import moment from "moment";
import "moment/locale/en-gb.js";

export default function SaveModel(props) {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { user } = controller;

  const [initialLoad, setInitialLoad] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const [rsn, setRsn] = React.useState([]);
  const [rsnFetched, setRsnFetched] = React.useState(false);
  const [eqpFac, setEqpFaC] = React.useState([]);
  const [updData, setUpdData] = React.useState([]);
  const [insert, setInsert] = React.useState([]);
  const [breakTable, setBreakTable] = React.useState<any>(null);

  useEffect(() => {
    console.log("breakData1: ", breakData);
    async function fetchData() {
      if (initialLoad == false) {
        const response = await GetAuthorization();
        api1(false);
        setInitialLoad(true);
      }
    }
    fetchData();
  }, []);

  useEffect(() => {
    if (rsn && rsn.length > 0) {
      setRsnFetched(true);
    }
  }, [rsn]);

  const api1 = (newToken = true) => {
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      let data = {};
      SPO0008SaveModalData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data: ", res.data);

            var items: any = [];
            var obj: any = new Object();
            obj.label = "Select";
            obj.value = "";
            items.push(obj);
            res?.data?.reasonData?.map((row: any) => {
              var obj: any = new Object();
              var rowSplit = row.split("-");
              obj.label = row;
              obj.value = rowSplit[0];
              items.push(obj);
            });
            setRsn(items);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  var tableRef: any = null;

  const saveData = async (cell: any, newToken = true) => {
    console.log("tableRef: ", tableRef);
    console.log("=>", breakTable?.getRows());
    console.log("breakData: ", breakData);
    // var data = tableRef.table.getRows(true);
    // console.log("data: ", data);
    var data = breakTable?.getRows(true);
    console.log("data: ", data);

    let error = false;
    var delay = 0;
    var starttime = props.data.FAO_TM_STOP_ST_REV;
    var endtime = props.data.FAO_TM_STOP_EN;
    data.forEach((element: any) => {
      const [reason, duration, remarks] = element._row.cells;
      if (!reason.value || !duration.value || !remarks.value) {
        error = true;
        return false;
      }
      delay += parseFloat(duration.value);
    });
    console.log("delay: ", delay);
    // if (error) {
    //   alertify.error("Row cannot be empty");
    //   return false;
    // }
    if (delay !== props.data.DURATION) {
      alertify.alert(
        "Error",
        "Sum of all Delays is not equal to Total Delay!!"
      );
      return false;
    }
    if (data !== "" || data !== null || data.length > 0) {
      var reason = data[0]._row.cells[0].value;
      var reason1 = data[1]._row.cells[0].value;
      var reason2 = data[2]._row.cells[0].value;
      var duration = data[0]._row.cells[1].value;
      var duration1 = data[1]._row.cells[1].value;
      var duration2 = data[2]._row.cells[1].value;
      var remarks = data[0]._row.cells[2].value;
      var remarks1 = data[1]._row.cells[2].value;
      var remarks2 = data[2]._row.cells[2].value;

      //var newDateObj = new Date(moment(starttime).format("DD-MM-YYYY hh:mm") + addMlSeconds);
      var startdt = new Date(starttime);
      var newDateObj = new Date(startdt.getTime() + duration * 60 * 1000);
      var newDateObj1 = new Date(newDateObj.getTime() + duration1 * 60 * 1000);
      var newDateObj2 = new Date(newDateObj1.getTime() + duration2 * 60 * 1000);

      // console.log(startdt.toDateString() + ":" + newDateObj1.toDateString() + ":" + newDateObj2.toLocaleString());
      // return;
      var i = 0;
      for (i = 0; i < 3; i++) {
        if (i == 0)
          await saveDetails(
            reason,
            newDateObj,
            remarks,
            startdt,
            false,
            props.data.OUTAGE_DT
          );
        else if (i == 1 && startdt !== null && reason1 && duration1)
          await insertDetails(
            reason1,
            duration1,
            remarks1,
            newDateObj,
            newDateObj1,
            false,
            props.data.OUTAGE_DT
          );
        else if (i == 2 && newDateObj1 !== null && reason2 && duration2)
          await insertDetails(
            reason2,
            duration2,
            remarks2,
            newDateObj1,
            newDateObj2,
            false,
            props.data.OUTAGE_DT
          );
      }
      alertify.success("Break Performed successfully");
    }
    if (data === "" || data === null || data.length === 0) {
      var msg = "Row cannot be empty";
      alertify.error(msg);
      props.closeModal(true);
    } else {
    }
    props.closeModal(false);
  };

  const saveDetails = async (
    reason: any,
    duration: any,
    remarks: any,
    starttime: any,
    newToken = true,
    outDt: any
  ) => {
    // if (newToken) {
    //   const rsp = await getAuthorization();
    // }
    // var defaultOptions = {
    //   headers: {
    //     Authorization: "Bearer " + localStorage.getItem("tcm_accessToken"),
    //   },
    // };
    await updateData(reason, duration, remarks, starttime, outDt);
    // props.closeModal(false);
  };

  const updateData = async (
    reason: any,
    duration: any,
    remarks: any,
    starttime: any,
    outDt: any
  ) => {
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      let data = {
        starttime,
        endDate: new Date(duration),
        reason,
        Reason: props.data.FAO_CD_OUTAGE,
        remarks,
        Remarks: props.data.FAO_REMARKS,
        FaqCD: props.data.FAO_CD_FAC_MAST,
        EquipCD: props.data.FAO_CD_EQP_MAST,
        OutageRsnDesc: "",
        p_line: props.data.FAO_CD_PROCESS, //props.filterData.selectBy,
        outDt: outDt,
        startDate: props.data.FAO_TM_STOP_ST,
        Shift: props.data.FAO_CD_SH_OUTAGE,
        PersonalNo: user,
      };
      SPO0008SaveTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data1: ", res.data);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const insertDetails = async (
    reason: any,
    duration: any,
    remarks: any,
    starttime: any,
    endtime: any,
    outDt: any,
    newToken = true
  ) => {
    // if (newToken) {
    //   const rsp = await getAuthorization();
    // }
    // var defaultOptions = {
    //   headers: {
    //     Authorization: "Bearer " + localStorage.getItem("tcm_accessToken"),
    //   },
    // };
    await insertData(reason, duration, remarks, starttime, endtime, outDt);
    // props.closeModal(false);
  };

  const insertData = async (
    reason: any,
    duration: any,
    remarks: any,
    starttime: any,
    endtime: any,
    outDt: any
  ) => {
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      let data = {
        endDate: new Date(endtime),
        reason,
        Reason: props.data.FAO_CD_OUTAGE,
        remarks,
        Remarks: props.data.FAO_REMARKS,
        FaqCD: props.data.FAO_CD_FAC_MAST,
        EquipCD: props.data.FAO_CD_EQP_MAST,
        OutageRsnDesc: "",
        p_line: props.filterData.selectBy,
        outDt: outDt,
        startDate: new Date(starttime),
        Shift: props.data.FAO_CD_SH_OUTAGE,
        PersonalNo: user,
      };
      SPO0008InsertTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res.data2: ", res.data);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const breakCol: any = [
    {
      title: "Reason",
      editor: "select",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: rsn,
      },
      formatter: function (cell: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        return value;
      },
    },
    { title: "Duration", editor: "input" },
    { title: "Remarks", editor: "input" },
  ];

  const breakData: any = [
    {
      Reason: "",
      Duration: "",
      Remarks: "",
    },
    {
      Reason: "",
      Duration: "",
      Remarks: "",
    },
    {
      Reason: "",
      Duration: "",
      Remarks: "",
    },
  ];

  React.useEffect(() => {
    console.log("breakData: ", breakData);
    if (breakData?.length > 0) {
      setBreakTable(
        new Tabulator("#breakTable", {
          data: breakData,
          columns: breakCol,
          height: 200,
          //movableRows: true,
          layout: "fitColumns",
          //   selectable: 1,
        })
      );
    }
  }, [rsnFetched]);

  const options: any = {
    //height: 400,
    pagination: "local",
    paginationSize: 12,
    layout: "fitColumns",
    downloadDataFormatter: (data) => data,
    downloadReady: (fileContents, blob) => blob,
    // responsiveLayout:"collapse",
    // responsiveLayoutCollapseStartOpen:false,
  };

  return (
    <div>
      <Grid
        container
        style={{
          marginLeft: "0rem",
          marginTop: "0rem",
          marginRight: "0rem",
        }}
      >
        <Dialog
          open={true}
          keepMounted
          //onClose={() => props.closeModal(false)}
          aria-labelledby="classic-modal-slide-title"
          aria-describedby="classic-modal-slide-description"
          fullWidth={true}
          maxWidth="md"
        >
          <DialogTitle
            style={{ cursor: "move", padding: "6px" }}
            id="draggable-dialog-title"
          >
            DELAY BREAK
          </DialogTitle>
          <DialogContent
            sx={{
              marginTop: "-10px",
              // backgroundColor: "#f0f0f0",
            }}
          >
            <Grid
              item
              xs={12}
              container
              spacing={1}
              sx={{
                p: 2,
                backgroundColor: csTheme?.palette.background.paper,
                borderRadius: 5,
                gap: 2,
              }}
            >
              <Grid item xs={2}>
                <Input
                  label="Outage Date"
                  value={props.data.OUTAGE_DT}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Shift"
                  value={props.data.FAO_CD_SH_OUTAGE}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Start Time"
                  value={props.data.FAO_TM_STOP_ST}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="End Time"
                  value={props.data.FAO_TM_STOP_EN}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Duration"
                  value={props.data.DURATION}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Reason"
                  value={props.data.FAO_CD_OUTAGE}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Remarks"
                  value={props.data.FAO_REMARKS}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Equip Code"
                  value={props.data.FAO_CD_EQP_MAST}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Trbl Type"
                  value={props.data.FAO_CD_TRBL_TYP}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
              <Grid item xs={2}>
                <Input
                  label="Coil Id"
                  value={props.data.FAO_ID_COIL}
                  readOnly={true}
                  onChange={""}
                />
              </Grid>
            </Grid>

            {/* <Grid item>
              {rsnFetched && (
                <ReactTabulator
                  columns={breakCol}
                  data={breakData}
                  options={options}
                  ref={(ref: any) => {
                    tableRef = ref;
                  }}
                />
              )}
            </Grid> */}
            {loading ? <Loader /> : null}
            {breakData?.length > 0 && <div id="breakTable"></div>}
          </DialogContent>
          <DialogActions>
            <ButtonElement
              children="Cancel"
              onClick={() => props.closeModal(false)}
            />
            <ButtonElement
              children="Save Changes"
              onClick={() => saveData(props.data)}
            />
          </DialogActions>
        </Dialog>
      </Grid>
    </div>
  );
}
