import { Router } from "express";
import { getData, getTableData } from "../controllers/SPC0011Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0011Route = Router();

SPC0011Route.route("/SPC0011/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPC0011Route.route("/SPC0011/getTableData").post(
  authenticationMiddleware.bearer,
  getTableData
);

export default SPC0011Route;
