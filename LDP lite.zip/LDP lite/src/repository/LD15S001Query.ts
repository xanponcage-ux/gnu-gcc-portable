import query from "../infrastructure/database/querys";
import { Post } from "../typed/typed";
import Error from "../models/errors";
import oracledb from "oracledb";

export const getRmList = async (status: any) => {
  try {
    let sql = ` select DISTINCT LOM_ID_PAR_COIL_NO from V_LDP_PRODN
        WHERE LOM_CD_STATUS= :status
        and LOM_CD_EPA='0780'
        AND LOM_CD_QLTY_ACTL<>'SCRP'`;
    let binds = {
      status: status,
    };
    console.log("rmlist", sql);
    console.log(binds);
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getPipeNoList = async (rmBatch: any, status: any) => {
  try {
    console.log("rmBatch: ", rmBatch);
    console.log("status: ", status);
    let sql = `select DISTINCT LOM_ID_BATCH from V_LDP_PRODN
        WHERE LOM_CD_STATUS = '${status}'
        and LOM_CD_EPA ='0780' `;
    // let binds = {
    //     status: status,
    //     rmBatch: rmBatch
    // }

    if (rmBatch !== "") {
      sql += ` AND LOM_ID_PAR_COIL_NO = '${rmBatch}'`;
    }
    console.log("pipeno", sql);
    // console.log("bindspipe",binds)
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const insertTempData = async (data: any) => {
  try {
    //console.log("insertdata20",data)
    const sql = ` INSERT INTO V_BARE_PDO_TEMP(
        TBP_PLANT_CD,
        TBP_BATCH_NO,
        TBP_CD_PROC,
        TBP_BATCH_PROC_NO,
        TBP_NEXT_PROC,
        TBP_PROD_DATE,
        TBP_SHIFT,
        TBP_CD_STATUS,
        TBP_PAR_COIL_NO,
        TBP_ID_ORDER_NO,
        TBP_NO_MATNR,
        TBP_PROD_START_DT,
        TBP_PROD_END_DT,
        TBP_RESULT,
        TBP_PIPSUR_TEMP_100,
        TBP_HOLD_RSN)
        VALUES(:PLANT,:BATCH_NO,:CD_PROC,:BATCH_PROC_NO,:NEXT_PROC,:PROD_DATE,:SHIFT,
               :STATUS,:PAR_COIL_NO,:ID_ORDER_NO,:NO_MATNR,TO_DATE(:START_DT,'DD/MM/YYYY HH24:MI'),
               TO_DATE(:END_DT,'DD/MM/YYYY HH24:MI'),:RESULT,:PIPE_SUR,
               :HOLD_RSN) `;
    let binds = {
      PLANT: data.PLANT,
      BATCH_NO: data.BATCH_NO,
      CD_PROC: data.CD_PROC,
      BATCH_PROC_NO: data.BATCH_PROC_NO,
      NEXT_PROC: data.NEXT_PROC,
      PROD_DATE: data.PROD_DATE,
      SHIFT: data.SHIFT,
      STATUS: data.STATUS,
      PAR_COIL_NO: data.PAR_COIL_NO,
      ID_ORDER_NO: data.ID_ORDER_NO,
      NO_MATNR: data.NO_MATNR,
      START_DT: data.START_DT,
      END_DT: data.END_DT,
      RESULT: data.RESULT,
      PIPE_SUR: data.PIPE_SUR,
      HOLD_RSN: data.HOLD_RSN,
    };
    //    console.log("insert120",sql)
    //    console.log("binds120",binds)
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const callproc150 = async (data: any) => {
  try {
    //console.log("20querydata",data)
    let resData = [];
    const sql = `call LDPDBA.LD15B001(
                    LS_BATCH_NO => :LS_BATCH_NO,
                    LS_CD_PROC => :LS_CD_PROC,
                    LS_PLANT_CD => :LS_PLANT_CD,
                    ls_out_flag => :LS_OUT_FLAG
                    )`;

    let binds = {
      LS_BATCH_NO: data.BATCH_NO ? data.BATCH_NO : "",
      LS_CD_PROC: data.CD_PROC ? data.CD_PROC : "",
      LS_PLANT_CD: data.PLANT ? data.PLANT : "",
      LS_OUT_FLAG: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    //console.log("binds",binds)
    //console.log("query",sql)
    const result = await query.executeQuery(sql, binds);
    console.log("proflag150", result);
    resData.push(result?.outBinds?.LS_OUT_FLAG);
    //console.log("resData: ", resData);
    return resData;
  } catch (error) {
    console.log("procedure error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const deleteTempData = async (data: any) => {
  try {
    console.log("deletedata", data);
    let sql = ` Delete V_BARE_PDO_TEMP 
                    where tbp_batch_no= :Batchno 
                    and  tbp_cd_proc= :curproc
                    and tbp_plant_cd= :plant `;
    let binds = {
      Batchno: data.BATCH_NO ? data.BATCH_NO : "",
      curproc: data.CD_PROC ? data.CD_PROC : "",
      plant: data.PLANT ? data.PLANT : "",
    };

    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log("delete error", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getFillData = async (rmBatch: any, pipeno: any, status: any) => {
  try {
    let sql = `SELECT TBP_BATCH_NO,TBP_PIPE_OD_10,TBP_PIPE_THK_10,TBP_PIPE_LNG_10,TBP_NO_MATNR ,
    TBP_VISUAL_INSP_80,
TBP_AMBT_TMP_100,
TBP_RH_100,
--TBP_DEW_TEMP_100,
TBP_WFT_F1_150,
TBP_WFT_F2_150,
TBP_WFT_F3_150,
TBP_WFT_F4_150,
TBP_WFT_T1_150,
TBP_WFT_T2_150,
TBP_WFT_T3_150,
TBP_WFT_T4_150,
TBP_ME_FEND_150,
TBP_UME_TEND_150,
TBP_RMUSE1_150,
TBP_RMUSE2_150,
TBP_RMUSE3_150,
TBP_RMUSE4_150,
TBP_RMUSE5_150,
TBP_BATCH1_150,
TBP_BATCH2_150,
TBP_BATCH3_150,
TBP_BATCH4_150,
TBP_BATCH5_150,
TBP_LINES_SPED_150,
--TBP_MIXPAINT_RATIO,
TBP_QUANTITY_150
    from v_bare_pdo 
                   where TBP_PAR_COIL_NO = '${rmBatch}'`;

    if (pipeno != "") {
      sql += ` AND TBP_BATCH_NO = '${pipeno}'  AND  TBP_CD_PROC = '1'`;
    } else {
      sql += ` AND TBP_BATCH_NO IN (select t.lom_id_batch from v_ldp_prodn t where t.lom_cd_status='${status}'
                     AND t.lom_id_par_coil_no = '${rmBatch}') AND TBP_CD_PROC = '1'`;
    }

    console.log("filldataqry150", sql);
    return await query.executeQuery(sql);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTataDate = async (prodEndDt: any) => {
  try {
    const sql = `select substr(F_Tatadate(
              TO_DATE(:prodEndDt,'YYYY-MM-DD HH24:MI')),1,1)
               shift,substr(F_Tatadate(TO_DATE(:prodEndDt,'YYYY-MM-DD HH24:MI')),2) prod_dt from dual`;
    const binds = {
      prodEndDt: prodEndDt,
    };
    return await query.executeQuery(sql, binds);
  } catch (error) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
