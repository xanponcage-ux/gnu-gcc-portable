import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

// export const getReportType = async () => {
//   try {
//     let sql: any = `SELECT SUBSTR(cd_desc,5) CD_DESC,CD_VALUE FROM V_CODES
//                     WHERE CD_TYPE = 'EPA340'
//                     AND CD_VALUE <> 'LS_FLAG'
//                     AND CD_DESC LIKE 'A%'
//                     ORDER BY CD_DESC`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getPlantCode = async () => {
//   try {
//     return getCommonPlantData();
//   }
//   catch (error: any) {
//     throw new Error.InternalServerError('Error');
//   }
// };

// export const getSourcePlant = async (data?: any) => {
//   try {
//     let sql: any = `SELECT distinct NVL(EIC_SOURCE_PLANT,EIC_CD_PLANT) src_plant FROM V_INPUT_COIL WHERE EIC_CD_EPA='${data?.plant}' ORDER BY 1`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getTableData = async (data: any) => {
//   try {
//     let value = data?.data;
//     let sql: any = `select tcy_cd_epa Plant,(SELECT DISTINCT EPL_EPA_DESC FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA =A.TCY_CD_EPA  ) Plant_Name, Round(sum(tcy_issueprod_wt),1) Issue_For_Production, Round(sum(tcy_prime_wt),1)  Prime, Round(sum(tcy_seconds_wt),1)  Seconds, Round(sum(tcy_scrap_wt),1)  Scrap, case
//                     WHEN SUM(tcy_issueprod_wt) > 0
//                     Then ROUND((SUM(tcy_prime_wt) /SUM(tcy_issueprod_wt))*100,1)
//                     ELSE  0 end Prime_Yield,case WHEN SUM(tcy_issueprod_wt) > 0
//                     Then ROUND(((SUM(tcy_prime_wt)+SUM(tcy_seconds_wt))/SUM(tcy_issueprod_wt))*100,1)
//                     ELSE  0  end Gross_Yield from V_COIL_YIELD A
//                     where tcy_yrmon IN '${value?.year}${value.month}'
//                     AND tcy_cd_epa = '${data?.plant}'
//                     group by tcy_cd_epa`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getyieldwisedata = async (data: any) => {
//   try {
//     let value = data?.data;
//     let sql: any = `SELECT TCY_YRMON Month, TCY_BATCH_ID Mother_Coil_ID, TCY_CD_EPA Plant, TCY_CD_COMP Company, TCY_MC_TDC Mother_Coil_TDC,TCY_MC_SEC1 Thickness, TCY_MC_SEC2 Width,
//     (select ( listagg( distinct EOM_SEC1||'X'||EOM_SEC2, ', ') WITHIN GROUP (ORDER BY 1)) sizes from v_epa_prodn where eom_cd_epa= A.TCY_CD_EPA AND EOM_ID_FIRST_PAR= A.TCY_BATCH_ID) Combination, TCY_MC_GRADE Mother_Coil_Grade, TCY_MC_PROD_CD Mother_Coil_Prod_Cd,
//     TCY_MC_CAT Mother_Coil_Catg, TCY_MC_MARK_CUST Mother_Coil_Mark_Cust, TCY_MC_INV_WT Mother_Coil_Weight, TCY_MC_CONSUM_WT Mother_Coil_Consumed_Wt, TCY_INPUT_WT Input_tonnage, TCY_ISSUEPROD_WT Issue_For_Production,
//     TCY_PRIME_WT Prime_Tonnage, TCY_SECONDS_WT Seconds_Tonnage, TCY_SCRAP_WT Scrap_Tonnage, TCY_RMDEF_SEC_WT RM_Defect_Sec, TCY_EPADEF_SEC_WT EPA_Defect_Sec, TCY_NOMIDEF_SEC_WT Nominal_Sec, TCY_PLNGDEF_SEC_WT Planning_Sec,
//     TCY_MKTDEF_SEC_WT Marketing_Sec, TCY_CSDDEF_SEC_WT CSD_Defect, TCY_UNACC_SEC_WT Unacc_Sec, TCY_RMDEF_SCRP_WT RM_Defect_Scrap, TCY_EPADEF_SCRP_WT EPA_Defect_Scrap, TCY_NOMIDEF_SCRP_WT Nominal_Scrap,
//     TCY_PLNGDEF_SCRP_WT Planning_Scrap, TCY_MKTDEF_SCRP_WT Marketing_Scrap, TCY_CSDDEF_SCRP_WT CSD_Defect_Scrap, TCY_UNACC_SCRP_WT Unacc_Scrap, TCY_PRIME_YLD Prime_Yield, TCY_GROSS_YLD Gross_Yield,
//     (select trim(CAD_DEF2_COMM) from v_coil_card where CAD_ID_COIL=A.TCY_BATCH_ID and CAD_DEF2_COMM like 'SLP%' and CAD_CD_COMPANY='1000' AND ROWNUM=1 ) Salvaging_remarks ,
//     (SELECT DISTINCT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_CD_EPA=A.TCY_CD_EPA AND EIC_ID_cOIL = A.TCY_BATCH_ID AND ROWNUM=1 ) Source_Plant
//     ,'' Source_Plant_Desc
//     From V_COIL_YIELD A, V_INPUT_COIL B
//     where tcy_yrmon IN '${value?.year}${value.month}'
//     AND A.TCY_BATCH_ID = B.EIC_ID_COIL  AND A.tcy_cd_epa =B.EIC_CD_EPA
//     AND tcy_cd_epa = '${data?.plant}' `;

//     if (value?.sourcePlant && value?.sourcePlant.length > 0) {
//       sql += ` AND B.EIC_SOURCE_PLANT = '${value?.sourcePlant}'`;
//     }
//     sql += ` ORDER BY  tcy_cd_epa,TCY_YRMON,TCY_BATCH_ID`;

//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getSecondsData = async (data?: any) => {
//   try {
//     let value = data?.data;
//     let sql: any = `SELECT SSY_ID_BATCH BATCH_ID,EOM_SEC1 FG_THK,EOM_SEC2 FG_WIDTH ,EOM_TDC_ACTL FG_TDC,EOM_CD_PROD FG_PROD_CD,SSY_CD_EPA PLANT,SSY_ID_COIL MOTHER_BATCH
//     ,EIC_TDC_ACTL MC_TDC ,EIC_CD_PROD MC_PRODCD,EIC_SEC1 MC_THK,EIC_SEC2 MC_WIDTH,EIC_MK_CUSTOMER MC_CUSTOMER,DECODE(EIC_SOURCE_PLANT,NULL,EIC_CD_PLANT,EIC_SOURCE_PLANT)SOURCE_PLANT
//     ,'' PRODUCT_TYPE  ,SSY_RSN_CAT,(SELECT DISTINCT ESR_RSN_DESC FROM V_SCRP_SEC_RSN WHERE ESR_cD_EPA=A.SSY_CD_EPA AND ESR_RSN_CAT=A.SSY_RSN_CAT AND ESR_RSN_CD=A.SSY_CD_RSN AND ROWNUM=1)RSN_DESC
//     ,SSY_MS_QTY TONN FROM V_SECSCR_YLDDTL A,V_EPA_PRODN B,V_INPUT_COIL C
//     WHERE A.SSY_CD_EPA=B.EOM_cD_EPA AND A.SSY_ID_BATCH=B.EOM_ID_BATCH AND A.SSY_CD_EPA=C.EIC_CD_EPA AND A.SSY_ID_COIL=C.EIC_ID_COIL
//     AND A.SSY_YEARMON IN '${value?.year}${value.month}'
//     AND A.SSY_CD_EPA = '${value?.plant}'
//     AND SSY_IND = 'A' order by PLANT`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

export const getyieldwisedata = async (data: any) => {
  try {
    let value = data ?.data
    let sql: any = `SELECT TCY_YRMON Month, TCY_BATCH_ID Mother_Coil_ID, TCY_CD_EPA Plant, TCY_CD_COMP Company, TCY_MC_TDC Mother_Coil_TDC,TCY_MC_SEC1 Thickness, TCY_MC_SEC2 Width,
    (select ( listagg( distinct EOM_SEC1||'X'||EOM_SEC2, ', ') WITHIN GROUP (ORDER BY 1)) sizes from v_epa_prodn where eom_cd_epa= A.TCY_CD_EPA AND EOM_ID_FIRST_PAR= A.TCY_BATCH_ID) Combination, TCY_MC_GRADE Mother_Coil_Grade, TCY_MC_PROD_CD Mother_Coil_Prod_Cd,
    TCY_MC_CAT Mother_Coil_Catg, TCY_MC_MARK_CUST Mother_Coil_Mark_Cust, TCY_MC_INV_WT Mother_Coil_Weight, TCY_MC_CONSUM_WT Mother_Coil_Consumed_Wt, TCY_INPUT_WT Input_tonnage, TCY_ISSUEPROD_WT Issue_For_Production,
    TCY_PRIME_WT Prime_Tonnage, TCY_SECONDS_WT Seconds_Tonnage, TCY_SCRAP_WT Scrap_Tonnage, TCY_RMDEF_SEC_WT RM_Defect_Sec, TCY_EPADEF_SEC_WT EPA_Defect_Sec, TCY_NOMIDEF_SEC_WT Nominal_Sec, TCY_PLNGDEF_SEC_WT Planning_Sec,
    TCY_MKTDEF_SEC_WT Marketing_Sec, TCY_CSDDEF_SEC_WT CSD_Defect, TCY_UNACC_SEC_WT Unacc_Sec, TCY_RMDEF_SCRP_WT RM_Defect_Scrap, TCY_EPADEF_SCRP_WT EPA_Defect_Scrap, TCY_NOMIDEF_SCRP_WT Nominal_Scrap,
    TCY_PLNGDEF_SCRP_WT Planning_Scrap, TCY_MKTDEF_SCRP_WT Marketing_Scrap, TCY_CSDDEF_SCRP_WT CSD_Defect_Scrap, TCY_UNACC_SCRP_WT Unacc_Scrap, TCY_PRIME_YLD Prime_Yield, TCY_GROSS_YLD Gross_Yield,
    (select trim(CAD_DEF2_COMM) from v_coil_card where CAD_ID_COIL=A.TCY_BATCH_ID and CAD_DEF2_COMM like 'SLP%' and CAD_CD_COMPANY='1000' AND ROWNUM=1 ) Salvaging_remarks ,
    (SELECT DISTINCT EIC_SOURCE_PLANT FROM V_INPUT_COIL WHERE EIC_CD_EPA=A.TCY_CD_EPA AND EIC_ID_cOIL = A.TCY_BATCH_ID AND ROWNUM=1 ) Source_Plant
    ,'' Source_Plant_Desc
    From V_COIL_YIELD A, V_INPUT_COIL B
    where tcy_yrmon IN '${value ?.year}${value.month}'
    AND A.TCY_BATCH_ID = B.EIC_ID_COIL  AND A.tcy_cd_epa =B.EIC_CD_EPA  
    AND tcy_cd_epa = '${data ?.plant}' `

    if (value ?.sourcePlant && value ?.sourcePlant.length > 0) {
      sql += ` AND B.EIC_SOURCE_PLANT = '${value ?.sourcePlant}'`

    }
    sql += ` ORDER BY  tcy_cd_epa,TCY_YRMON,TCY_BATCH_ID`;


    return await query(sql);
  }
  catch (error: any) {
    throw new Error.InternalServerError('Error');
  }
};


export const getSecondsData = async (data?: any) => {
  try {
    let value = data ?.data
    let sql: any = `SELECT SSY_ID_BATCH BATCH_ID,EOM_SEC1 FG_THK,EOM_SEC2 FG_WIDTH ,EOM_TDC_ACTL FG_TDC,EOM_CD_PROD FG_PROD_CD,SSY_CD_EPA PLANT,SSY_ID_COIL MOTHER_BATCH
    ,EIC_TDC_ACTL MC_TDC ,EIC_CD_PROD MC_PRODCD,EIC_SEC1 MC_THK,EIC_SEC2 MC_WIDTH,EIC_MK_CUSTOMER MC_CUSTOMER,DECODE(EIC_SOURCE_PLANT,NULL,EIC_CD_PLANT,EIC_SOURCE_PLANT)SOURCE_PLANT
    ,'' PRODUCT_TYPE  ,SSY_RSN_CAT,(SELECT DISTINCT ESR_RSN_DESC FROM V_SCRP_SEC_RSN WHERE ESR_cD_EPA=A.SSY_CD_EPA AND ESR_RSN_CAT=A.SSY_RSN_CAT AND ESR_RSN_CD=A.SSY_CD_RSN AND ROWNUM=1)RSN_DESC
    ,SSY_MS_QTY TONN FROM V_SECSCR_YLDDTL A,V_EPA_PRODN B,V_INPUT_COIL C
    WHERE A.SSY_CD_EPA=B.EOM_cD_EPA AND A.SSY_ID_BATCH=B.EOM_ID_BATCH AND A.SSY_CD_EPA=C.EIC_CD_EPA AND A.SSY_ID_COIL=C.EIC_ID_COIL
    AND A.SSY_YEARMON IN '${value ?.year}${value.month}'
    AND A.SSY_CD_EPA = '${value ?.plant}'
    AND SSY_IND = 'A' order by PLANT`;
    return await query(sql);
  }
  catch (error: any) {
    throw new Error.InternalServerError('Error');
  }
};

export const getScrapData = async (data?: any) => {
  try {
    let value = data ?.data
    let sql: any = `SELECT SSY_ID_BATCH BATCH_ID,EOM_SEC1 FG_THK,EOM_SEC2 FG_WIDTH ,EOM_TDC_ACTL FG_TDC,EOM_CD_PROD FG_PROD_CD,SSY_CD_EPA PLANT,SSY_ID_COIL MOTHER_BATCH
    ,EIC_TDC_ACTL MC_TDC ,EIC_CD_PROD MC_PRODCD,EIC_SEC1 MC_THK,EIC_SEC2 MC_WIDTH,EIC_MK_CUSTOMER MC_CUSTOMER,DECODE(EIC_SOURCE_PLANT,NULL,EIC_CD_PLANT,EIC_SOURCE_PLANT)SOURCE_PLANT
    ,'' PRODUCT_TYPE
    ,SSY_RSN_CAT,(SELECT DISTINCT ESR_RSN_DESC FROM V_SCRP_SEC_RSN WHERE ESR_cD_EPA=A.SSY_CD_EPA AND ESR_RSN_CAT=A.SSY_RSN_CAT AND ESR_RSN_CD=A.SSY_CD_RSN AND ROWNUM=1)RSN_DESC
    ,SSY_MS_QTY TONN
    FROM V_SECSCR_YLDDTL A,V_EPA_PRODN B,V_INPUT_COIL C
    WHERE A.SSY_CD_EPA=B.EOM_cD_EPA AND A.SSY_ID_BATCH=B.EOM_ID_BATCH AND A.SSY_CD_EPA=C.EIC_CD_EPA AND A.SSY_ID_COIL=C.EIC_ID_COIL
    AND A.SSY_YEARMON IN '${value ?.year}${value.month}'
    AND A.SSY_CD_EPA = '${value ?.plant}'
    AND SSY_IND = 'B' order by PLANT`;
    return await query(sql);
  }
  catch (error: any) {
    throw new Error.InternalServerError('Error');
  }
};
export const getInvData = async (data: any) => {
  try {
    let binds: any = {
      plant: data?.epa
    }
    let sql: any = `SELECT EOM_ID_BATCH BATCH_ID
    ,EOM_CD_STATUS STATUS
    ,EOM_CD_PROD PROD
    ,EOM_CD_QLTY_ACTL QLTY
    ,SUBSTR(F_GET_GRADE (EOM_CD_EPA, EOM_ID_BATCH, EOM_ID_ORDER_CUS , EOM_ID_ORD_ITEM_CUS,NULL),3) GRADE_DESC
    ,EOM_SEC1 THICK
    ,EOM_SEC2 WIDTH
    ,EOM_LENGTH LENGTH
    ,EOM_TDC_ACTL ACTUAL_TDC
    ,EOM_MS_GROSS_CAL NET_WT_PCS
    ,EOM_MS_GROSS_ACTL GROSS_WT_PCS
    ,EOM_MS_SCRAP SCRAP_WT
    ,EOM_FL_SEND_SAP SEND_TO_SAP
    ,EOM_TS_CREATION PRODN_ARRIVAL_DATE
    ,ROUND(SYSDATE-EOM_TS_CREATION) AGE_DAYS
    ,EOM_NO_CAST CAST_NO
    ,EOM_ID_PAR_COIL_NO PARENT_CHARG
    ,EOM_ID_FIRST_PAR MOTHER_CHARG
    ,ROUND(SYSDATE-EIC_TS_CREATION) MOTHER_CHARG_AGE
    ,C.EIC_MS_GROSS_ACTL MOTHER_WT
    ,C.EIC_NO_MATNR RAW_MATRL_NO
    ,EOM_CD_PREV_PROC PREV_PROC
    ,EOM_CD_CURR_PROC CURR_PROC
    ,EOM_CD_NEXT_PROC NEXT_PROC
    ,EOM_PASSED_PROC PLAN_PROC
    ,EOM_PLANNED_PROC PASSED_PROC
    ,EOM_ID_ORDER_CUS CUSTOMER_ORDER
    ,EOM_ID_ORD_ITEM_CUS ITEM
    ,ENC_ORDER_TYPE ORDER_TYPE
    ,ENC_CD_END_CUST CUSTOMER_CODE
    ,ENC_CUST_NAME CUSTOMER_NM
    ,ENC_MARK_CUST MK_CUST_CD
    ,ENC_MARK_CUST_NAME MK_CUST_NM
    ,ENC_NO_TRACKING TRACKING_NO
    ,NVL(EOM_NO_MATNR,ENC_NO_MATNR) FG_MATERIAL_NO
    ,EOM_ID_ORDER SCO_ORDER
    ,EOM_NO_ITEM SCO_ITEM
    ,EOM_NO_PIECES NO_PIECES
    ,EOM_NO_INVOICE INVOICE_NO
    ,TO_CHAR(EOM_DT_INVOICE, 'DD-MON-YY HH24:MI:SS') INVOICE_DATE
    ,(SELECT DISTINCT (LPAD(ENC_ROAD_DEST,6,'0')) FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) ROAD_DESTN 
    ,(SELECT DISTINCT ENC_ROADDEST_DESC FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) ROAD_DEST_DESCRIPTION
     ,(SELECT DISTINCT (LPAD(ENC_RAIL_DEST,6,0)) FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) RAIL_DESTN
     ,(SELECT DISTINCT ENC_RAILDEST_DESC FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA = EOM_CD_EPA  AND ENC_ID_ORDER = EOM_ID_ORDER_CUS AND ENC_NO_ITEM=EOM_ID_ORD_ITEM_CUS) RAIL_DESTN_DESCRIPTION
    ,EOM_CD_YRD YARD
    ,EOM_ID_LOC_X LOC_X
    ,EOM_ID_LOC_Y LOC_Y
    ,EOM_ID_POS LOC_Z
    ,EOM_CD_EPA SPC
    ,(SELECT EPL_EPA_DESC FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA = A.EOM_CD_EPA AND ROWNUM=1) SPC_NAME
    ,EOM_OPER_COMMENT OPERATOR_REMARKS
    ,EOM_OPER_ID OPERATOR_ID
    ,( SELECT DISTINCT MAX(TRIM(REPLACE(CAD_DEF2_COMM, CHR(10),' '))) FROM V_COIL_CARD WHERE CAD_ID_COIL = A.EOM_ID_FIRST_PAR AND CAD_DEF2_COMM LIKE 'SLP%' ) SALVAGING_REMARKS
    --,(SELECT DISTINCT EHR_CD_RSN_HOLD|| '-' || (SELECT DISTINCT CD_DESC FROM V_EPA_HOLD_RSN WHERE CD_HOLD = E.EHR_CD_RSN_HOLD AND CD_COMP = (SELECT DISTINCT EPL_CD_COMP  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA = E.EHR_CD_EPA)) FROM V_EPA_MATL_HOLD_RLS E WHERE EHR_CD_EPA=A.EOM_CD_EPA AND EHR_ID_BATCH=A.EOM_ID_BATCH AND EHR_TS_HOLD = ( SELECT MAX(EHR_TS_HOLD) FROM V_EPA_MATL_HOLD_RLS WHERE EHR_CD_EPA=E.EHR_CD_EPA AND EHR_ID_BATCH=E.EHR_ID_BATCH) AND ROWNUM=1) HOLD_CODE_REASON
    --,(SELECT DISTINCT  EHR_OP_REMARKS FROM V_EPA_MATL_HOLD_RLS E WHERE EHR_CD_EPA=A.EOM_CD_EPA AND EHR_ID_BATCH=A.EOM_ID_BATCH AND EHR_TS_HOLD = ( SELECT DISTINCT MAX(EHR_TS_HOLD) FROM V_EPA_MATL_HOLD_RLS WHERE EHR_CD_EPA=E.EHR_CD_EPA AND EHR_ID_BATCH=E.EHR_ID_BATCH)AND ROWNUM=1) HOLD_OPERATOR_REMARKS
    ,EIC_TDC_AIM MOTHER_BATCH_AIM_TDC
    ,EIC_TDC_ACTL MOTHER_BATCH_TDC
    ,EIC_CD_PROD MOTHER_BATCH_PROD_CD
    ,NVL(EIC_SOURCE_PLANT,EIC_CD_PLANT) SOURCE_PLANT
    ,(SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=A.EOM_ID_FIRST_PAR And TCO_CAST_NO=A.EOM_NO_CAST And TCO_TEST_PARA IN ('YS','LYS') AND ROWNUM=1) LYS
    ,(SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=A.EOM_ID_FIRST_PAR And TCO_CAST_NO=A.EOM_NO_CAST And TCO_TEST_PARA IN ('UTS') AND ROWNUM=1) UTS
    ,ENC_CD_SHIP_TO_PRTY SHIP_TO_PARTY_CD
    ,ENC_SHIP_TO_PRTY_DESC SHIP_TO_PARTY_DESC  
    from v_epa_prodn A,v_end_cust_ord_epa B, v_input_coil C    
    where eom_cd_epa = enc_cd_epa(+)    
    and EOM_ID_ORDER_CUS = enc_id_order(+)    
    and  EOM_ID_ORD_ITEM_CUS = enc_no_item(+)    
    and eom_cd_epa = eic_cd_Epa    
    and eom_id_first_par = eic_id_coil    
    and eom_cd_Epa='${data?.epa}'    
    and eom_cd_status not like '%L'    
    `;
     if(data.batch && data.batch?.length > 0) {
      sql += ` and eom_id_batch='${data?.batch}'`;
      binds['batch'] = data?.batch;
    }
    if(data.mBatch && data.mBatch?.length > 0) {
      sql += ` and eom_id_first_par='${data?.mBatch}'`;
      binds['mBatch'] = data?.mBatch;
    }
    if(data.materialNo && data.materialNo?.length > 0) {
      sql += ` and (EOM_NO_MATNR='${data?.materialNo}' OR ENC_NO_MATNR='${data?.materialNo}')`;
      binds['materialNo'] = data?.materialNo;
    } 
  if(data.prodCd && data.prodCd?.length > 0) {
    sql += ` AND EOM_CD_PROD = '${data?.prodCd}'`;
    binds['prodCd'] = data?.prodCd;
  }
  if(data.tdc && data.tdc?.length > 0) {
    sql += ` AND EOM_TDC_ACTL = '${data?.tdc}'`;
    binds['tdc'] = data?.tdc;
  }
  if (data?.productionDateFr && data?.productionDateTo) {
    sql += ` AND ENC_DT_ORD_CREATE BETWEEN NVL('${data?.productionDateFr}','01-JAN-1900') AND NVL('${data?.productionDateTo}','31-DEC-9999')` 
    binds.productionDateFr = data?.productionDateFr;
    binds.productionDateTo = data?.productionDateTo;
  }
  if (data?.deliveryDateFr && data?.deliveryDateTo) {
    sql += ` AND ENC_DT_DELV BETWEEN NVL('${data?.deliveryDateFr}','01-JAN-1900') AND NVL('${data?.deliveryDateTo}','31-DEC-9999')` 
    binds.deliveryDateFr = data?.deliveryDateFr;
    binds.deliveryDateTo = data?.deliveryDateTo;
  }
  if ((data?.ThickFr && data?.ThickFr != "")) {
    sql += ` AND ENC_SEC1_MIN >= nvl('${data?.ThickFr}', enc_sec1_min)` 
    binds["ThickFr"] = data?.ThickFr;
  }
  if (data?.ThickTo && data?.ThickTo !== "") {
    sql += `AND ENC_SEC1_MAX <= nvl('${data?.ThickTo}', ENC_SEC1_MAX) `
    binds["ThickTo"] = data?.ThickTo;
  }
  if ((data?.widthFr && data?.widthFr != "")) {
    sql += ` AND ENC_SEC2_MIN >= nvl('${data?.widthFr}', ENC_SEC2_MIN)` 
    binds["widthFr"] = data?.widthFr;
  }
  if (data?.widthTo && data?.widthTo !== "") {
    sql += `AND ENC_SEC2_MAX <= nvl('${data?.widthTo}', ENC_SEC2_MAX)`;
    binds["widthTo"] = data?.widthTo;
  }
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError(error);
  }
};
export const getInvMonData = async (data: any) => {
  try {
    let binds: any = {
      plant: data ?.epa
    }
    let sql: any = `SELECT
    sim_id_batch	BATCH_ID	,
   sim_cd_epa	SPC	,
   sim_cd_status	STATUS	,
   sim_cd_prod	PROD	,
   sim_cd_qlty_actl	QLTY	,
   sim_grade_desc	GRADE_DESC	,
   sim_sec1	THICK	,
   sim_sec2	WIDTH	,
   sim_length	LENGTH	,
   sim_tdc_actl	ACTUAL_TDC	,
   sim_ms_gross_cal	NET_WT_PCS	,
   sim_ms_gross_actl	GROSS_WT_PCS	,
   sim_scrap_wt	SCRAP_WT	,
   sim_fl_send_sap	SEND_TO_SAP	,
   sim_prodn_arrival_date	PRODN_ARRIVAL_DATE	,
   sim_age_days	AGE_DAYS	,
   sim_no_cast	CAST_NO	,
   sim_id_par_coil_no	PARENT_CHARG	,
   sim_id_first_par	MOTHER_CHARG	,
   sim_mother_charg_age	MOTHER_CHARG_AGE	,
   sim_mother_wt	MOTHER_WT	,
   sim_raw_matrl_no	RAW_MATRL_NO	,
   sim_cd_prev_proc	PREV_PROC	,
   sim_cd_curr_proc	CURR_PROC	,
   sim_cd_next_proc	NEXT_PROC	,
   sim_passed_proc	PLAN_PROC	,
   sim_planned_proc	PASSED_PROC	,
   sim_id_order_cus	CUSTOMER_ORDER	,
   sim_id_ord_item_cus	ITEM	,
   sim_order_type	ORDER_TYPE	,
   sim_cd_end_cust	CUSTOMER_CODE	,
   sim_cust_name	CUSTOMER_NM	,
   sim_mark_cust	MK_CUST_CD	,
   sim_mark_cust_name	MK_CUST_NM	,
   sim_no_tracking	TRACKING_NO	,
   sim_no_matnr	FG_MATERIAL_NO	,
   sim_id_order	SCO_NO	,
   sim_no_item	SCO_ITEM	,
   sim_no_pieces	NO_PIECES	,
   sim_no_invoice	INVOICE_NO	,
   sim_dt_invoice	INVOICE_DATE	,
   sim_road_destn	ROAD_DESTN	,
   sim_road_dest_description	ROAD_DEST_DESCRIPTION	,
   sim_rail_destn	RAIL_DESTN	,
   sim_rail_destn_description	RAIL_DESTN_DESCRIPTION	,
   sim_cd_yrd	YARD	,
   sim_id_loc_x	LOC_X	,
   sim_id_loc_y	LOC_Y	,
   sim_id_pos	LOC_Z	,
   sim_spc_name	SPC_NAME	,
   sim_oper_comment	OPERATOR_REMARKS	,
   sim_oper_id	OPERATOR_ID	,
   sim_salvaging_remarks	SALVAGING_REMARKS	,
   sim_hold_code_reason	HOLD_CODE_REASON	,
   sim_hold_operator_remarks	HOLD_OPERATOR_REMARKS	,
   sim_mother_batch_aim_tdc	MOTHER_BATCH_AIM_TDC	,
   sim_mother_batch_tdc	MOTHER_BATCH_TDC	,
   sim_mother_batch_prod_cd	MOTHER_BATCH_PROD_CD	,
   sim_source_plant	SOURCE_PLANT	,
   sim_lys	LYS	,
   sim_uts	UTS	,
   sim_cd_ship_to_prty	SHIP_TO_PARTY_CD	,
   sim_ship_to_prty_desc	SHIP_TO_PARTY_DESC	
FROM
    v_spc_inven_monthly
WHERE
    sim_cd_epa = '${data ?.epa}'
    and sim_year_mon = (select to_char(sysdate,'yyyymm') from dual)`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};

// export const getData = async (data: any) => {
//   try {
//     if (data?.type === "getData") {
//       if (data.Plant) {
//         return {
//           batch: await ResponceData(
//             await query(`
//             select distinct EOM_ID_BATCH 
//             from v_epa_prodn where eom_cd_status in ('VB','VF')
//             AND EOM_CD_EPA = ${data.Plant}
//             `)
//           ),
//           ordTypeData: await ResponceData(
//             await query(
//               `SELECT DISTINCT ENC_ORDER_TYPE FROM V_END_CUST_ORD_EPA 
//                 WHERE ENC_CD_EPA=${data.Plant} and ENC_ST_ORDER='A' ORDER  BY 1`
//             )
//           ),
//           custData: await ResponceData(
//             await query(
//               `SELECT DISTINCT ENC_CD_END_CUST,ENC_CD_END_CUST||' - '||ENC_CUST_NAME ENC_CUST_NAME 
//                 FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA=${data.Plant} AND  ENC_ST_ORDER='A' AND TRIM(ENC_CD_END_CUST) IS NOT NULL ORDER BY 1`
//             )
//           ),
//         };
//       } else {
//         return await query(`
//           SELECT DISTINCT EPL_CD_EPA, EPL_CD_EPA||'-'||EPL_EPA_DESC EPL_CD_EPA_DESC 
//           FROM V_EPA_PROC_LINE
//           where EPL_BUSI_ROLE IN (SELECT DISTINCT (SUBSTR(uug_id_usergrp,2,4)) FROM v_user_user_group
//           WHERE uug_id_users = '${data.pno}') AND EPL_ACTIVE_PLANT_FL='A' ORDER BY EPL_CD_EPA
//         `);
//       }
//     }
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getDispatchData = async (data: any) => {
//   try {
//     let binds: any = {
//       plant: data?.epa,
//     };
//     if (data?.type === "dispatchSummary") {
//       let sqlDisSummary = `
//       SELECT TO_CHAR(EOM_TS_CREATION, 'YYYY-MM-DD') DT_LOAD, SUM(EOM_MS_PIECE_ACTL) MS_WT, 0 SCRAP_WT
// 	   	 FROM V_EPA_PRODN,V_END_CUST_ORD_EPA--sapr3.ympct_tub_matl@crmrup--Commented by vikash via cmr 2013/08/65/J1/T2
// 		   WHERE EOM_CD_EPA = ${data.plant} 
// 		-- AND EOM_CD_STATUS='WL'
//       AND NVL(EOM_ID_ORDER_CUS,' ')= ENC_ID_ORDER(+) 
//       AND NVL(EOM_ID_ORD_ITEM_CUS,0) = ENC_NO_ITEM(+) 
//      `;
//       if (data?.dispatchDateFr && data?.dispatchDateFr?.length > 0) {
//         sqlDisSummary += `AND TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD') BETWEEN '${data.dispatchDateFr}' AND NVL('${data.dispatchDateTo}','${data.dispatchDateFr}')`;
//       }
//       if (data?.tdc && data?.tdc?.length > 0) {
//         sqlDisSummary += `AND (EOM_TDC_ACTL=NVL('${data.tdc}',EOM_TDC_ACTL) OR EOM_TDC_ACTL IS NULL)`;
//       }
//       if (data?.qltyCd && data?.qltyCd?.length > 0) {
//         sqlDisSummary += `AND (EOM_CD_QLTY_ACTL=NVL('${data.qltyCd}',EOM_CD_QLTY_ACTL) OR EOM_CD_QLTY_ACTL IS NULL)`;
//       }
//       if (data?.ThickFr && data?.ThickFr?.length > 0) {
//         sqlDisSummary += `AND EOM_SEC1 BETWEEN NVL('${data.ThickFr}',EOM_SEC1) AND NVL('${data.ThickTo}',NVL('${data.ThickFr}',EOM_SEC1))`;
//       }
//       sqlDisSummary += ` GROUP BY TO_CHAR(EOM_TS_CREATION, 'YYYY-MM-DD')`;
//       return await query(sqlDisSummary);
//     } else if (data?.type === "dispatchDetails") {
//       let sql: any = `   SELECT EOM_ID_BATCH,EOM_CD_PROD, TO_CHAR(EOM_TS_CREATION, 'DD-MON-YY HH24:MI:SS') DT_LOAD,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS,
//       EOM_CD_QLTY_ACTL,EOM_SEC1 THICK,EOM_SEC2 WIDTH,EOM_TDC_ACTL,EOM_NO_INVOICE,TO_CHAR(EOM_DT_INVOICE, 'DD-MON-YY HH24:MI:SS') EOM_DT_INVOICE,EOM_NO_PIECES,
//       EOM_MS_PIECE_ACTL NET_WT,EOM_MS_GROSS_CAL GROSS_WT,EOM_LENGTH,EOM_CD_EPA,EOM_NO_MATNR,
//       (select MAKTX from V_MAKT where MANDT = '600' and MATNR = EOM_NO_MATNR and rownum = 1 ) MATNR_DESC, EOM_MK_CUSTOMER,
//       EOM_ID_FIRST_PAR,ENC_ORDER_TYPE,ENC_ORD_DESC, TO_CHAR(ENC_DT_ORD_CREATE, 'DD-MON-YY HH24:MI:SS') ENC_DT_ORD_CREATE,ENC_DESPATCH_WK ,ENC_CUST_NAME,ENC_MARK_CUST_NAME,
//       ENC_IDIA,ENC_FRT_IND,EOM_DELV_NO,(SELECT MIN(EPR_TS_CREATION) FROM V_EPA_LINE_PRODN WHERE EPR_CD_EPA = EOM_CD_EPA
//       AND EPR_ID_BATCH = EOM_ID_BATCH) BTCH_CRT_DATE
//       FROM V_EPA_PRODN,V_END_CUST_ORD_EPA     
//       WHERE  EOM_ID_ORDER_CUS    = ENC_ID_ORDER(+)
//       AND EOM_ID_ORD_ITEM_CUS = ENC_NO_ITEM(+)
//       AND EOM_CD_EPA = '${data?.epa}' 
//   --  AND EOM_CD_STATUS = 'WL'
//   --  AND EOM_ID_ORDER_CUS   = NVL(:NBT_ORDER,EOM_ID_ORDER_CUS)
//   --  AND EOM_ID_ORD_ITEM_CUS = NVL(:NBT_ITEM,EOM_ID_ORD_ITEM_CUS)
//       AND TO_CHAR(TRUNC(EOM_TS_CREATION),'YYYY-MM-DD') = '${data?.dt_load}'      
//       `;
//       if (data.prodCd && data.prodCd?.length > 0) {
//         sql += `AND (EOM_CD_PROD = NVL('${data?.prodCd}',EOM_CD_PROD) OR EOM_CD_PROD IS NULL) `;
//         binds["prodCd"] = data?.prodCd;
//       }
//       if (data.tdc && data.tdc?.length > 0) {
//         sql += `AND (EOM_TDC_ACTL = NVL('${data?.tdc}',EOM_TDC_ACTL) OR EOM_TDC_ACTL IS NULL) `;
//         binds["tdc"] = data?.tdc;
//       }
//       if (data.qltyCd && data.qltyCd?.length > 0) {
//         sql += `AND (EOM_CD_QLTY_ACTL = NVL('${data?.qltyCd}',EOM_CD_QLTY_ACTL) OR EOM_CD_QLTY_ACTL IS NULL) `;
//         binds["qltyCd"] = data?.qltyCd;
//       }
//       if (data?.dispatchDateFr && data?.dispatchDateTo) {
//         sql += ` AND TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD') BETWEEN '${data?.dispatchDateFr}' AND '${data?.dispatchDateTo}')`;
//         binds.dispatchDateFr = data?.dispatchDateFr;
//         binds.dispatchDateTo = data?.dispatchDateTo;
//       }
//       if (data?.ThickFr && data?.ThickFr != "") {
//         sql += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFr}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFr}',EOM_SEC1))`;
//         binds["ThickFr"] = data?.ThickFr;
//         binds["ThickTo"] = data?.ThickTo;
//       }
//       if (data?.widthFr && data?.widthFr != "") {
//         sql += ` AND EOM_SEC2 BETWEEN NVL('${data?.widthFr},EOM_SEC2) AND NVL('${data?.widthTo},NVL('${data?.widthFr},EOM_SEC2)) `;
//         binds["widthFr"] = data?.widthFr;
//         binds["widthTo"] = data?.widthTo;
//       }
//       sql += ` ORDER BY TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD'),EOM_ID_BATCH `;

//       return await query(sql);
//     } else if (data?.type === "batchDetails") {
//       let sql: any = `SELECT EOM_ID_BATCH,EOM_CD_PROD, TO_CHAR(EOM_TS_CREATION, 'DD-MON-YY HH24:MI:SS') DT_LOAD ,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS , 
//         EOM_CD_QLTY_ACTL,EOM_SEC1,EOM_SEC2,EOM_TDC_ACTL,EOM_NO_INVOICE,EOM_DT_INVOICE,
//         EOM_NO_PIECES,EOM_MS_PIECE_ACTL mass,EOM_MS_GROSS_CAL gross,
//         EOM_LENGTH,EOM_CD_EPA,EOM_NO_MATNR,EOM_MK_CUSTOMER,EOM_ID_FIRST_PAR,ENC_ORDER_TYPE
//         FROM V_EPA_PRODN,V_END_CUST_ORD_EPA
//         WHERE 
//         EOM_ID_ORDER_CUS 		= ENC_ID_ORDER(+)
//         AND EOM_ID_ORD_ITEM_CUS = ENC_NO_ITEM(+)
//         AND EOM_CD_EPA = '${data?.epa}' 
//   --  AND EOM_CD_STATUS = 'WL'
//       AND TO_CHAR(TRUNC(EOM_TS_CREATION),'YYYY-MM-DD') = '${data?.dt_load}'    
//       `;
//       return await query(sql);
//     }
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getEpa08 = async () => {
//   try {
//     return getCommonPlantData();
//   } catch (error: any) {
//     console.log("err", error)
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getOrderData08 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT SOI_ID_ORDER
//   FROM
//     V_SCO_ORDER_ITEM`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log("err", error)
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getNoEnd08 = async () => {
//   try {
//     const sql: any = `SELECT DISTINCT SOI_NO_END_MATNR FROM V_SCO_ORDER_ITEM`;
//     return await query(sql);
//   } catch (error: any) {

//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getNoInp08 = async () => {
//   try {
//     const sql: any = `SELECT DISTINCT SOI_NO_INP_MATNR FROM V_SCO_ORDER_ITEM`;
//     return await query(sql);
//   } catch (error: any) {

//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getData08 = async (data: any) => {
//   try {
//     let binds: any = {}

//     let sql: any = `SELECT
//     SOI_ID_ORDER ORDER_ID,
//     SOI_NO_ITEM ITEM_NO,
//     SOI_NO_END_MATNR END_MATNR_NO,
//     SOI_END_PROD_DESC END_PROD_DESC,
//     SOI_CD_PROD CD_PROD,
//     SOI_CD_QLTY CD_QLTY,
//     SOI_SEC1_MIN THICKNESS_MIN,
//     SOI_SEC1_MAX THICKNESS_MAX,
//     SOI_SEC2_MIN WIDTH_MIN,
//     SOI_SEC2_MAX WIDTH_MAX,
//     SOI_LENGTH_MIN LENGTH_MIN,
//     SOI_LENGTH_MAX LENGTH_MAX,
//     SOI_QUANTITY QUANTITY,
//     SOI_PRICE PRICE,
//     SOI_CD_BASE_QLTY CD_BASE_QLTY,
//     SOI_CD_EPA CD_EPA,
//     SOI_NO_TRACKING TRACKING_NO,
//     SOI_DT_DELIVERY DELIVERY_DT,
//     SOI_CD_STATUS CD_STATUS,
//     SOI_ID_USER ID_USER,
//     SOI_DT_ORDER ORDER_DT,
//     SOI_CD_PUR_GRP CD_PUR_GRP,
//     SOI_CD_TYPE_ORDER CD_TYPE_ORDER,
//     SOI_NO_INP_MATNR NO_INP_MATNR,
//     SOI_NO_TDC TDC_NO,
//     SOI_VAL_START_DT VAL_START_DT,
//     SOI_VAL_END_DT VAL_END_DT,
//     SOI_UOM UOM,
//     SOI_CD_COMP CD_COMP,
//     SOI_CD_PROCESS CD_PROCESS,
//     SOI_IDIA IDIA,
//     SOI_ODIA ODIA,
//     SOI_MAT_CHAR MAT_CHAR,
//     SOI_INP_MATNR1
//     FROM
//     V_SCO_ORDER_ITEM`

//     if (data.epa && data.epa?.length > 0) {
//       sql += ` Where SOI_CD_EPA = '${data?.epa}'`;
//       binds['epa'] = data?.epa;
//     }
//     if (data.order && data.order?.length > 0) {
//       sql += ` AND SOI_ID_ORDER = '${data?.order}'`;
//       binds['order'] = data?.order;
//     }
//     if (data.endmaterialNo && data.endmaterialNo?.length > 0) {
//       sql += ` AND SOI_NO_END_MATNR = '${data?.endmaterialNo}'`;
//       binds['endmaterialNo'] = data?.endmaterialNo;
//     }
//     if (data.inpmaterialNo && data.inpmaterialNo?.length > 0) {
//       sql += ` AND SOI_NO_INP_MATNR = '${data?.inpmaterialNo}'`;
//       binds['inpmaterialNo'] = data?.inpmaterialNo;
//     }
//     return await query(sql);
//   } catch (error: any) {
//     console.log("err", error)
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getPlantData = async (data?: any) => {
//   try {
//     return getCommonPlantData();
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getBatchData = async (data?: any) => {
//   try {
//     let sql: any = `select distinct EICA_ID_COIL  from v_input_coil_aud`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getBatchData2 = async (data?: any) => {
//   try {
//     let sql: any = `select distinct EOMA_ID_BATCH from v_epa_prodn_aud`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getOrderData = async (data?: any) => {
//   try {
//     let sql: any = `select distinct  ENCA_ID_ORDER from v_end_cust_ord_epa_aud`;
//     return await query(sql);
//   }
//   catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError('Error');
//   }
// };

// export const getInputCoilAudit = async (data?: any) => {
//   try {
//     let sql: any = `select EICA_ID_COIL,EICA_COLUMN_NAME,
//                     EICA_OLD_VALUE,EICA_NEW_VALUE,
//                     EICA_USERID,EICA_TIMESTAMP_CHNG,
//                     EICA_ACTION from v_input_coil_aud
//                     where EICA_ID_COIL = '${data?.batchId}'
//                     and EICA_NEW_VALUE = '${data?.plant}'`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getProductionAudit = async (data?: any) => {
//   try {
//     let sql: any = `select EOMA_ID_BATCH,EOMA_COLUMN_NAME,
//                     EOMA_OLD_VALUE,EOMA_NEW_VALUE,
//                     EOMA_USERID,EOMA_TIMESTAMP_CHNG,
//                     EOMA_ACTION  from v_epa_prodn_aud
//                     where EOMA_ID_BATCH = '${data?.batchId}'
//                     and EOMA_NEW_VALUE = '${data?.plant}'`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const getCustOrdAudit = async (data?: any) => {
//   try {
//     let sql: any = `SELECT ENCA_ID_ORDER,ENCA_NO_ITEM,
//                     ENCA_COLUMN_NAME,ENCA_OLD_VALUE,
//                     ENCA_NEW_VALUE,ENCA_USERID,
//                     ENCA_TIMESTAMP_CHNG,ENCA_ACTION
//                     FROM v_end_cust_ord_epa_aud
//                      WHERE ENCA_ID_ORDER = '${data?.orderId}'
//                      AND ENCA_NEW_VALUE = '${data?.plant}'`;
//     return await query(sql);
//   } catch (error: any) {
//     console.log(error);
//     throw new Error.InternalServerError("Error");
//   }
// };
