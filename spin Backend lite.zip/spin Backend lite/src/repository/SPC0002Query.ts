import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getProcLineData02 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT
          EPL_ACTIVE_PLANT_FL,
          EPL_ACTIVITY_FLAG,
          EPL_ACTIVITY_NM,
          EPL_ACTIVITY_TIME,
          EPL_ADDRESS,
          EPL_BUSINESS_UNIT,
          EPL_BUSI_ROLE,
          EPL_CD_COMP,
          EPL_CD_CUST,
          EPL_CD_EPA,
          EPL_CD_PROCESS,
          EPL_CONSP_FLAG,
          EPL_ID_PRINTER,
          EPL_NO_PROC_SEQ,
          EPL_PLNG_FLAG,
          EPL_PROC_LINE_DESC,
          EPL_PRODUCTION_TYPE,
          EPL_REM1,
          EPL_REM2,
          EPL_REM3,
          EPL_SAP_INTERFACE_IND,
          EPL_SERVER,
          NVL(EPL_STOR_LOC, 0) EPL_STOR_LOC,
          EPL_THK_TOL_FLAG,
          EPL_URL,
          EPL_EPA_DESC,
          EPL_PROC_LINE_DESC
        FROM
          V_EPA_PROC_LINE
        WHERE EPL_CD_EPA = :code `;
    if (data.process && data.process?.length > 0) {
      sql += ` AND EPL_CD_PROCESS = :process`;
      binds["process"] = data?.process;
    }
    if (data.flag && data.flag?.length > 0) {
      sql += ` AND EPL_ACTIVE_PLANT_FL = :flag`;
      binds["flag"] = data?.flag;
    }
    sql += " ORDER BY EPL_NO_PROC_SEQ";

    return await query(sql, binds);
  } catch (error: any) {
    // console.log("=>", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
export const getProcPath02 = async (data: any) => {
  try {
    let sql = "";
    let binds: any = {};
    if (data.code?.length > 0 || data.process?.length > 0) {
      binds = {
        code: data?.code ? parseInt(data?.code) : 0,
      };
      sql = `SELECT
            *
          FROM
            V_EPA_PROC_PATH
          WHERE  PPH_CD_EPA = :code`;
      if (data.process && data.process?.length > 0) {
        sql += ` AND PPH_CD_PROC_PATH = :process`;
        binds["process"] = data?.process;
      }
    } else {
      sql = `SELECT
            *
          FROM
          V_EPA_PROC_PATH`;
    }
    return await query(sql, binds);
  } catch (error: any) {
    // console.log("->", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
