@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
  echo Python was not found in PATH.
  echo Reinstall Python with "Add Python to PATH" enabled or contact IT.
  exit /b 1
)

python -m venv .venv
if errorlevel 1 exit /b 1

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Online package installation failed.
  echo If internet access is blocked, follow the offline installation section in GUIDE.md.
  exit /b 1
)

if not exist .env copy .env.example .env >nul
echo.
echo Installation complete. Edit .env before running start_bridge.bat.
endlocal
