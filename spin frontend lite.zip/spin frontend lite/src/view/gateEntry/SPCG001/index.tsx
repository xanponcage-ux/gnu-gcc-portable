import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPCG001GetData,
  // SPC001GetPlantData,
  GetPlantDataApi,
  SPCG001GetEpaData,
  SPCG001SaveTableDataApi,
  SPCG001TabAccessApi,
  SPCG001DeleteCoil,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType, InputChangeType } from "./type";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";
import { setTheme, useMaterialUIController } from "../../../context";
import DeleteIcon from "@mui/icons-material/Delete";

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [statusCodeData, setStatusCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [qltyData, setQltyData] = React.useState<Array<SelectType>>([]);
  const [invoiceData, setInvoiceData] = React.useState<Array<SelectType>>([]);
  const [materialData, setMaterialData] = React.useState<Array<SelectType>>([]);
  const [prodData, setProdData] = React.useState<Array<SelectType>>([]);
  const [tdcData, setTdcData] = React.useState<Array<SelectType>>([]);
  const [tabFlag, setTabFlag] = React.useState<number>(0);
  const [tabValue, setTabValue] = React.useState<number>(0);
  const [yardList, setYardList] = React.useState<Array<SelectType>>([]);

  const [batchId, setBatchId] = React.useState<string>("");

  // tab 1 - intransit report
  // tab 2 - Rec Raw Material Report
  // tab 3 - Tab to rec raw material (selective user access)

  const varInput: InputChangeType = {
    // key1: {
    //   config: {
    //     type: "select",
    //     label: "Batch Id",
    //   },
    //   value: "",
    //   data: [],
    //   onChange: (e) => onInputChange(e?.toString(), "key1"),
    // },
    key2: {
      config: {
        type: "select",
        label: "Invoice No",
      },
      value: "",
      data: [],
      onChange: (e) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "select",
        label: "Material No",
      },
      value: "",
      data: [],
      onChange: (e) => onInputChange(e?.toString(), "key3"),
    },
    key4: {
      config: {
        type: "select",
        label: "TDC",
      },
      value: "",
      data: [],
      onChange: (e) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "select",
        label: "Prod Code",
      },
      value: "",
      data: [],
      onChange: (e) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "select",
        label: "Qlty Cd",
      },
      value: "",
      data: [],
      onChange: (e) => onInputChange(e?.toString(), "key6"),
    },
    key7: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key7"),
    },
    key8: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key8"),
    },
    key9: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key9"),
    },
    key10: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key10"),
    },
    key11: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key11"),
    },
    key12: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "key12"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const [indentDateTo, setindentDateTo] = React.useState<any>(null);
  const [indentDateFrm, setindentDateFrm] = React.useState<any>(null);

  const column: Array<any> = [
    {
      title: "Indeted Date Time",
      field: "INDENT_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status Code",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice Weight",
      field: "INVOICE_WEIGHT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Yard Code",
      field: "YARD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Loc X",
      field: "LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Y",
      field: "LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pos Id",
      field: "POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mark Customer Name",
      field: "MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    //2 missing feilds as per excel
    {
      title: "Customer Order No.",
      field: "CUST_ORD_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Item No.",
      field: "CUST_ITEM_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice No",
      field: "INVOICE_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice Date",
      field: "INVOICE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Delivery No",
      field: "DELV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Material no",
      field: "MATERIAL_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Coil Edge",
      field: "EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Residual Weight",
      field: "RESIDUAL_WEIGHT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },

    {
      title: "Remarks",
      field: "REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SPC Wt",
      field: "SPC_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },

    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Operator ID",
      field: "OPERATOR_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Customer Code",
      field: "CUSTOMER_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    // {
    //   title: "Cust NM",
    //   field: "CUSTNM",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Salvaging Remarks",
    //   field: "SALVAGING_REMARKS",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Mill Passed Process",
      field: "MILL_PASSED_PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice Age(Days)",
      field: "INVOICE_AGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Age at SPC",
      field: "AGE_AT_SPC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Arrival Dt",
      field: "ARRIVAL_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Transit Lead Time(Days)",
      field: "TRANSIT_LEAD_TIME_DAYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    // {
    //   title: "Processing Date",
    //   field: "PROCESSING_DATE",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    //   hozAlign: "left",
    // },
  ];

  //Recive Raw material col, Tab 4
  const column2: Array<any> = [
    {
      formatter: "rowSelection",
      // titleFormatter: "rowSelection", //Removing select all
      hozAlign: "center",
      download: false,
      //frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Indent Date",
      field: "INDENT_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status Code",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Yard (Unloading Bay)",
      field: "YRD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: "list",
      editorParams: {
        allowEmpty: false,
        showListOnEmpty: true,
        values: yardList,
      },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        cell.getElement().style["border"] = "1.5px solid #748da6";
        if (value) {
          return value;
        }
        return value;
      },
    },

    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice Weight",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Material no",
      field: "MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Loc X",
      field: "LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Loc Y",
      field: "LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pos Id",
      field: "POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Invoice No",
      field: "INV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Invoice Date",
      field: "INV_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Delivery No",
      field: "DELV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Arrival Dt",
      field: "CREATE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  //Rec Raw mat report, Tab 2
  const column3: Array<any> = [
    // {
    //   formatter: "rowSelection",
    //   titleFormatter: "rowSelection",
    //   hozAlign: "center",
    //   download: false,
    //   //frozen: true,
    //   headerSort: false,
    //   title: "",
    // },
    {
      title: "Reciving Dt",
      field: "CREATE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Yard Code",
      field: "YRD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status Code",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice Weight",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Mark Customer",
      field: "MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Idia",
      field: "COIL_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Odia",
      field: "COIL_ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material no",
      field: "MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Loc X",
      field: "LOC_X",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Loc Y",
      field: "LOC_Y",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Pos Id",
      field: "POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },

    {
      title: "Invoice No",
      field: "INV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
    {
      title: "Invoice Date",
      field: "INV_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: false,
    },
    {
      title: "Delivery No",
      field: "DELV_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      visible: false,
    },
  ];

  //Return Raw mat report, Tab 3
  const column4: Array<any> = [
    {
      formatter: "rowSelection",
      // titleFormatter: "rowSelection", //Removing select all
      hozAlign: "center",
      download: false,
      //frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Arrival Dt",
      field: "CREATE_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status Code",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Invoice Weight",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Material no",
      field: "MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
    setSelectedCode("");
    fetchEpaData();
    handleClearAll();
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  const getColumns = () => {
    switch (tabValue) {
      case 0:
        return column; //Intransit details tab
      case 1:
        return column3; //rec raw mat report
      case 2:
        return column2; //rec raw mat
      case 3:
        return column4; //return raw mat
      default:
        return column;
    }
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          // columns: value === 0 ? column : pathColumn,
          columns: getColumns(), //value === 0 ? column : column2,
          // columns: column,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
          selectable: tabValue === 3 ? 1 : true,
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchEpaData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantCodeData(varData);
            setSelectedCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
      SPCG001GetEpaData(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.statusCode?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x.EIC_CD_STATUS?.toString(),
                  label: x.EIC_CD_STATUS?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setStatusCodeData(varData);
            const varData1: Array<SelectType> = [];
            res.data?.invoice?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData1.push({
                  value: x.EIC_NO_INVOICE?.toString(),
                  label: x.EIC_NO_INVOICE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setInvoiceData(varData1);
            const varData2: Array<SelectType> = [];
            res.data?.material?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData2.push({
                  value: x.EIC_NO_MATNR?.toString(),
                  label: x.EIC_NO_MATNR?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setMaterialData(varData2);
            const varData3: Array<SelectType> = [];
            res.data?.prod?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData3.push({
                  value: x.EIC_CD_PROD?.toString(),
                  label: x.EIC_CD_PROD?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setProdData(varData3);
            const varData4: Array<SelectType> = [];
            res.data?.qlty?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData4.push({
                  value: x.EIC_CD_QLTY_ACTL?.toString(),
                  label: x.EIC_CD_QLTY_ACTL?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setQltyData(varData4);
            const varData5: Array<SelectType> = [];
            res.data?.tdc?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData5.push({
                  value: x.EIC_TDC_ACTL?.toString(),
                  label: x.EIC_TDC_ACTL?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setTdcData(varData5);

            const varData6: Array<SelectType> = [];
            res?.data?.yardValue?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData6.push({
                  value: x?.YARD?.toString(),
                  label: x?.YARD?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setYardList(varData6);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
      SPCG001TabAccessApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x.CD_VALUE?.toString(),
                  label: x.CD_VALUE?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            for (let i = 0; i < varData.length; i++) {
              if (user === varData[i].value) {
                setTabFlag(1);
                break;
              }
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const fetchData = (tabVal: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    //Only required for rec raw mat report
    if (
      tabValue === 1 &&
      (inputObj.key9.value === undefined || inputObj.key9.value === "")
    ) {
      alertify.error("Please select Reciving Dt");
      return;
    }

    // if (inputObj.key2.value === undefined || inputObj.key2.value === "") {
    //   alertify.error("Please select Invoice No.");
    //   return;
    // }
    const data = {
      data: tabVal,
      process: selectedProcess,
      code: selectedCode?.split(" - ")[0],
      tdc: inputObj.key4.value,
      batchId: batchId,
      invoiceNo: inputObj.key2.value,
      materialNo: inputObj.key3.value,
      prodCode: inputObj.key5.value,
      qltyCode: inputObj.key6.value,
      invoiceDateFr: DateFormat(inputObj.key7.value),
      invoiceDateTo: DateFormat(inputObj.key8.value),
      // processDateFr: DateFormat(inputObj.key9.value),
      // processDateTo: DateFormat(inputObj.key10.value),
      receivingDateFr: DateFormat(inputObj.key9.value),
      receivingDateTo: DateFormat(inputObj.key10.value),
      indentDateTo: indentDateTo ? DateFormat(indentDateTo) : "",
      indentDateFrm: indentDateFrm ? DateFormat(indentDateFrm) : "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPCG001GetData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (tabVal === 0 && res?.data?.intransitData?.length === 0) {
              alertify.error("No Data Found");
              return;
            }
            if (tabVal === 1 && res?.data?.recRepData?.length === 0) {
              alertify.error("No Data Found");
              return;
            }
            if (tabVal === 2 && res?.data?.recData?.length === 0) {
              alertify.error("No Data Found");
              return;
            }
            if (tabVal === 3 && res?.data?.returnRawMat?.length === 0) {
              alertify.error("No Data Found");
              return;
            }

            if (tabVal === 0) {
              setTableData(res.data?.intransitData);
            } else if (tabVal === 1) {
              setTableData(res.data?.recRepData);
            } else if (tabVal === 2) {
              setTableData(res.data?.recData);
            } else if (tabVal === 3) {
              setTableData(res.data?.returnRawMat);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var fileName = "SPCG001_" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    // setSelectedCode("");
    setSelectedProcess("");
    setTableData([]);
    setInputObj(varInput);
    setindentDateTo(null);
    setindentDateFrm(null);
  };
  let arr_select = [invoiceData, materialData, tdcData, prodData, qltyData];
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const saveTableData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (tableData.length === 0) {
      alertify.error("No Data exist to save");
      return;
    }

    const gridData = table?.getSelectedRows();

    if (gridData?.length === 0) {
      alertify.error("Please select row");
      return;
    }

    let batchIds: Array<string> = [];
    let yard: Array<string> = [];

    let yardFlag = false;
    for (let i = 0; i < gridData.length; i++) {
      let yardVal = gridData[i]?._row?.data?.YRD;
      if (
        yardVal === null ||
        yardVal === undefined ||
        (typeof yardVal === "string" && yardVal?.trim() === "")
      ) {
        yardFlag = true;
        break;
      }

      let status = gridData[i]?._row?.data?.STATUS;
      if (status === "VA") {
        let invNo = gridData[i]?._row?.data?.INV_NO;
        if (invNo === "" || invNo === null || invNo === " ") {
          alertify.error("Invoice no can't be blank for coils in VA");
          return;
        }
      }
      batchIds.push(gridData[i]?._row?.data?.COIL_ID);
      yard.push(yardVal);
    }

    if (yardFlag) {
      alertify.error("Please Select Yard");
      return;
    }

    // const batchId = table?.getSelectedRows()[0]?._row?.data?.CoilId;
    const data = {
      batchId: batchIds,
      yard: yard,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPCG001SaveTableDataApi(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            alertify.success("Data Saved Successfully");
            setTableData([]);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const deleteCoil = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (tableData.length === 0) {
      alertify.error("No Data exist to save");
      return;
    }

    const gridData = table?.getSelectedRows();

    if (gridData?.length === 0) {
      alertify.error("Please select row");
      return;
    }

    let batchIds: Array<string> = [];

    let errFlag = false;
    for (let i = 0; i < gridData.length; i++) {
      let status = gridData[i]?._row?.data?.STATUS;

      if (status !== "VG") {
        errFlag = true;
        return;
      }
      batchIds.push(gridData[i]?._row?.data?.COIL_ID);
    }

    if (errFlag) {
      alertify.error("Coil Deletion applicable on for VG coils");
      return;
    }

    const data = {
      batchId: batchIds ?? "",
      plantCd: selectedCode?.split(" - ")[0] ?? "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPCG001DeleteCoil(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.substr(0, 1) === "Y") {
            alertify.success(res?.data);
            setTableData([]);
          } else if (res?.data?.substr(0, 1) === "N") {
            alertify.error(res?.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            label="Plant*"
                            data={plantCodeData}
                            id={"id"}
                            value={selectedCode}
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedCode(e);
                            }}
                          />
                        </Grid>
                        {/* <Grid item xs={1.5}>
                        <SelectInput
                          id={"process"}
                          data={statusCodeData}
                          value={selectedProcess}
                          label="Status"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProcess(e);
                          }}
                        />
                      </Grid> */}

                        <Grid item xs={1.5}>
                          {/* {"Batch Id"} */}
                          <Input
                            label="Batch Id"
                            id={"batchId"}
                            value={batchId}
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {formData?.map(
                          (x: FormType, i: number) =>
                            i < 5 && (
                              <React.Fragment key={i}>
                                <Grid item xs={1.7}>
                                  <SelectInput
                                    id={x?.key}
                                    data={arr_select[i]}
                                    value={x?.data?.value}
                                    {...x?.data?.config}
                                    // onChange={x?.data?.onChange}
                                    onChange={(e: string) => {
                                      if (x?.data?.onChange) {
                                        x.data.onChange(e);
                                      }
                                      setTableData([]);
                                    }}
                                  />
                                </Grid>
                              </React.Fragment>
                            )
                        )}
                        <Grid item xs={3}>
                          <Box component="span">
                            {" "}
                            Invoice Date
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 5 &&
                                  i < 7 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        // onChange={x?.data?.onChange}
                                        onChange={(e: string) => {
                                          if (x?.data?.onChange) {
                                            x.data.onChange(e);
                                          }
                                          setTableData([]);
                                        }}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        <Grid item xs={3}>
                          <Box component="span">
                            {" "}
                            Receiving Date
                            <Grid container spacing={2}>
                              {formData.map(
                                (x: FormType, i: number) =>
                                  i >= 7 &&
                                  i < 9 && (
                                    <Grid item key={x?.key} xs={6}>
                                      <DatePickerInput
                                        id={x?.key}
                                        value={
                                          x?.data?.value?.length > 0
                                            ? x?.data?.value
                                            : null
                                        }
                                        {...x?.data?.config}
                                        // onChange={x?.data?.onChange}
                                        onChange={(e: string) => {
                                          if (x?.data?.onChange) {
                                            x.data.onChange(e);
                                          }
                                          setTableData([]);
                                        }}
                                      />
                                    </Grid>
                                  )
                              )}
                            </Grid>
                          </Box>
                        </Grid>
                        {tabValue === 0 && (
                          <Grid item xs={4}>
                            <Box component="span">
                              {" "}
                              Indent Date
                              <Grid container spacing={2}>
                                <Grid item xs={5}>
                                  <DatePickerInput
                                    id="IndFrom"
                                    value={indentDateFrm}
                                    label="From"
                                    // onChange={x?.data?.onChange}
                                    onChange={(e: string) => {
                                      setindentDateFrm(e?.toString());
                                      setTableData([]);
                                    }}
                                  />
                                </Grid>
                                <Grid item xs={5}>
                                  <DatePickerInput
                                    id="IndTo"
                                    value={indentDateTo}
                                    label="To"
                                    onChange={(e: string) => {
                                      setindentDateTo(e?.toString());
                                      setTableData([]);
                                    }}
                                  />
                                </Grid>
                              </Grid>
                            </Box>
                          </Grid>
                        )}

                        <Grid item xs={2} sx={{ mt: 2 }}>
                          <ButtonElement onClick={() => fetchData(tabValue)}>
                            Search
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Grid container>
                  {tabFlag === 1 && (
                    <Grid item>
                      <Tooltip title="Delete Coil">
                        <IconButton
                          onClick={deleteCoil}
                          disabled={tabValue !== 3 || restricted !== "RL_RW"}
                        >
                          <DeleteIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  )}
                  {tabFlag === 1 && (
                    <Grid item>
                      <Tooltip title="Save">
                        <IconButton
                          onClick={saveTableData}
                          disabled={tabValue !== 2 || restricted !== "RL_RW"}
                        >
                          <SaveIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  )}

                  <Grid item>
                    <Tooltip title="Download">
                      <IconButton onClick={downloadExcel}>
                        <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                </Grid>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={tabValue}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Intransit Details" />
                    <Tab label="Received Raw Mat report" />
                    {tabFlag === 1 && <Tab label="Receive Raw Material" />}
                    {tabFlag === 1 && <Tab label="Return Raw Material" />}
                  </Tabs>
                </Box>
                {/* {tabValue === 0 && tableData?.length > 0 && (
                  <>
                    <div id="table"></div>
                  </>
                )}
                {tabValue === 1 && tableData?.length > 0 && (
                  <div id="table"></div>
                )}
                {tabValue === 2 && tableData?.length > 0 && (
                  <div id="table"></div>
                )} */}
                {tableData?.length > 0 && <div id="table"></div>}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
