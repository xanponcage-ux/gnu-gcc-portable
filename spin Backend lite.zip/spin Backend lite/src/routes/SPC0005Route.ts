import { Router } from "express";
import { getData05, getTdcCode05 } from "../controllers/SPC0005Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0005Route = Router();

SPC0005Route.route("/SPC0005/getTdcData").post(
  authenticationMiddleware.bearer,
  getData05
);

SPC0005Route.route("/SPC0005/getTdcCode").get(
  authenticationMiddleware.bearer,
  getTdcCode05
);

export default SPC0005Route;
