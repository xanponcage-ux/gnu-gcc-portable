import { Request, Response } from "express";
import SPC0001Model from "../models/SPC0001Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getInvData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0001Model.prototype.getInvData(req.body);
    return res.status(200).json(await ResponceData(result1, true));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getInvMonData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0001Model.prototype.getInvMonData(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
