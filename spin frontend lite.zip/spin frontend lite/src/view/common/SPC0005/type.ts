

export interface InputDownType {
    key1: string,
    key2: string,
    key3: string,
    key4: string,
    key5: string,
    key6: string,
    key7: string,
    key8: string,
    key9: string,
}

export interface TableType {
    TSL_TDC_NO: string;
    IQL_CD_QLTY: string;
    TMA_TDC_NO: string;
}