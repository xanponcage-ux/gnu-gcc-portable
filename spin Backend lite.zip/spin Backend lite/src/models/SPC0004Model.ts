const SPC0004Query = require("../repository/SPC0004Query");

export default class SPC0004Model {
  upcomingpageCode04(data: any) {
    return SPC0004Query.upcomingpageCode04(data);
  }
  upcomingpage_02_Code04(data: any) {
    return SPC0004Query.upcomingpage_02_Code04(data);
  }
}
