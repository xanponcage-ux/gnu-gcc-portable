import { Request, Response } from "express";
import SPC0015Model from "../models/SPC0015Model";
import { ResponceData } from "../utils";



export const SPC0015getData = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1, result2, result3;

    if (req.body.tabIndex === 0) {
      result1 = await SPC0015Model.prototype.getSubrangeMaster(req.body);
    }
    if (req.body.tabIndex === 1) {
      result2 = await SPC0015Model.prototype.getPackageSubrange(req.body);
    }
    if (req.body.tabIndex === 2) {
      result3 = await SPC0015Model.prototype.getProcessSubrange(req.body);
    }

    varData = {
      subrangeMaster: await ResponceData(result1),
      packageSubrange: await ResponceData(result2),
      processSubrange: await ResponceData(result3)
    };

    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};