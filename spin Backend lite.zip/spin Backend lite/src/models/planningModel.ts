const PlanningQuery = require("../repository/planningQuery");

export default class PlanningModel {
  getData01(data: any) {
    return PlanningQuery.getData01(data);
  }
  // deleteScheduling(data: any) {
  //   return PlanningQuery.deleteScheduling(data);
  // }
  // scheduling(data: any) {
  //   return PlanningQuery.scheduling(data);
  // }
  getCoilData01() {
    return PlanningQuery.getCoilData01();
  }
  getVCoilData01(data: any) {
    return PlanningQuery.getVCoilData01(data);
  }
  updateCoilStatus01(data: any) {
    return PlanningQuery.updateCoilStatus01(data);
  }
  getProdData01() {
    return PlanningQuery.getProdData01();
  }
  getQltyData01() {
    return PlanningQuery.getQltyData01();
  }
  getTdcData01() {
    return PlanningQuery.getTdcData01();
  }
  // getOrderData(data: any) {
  //   return PlanningQuery.getOrderData(data);
  // }
  // scheduleID() {
  //   return PlanningQuery.scheduleID();
  // }
  // indenting(data: any) {
  //   return PlanningQuery.indenting(data);
  // }
  // scheduleDeletion(data: any) {
  //   return PlanningQuery.scheduleDeletion(data);
  // }
}
