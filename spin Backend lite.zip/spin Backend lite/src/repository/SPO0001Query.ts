import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data?.Plant) {
        return {
          process: await ResponceData(
            await query(`
                  select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
                  FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} AND EPL_CD_PROCESS != 'W' 
                  ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS`)
          ),
          //orderTypeData: await ResponceData(await query(`SELECT CD_VALUE FROM V_CODES WHERE CD_TYPE='TB005' ORDER BY 1`))
        };
      } else {
        return getCommonPlantData();
      }
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getProdData = async (data: any) => {
  try {
    if (data.type === "prodData") {
      if (data?.plant) {
        if (data?.process === "S") {
          //--Changed on 27.10.25, By Ritya, All feilds from RDC_NSPR6
          let sql = ` SELECT   RDC_CD_EPA PLANT, RDC_ID_BATCH ID_BATCH, RDC_ID_PDI ID_PDI,
          RDC_ID_SCHEDULE ID_SCHEDULE, RDC_SLIT_POS SLIT_POS,
          RDC_ID_INPUT_COIL COIL_ID,
          TO_CHAR (RDC_BATCH_START, 'dd-mm-yyyy hh24:MI:SS') BATCHSTART,
          TO_CHAR (RDC_BATCH_END, 'dd-mm-yyyy hh24:MI:SS') BATCHEND,
          TO_CHAR (RDC_TS_PROC_STRT, 'dd-mm-yyyy hh24:MI:SS') PROCSTART,
          TO_CHAR (RDC_TS_PROC_END, 'dd-mm-yyyy hh24:MI:SS') PROCEND,
          RDC_CAL_MASS CAL_WT, RDC_NET_MASS NET_WT, EOM_MS_GROSS_ACTL GROSS_WT,  --RDC_GROSS_MASS GROSS_WT,
          RDC_WIDTH BATCH_WIDTH, RDC_THICK THICK, RDC_MAX_SPEED MAXSPEED,
          RDC_AVG_SPEED AVGSPEED, RDC_LENGTH BATCH_LENGTH, RDC_ODIA ODIA,
          RDC_IDIA IDIA, RDC_RECOILER_TENSION RECOILERTENSION,
          RDC_RECOILER_TAPER RECOILERTAPER, RDC_OIL_TYPE OILTYPE,
          RDC_OIL_MAX_QTY OILMAXQTY, RDC_OIL_MIN_QTY OILMINQTY,
          RDC_REMARKS REMARKS, RDC_ORDER ORD_NO, RDC_ITEM_NO ORD_ITEM,
          RDC_CUST_DESC CUST_DESC, RDC_HOLD_FLAG HOLD_FLAG,
          RDC_HOLD_CODE HOLD_CODE, EOM_TDC_ACTL ACTL_TDC, RDC_TDC TDC, 
          RDC_GRADE_DESC GRADE_DESC,
          RDC_TRIM TRIM1, RDC_PACK_CODE PACK_CODE, RDC_CURR_PROC CURR_PROC,
          RDC_NXT_PROC NEXT_PROC, RDC_PLANNED_PROC PLANNED_PROC,
          RDC_ACTL_PROC_PATH ACT_PROC_PATH, RDC_PART_NUMBER PART_NO,
          RDC_EDGE_WAVINESS EDGE_WAVINESS, RDC_CENTRE_BUCKLE CENTRE_BUCKLE,
          RDC_CROSSBOW CROSSBOW, RDC_BURR_HEIGHT BURR_HEIGHT,
          RDC_SURF_REQ SURF_SEQ, RDC_HORIZONTAL_GAP HORIZONTAL_GAP,
          RDC_VERTICAL_GAP VERTICAL_GAP, RDC_WIDTH_TOL WIDTH_TOTAL,
          ENC_ORDER_EDGE ORDER_EDGE, ENC_MARK_CUST MARK_CUST_CODE,
          ENC_MARK_CUST_NAME MARK_CUST_NAME, ENC_CUST_NAME CUST_NAME,
          ENC_CD_END_CUST CUST_CODE, ENC_ORDER_TYPE ORDER_TYPE,
          ENC_CD_SHIP_TO_PRTY SHIP_TO_PARTY_CD,
          ENC_SHIP_TO_PRTY_DESC SHIP_TO_PARTY,
          ENC_ROAD_DEST ROAD_DEST_CD, ENC_ROADDEST_DESC ROAD_DEST_DESC,
          ENC_RAIL_DEST RAIL_DEST_CD, ENC_RAILDEST_DESC RAIL_DEST_DESC,
          EOM_NO_PIECES NO_PCS,
          EOM_CD_OIL OIL_TYPE,
          EOM_CD_PROD PROD_CD,
          EOM_SCO_ORDER SCO_ORDER,
          EOM_SCO_ITEM SCO_ITEM,
          EOM_ID_PAR_COIL_NO PARENT_BATCH,
          EOM_CD_STATUS STATUS,
          EOM_CD_QLTY_ACTL QLTY_CD,
          EOM_ID_FIRST_PAR MOTHER_BATCH,
          (SELECT EOM_MS_PIECE_ACTL FROM V_EPA_PRODN WHERE EOM_ID_BATCH = C.EOM_ID_FIRST_PAR) MOTHER_NET_WT,
          (SELECT EOM_SEC1 FROM V_EPA_PRODN WHERE EOM_ID_BATCH = C.EOM_ID_FIRST_PAR) MOTHER_THICK,
          (SELECT EOM_SEC2 FROM V_EPA_PRODN WHERE EOM_ID_BATCH = C.EOM_ID_FIRST_PAR) MOTHER_WIDTH,
          (SELECT TO_CHAR (RMH_TS_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) PROD_DATE,
          (SELECT RMH_SHIFT FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) SHIFT,
          (SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=C.EOM_ID_FIRST_PAR
           And TCO_CAST_NO=C.EOM_NO_CAST And TCO_TEST_PARA IN ('YS','LYS') AND ROWNUM=1) LYS,
          (SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=C.EOM_ID_FIRST_PAR 
          And TCO_CAST_NO=C.EOM_NO_CAST And TCO_TEST_PARA IN ('UTS') AND ROWNUM=1) UTS,
          (SELECT DISTINCT TCO_TEST_PARA_VAL FROM V_TC_COIL_TEST WHERE TCO_PROD_NO=C.EOM_ID_FIRST_PAR 
          And TCO_CAST_NO=C.EOM_NO_CAST And TCO_TEST_PARA IN ('EL') AND ROWNUM=1) ELONG,
          (SELECT RMH_NO_SLIT FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) NO_SLIT,
          (SELECT TO_CHAR(RMH_LOAD_DATE, 'dd-mm-yyyy hh24:MI:SS') FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) LOAD_DATE,
          --(SELECT RMH_WIDTH FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) MOTHER_WIDTH,
          --(SELECT RMH_THICK FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) MOTHER_THICK,
          (SELECT RMH_NO_CUTS FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) NO_CUTS,
          (SELECT RMH_TOT_TIME FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) TOT_TIME,
          (SELECT RMH_RUN_TIME FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) RUN_TIME,
          (SELECT RMH_SETUP_TIME FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) SETUP_TIME,
          (SELECT RMH_STOP_TIME FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) STOP_TIME,
          (SELECT RMH_SCRAP_PUP_COIL FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) SCRAP_PUP_COIL,
          (SELECT RMH_NSPR1 FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) UNCOIL_PRES,
          (SELECT RMH_NSPR2 FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) PRES_TEN_UNIT,
          (SELECT RMH_NSPR3 FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) UNCOIL_BACK_TEN,
          (SELECT RMH_CSPR1 FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) CUT_SET_USED,
          (SELECT RMH_CSPR2 FROM V_SL_MOTHER_COIL_PDO WHERE RMH_ID_COIL = A.RDC_ID_INPUT_COIL) MCOIL_UNCOIL_DIR,
          RDC_NSPR1 SLIT_WIDTH,
          RDC_NSPR2 ACTUAL_THICK,
          RDC_NSPR3 ACTUAL_IDIA,
          RDC_CSPR1 COIL_EDGE_COND,
          RDC_CSPR2 TELESCOPICITY,
          RDC_CSPR3 ZIG_ZAG_WIND,
          RDC_CSPR4 CUTTER_MARK,
          RDC_CSPR5 OIL_COND,
          RDC_NSPR5	CENTERING_ROLLS_POSITION ,
          RDC_NSPR6	FEEDING_ROLL_TORQUE,      
          RDC_NSPR7	DEBURRING_ROLLS_ACTUAL ,
          RDC_NSPR8	DEBURRING_ROLLS_UNIT ,
          RDC_NSPR9	DEBURRING_ROLLS_OVERSPEED,
          RDC_NSPR10	SCRAP_CHOPPER_OVERSPEED,
          RDC_SCRAP_CHOPPER_ROLLS_OVERSPEED	SCRAP_CHOPPER_ROLLS_OVERSPEED,
          RDC_OVERSPEED	SLITTER_OVERSPEED,
          RDC_TENSION_BRIDLE1_POSITION	TENSION_BRIDLE_ROLL_#1_POSITION,
          RDC_TENSION_BRIDLE2_POSITION	TENSION_BRIDLE_ROLL_#2_POSITION,
          RDC_TENSION_BRIDLE3_POSITION	TENSION_BRIDLE_ROLL_#3_POSITION,
          RDC_TENSION_BRIDLE1_PENETRATION	TENSION_BRIDLE_ROLL_#1_PENETRATION,
          RDC_TENSION_BRIDLE2_PENETRATION	TENSION_BRIDLE_ROLL_#2_PENETRATION,
          RDC_TENSION_BRIDLE3_PENETRATION	TENSION_BRIDLE_ROLL_#3_PENETRATION,
          RDC_TENSION_BRIDLE1_PRESSURE	TENSION_BRIDLE_ROLL_#1_SET_PRESSURE,
          RDC_TENSION_BRIDLE2_PRESSURE	TENSION_BRIDLE_ROLL_#2_SET_PRESSURE,
          RDC_TENSION_BRIDLE3_PRESSURE	TENSION_BRIDLE_ROLL_#3_SET_PRESSURE,
          RDC_TENSION_BRIDLE1_LOAD	TENSION_BRIDLE_ROLL_#1_LOAD_FACTOR,
          RDC_TENSION_BRIDLE2_LOAD	TENSION_BRIDLE_ROLL_#2_LOAD_FACTOR,
          RDC_TENSION_BRIDLE3_LOAD	TENSION_BRIDLE_ROLL_#3_LOAD_FACTOR,
          RDC_TENSION_BRIDLE1_SET_TENSION TENSION_BRIDLE_ROLL_#1_Set_TENSION,
          RDC_TENSION_BRIDLE2_SET_TENSION TENSION_BRIDLE_ROLL_#2_Set_TENSION,
          RDC_TENSION_BRIDLE3_SET_TENSION TENSION_BRIDLE_ROLL_#3_Set_TENSION,
          RDC_TENSION_BRIDLE1_ACT_TENSION TENSION_BRIDLE_ROLL_#1_Actual_TENSION,
          RDC_TENSION_BRIDLE2_ACT_TENSION TENSION_BRIDLE_ROLL_#2_Actual_TENSION,
          RDC_TENSION_BRIDLE3_ACT_TENSION TENSION_BRIDLE_ROLL_#3_Actual_TENSION,
          RDC_DEFLECTOR_ROLL_POSITION	DEFLECTOR_ROLL_POSITION,
          RDC_RECOILER_ACTUAL_UNIT_TENSION	RECOILER_ACTUAL_UNIT_TENSION,
          RDC_RECOILER_UNIT_APPLIED_TENSION	RECOILER_UNIT_APPLIED_TENSION,
          RDC_RECOILER_UNIT_TAPER_DIAMETER	RECOILER_UNIT_TAPER_DIAMETER,
          RDC_FEEDING_CAR_DISTANCE	FEEDING_CAR_DISTANCE,
          RDC_RECOILER_SEPARATORS_PENETRATION	RECOILER_SEPARATORS_PENETRATION,
          (select LISTAGG(CAD_DEF2_COMM,' ; ') from v_coil_card
           where CAD_ID_COIL=c.EOM_ID_FIRST_PAR 
           and (CAD_DEF2_COMM like '@SLP%' OR CAD_DEF2_COMM LIKE 'SLP%')) SLP_REMARKS,
          (SELECT CD_DESC
            FROM V_EPA_HOLD_RSN
            WHERE CD_HOLD = A.RDC_HOLD_CODE AND ROWNUM = 1) HOLD_DESC
          ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA 
            and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
          ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA 
            and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd                  
        FROM V_SL_DAUTR_PDO A, V_END_CUST_ORD_EPA B, V_EPA_PRODN C
       WHERE A.RDC_CD_EPA = B.ENC_CD_EPA
         AND A.RDC_ORDER = B.ENC_ID_ORDER
         AND A.RDC_ITEM_NO = B.ENC_NO_ITEM
         AND A.RDC_ID_BATCH = C.EOM_ID_BATCH
         AND A.RDC_CD_EPA = C.EOM_CD_EPA 
         --AND EOM_CD_STATUS NOT LIKE '%L' 
         `;

          if (
            data?.prodDateFrom &&
            data?.prodDateFrom != "" &&
            data?.prodDateTo &&
            data?.prodDateTo != ""
          ) {
            sql += ` AND  TO_DATE(SUBSTR(RDC_TIMESTAMP,1,10),'YYYY-MM-DD') >= TO_DATE('${data?.prodDateFrom}','DD-MM-YY')
                  and TO_DATE(SUBSTR(RDC_TIMESTAMP,1,10),'YYYY-MM-DD') <= TO_DATE('${data?.prodDateTo}','DD-MM-YY')`;
          }
          if (data?.batchId && data?.batchId?.length > 0) {
            sql += ` AND RDC_ID_BATCH = '${data?.batchId}' `;
          }
          if (data?.mBatch && data?.mBatch?.length > 0) {
            sql += ` AND RDC_ID_INPUT_COIL = '${data?.mBatch}' `;
          }

          if (data?.process && data?.process?.length > 0) {
            sql += ` AND RDC_CURR_PROC = '${data?.process}' `;
          }
          if (data?.order) {
            sql += ` AND RDC_ORDER = '${data?.order}' `;
          }
          if (data?.item) {
            sql += ` AND RDC_ITEM_NO = '${data?.item}' `;
          }
          sql += ` ORDER BY RDC_ID_BATCH,RDC_ID_INPUT_COIL `;
          console.log("slt-sql- ", sql);
          return await query(sql);
        } else if (
          data?.process === "N" ||
          data?.process === "T" ||
          data?.process === "E"
        ) {
          let sql = ` SELECT   CDP_CD_EPA PLANT, CDP_ID_BATCH ID_BATCH, CDP_ID_PDI ID_PDI,
         CDP_ID_SCHEDULE ID_SCHEDULE, CDP_ID_INPUT_COIL COIL_ID,
         TO_CHAR (CDP_BATCH_START, 'dd-mm-yyyy hh24:MI:SS') BATCHSTART,
         TO_CHAR (CDP_BATCH_END, 'dd-mm-yyyy hh24:MI:SS') BATCHEND,
         CDP_CUT_LENGTH BATCH_LENGTH,
         CDP_CUT_ANGLE CUT_ANGLE, CDP_WIDTH BATCH_WIDTH, CDP_THICK THICK,
         CDP_PACK_NET_WT NET_WT, CDP_PACK_GROSS_WT GROSS_WT,
         CDP_PROD_DUR PROD_DUR, CDP_PROD_ACT_PIECE ACT_PIECE,
         CDP_REMARKS REMARKS, CDP_ORDER ORD_NO, CDP_ITEM_NO ORD_ITEM,
         CDP_CUST_DESC CUST_DESC, CDP_HOLD_FLAG HOLD_FLAG,
         CDP_HOLD_CODE HOLD_CODE, EOM_TDC_ACTL ACTL_TDC, CDP_TDC TDC, 
         CDP_GRADE_DESC GRADE_DESC,
         CDP_TRIM TRIM1, CDP_PACK_CODE PACK_CODE, CDP_NXT_PROC NEXT_PROC,
         CDP_PLANNED_PROC PLANNED_PROC, CDP_ACTL_PROC ACTL_PROC,
         CDP_REC_CRT_DT REC_CRT_DT, CDP_REC_CRT_BY REC_CRT_BY,
         CDP_CD_PROCESS CURR_PROC,
         ENC_ORDER_EDGE ORDER_EDGE, ENC_MARK_CUST MARK_CUST_CODE,
         ENC_MARK_CUST_NAME MARK_CUST_NAME, ENC_CUST_NAME CUST_NAME,
         ENC_CD_END_CUST CUST_CODE, ENC_ORDER_TYPE ORDER_TYPE,
         ENC_CD_SHIP_TO_PRTY SHIP_TO_PARTY_CD,
         ENC_SHIP_TO_PRTY_DESC SHIP_TO_PARTY, ENC_ROAD_DEST ROAD_DEST_CD,
         ENC_ROADDEST_DESC ROAD_DEST_DESC, ENC_RAIL_DEST RAIL_DEST_CD,
         ENC_RAILDEST_DESC RAIL_DEST_DESC, EOM_NO_PIECES NO_PCS,
         EOM_CD_OIL OIL_TYPE, EOM_CD_PROD PROD_CD, EOM_SCO_ORDER SCO_ORDER,
         EOM_SCO_ITEM SCO_ITEM, EOM_ID_PAR_COIL_NO PARENT_BATCH, 
         EOM_CD_STATUS STATUS, EOM_ID_FIRST_PAR MOTHER_BATCH,
         EOM_CD_QLTY_ACTL QLTY_CD,
         (SELECT TO_CHAR (RMH_TS_CRT_DT, 'dd-mm-yyyy hh24:MI:SS')
            FROM V_SL_MOTHER_COIL_PDO
           WHERE RMH_ID_COIL = A.CDP_ID_BATCH) PROD_DATE,
         (SELECT RMH_SHIFT
            FROM V_SL_MOTHER_COIL_PDO
           WHERE RMH_ID_COIL = A.CDP_ID_BATCH) SHIFT,
         (SELECT DISTINCT TCO_TEST_PARA_VAL
                     FROM V_TC_COIL_TEST
                    WHERE TCO_PROD_NO = C.EOM_ID_FIRST_PAR
                      AND TCO_CAST_NO = C.EOM_NO_CAST
                      AND TCO_TEST_PARA IN ('YS', 'LYS')
                      AND ROWNUM = 1) LYS,
         (SELECT DISTINCT TCO_TEST_PARA_VAL
                     FROM V_TC_COIL_TEST
                    WHERE TCO_PROD_NO = C.EOM_ID_FIRST_PAR
                      AND TCO_CAST_NO = C.EOM_NO_CAST
                      AND TCO_TEST_PARA IN ('UTS')
                      AND ROWNUM = 1) UTS,
         (SELECT DISTINCT TCO_TEST_PARA_VAL
                     FROM V_TC_COIL_TEST
                    WHERE TCO_PROD_NO = C.EOM_ID_FIRST_PAR
                      AND TCO_CAST_NO = C.EOM_NO_CAST
                      AND TCO_TEST_PARA IN ('EL')
                      AND ROWNUM = 1) ELONG,
          (select LISTAGG(CAD_DEF2_COMM,' ; ') from v_coil_card
           where CAD_ID_COIL=c.EOM_ID_FIRST_PAR 
           and (CAD_DEF2_COMM like '@SLP%' OR CAD_DEF2_COMM LIKE 'SLP%')) SLP_REMARKS,
          (SELECT CD_DESC
            FROM V_EPA_HOLD_RSN
            WHERE CD_HOLD = A.CDP_HOLD_CODE AND ROWNUM = 1) HOLD_DESC
          ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA 
            and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer
          ,(select EIC_MARK_CUST from v_input_coil where eic_cd_Epa=c.EOM_CD_EPA 
            and eic_id_coil =c.EOM_ID_FIRST_PAR ) inp_customer_cd
          FROM V_CTL_DAUTR_PDO A, V_END_CUST_ORD_EPA B, V_EPA_PRODN C
         WHERE A.CDP_CD_EPA = B.ENC_CD_EPA
           AND A.CDP_ORDER = B.ENC_ID_ORDER
           AND A.CDP_ITEM_NO = B.ENC_NO_ITEM
           AND A.CDP_ID_BATCH = C.EOM_ID_BATCH
           AND A.CDP_CD_EPA = C.EOM_CD_EPA 
           --AND EOM_CD_STATUS NOT LIKE '%L' 
           `;

          if (
            data?.prodDateFrom &&
            data?.prodDateFrom != "" &&
            data?.prodDateTo &&
            data?.prodDateTo != ""
          ) {
            sql += ` AND  TO_DATE(CDP_BATCH_START,'DD-MON-YY') >= TO_DATE('${data?.prodDateFrom}','DD-MON-YY')
                  and TO_DATE(CDP_BATCH_START,'DD-MON-YY') <= TO_DATE('${data?.prodDateTo}','DD-MON-YY')`;
          }
          if (data?.batchId && data?.batchId?.length > 0) {
            sql += ` AND CDP_ID_BATCH = '${data?.batchId}' `;
          }
          if (data?.mBatch && data?.mBatch?.length > 0) {
            sql += ` AND CDP_ID_INPUT_COIL = '${data?.mBatch}' `;
          }
          if (data?.process && data?.process?.length > 0) {
            sql += ` AND CDP_CD_PROCESS = '${data?.process}' `;
          }
          if (data?.order) {
            sql += ` AND CDP_ORDER = '${data?.order}' `;
          }
          if (data?.item) {
            sql += ` AND CDP_ITEM_NO = '${data?.item}' `;
          }
          sql += ` ORDER BY CDP_ID_BATCH, CDP_ID_INPUT_COIL `;
          // console.log("ctl-sql: ", sql);
          return await query(sql);
        } else if (data?.process === "K") {
          let sql = ` select 
                TPC_CD_EPA          PLANT, 
                TPC_ID_BATCH        ID_BATCH, 
                TPC_ID_INPUT_COIL   COIL_ID, 
                TPC_ID_PDI          ID_PDI,
                TPC_WIDTH           BATCH_WIDTH, 
                TPC_THICK           THICK, 
                TPC_ODIA            ODIA, 
                TPC_IDIA            IDIA, 
                TPC_NET_MASS        NET_WT, 
                TPC_GROSS_MASS      GROSS_WT, 
                TPC_LENGTH          BATCH_LENGTH, 
                TPC_ORDER           ORD_NO, 
                TPC_ITEM_NO         ORD_ITEM, 
                TPC_PACK_CODE       PACK_CODE, 
                TO_CHAR(TPC_TS_PROC_STRT,'dd-mm-yyyy hh24:MI:SS') PROCSTART, 
                TO_CHAR(TPC_TS_PROC_END,'dd-mm-yyyy hh24:MI:SS') PROCEND, 
                TO_CHAR(TPC_PKG_DATE,'dd-mm-yyyy hh24:MI:SS')        PKG_DATE,
                TPC_SHIFT           SHIFT,
                TO_CHAR(TPC_CRT_DT,'dd-mm-yyyy hh24:MI:SS')   CRT_DT,
                TPC_CRT_USR         CRT_BY
                from v_package_coil `;

          if (data?.plant) {
            sql += `where TPC_CD_EPA = '${data?.plant}'`;
          }
          if (
            data?.prodDateFrom &&
            data?.prodDateFrom != "" &&
            data?.prodDateTo &&
            data?.prodDateTo != ""
          ) {
            sql += ` AND  TO_DATE(TPC_TS_PROC_STRT,'DD-MON-YY') >= TO_DATE('${data?.prodDateFrom}','DD-MON-YY')
                  and TO_DATE(TPC_TS_PROC_STRT,'DD-MON-YY') <= TO_DATE('${data?.prodDateTo}','DD-MON-YY')`;
          }
          if (data?.batchId && data?.batchId?.length > 0) {
            sql += ` AND TPC_ID_BATCH = '${data?.batchId}' `;
          }
          if (data?.mBatch && data?.mBatch?.length > 0) {
            sql += ` AND TPC_ID_INPUT_COIL = '${data?.mBatch}' `;
          }
          if (data?.order) {
            sql += ` AND TPC_ORDER = '${data?.order}' `;
          }
          if (data?.item) {
            sql += ` AND TPC_ITEM_NO = '${data?.item}' `;
          }
          // console.log("pack-sql: ", sql);
          return await query(sql);
        }
      }
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};
