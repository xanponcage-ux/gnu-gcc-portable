import { Router } from "express";
import { getInvData, getInvMonData } from "../controllers/SPC0001Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0001Route = Router();

SPC0001Route.route("/SPC0001/getInvData").post(
  authenticationMiddleware.bearer,
  getInvData
);

SPC0001Route.route("/SPC0001/getInvMonData").post(
  authenticationMiddleware.bearer,
  getInvMonData
);

export default SPC0001Route;
