import { Request, Response } from "express";
import SPS0025Model from "../models/SPS0025Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const SPS0025Controller = async (req: Request, res: Response) => {
  try {
    if (req.body?.type === "pageData") {
      const results1 = await ResponceData(
        await SPS0025Model.prototype.getPlantData(req.body)
      );
      // const results2 = await ResponceData(await reportModel.prototype.getBatchData(req.body));
      // const results3 = await ResponceData(await reportModel.prototype.getOrderData(req.body));
      // console.log("cont1", results1);
      return res.status(200).json({ plant: results1 });
    }
    return res.status(200).json();
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const SPS0025BatchId = async (req: Request, res: Response) => {
  try {
    if (req.body.type === "01") {
      const results1 = await ResponceData(
        await SPS0025Model.prototype.getBatchData(req.body)
      );
      return res.status(200).json(results1);
    } else if (req.body.type === "02") {
      //api
      const result2 = await ResponceData(
        await SPS0025Model.prototype.getBatchData2(req.body)
      );

      return res.status(200).json(result2);
    }
    return res.status(200).json();
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const SPS0025TableApi = async (req: Request, res: Response) => {
  try {
    if (req.body.type === "01") {
      const results1 = await ResponceData(
        await SPS0025Model.prototype.getInputCoilAudit(req.body)
      );
      // console.log(results1);
      return res.status(200).json(results1);
    } else if (req.body.type === "02") {
      const result2 = await ResponceData(
        await SPS0025Model.prototype.getProductionAudit(req.body)
      );
      return res.status(200).json(result2);
    } else if (req.body.type === "03") {
      const result3 = await ResponceData(
        await SPS0025Model.prototype.getCustOrdAudit(req.body)
      );
      return res.status(200).json(result3);
    }

    return res.status(200).json();
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
