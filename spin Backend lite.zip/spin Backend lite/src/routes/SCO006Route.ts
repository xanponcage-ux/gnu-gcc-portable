import { Router } from "express";
import { SCO006Api } from "../controllers/SCO006Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SCO006Route = Router();

SCO006Route.route("/SCO006/action").post(
  authenticationMiddleware.bearer,
  SCO006Api
);

export default SCO006Route;
