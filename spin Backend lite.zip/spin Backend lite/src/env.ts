import { GetIp } from "./utils";

//local DEV - Always move this in DEV
const local = {
  CHAVE_JWT: "4eab6260-ef82-46bb-9027-69fbbb31377f",
  API_KEY: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  REFRESH_KEY: "9231f9cc-557c-4dd8-ac5c-babc20aad792",
  SCREEN_AUTH_KEY: "8e38c77d-ec78-481d-8658-8911d5a1e142",
  ORACLE: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  JWT_KEY: "secret",
  appport: 5556,
  dbUri: "10.152.98.196/tskepatest", //QA
  saltWorkFactor: "10",
  accessTokenTtl: "15m",
  refreshTokenTtl: "1y",
  host: "176.0.7.18", //QA
  port: 1521,
  database: "tskepatest", //QA
  whitelistdUrl: ["*"],
  SOAP_URL: "https://tslapiadso.corp.tatasteel.com/FSSO/Service.asmx?WSDL",
  devMode: "N",
  deploy: "N",
};

//Local Prd - Only for testing of display data
//Always comment this if uncommented when code is pushed

// const local = {
//   CHAVE_JWT: "4eab6260-ef82-46bb-9027-69fbbb31377f",
//   API_KEY: "6cc0a083-237c-4947-ba25-afeb388e54e9",
//   REFRESH_KEY: "9231f9cc-557c-4dd8-ac5c-babc20aad792",
//   SCREEN_AUTH_KEY: "8e38c77d-ec78-481d-8658-8911d5a1e142",
//   ORACLE: "6cc0a083-237c-4947-ba25-afeb388e54e9",
//   JWT_KEY: "secret",
//   appport: 5556,
//   dbUri: "10.152.98.211:1521/tskepaprod", //PRD
//   saltWorkFactor: "10",
//   accessTokenTtl: "15m",
//   refreshTokenTtl: "1y",
//   host: "10.152.98.211", //PRD
//   port: 1521,
//   database: "tskepaprod", //PRD
//   whitelistdUrl: ["*"],
//   SOAP_URL: "https://tslapiadso.corp.tatasteel.com/FSSO/Service.asmx?WSDL",
//   devMode: "N",
//   deploy: "N",
// };

const dev = {
  CHAVE_JWT: "4eab6260-ef82-46bb-9027-69fbbb31377f",
  API_KEY: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  REFRESH_KEY: "9231f9cc-557c-4dd8-ac5c-babc20aad792",
  SCREEN_AUTH_KEY: "8e38c77d-ec78-481d-8658-8911d5a1e142",
  ORACLE: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  JWT_KEY: "secret",
  appport: 5553,
  dbUri: "10.152.98.196/tskepatest", //QA
  saltWorkFactor: "10",
  accessTokenTtl: "15m",
  refreshTokenTtl: "1y",
  host: "176.0.7.18", //QA
  port: 1521,
  database: "tskepatest", //QA
  whitelistdUrl: ["https://tslweblindev.corp.tatasteel.com"],
  SOAP_URL: "https://tslapiadso.corp.tatasteel.com/FSSO/Service.asmx?WSDL",
  devMode: "N",
  deploy: "Y",
};

const qa = {
  CHAVE_JWT: "4eab6260-ef82-46bb-9027-69fbbb31377f",
  API_KEY: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  REFRESH_KEY: "9231f9cc-557c-4dd8-ac5c-babc20aad792",
  SCREEN_AUTH_KEY: "8e38c77d-ec78-481d-8658-8911d5a1e142",
  ORACLE: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  JWT_KEY: "secret",
  appport: 5557,
  dbUri: "10.152.98.196/tskepatest", //QA
  saltWorkFactor: "10",
  accessTokenTtl: "15m",
  refreshTokenTtl: "1y",
  host: "176.0.7.18", //QA
  port: 1521,
  database: "tskepatest", //QA
  whitelistdUrl: ["https://tslweblindev.corp.tatasteel.com"],
  SOAP_URL: "https://tslapiadso.corp.tatasteel.com/FSSO/Service.asmx?WSDL",
  devMode: "N",
  deploy: "Y",
};

const prd = {
  CHAVE_JWT: "4eab6260-ef82-46bb-9027-69fbbb31377f",
  API_KEY: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  REFRESH_KEY: "9231f9cc-557c-4dd8-ac5c-babc20aad792",
  SCREEN_AUTH_KEY: "8e38c77d-ec78-481d-8658-8911d5a1e142",
  ORACLE: "6cc0a083-237c-4947-ba25-afeb388e54e9",
  JWT_KEY: "secret",
  appport: 6660,
  dbUri: "10.152.98.211:1521/tskepaprod", //PRD
  saltWorkFactor: "10",
  accessTokenTtl: "15m",
  refreshTokenTtl: "1y",
  host: "10.152.98.211", //PRD
  port: 1521,
  database: "tskepaprod", //PRD
  whitelistdUrl: ["https://kpofpmes.corp.tatasteel.com"],
  SOAP_URL: "https://tslapiadso.corp.tatasteel.com/FSSO/Service.asmx?WSDL",
  devMode: "N",
  deploy: "Y",
};

let varVal = "local";

if (GetIp() === "176.0.15.164") {
  varVal = "dev";
} else if (GetIp() === "176.0.15.247") {
  varVal = "uat";
} else if (GetIp() === "10.152.98.222") {
  varVal = "prd";
}

console.log(GetIp());
console.log(varVal);
const env = {
  ...(varVal === "dev" && dev),
  ...(varVal === "uat" && qa),
  ...(varVal === "local" && local),
  ...(varVal === "prd" && prd),
};

export default env;
