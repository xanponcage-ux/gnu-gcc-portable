import axios, { AxiosError, AxiosResponse } from "axios";
import SERVER from "../constant/serverConnection";
import env from "../constant/env";

const HttpClient = axios.create({
  baseURL: SERVER[env.server].baseURL,
});

HttpClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return Promise.resolve(response);
  },
  (error: AxiosError) => {
    return Promise.reject({ error });
  }
);

export default HttpClient;
