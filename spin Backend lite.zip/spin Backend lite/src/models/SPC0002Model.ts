const SPC0002Query = require("../repository/SPC0002Query");

export default class SPC0002Model {
  getProcLineData02(data: any) {
    return SPC0002Query.getProcLineData02(data);
  }
  getProcPath02(data: any) {
    return SPC0002Query.getProcPath02(data);
  }
}
