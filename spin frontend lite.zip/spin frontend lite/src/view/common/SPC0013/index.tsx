/* ------ TEST RESULT ENQUIRY SCREEN INSIDE OPERATION --------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip, Tab, Tabs } from "@mui/material";
import {
  GetPlantDataApi,
  SPC0013getCastDetails,
  SPC0013getCoilDetails,
  SPC0013getFittingDetails,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import SaveIcon from "@mui/icons-material/Save";
import Loader from "../../../components/preloader";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { setTheme, useMaterialUIController } from "../../../context";
import { SelectType } from "../../../components/input/type";
import { DatePickerInput } from "../../../components/input";
import { FormType } from "../../auth/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";

import ClearAllIcon from "@mui/icons-material/ClearAll";
import AutoAwesomeMotionIcon from "@mui/icons-material/AutoAwesomeMotion";
import DoubleArrowIcon from "@mui/icons-material/DoubleArrow";
import ContentPasteGoIcon from "@mui/icons-material/ContentPasteGo";
import PublishedWithChangesIcon from "@mui/icons-material/PublishedWithChanges";
import PlayForWorkIcon from "@mui/icons-material/PlayForWork";
import ArrowDropDownCircleIcon from "@mui/icons-material/ArrowDropDownCircle";
import DomainVerificationIcon from "@mui/icons-material/DomainVerification";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0013 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);

  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<any>("");
  const [coilId, setCoilId] = React.useState<any>("");
  const [castNo, setCastNo] = React.useState<any>("");
  const [fittngTdc, setFittingTdc] = React.useState<any>("");
  const [tabValue, setTabValue] = React.useState<number>(0);

  const [castTable, setCastTable] = React.useState<any>(null);
  const [castTableData, setCastTableData] = React.useState<any>([]);

  const [coilTable, setCoilTable] = React.useState<any>(null);
  const [coilTableData, setCoilTableData] = React.useState<any>([]);

  const [fittingTable, setFittingTable] = React.useState<any>(null);
  const [fittingTableData, setFittingTableData] = React.useState<any>([]);

  //   React.useEffect(() => {
  //     fetchPlantData();
  //   }, []);

  //   const fetchPlantData = () => {
  //     setLoading(true);
  //     GetAuthorization().then((token: TokenType) => {
  //       GetPlantDataApi(token)
  //         .then((res) => {
  //           if (res.statusText !== "" && res.statusText !== "OK") {
  //             alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //           } else if (res?.data) {
  //             const varData: Array<SelectType> = [];
  //             res.data?.map((x: any, i: number) => (
  //               <React.Fragment key={i}>
  //                 {varData.push({
  //                   value: x?.EPL_CD_EPA?.toString(),
  //                   label: x?.EPL_CD_EPA_DESC?.toString(),
  //                   id: i,
  //                 })}
  //               </React.Fragment>
  //             ));
  //             setPlant(varData);
  //             setSelectedPlant(varData[0]?.value);
  //           }
  //         })
  //         .catch((e: any) => {
  //           console.log("e", e);
  //           alertify.error(
  //             e?.error?.message ? e.error.message : "Something Wents wrong!"
  //           );
  //         })
  //         .finally(() => {
  //           setLoading(false);
  //         });
  //     });
  //   };

  const coilTableCol: any = [
    {
      field: "TCO_PROD_NO",
      title: "Coil Id",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCO_CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCO_LAB_TEST_CD",
      title: "Test Cd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCO_TEST_PARA",
      title: "Test Para",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCO_TEST_PARA_VAL",
      title: "Test Para Val",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "TCO_TEST_PARA_REM",
      title: "Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const castTableCol: any = [
    {
      field: "TCA_CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCA_LAB_TEST_CD",
      title: "Test Cd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCA_TEST_PARA",
      title: "Test Para",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TCA_TEST_PARA_VAL",
      title: "Test Para Val",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
  ];

  const fittingTableCol: any = [
    {
      field: "TSL_TDC_NO",
      title: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TSL_CD_TEST",
      title: "Test Cd",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TSL_TEST_PARA",
      title: "Test Para",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TSL_PARA_MIN",
      title: "Para Min",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TSL_PARA_MAX",
      title: "Para Max",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PARA_VAL",
      title: "Test Para Val",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  React.useEffect(() => {
    if (castTableData?.length > 0) {
      setCastTable(
        new Tabulator("#castTable", {
          data: castTableData,
          columns: castTableCol,
          height: "340",
          layout: "fitDataFill",
        })
      );
    } else {
      setCastTable(null);
    }
    return () => {
      castTable?.destroy();
    };
  }, [castTableData]);

  React.useEffect(() => {
    if (coilTableData?.length > 0) {
      setCoilTable(
        new Tabulator("#coilTable", {
          data: coilTableData,
          columns: coilTableCol,
          height: "340",
          layout: "fitDataFill",
        })
      );
    } else {
      setCoilTable(null);
    }
    return () => {
      coilTable?.destroy();
    };
  }, [coilTableData]);

  React.useEffect(() => {
    if (fittingTableData?.length > 0) {
      setCoilTable(
        new Tabulator("#fittingTable", {
          data: fittingTableData,
          columns: fittingTableCol,
          height: "340",
          layout: "fitDataFill",
        })
      );
    } else {
      setFittingTable(null);
    }
    return () => {
      fittingTable?.destroy();
    };
  }, [fittingTableData]);

  const fetchCastTableData = () => {
    let castData = {
      castNo: castNo,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0013getCastDetails(token, castData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setCastTableData(res.data);
          } else {
            console.log("2: ", res);
            setCastTableData([]);
            alertify.error("No Cast data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchCoilTableData = () => {
    let castData = {
      coilId: coilId,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0013getCoilDetails(token, castData)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setCoilTableData(res.data);
          } else {
            setCoilTableData([]);
            alertify.error("No Coil data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchFittingTableData = () => {
    let data = {
      coilId: coilId,
      castNo: castNo,
      fittingTdc: fittngTdc,
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0013getFittingDetails(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setFittingTableData(res.data);
          } else {
            setFittingTableData([]);
            alertify.error("No Fitting data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      {/* <Grid item xs={2}>
                        <SelectInput
                          placeholder="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            //   fetchEpaData(e);
                          }}
                        />
                      </Grid> */}

                      <Grid item xs={2}>
                        <Input
                          label="Coil Id"
                          value={coilId}
                          size={"small"}
                          onChange={(e: string) => {
                            setCoilId(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <Input
                          label="Cast No"
                          value={castNo}
                          size={"small"}
                          onChange={(e: string) => {
                            setCastNo(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <Input
                          label="Fitting TDC"
                          value={fittngTdc}
                          size={"small"}
                          onChange={(e: string) => {
                            setFittingTdc(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <ButtonElement
                          onClick={() => {
                            fetchCastTableData();
                            fetchCoilTableData();
                          }}
                        >
                          DISPLAY TEST
                        </ButtonElement>
                      </Grid>

                      <Grid item xs={2}>
                        <ButtonElement
                          onClick={() => {
                            fetchFittingTableData();
                          }}
                        >
                          DISPLAY FITTING
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={6}>
              <TableContainer
                title="Cast Details"
                headerContainer={
                  <Tooltip title="Download">
                    <IconButton
                    // onClick={downloadExcel}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {castTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="castTable"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {castTableData?.length} of{" "}
                          {castTableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
                {/* <Box sx={{ width: "100%" }}>
                  <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                    <Tabs
                      value={tabValue}
                      onChange={handleTabChange}
                      aria-label="basic tabs example"
                    >
                      <Tab label="Display Test" />
                      <Tab label="Display Fitting" />
                    </Tabs>
                  </Box>
                  {tabValue === 0 && castTableData?.length > 0 && (
                    <div id="castTable"></div>
                  )}
                  {tabValue === 1 && coilTableData?.length > 0 && (
                    <div id="coilTable"></div>
                  )}
                  {value === 1 && tableDataQc?.length > 0 && (
                    <div id="table"></div>
                  )}
                </Box> */}
              </TableContainer>
            </Grid>

            <Grid item xs={6}>
              <TableContainer
                title="Coil Details"
                headerContainer={
                  <Tooltip title="Download">
                    <IconButton
                    // onClick={downloadExcel}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {coilTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="coilTable"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {coilTableData?.length} of{" "}
                          {coilTableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Fitting Details"
                // headerContainer={
                //   <Tooltip title="Download">
                //     <IconButton
                //     // onClick={downloadExcel}
                //     >
                //       <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                //     </IconButton>
                //   </Tooltip>
                // }
              >
                <Box sx={{ width: "100%" }}>
                  {fittingTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="fittingTable"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {fittingTableData?.length} of{" "}
                          {fittingTableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0013;
