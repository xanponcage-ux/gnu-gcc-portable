import React from "react";
import tataImage from "src/assets/images/ts_logo.jpg";
import backImage from "src/assets/images/steelPlant.jpg";
// import tataImage from "src/assets/images/Tata_White.png";
import imageBackground from "src/assets/images/plant.jpg";
import { BannerContainer } from "./style";
import {
  Box,
  Grid,
  Typography,
  Dialog,
  DialogContent,
  DialogActions,
  DialogTitle,
} from "@mui/material";
import People from "@mui/icons-material/People";
import Key from "@mui/icons-material/Key";
import { Input } from "src/components/input";
import Button from "src/components/button";
import { FormType, InputType } from "./type";
import { GenaratePasscodeApi, LoginApi } from "src/apiConfig/outsideAuthApi";
import { setInStorage } from "src/utils";
import { useMaterialUIController, setUser } from "src/context";
import { useNavigate } from "react-router-dom";
import routes from "src/constant/route";
import alertify from "src/components/alert";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import { csTheme } from "src/theme/type";
import { useTheme } from "@mui/material/styles";

const LoginScreen = () => {
  const navigate = useNavigate();
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);
  const [pin, setPin] = React.useState(Array(6).fill(""));
  const [newPin, setNewPin] = React.useState(Array(6).fill(""));
  const [isNewReq, setIsNewReq] = React.useState(false);
  const [isNewGen, setIsNewGen] = React.useState(false);
  const [inputObj, setInputObj] = React.useState<InputType>({
    user: {
      config: {
        type: "input",
        // label: "User Name",
        // sIcon: <People />,
        autoFocus: true,
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "user"),
    },
    password: {
      config: {
        type: "password",
        // label: "Password",
        // sIcon: <Key />,
      },
      value: "",
      onChange: (e) => onInputChange(e?.toString(), "password"),
    },
  });

  React.useEffect(() => {
    if (user) {
      navigate(routes.dashboard);
    }
  }, [user]);

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputType],
        value: value,
      },
    }));
  };

  const handlPinChange = (value: any, i: number) => {
    let varPin = [...pin];
    varPin[i] = value;
    if (
      (pin[i]?.length === 0 || value?.length === 0) &&
      Number(value?.toString())?.toString() !== "NaN"
    ) {
      setPin(varPin);
      if (value?.length > 0) {
        document.getElementById(`pin${i + 1}`)?.focus();
      }
    }
  };

  const handlPinNewChange = (value: any, i: number) => {
    let varPin = [...newPin];
    varPin[i] = value;
    if (
      (newPin[i]?.length === 0 || value?.length === 0) &&
      Number(value?.toString())?.toString() !== "NaN"
    ) {
      setNewPin(varPin);
      document.getElementById(`npin${i + 1}`)?.focus();
    }
  };

  const inputfocus = (elmnt: any, i: number) => {
    if (elmnt.key === "Delete" || elmnt.key === "Backspace") {
      if (pin[i]?.length === 0 || pin[i]?.length === undefined) {
        document.getElementById(`pin${i - 1}`)?.focus();
      }
    }
  };

  const inputfocusNew = (elmnt: any, i: number) => {
    if (elmnt.key === "Delete" || elmnt.key === "Backspace") {
      if (newPin[i]?.length === 0 || newPin[i]?.length === undefined) {
        document.getElementById(`npin${i - 1}`)?.focus();
      }
    }
  };

  const onGenerate = (isForgot: boolean, reset?: boolean) => {
    var uName = inputObj.user.value;
    var pWord = inputObj.password.value;

    var username = uName.replaceAll(" ", "");
    var password = pWord.replaceAll(" ", "");

    if (
      !username ||
      !password ||
      username.length == 0 ||
      password.length == 0
    ) {
      alertify.error("Please provide user id, password");
      return;
    }

    if (isNewGen) {
      if (newPin.join("")?.length !== 6) {
        alertify.error("Please provide New Passcode");
        return;
      }
    }
    setLoading(true);
    var text = username + ":" + password;
    var t = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
    var CryptoJS = require("crypto-js");
    var key = CryptoJS.MD5(t).toString();
    var encrypted = CryptoJS.TripleDES.encrypt(text, key);
    var base64String = encrypted.toString();
    var data = {
      userDetails: base64String,
      isForgot: isForgot,
      ...(reset && { onReset: true }),
      ...(isNewGen && { newPasscode: newPin.join("") }),
    };
    GenaratePasscodeApi(data)
      .then((response) => {
        setLoading(false);
        if (response?.statusText != "" && response?.statusText != "OK") {
          return Promise.reject(response.statusText);
        } else if (response?.data?.status !== true) {
          if (response?.data?.error?.slice(0, 3) === "NP-") {
            if (isNewGen) {
              alertify.error(response.data.error);
            } else {
              setIsNewGen(true);
            }
          } else {
            setIsNewGen(false);
            alertify.error(response.data.error);
            setNewPin(Array(6).fill(""));
            setPin(Array(6).fill(""));
          }
          return;
        } else if (response?.data?.status === true) {
          setNewPin(Array(6).fill(""));
          setPin(Array(6).fill(""));
          setIsNewGen(false);
          setIsNewReq(false);
          if (isForgot) {
            onGenerate(false, true);
          } else {
            alertify.success(response.data.message);
          }
        } else {
          alertify.error("Something went wrong!");
        }
      })
      .catch((e) => {
        setLoading(false);
        alertify.error("Something went wrong!");
      });
  };

  const onFormSubmit = (e: React.SyntheticEvent) => {
    e.preventDefault();
    let username = inputObj.user.value;
    let password = inputObj.password.value;
    let text = username + ":" + password;
    let paramData = {
      username: username,
      password: password,
      passcode: pin.join(""),
      ...(isNewReq && { newPasscode: newPin.join("") }),
    };
    var t = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
    var CryptoJS = require("crypto-js");
    var key = CryptoJS.MD5(t).toString();
    var encrypted = CryptoJS.TripleDES.encrypt(JSON.stringify(paramData), key);
    var base64String = encrypted.toString();
    var data = {
      userDetails: base64String,
    };
    if (
      !username ||
      !password ||
      username.length == 0 ||
      password.length == 0
    ) {
      alertify.error("Please provide user id, password");
      return;
    }

    if (pin.join("")?.length !== 6) {
      alertify.error("Please provide Passcode");
      return;
    }

    if (isNewReq && newPin.join("")?.length !== 6) {
      alertify.error("Please provide New Passcode");
      return;
    }
    setLoading(true);
    LoginApi(data)
      .then((res: any) => {
        if (!res.data?.error) {
          var CryptoJS = require("crypto-js");
          var t = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
          var bytes = CryptoJS.AES.decrypt(res.data, t);
          var decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
          console.log(decryptedData);
          if (
            decryptedData?.accessToken &&
            decryptedData?.refreshToken &&
            decryptedData?.user
          ) {
            setInStorage("user", decryptedData?.user);
            setInStorage("weak", decryptedData?.weak?.[0]?.WEAK);
            setInStorage("idleTime", decryptedData?.idleTime);
            setInStorage("token", {
              accessToken: decryptedData?.accessToken,
              refreshToken: decryptedData?.refreshToken,
            });
            setUser(dispatch, {
              user: decryptedData?.user,
              token: {
                accessToken: decryptedData?.accessToken,
                refreshToken: decryptedData?.refreshToken,
              },
            });
          } else {
            console.log(decryptedData);
            alertify.error(
              decryptedData?.error
                ? decryptedData?.error?.toString()
                : "Something wents wrong!"
            );
          }
        } else {
          alertify.error(
            res.data?.error
              ? res.data?.error?.toString()
              : "Something wents wrong!"
          );
        }
      })
      .catch((e) => {
        console.log(e);
        alertify.error(
          e?.error?.message ? e.error.message : "Something Wents wrong!"
        );
      })
      .finally(() => {
        setLoading(false);
      });
  };

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputType],
    });
  }

  return (
    <Grid container spacing={0}>
      <Grid
        item
        xs={8}
        style={{
          background: `url(${backImage})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
        }}
      ></Grid>
      <Grid item xs={4}>
        <div
          style={{
            // backgroundImage: `url(${imageBackground})`,
            // backgroundPosition: "center",
            // backgroundRepeat: "no-repeat",
            // backgroundSize: "cover",
            height: "100vh",
            width: "100%",
            minHeight: "450px",
            position: "relative",
            backgroundColor: "#f0f2f5",
          }}
        >
          <BannerContainer>
            <Box
              className="banner"
              style={{
                borderRadius: "0.5rem",
                textAlign: "center",
                padding: "4px",
                opacity: 1,
                background: "linear-gradient(195deg, #49a3f1, #1A73E8)",
                boxShadow:
                  "0rem 0.25rem 1.25rem 0rem rgba(0, 0, 0, 0.14), 0rem 0.4375rem 0.625rem -0.3125rem rgba(0, 187, 212, 0.4)",
              }}
            >
              <Card style={{ backgroundColor: "secondary" }}>
                <img
                  style={{ width: "150px", borderRadius: "0.75rem" }}
                  src={tataImage}
                  alt="logo"
                />
                <CardContent sx={{ paddingTop: "0px", marginTop: "-35px" }}>
                  <Typography
                    variant="h4"
                    fontWeight="bold"
                    // color={csTheme?.palette.primary.main}
                    color={"#344767"}
                    mt={0}
                    sx={{ fontSize: "1.3rem" }}
                  >
                    {/* SPC Production Planning & Integrated Network */}
                    SPCIS NXT
                  </Typography>
                  <Typography
                    paragraph={true}
                    fontWeight="light"
                    color="grey"
                    mt={1}
                    mb={0}
                  >
                    Please enter your credentials
                  </Typography>
                </CardContent>
              </Card>
            </Box>
            <Box className="container" style={{ backgroundColor: "#ffffff" }}>
              <form onSubmit={onFormSubmit}>
                <Grid container spacing={2}>
                  {formData?.map((x: FormType) => (
                    <Grid item xs={12} key={x.key}>
                      <Typography
                        fontWeight="regular"
                        fontSize="small"
                        textTransform="capitalize"
                        variant="h6"
                        color={"dark"}
                        noWrap
                      >
                        {x.key === "user" ? "User Name" : "Password"}
                      </Typography>
                      <Input
                        id={x?.key}
                        value={x?.data?.value}
                        {...x?.data?.config}
                        onChange={x?.data?.onChange}
                      />
                    </Grid>
                  ))}
                  <Grid item xs={12}>
                    <Box>
                      <Typography
                        fontWeight="regular"
                        fontSize="small"
                        textTransform="capitalize"
                        variant="h6"
                        color={"dark"}
                        noWrap
                      >
                        Passcode
                      </Typography>
                      <Grid container spacing={1}>
                        {pin?.map((x, i) => (
                          <Grid item xs={2} key={i}>
                            <Input
                              type="passcode"
                              id={`pin${i}`}
                              value={x ? x.toString() : ""}
                              onChange={(e: any) => handlPinChange(e, i)}
                              onKeyDown={(e: any) => inputfocus(e, i)}
                            />
                          </Grid>
                        ))}
                      </Grid>
                      {isNewReq || isNewGen ? (
                        <Dialog
                          open={isNewReq || isNewGen}
                          onClose={() => {
                            setIsNewGen(false);
                            setIsNewReq(false);
                          }}
                        >
                          <DialogTitle>Update Passcode</DialogTitle>
                          <DialogContent>
                            <Box>
                              <Grid container spacing={1}>
                                {newPin?.map((x, i) => (
                                  <Grid item xs={2} key={i}>
                                    <Input
                                      type="passcode"
                                      id={`npin${i}`}
                                      value={x ? x.toString() : ""}
                                      onChange={(e: any) =>
                                        handlPinNewChange(e, i)
                                      }
                                      onKeyDown={(e: any) =>
                                        inputfocusNew(e, i)
                                      }
                                    />
                                  </Grid>
                                ))}
                              </Grid>
                            </Box>
                          </DialogContent>
                          <DialogActions>
                            <Button
                              onClick={
                                !loading
                                  ? () => {
                                      setIsNewGen(false);
                                      setIsNewReq(false);
                                    }
                                  : () => {}
                              }
                            >
                              CLose
                            </Button>
                            <Button
                              onClick={
                                !loading
                                  ? isNewGen
                                    ? () =>
                                        onGenerate(
                                          false,
                                          isNewGen ? true : false
                                        )
                                    : onFormSubmit
                                  : () => {}
                              }
                            >
                              {loading ? "Saving..." : "Save"}
                            </Button>
                          </DialogActions>
                        </Dialog>
                      ) : null}
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          mt: 1,
                          mb: 2,
                        }}
                      >
                        <Typography
                          fontWeight="regular"
                          fontSize="small"
                          textTransform="capitalize"
                          sx={{ cursor: "pointer", color: "deepskyblue" }}
                          onClick={() => onGenerate(true)}
                        >
                          Forgot Passcode?
                        </Typography>
                        <Typography
                          fontWeight="regular"
                          fontSize="small"
                          textTransform="capitalize"
                          sx={{ cursor: "pointer", color: "deepskyblue" }}
                          onClick={() => onGenerate(false)}
                        >
                          Generate Passcode
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
                <Grid item xs={12}>
                  <Button
                    sx={{ width: "100%" }}
                    type="submit"
                    variant="contained"
                    extra={{ loading: loading }}
                  >
                    Login
                  </Button>
                </Grid>
              </form>
            </Box>
          </BannerContainer>
        </div>
      </Grid>
    </Grid>
  );
};

export default LoginScreen;
