@echo off
echo ===== CLAUDE BRIDGE CHAT TEST =====
curl.exe -sS -X POST "http://127.0.0.1:8765/v1/chat/completions" ^
  -H "Content-Type: application/json" ^
  -H "Authorization: Bearer dummy" ^
  -d "{\"model\":\"ignored-by-launcher\",\"messages\":[{\"role\":\"user\",\"content\":\"Reply exactly CLAUDE_BRIDGE_V4_OK\"}]}"
echo.
pause
