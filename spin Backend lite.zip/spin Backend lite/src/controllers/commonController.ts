import { Request, Response } from "express";
import CommonModel from "../models/commonModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getPlantData = async (req: Request, res: Response) => {
  try {
    const result1 = await CommonModel.prototype.getPlantData();
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getEpaCode02 = async (req: Request, res: Response) => {
  try {
    const result1 = await CommonModel.prototype.getEpaCode02();

    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
// export const getData02 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     console.log("req.body.data ==>", req.body.data);
//     if(req.body.data === 0) {
//         result1 = await CommonModel.prototype.getProcLineData02(req.body);
//     }
//     if(req.body.data === 1) {
//         result2 = await CommonModel.prototype.getProcPath02(req.body);
//     }
//     varData = {
//       ... { procLine: await ResponceData(result1) },
//       ...{ procPath: await ResponceData(result2) },
//     }
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
// export const getData05 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     let result3;
//     if (req.body.data === 0) {
//       result1 = await CommonModel.prototype.getSpecLimit05(req.body);
//     }
//     if (req.body.data === 1) {
//       result2 = await CommonModel.prototype.getQualityData05(req.body);
//     }
//     if (req.body.data === 2) {
//       result3 = await CommonModel.prototype.getTdcMain05(req.body);
//     }
//     varData = {
//       ...{ specLimit: await ResponceData(result1) },
//       ...{ tdcQlty: await ResponceData(result2) },
//       ...{ tdcMain: await ResponceData(result3) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getData06 = async (req: Request, res: Response) => {
//   try {
//     const  result1 = await CommonModel.prototype.getData06(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
// export const getData07 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await CommonModel.prototype.getData07(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
export const getData08 = async (req: Request, res: Response) => {
  try {
    const result1 = await CommonModel.prototype.getData08(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
// export const getTdcCode05 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await CommonModel.prototype.getTdcCode05();
//     const result2 = await CommonModel.prototype.getQltyCode05();
//     const result3 = await CommonModel.prototype.getTdcMainCode05();
//     const varData = {
//       tdc: await ResponceData(result1),
//       tdcMain: await ResponceData(result3),
//       qlty: await ResponceData(result2),
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getOrderId07 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await CommonModel.prototype.getOrderId07();
//     const result2 = await CommonModel.prototype.getEpa07();
//     const result3 = await CommonModel.prototype.getOrderStatus07();
//     const result4 = await CommonModel.prototype.getCustomer07();
//     const result5 = await CommonModel.prototype.getOrderType07();
//     const varData = {
//       epa: await ResponceData(result2),
//       order: await ResponceData(result1),
//       orderStatus: await ResponceData(result3),
//       customer: await ResponceData(result4),
//       orderType: await ResponceData(result5),
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
export const getEpaCodeData08 = async (req: Request, res: Response) => {
  try {
    const result1 = await CommonModel.prototype.getEpaCodeData08();
    const result2 = await CommonModel.prototype.getOrderData08();
    const varData = {
      epa: await ResponceData(result1),
      order: await ResponceData(result2),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getData06 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;

    if (req.body.data === 0) {
      result1 = await CommonModel.prototype.getSECONDSTdc06(req.body);
    }
    if (req.body.data === 1) {
      result2 = await CommonModel.prototype.getTdcMap06(req.body);
    }

    varData = {
      ...{ SecondsTb: await ResponceData(result1) },
      ...{ TdcMapTb: await ResponceData(result2) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const getEpaCode06 = async (req: Request, res: Response) => {
  try {
    const result1 = await CommonModel.prototype.getEpaPlant06();
    const result2 = await CommonModel.prototype.getTdcsec06();
    const result3 = await CommonModel.prototype.getActTdc06();

    console.log(result1);
    const varData = {
      EpaPlant: await ResponceData(result1),
      TdcSec: await ResponceData(result2),
      Acttdc: await ResponceData(result3),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const callProcedure06 = async (req: Request, res: Response) => {
  try {
    const data = req.body;
    let results: any = {}; //{ 'success': 0, "fail": 0 }
    for (let i in data) {
      let singleData = data[i];
      let result1: any = await CommonModel.prototype.callProcedure06(
        singleData
      );
      let outBinds = result1.outBinds.ls_message;
      results = outBinds;
    }
    return res.status(200).json(results);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
