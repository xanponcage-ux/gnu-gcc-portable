// const SPS0025Query = require("../repository/SPS0025Query");
import * as SPS0025Query from "../repository/SPS0025Query";

export default class SPS0025Model {
  getPlantData(data: any) {
    return SPS0025Query.getPlantData(data);
  }
  getBatchData(data: any) {
    return SPS0025Query.getBatchData(data);
  }
  getBatchData2(data: any) {
    return SPS0025Query.getBatchData2(data);
  }
  getInputCoilAudit(data: any) {
    return SPS0025Query.getInputCoilAudit(data);
  }
  getProductionAudit(data: any) {
    return SPS0025Query.getProductionAudit(data);
  }
  getCustOrdAudit(data: any) {
    return SPS0025Query.getCustOrdAudit(data);
  }
}
