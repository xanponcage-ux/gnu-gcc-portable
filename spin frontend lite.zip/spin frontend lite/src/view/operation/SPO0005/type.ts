import { dateInput, input } from "../../type";

export interface InputChangeType {
  // key1: input,
  key1: input;
  key2: input;
}
export interface TableType {
  EGP_CD_EPA: string;
  CIR_ID_COIL: string;
  EIC_ID_COIL: string;
}
