"""End-to-end test of the running localhost bridge."""

import json
from pathlib import Path

import requests
from dotenv import dotenv_values


config = dotenv_values(Path(__file__).resolve().parent / ".env")
token = config.get("BRIDGE_LOCAL_TOKEN", "")
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

health = requests.get("http://127.0.0.1:8765/health", timeout=5)
print("Health:", health.status_code, health.json())

payload = {
    "model": "gpt-4o-mini",
    "messages": [
        {"role": "system", "content": "You are a concise coding assistant."},
        {"role": "user", "content": "Write one valid JavaScript line that adds 2 and 3."},
    ],
    "temperature": 0.1,
    "max_tokens": 100,
    "stream": False,
}
response = requests.post(
    "http://127.0.0.1:8765/v1/chat/completions",
    headers=headers,
    data=json.dumps(payload),
    timeout=200,
)
print("Chat:", response.status_code)
print(json.dumps(response.json(), indent=2))
response.raise_for_status()
