import { Request, Response } from "express";
import SPC0008Model from "../models/SPC0008Model";
import { ResponceData } from "../utils";

export const getData08 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0008Model.prototype.getData08(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getOrderData08 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0008Model.prototype.getEpa08();
    const result2 = await SPC0008Model.prototype.getOrderData08();
    const result3 = await SPC0008Model.prototype.getNoEnd08();
    const result4 = await SPC0008Model.prototype.getNoInp08();
    const varData = {
      epa: await ResponceData(result1),
      order: await ResponceData(result2),
      endmaterialNo: await ResponceData(result3),
      inpmaterialNo: await ResponceData(result4),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
