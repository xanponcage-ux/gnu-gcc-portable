import { Request, Response } from "express";
import SPC0011Model from "../models/SPC0011Model";
import { ResponceData } from "../utils";

export const getData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPC0011Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getTableData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPC0011Model.prototype.getTableData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
