import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, SelectInput } from "../../../components/input";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
//import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import PrintIcon from "@mui/icons-material/Print";
import {
  QPconfirmExecQuery,
  QPexecQuery,
  QPexecQueryScreenAccess,
  QPtestConnection,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
// import { InputChangeType } from "./type";
//import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "../../../context";
import { FormType } from "../../auth/type";
import { useReactToPrint } from "react-to-print";
import Auth from "../../../components/layout/dashboardLayout/auth";
import { styled } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/material";
// import FormControl from "@material-ui/core/FormControl";
// import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@mui/material";
import FormControlLabel from "@mui/material";
import RadioGroup from "@mui/material";
import Radio from "@mui/material";
import { RadioInput } from "../../../components/input";
import { useEffect } from "react";
import TextareaAutosize from "@mui/material/TextareaAutosize";

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

const Query_Pg = () => {
  const csTheme = useTheme();
  const [controller] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState(false);
  const [isAdmin, setAdmin] = React.useState(false);
  const [isRestricted, setRestricted] = React.useState(true);
  const [isReadWriteAccess, setReadWriteAccess] = React.useState(true);
  const [tabValue, setTabValue] = React.useState(0);
  const handleSetTabValue = (event, newValue) => {
    setTabValue(newValue);
  };
  //   const useStyles = makeStyles(() => ({
  //     ...styles,
  //     root: {
  //       "& .MuiOutlinedInput-input": {
  //         fontWeight: "bold",
  //       },
  //       "& .MuiAccordionSummary-content": {
  //         color: "white",
  //       },
  //     },
  //   }));
  //   const classes = useStyles();
  //   const { ...rest } = props;
  const [qryType, setQryType] = React.useState([
    { label: "-Select", value: "" },
    { label: "Select Operation", value: "SelectOperation" },
    { label: "Execute Operation", value: "ExecuteOperation" },
    { label: "DECLARE", value: "DECLARE" },
  ]);
  const [selectedQryType, setSelectedQryType] = React.useState(null);
  const [showSaveMsgSuccess, setShowSaveMsgSuccess] = React.useState(false);
  const [showSaveMsgError, setShowSaveMsgError] = React.useState(false);
  const [saveMsg, setSaveMsg] = React.useState("");
  const [queryState, setQueryState] = React.useState("");
  const [resultDataTable, setResultDataTable] = React.useState(null);
  const [resultData, setResultData] = React.useState([]);
  const [resultDataClm, setResultDataClm] = React.useState([]);
  const [resultExcData, setResultExeData] = React.useState(null);
  const [resultExcErrData, setResultExeErrData] = React.useState(null);
  const [allValues, setAllValues] = React.useState({
    Server: "",
    Port: "",
    DBName: "",
    testId: "",
    testCode: "",
  });
  const [valueRadio, setValueRadio] = React.useState("S");
  const [connMsg, setConnMsg] = React.useState("");

  const radioOptions = [
    { label: "SID", value: "SID" },
    { label: "Service Name", value: "SNM" },
  ];
  const [selectedROptn, setSelectedROptn] = React.useState("SID");

  const fetchData = async () => {
    setLoading(true);
    // getUserScreenAccess();
    Promise.all([getUserScreenAccess()]).finally(() => {
      setLoading(false);
    });
  };

  // React.useEffect(() => {
  //   fetchData();
  // }, []);

  React.useEffect(() => {
    var o = localStorage.getItem("dbLogin");
    var salt = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
    if (o) {
      o = decodeURI(o);
      if (salt && o.indexOf(salt) != 0)
        throw new Error("object cannot be decrypted");
      o = o.substring(salt.length).split("");
      for (var i = 0, l = o?.length; i < l; i++)
        if (o?.[i] == "{") o[i] = "}";
        else if (o[i] == "}") o[i] = "{";
      var d = JSON.parse(o.join(""));
      console.log(d, "+++++++++++");

      if (d) {
        setConnMsg("Connection Restored");
        var s = d.dbUri.split(/[:/]/);
        setAllValues({
          Server: s[0],
          Port: s[1],
          DBName: s[2],
          testId: d.testId,
          testCode: d.testCode,
        });
      } else {
        setConnMsg("");
      }
    }
    fetchData();
  }, []);

  useEffect(() => {
    if (
      resultData &&
      resultData.length > 0 &&
      resultDataClm &&
      resultDataClm.length > 0
    ) {
      setResultDataTable(
        new Tabulator("#resulttable", {
          data: resultData,
          columns: resultDataClm,
          maxHeight: 400,
          layout: "fitDataFill",
          pagination: "local", //enable local pagination.
          paginationSize: 12,
        })
      );
    }
  }, [resultData, resultDataClm]);

  function encrypt(o, salt) {
    o = JSON.stringify(o).split("");
    for (var i = 0, l = o.length; i < l; i++)
      if (o[i] == "{") o[i] = "}";
      else if (o[i] == "}") o[i] = "{";
    return encodeURI(salt + o.join(""));
  }

  const getUserScreenAccess = () => {
    setLoading(true);
    GetAuthorization().then((token) => {
      let data = {
        user: user,
      };
      QPexecQueryScreenAccess(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log("res?.data: ", res?.data.rows[0][0]);
            if (res.data.rows[0][0] != 1) {
              setRestricted(true);
              setAdmin(false);
              setLoading(false);
            } else {
              setRestricted(false);
            }
            setLoading(false);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const testConnection = () => {
    setConnMsg("");
    if (
      allValues.Server == "" ||
      allValues.Port == "" ||
      allValues.DBName == "" ||
      allValues.testId == "" ||
      allValues.testCode == ""
    ) {
      alertify.error("All filds are mandatory!");
      return;
    }
    GetAuthorization().then((token) => {
      // let data = {
      //   user: user,
      // };
      var data = {
        dbUri: `${
          allValues.Server + ":" + allValues.Port + "/" + allValues.DBName
        }`,
        testId: allValues.testId,
        testCode: allValues.testCode,
      };
      var salt = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
      var encrypted = encrypt(data, salt);
      localStorage.setItem("dbLogin", encrypted);
      setLoading(true);
      QPtestConnection(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.errorNum == 1017) {
              alertify.error(
                "Error: ORA-01017: invalid username/password; logon denied"
              );
              setConnMsg(
                "Error: ORA-01017: invalid username/password; logon denied"
              );
              setLoading(false);
            } else if (res?.data?.metaData != 0) {
              setConnMsg("Connection Successful");
            }
            setLoading(false);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const executeBtn = () => {
    var getLoc = localStorage.getItem("dbLogin");

    if (getLoc) {
      if (selectedQryType == "ExecuteOperation") {
        var a = queryState.split(" ");
        if (a[0].toUpperCase() == "INSERT") {
          executeQuery();
        } else {
          confirmExecQuery();
        }
      } else {
        executeQuery();
      }
    } else {
      alertify.error(
        "database connection could not establish, please check your configuration !!!"
      );
    }
  };

  const executeQuery = () => {
    setResultExeErrData("");
    setResultExeData("");
    if (!selectedQryType) {
      alertify.error("Please select Type of query");
      return;
    }
    if (queryState == "") {
      alertify.error("Please enter query");
      return;
    }
    GetAuthorization().then((token) => {
      var txt = queryState?.split("\n")?.join(" ");
      var t = txt.replace(/\n/g, "");
      var str = t.replace(/\s\s+/g, " ");
      var b = str.replace(/"/g, "'");
      let data = {
        queryType: selectedQryType,
        query: b,
        dt: localStorage.getItem("dbLogin"),
      };
      setLoading(true);

      QPexecQuery(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            // alertify.error(res?.data?.err ? res.data.err : res?.toString());
            setResultExeErrData(
              res?.error?.res?.data?.name ?? "Something wents wrong!"
            );
          } else if (res?.data) {
            setLoading(false);
            if (selectedQryType == "SelectOperation") {
              setResultData(res.data[1]);
              setResultDataClm(res.data[0]);
            } else {
              setResultExeData(res?.data);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const confirmExecQuery = () => {
    // setLoading(true);
    setResultExeErrData("");
    setResultExeData("");
    if (!selectedQryType) {
      alertify.error("Please select Type of query");
      return;
    }
    if (queryState == "") {
      alertify.error("Please enter query");
      return;
    }
    GetAuthorization().then((token) => {
      var txt = queryState?.split("\n")?.join(" ");
      var t = txt.replace(/\n/g, "");
      var str = t.replace(/\s\s+/g, " ");
      var b = str.replace(/"/g, "'");
      let data = {
        queryType: selectedQryType,
        query: b,
        dt: localStorage.getItem("dbLogin"),
      };
      setLoading(true);

      QPconfirmExecQuery(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            // alertify.error(res?.data?.err ? res.data.err : res?.toString());
            setResultExeErrData(
              res?.error?.res?.data?.name ?? "Something wents wrong!"
            );
            return;
          } else if (res?.data?.rows) {
            alertify.confirm(
              `Number of rows will get effected = ${res?.data?.rows?.length}!`,
              "",
              function () {
                setTimeout(function () {
                  alertify.confirm(
                    `Do you want to Execute this?`,
                    "",
                    function () {
                      executeQuery();
                    },
                    function () {
                      console.log("Cancel");
                    }
                  );
                }, 1000);
              },
              function () {
                console.log("Cancel");
              }
            );
          } else {
            setResultExeData(res?.data);
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // const handleChangeServerDetails = (e) => {
  //   console.log("e: ", e);
  //   // console.log("e.target.name: ", e.target.value);
  //   setAllValues({ ...allValues, [e.target.name]: e.target.value });
  // };

  // const handleRadioChange = (event) => {
  //   setValueRadio(event.target.value);
  // };

  return (
    <DashboardLayout>
      {/* <Auth isRestricted={restricted} setRestricted={setRestricted}> */}

      {isRestricted && (
        <Grid Container justify="center">
          <h4 style={{ color: "red" }}>
            You are not authorized to view this page !
          </h4>
        </Grid>
      )}

      {!isRestricted && (
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              //   headerContainer={
              //     <Tooltip title="Clear All">
              //       <IconButton onClick={handleClearAll}>
              //         <ClearAllIcon sx={{ color: "#ffffff" }} />
              //       </IconButton>
              //     </Tooltip>
              //   }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={2}>
                      <Input
                        id={"Server"}
                        name={"Server"}
                        value={allValues.Server || ""}
                        label="SERVER"
                        size={"small"}
                        onChange={(e) => {
                          setAllValues({
                            ...allValues,
                            Server: e,
                          });
                        }}
                      />
                    </Grid>
                    <Grid item xs={1.5}>
                      <Input
                        id={"Port"}
                        name={"Port"}
                        value={allValues.Port || ""}
                        label="PORT"
                        size={"small"}
                        onChange={(e) => {
                          setAllValues({
                            ...allValues,
                            Port: e,
                          });
                        }}
                      />
                    </Grid>
                    <Grid item xs={1.5}>
                      <Input
                        id={"dbName"}
                        name={"dbName"}
                        value={allValues.DBName || ""}
                        label="DB NAME"
                        size={"small"}
                        onChange={(e) => {
                          setAllValues({
                            ...allValues,
                            DBName: e,
                          });
                        }}
                      />
                    </Grid>

                    <Grid item xs={1.5}>
                      <Input
                        id={"testId"}
                        name={"Test Id"}
                        value={allValues.testId || ""}
                        label="TEST ID"
                        size={"small"}
                        onChange={(e) => {
                          setAllValues({
                            ...allValues,
                            testId: e,
                          });
                        }}
                      />
                    </Grid>

                    <Grid item xs={1.5}>
                      <Input
                        id={"testCode"}
                        name={"Test Code"}
                        value={allValues.testCode || ""}
                        label="TEST CODE"
                        size={"small"}
                        type="password"
                        onChange={(e) => {
                          setAllValues({
                            ...allValues,
                            testCode: e,
                          });
                          // handleChangeServerDetails(e);
                        }}
                      />
                    </Grid>

                    <Grid item xs={4}>
                      <RadioInput
                        id={"radioOption"}
                        row={true}
                        value={selectedROptn}
                        data={radioOptions}
                        onChange={(e) => {
                          setSelectedROptn(e);
                        }}
                      />
                    </Grid>

                    <Grid item xs={2.2}>
                      <Box component="span">
                        <Grid container>
                          <ButtonElement
                            onClick={() => {
                              testConnection();
                            }}
                          >
                            TEST CONNECTION
                          </ButtonElement>
                        </Grid>
                      </Box>
                    </Grid>
                    <Grid item xs={1.5}>
                      <Box component="span">
                        <Grid container>
                          <ButtonElement onClick={() => {}}>
                            DISCONNECT
                          </ButtonElement>
                        </Grid>
                      </Box>
                    </Grid>
                    <Grid item xs={3}>
                      <Box component="span">
                        <Grid container>
                          {!connMsg && (
                            <h4 style={{ color: "red" }}>
                              All filds are Mandatory !!!
                            </h4>
                          )}
                          {connMsg && (
                            <h4 style={{ color: "green" }}>{connMsg}</h4>
                          )}
                        </Grid>
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>

          <Grid item xs={12}>
            <TableContainer
              title="Test Connection"
              //   headerContainer={
              //     <Tooltip title="Clear All">
              //       <IconButton onClick={handleClearAll}>
              //         <ClearAllIcon sx={{ color: "#ffffff" }} />
              //       </IconButton>
              //     </Tooltip>
              //   }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={2.8}>
                      <label style={{ fontSize: "1.3em" }}>
                        Select Query Type{" "}
                      </label>
                      <SelectInput
                        placeholder="Select Query Type"
                        data={qryType}
                        value={selectedQryType}
                        size={"small"}
                        onChange={(e) => {
                          setSelectedQryType(e);
                          setQueryState("");
                        }}
                      />
                    </Grid>
                    <Grid item xs={8}>
                      <label style={{ fontSize: "1.3em" }}>Enter Query </label>
                      <TextareaAutosize
                        maxRows={10}
                        aria-label="maximum height"
                        placeholder="Maximum 4 rows"
                        defaultValue=""
                        value={queryState}
                        style={{
                          maxWidth: "100%",
                          minWidth: "100%",
                          height: "5em",
                          backgroundColor: "#f5f5dc",
                          borderRadius: "6px",
                        }}
                        onChange={(e) => {
                          setQueryState(e.target.value);
                        }}
                      />
                    </Grid>
                    <Grid item xs={1}>
                      &nbsp;
                      <Box component="span">
                        <Grid container>
                          <ButtonElement
                            onClick={() => {
                              executeBtn();
                            }}
                          >
                            EXECUTE
                          </ButtonElement>
                        </Grid>
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>

          {selectedQryType === "SelectOperation" && (
            <Grid item xs={12}>
              <TableContainer title="Select Operation">
                {resultData?.length > 0 && <div id="resulttable"></div>}
              </TableContainer>
            </Grid>
          )}

          {selectedQryType === "ExecuteOperation" && (
            <Grid item xs={12}>
              <TableContainer title="Execute Operation">
                <Grid item xs={12}>
                  {resultExcData && (
                    <h4 style={{ color: "green" }}>
                      {JSON.stringify(resultExcData, null, 2)}
                    </h4>
                  )}

                  {resultExcErrData && (
                    <h4 style={{ color: "red" }}>
                      {JSON.stringify(resultExcErrData, null, 2)}
                    </h4>
                  )}
                </Grid>
              </TableContainer>
            </Grid>
          )}
        </Grid>
      )}

      {/* </Auth> */}
    </DashboardLayout>
  );
};

export default Query_Pg;
