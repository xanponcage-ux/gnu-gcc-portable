CODEGENIE -> ROO BRIDGE v3
===========================

WHAT CHANGED
------------
The bridge can now be started by double-clicking:

    START_CODEGENIE_BRIDGE.cmd

No command typing is required.

The command window gives you keyboard-controlled selections:

1. MODEL
   - UP / DOWN arrows
   - Default: Claude 4.5 Sonnet

2. TEMPERATURE
   - LEFT / RIGHT slider
   - Range: 0.0 to 1.0
   - Default: 1.0 (maximum)

3. MAX OUTPUT TOKENS
   - LEFT / RIGHT slider
   - Presets: 500, 1K, 2K, 4K, 8K, 16K, 32K, 64K, MAX
   - Default: MAX

MAX means the bridge DOES NOT SEND max_tokens.
Therefore the bridge itself imposes no output-token cap.
The actual selected model / CodeGenie gateway still has its own provider-side
limits, which the bridge cannot remove.

FIRST-TIME SETUP
----------------
1. Open BRIDGE_CREDENTIALS.cmd in Notepad.
2. Enter your own CODEGENIE_ADID and CODEGENIE_APIKEY locally.
3. Save.
4. Double-click START_CODEGENIE_BRIDGE.cmd.

Do not share BRIDGE_CREDENTIALS.cmd after adding credentials.

ROO CONFIG
----------
Provider:
    OpenAI Compatible

Base URL:
    http://127.0.0.1:8765/v1

API Key:
    dummy

The launcher forces the selected CodeGenie model, temperature, and token
behavior, so the model name configured in Roo is not authoritative while
the bridge is running in launcher mode.

CONFIRMED CODEGENIE DEPLOYMENTS INCLUDED
----------------------------------------
- Claude 4.5 Sonnet    -> claude-4.5-sonnet
- GPT 5 Mini          -> gpt-5-mini
- Gemini 3 Flash      -> gemini-3-flash
- Claude 4.5 Haiku    -> claude-4.5-haiku
- GPT-4o-mini         -> gpt-4o-mini

Other models visible in CodeGenie are left in models.json with blank
deployment_name values until their exact Network payload values are known.
This avoids silently guessing deployment IDs.

If you obtain another exact deployment_name, edit models.json:
- fill deployment_name
- restart the launcher
It will automatically become selectable.

TEMPERATURE NOTE
----------------
1.0 is "maximum" only within CodeGenie's observed 0-1 control range.
Higher temperature is not sent.

TOKENS NOTE
-----------
MAX does not mean infinite output. It means "no bridge-side limiter".
The model and CodeGenie gateway still enforce their own maximums.

STOPPING
--------
Keep the command window open.
Press CTRL+C to stop the bridge.


V4 - CLAUDE / BEDROCK COMPATIBILITY
-----------------------------------
CodeGenie's Claude 4.5 Sonnet route returns a Bedrock-style response and,
in testing, emits Roo tool requests as XML text rather than OpenAI
tool_calls.

V4 handles this automatically:

Roo OpenAI messages
    -> bridge converts Claude messages to Bedrock-style content blocks
    -> CodeGenie Claude
    -> Claude XML tool requests
    -> bridge converts them to OpenAI tool_calls
    -> Roo executes the local tools
    -> tool results return through the bridge

You do NOT need to change Roo's tool settings.

Claude 4.5 Sonnet MAX output is configured as 64000 because that value was
observed in the company's CodeGenie UI / working request path.

For models whose exact maximum has not been captured yet, MAX means the
bridge leaves the provider to enforce its own limit.

IMPORTANT
---------
The XML tool shim exists because the current CodeGenie Claude route does not
return native OpenAI tool_calls in the observed responses. GPT-4o-mini keeps
using CodeGenie's native OpenAI tool calling.
