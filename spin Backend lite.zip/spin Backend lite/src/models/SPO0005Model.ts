// const SPO0005Query = require("../repository/SPO0005Query");
import * as SPO0005Query from "../repository/SPO0005Query";

export default class SPO0005Model {
  getData(data: any) {
    return SPO0005Query.getData(data);
  }
  getTableData(data: any) {
    return SPO0005Query.getTableData(data);
  }
  callDeleteProcedure(data: any) {
    return SPO0005Query.callDeleteProcedure(data);
  }
}
