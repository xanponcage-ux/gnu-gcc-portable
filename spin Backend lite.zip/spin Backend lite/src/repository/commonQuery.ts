import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { getCommonPlantData } from "./plantQuery";

export const getPlantData = async () => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};

export const getEpaCode02 = async () => {
  try {
    const sql = `SELECT
    DISTINCT EPL_CD_EPA
   FROM
       V_EPA_PROC_LINE`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getProcLineData02 = async (data: any) => {
  try {
    let binds: any = {
      code: data?.code ? parseInt(data?.code) : 0,
    };
    let sql = `SELECT
      EPL_ACTIVE_PLANT_FL,
      EPL_ACTIVITY_FLAG,
      EPL_ACTIVITY_NM,
      EPL_ACTIVITY_TIME,
      EPL_ADDRESS,
      EPL_BUSINESS_UNIT,
      EPL_BUSI_ROLE,
      EPL_CD_COMP,
      EPL_CD_CUST,
      EPL_CD_EPA,
      EPL_CD_PROCESS,
      EPL_CONSP_FLAG,
      EPL_ID_PRINTER,
      EPL_NO_PROC_SEQ,
      EPL_PLNG_FLAG,
      EPL_PROC_LINE_DESC,
      EPL_PRODUCTION_TYPE,
      EPL_REM1,
      EPL_REM2,
      EPL_REM3,
      EPL_SAP_INTERFACE_IND,
      EPL_SERVER,
      NVL(EPL_STOR_LOC, 0) EPL_STOR_LOC,
      EPL_THK_TOL_FLAG,
      EPL_URL,
      EPL_EPA_DESC,
      EPL_PROC_LINE_DESC
    FROM
      V_EPA_PROC_LINE
    WHERE EPL_CD_EPA = :code`;
    if (data.process && data.process?.length > 0) {
      sql += ` AND EPL_CD_PROCESS = :process`;
      binds["process"] = data?.process;
    }
    if (data.flag && data.flag?.length > 0) {
      sql += ` AND EPL_ACTIVE_PLANT_FL = :flag`;
      binds["flag"] = data?.flag;
    }
    sql += " ORDER BY EPL_NO_PROC_SEQ";

    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getProcPath02 = async (data: any) => {
  try {
    let sql = "";
    let binds: any = {};
    if (data.code?.length > 0 || data.process?.length > 0) {
      binds = {
        code: data?.code ? parseInt(data?.code) : 0,
      };
      sql = `SELECT
        *
      FROM
        V_EPA_PROC_PATH
      WHERE  PPH_CD_EPA = :code`;
      if (data.process && data.process?.length > 0) {
        sql += ` AND PPH_CD_PROC_PATH = :process`;
        binds["process"] = data?.process;
      }
    } else {
      sql = `SELECT
        *
      FROM
      V_EPA_PROC_PATH`;
    }
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
// export const getTdcCode05 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT TSL_TDC_NO
//    FROM
//     V_TDC_SPEC_LIMIT`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getSpecLimit05 = async (data: any) => {
//   try {
//     let binds: any = {};

//     let sql = `SELECT
//       NVL(TSL_CD_TEST, '') TSL_CD_TEST,
//       NVL(TSL_FL_CHNG_SAP, '') TSL_FL_CHNG_SAP,
//       NVL(TSL_PARA_MAX, 0) TSL_PARA_MAX,
//       NVL(TSL_PARA_MIN, 0) TSL_PARA_MIN,
//       NVL(TSL_PARA_UNIT, '') TSL_PARA_UNIT,
//       NVL(TSL_RFD_ID, ' ') TSL_RFD_ID,
//       NVL(TSL_SR_COMPANY, '') TSL_SR_COMPANY,
//       NVL(TSL_SR_COMP_FLAG, ' ') TSL_SR_COMP_FLAG,
//       NVL(TSL_TDC_NO, '') TSL_TDC_NO,
//       NVL(TSL_TEST_PARA, '') TSL_TEST_PARA
//     FROM
//     V_TDC_SPEC_LIMIT`;
//     if (data?.tdc) {
//       sql += ` WHERE TSL_TDC_NO = :tdc`;
//       binds["tdc"] = data?.tdc;
//     }
//     if (data.testPara && data.testPara?.length > 0) {
//       sql += ` AND TSL_TEST_PARA = :testPara`;
//       binds["testPara"] = data?.testPara;
//     }
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getQltyCode05 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT IQL_CD_QLTY
//    FROM
//     V_QUALITY`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getQualityData05 = async (data: any) => {
//   try {
//     let binds: any = {};
//     let sql = `SELECT
//       IQL_CD_QLTY CD_QLTY,
//       IQL_GRADE GRADE,
//       IQL_GRADE_DESC GRADE_DESC,
//       to_char(IQL_TS_CREATE, 'DD-MON-YY HH24:MI:SS') TS_CREATE,
//       IQL_CD_SPEC_TOL CD_SPEC_TOL,
//       IQL_DS_QLTY DS_QLTY,
//       IQL_PS_INDICATOR PS_INDICATOR
//     FROM
//       V_QUALITY`;
//     if (data?.qltyCode) {
//       sql += ` WHERE IQL_CD_QLTY = :qltyCode`;
//       binds["qltyCode"] = data?.qltyCode;
//     }

//     if (data.grade && data.grade?.length > 0) {
//       sql += ` AND IQL_GRADE = :grade`;
//       binds["grade"] = data?.grade;
//     }
//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getTdcMainCode05 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT TMA_TDC_NO
//    FROM
//     V_TDC_MAIN`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getTdcMain05 = async (data: any) => {
//   try {
//     let binds: any = {};
//     let sql = `SELECT
//     TMA_TDC_NO TDC_NO,
//     TMA_TDC_DESC TDC_DESC,
//     TMA_CD_QLTY CD_QLTY,
//     TMA_GRADE GRADE,
//     TMA_TDC_GRD_DESC TDC_GRD_DESC,
//     TMA_SEC1_AIM_FR SEC1_AIM_FR,
//     TO_CHAR(ROUND(TMA_SEC1_AIM_TO, 3), '9990.000') SEC1_AIM_TO,
//     TMA_SEC2_AIM_FR SEC2_AIM_FR,
//     TMA_SEC2_AIM_TO SEC2_AIM_TO,
//     TMA_CD_END_USE CD_END_USE,
//     TMA_END_USE_DESC END_USE_DESC,
//     TMA_SEC1_TOL_MIN SEC1_TOL_MIN,
//     TMA_SEC1_TOL_MAX SEC1_TOL_MAX,
//     TMA_HR_TDC_NO HR_TDC_NO,
//     TMA_CD_PROD CD_PROD,
//     TMA_RFD_ID RFD_ID,
//     TMA_CD_QLTY CD_QLTY,
//     TMA_CD_PROD CD_PROD

//   FROM
//     V_TDC_MAIN`;
//     if (data?.tdc) {
//       sql += ` WHERE TMA_TDC_NO = :tdc`;
//       binds["tdc"] = data?.tdc;
//     }

//     if (data.qltyCode && data.qltyCode?.length > 0) {
//       sql += ` AND TMA_CD_QLTY = :qltyCode`;
//       binds["qltyCode"] = data?.qltyCode;
//     }

//     return await query(sql, binds);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getData06 = async (data: any) => {
//   try {
//     let binds = {
//       tdc: data?.tdc
//     }
//     const sql = `SELECT
//     *
// FROM
//   V_EPA_LINE_PRODN`;
//     return await query(sql);
//   } catch (error: any) {
//
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getEpa07 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT ENC_CD_EPA
//   FROM
//     V_END_CUST_ORD_EPA`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getOrderId07 = async () => {
//   try {
//     const sql = `SELECT
//     DISTINCT ENC_ID_ORDER
//   FROM
//     V_END_CUST_ORD_EPA`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getData07 = async (data: any) => {
//   try {
//     let binds: any = {
//       order: data?.epa,
//     };
//     let sql: any = `select ENC_ID_ORDER OrderNo,
//     NVL(ENC_NO_ITEM, '') OrdItem,
//     NVL(ENC_ORDER_TYPE, '') OrdType,
//     NVL(ENC_CD_PROD, '') Prod_cd,

//     NVL(ENC_CD_QLTY, '') Qlty_Cd,

//     NVL(ENC_SEC1_MIN, '') Thick_Min,

//     NVL(ENC_SEC1_MAX, '') Thick_Max,

//     NVL(ENC_SEC2_MIN, '') Width_Min,

//     NVL(ENC_SEC2_MAX, '') Width_Max,

//     NVL(ENC_LENGTH_MIN, '') Length_Min,

//     NVL(ENC_LENGTH_MAX, '') Length_Max,

//     NVL(ENC_NO_TDC, '') TDC,

//     NVL(ENC_CD_GRADE, '') Grade,

//     NVL(ENC_NO_MATNR, '') FG_Material,

//     NVL(ENC_ORD_DESC, '') Order_Desc,

//     NVL(ENC_ORD_QUANTITY, '') Ord_Qnty,

//     TO_CHAR(ENC_DT_ORD_CREATE, 'DD-MON-YYYY') Order_Creation_dt,

//     TO_CHAR(ENC_DT_DELV, 'DD-MON-YYYY') Delivary_Dt,

//     NVL(ENC_ST_ORDER, '') Order_Status,

//     NVL(TO_CHAR(ENC_DT_ORD_REL, 'DD-MON-YYYY'), ' ') Order_Release_dt,

//     NVL(ENC_CD_END_CUST, 0) Cust_Code,

//     NVL(TO_CHAR(ENC_DT_ORD_CLOSE, 'DD-MON-YYYY'), ' ') Order_Close_dt,

//     NVL(TO_CHAR(ENC_TS_ORD_DWNLD, 'DD-MON-YYYY'), 0) Download_Dt,

//     NVL(ENC_NO_TRACKING, 0) Tracking_No,

//     NVL(ENC_CD_EPA, '') PlantCD,

//     NVL(ENC_CUST_NAME, ' ') Cust_NM,

//     NVL(ENC_IDIA, 0) Idia,

//     NVL(ENC_MIN_PIECE_WT, 0) PIece_Wt_Min,

//     NVL(ENC_MAX_PIECE_WT, 0) PIece_Wt_Max,

//     NVL(ENC_AIM_PIECE_WT, 0) PIece_Wt_Aim,

//     NVL(ENC_CD_SHIP_TO_PRTY, 0) Ship_To_P_cd,

//     NVL(ENC_SHIP_TO_PRTY_DESC, 0) Ship_To_P_desc,

//     NVL(ENC_ODIA, 0) ODia,

//     NVL(ENC_ROAD_DEST, 0) ENC_ROAD_DEST,

//     NVL(ENC_ROADDEST_DESC, ' ') Road_Desc,

//     NVL(ENC_RAIL_DEST, 0) ENC_RAIL_DEST,

//     NVL(ENC_RAILDEST_DESC, ' ') Rail_Desc,

//     NVL(TO_CHAR(ENC_CUST_REQ_DT, 'DD-MON-YYYY'), '') Cust_Ask_Dt,

//     NVL(ENC_MK_SPEC, 0) Cust_SPec,

//     NVL(ENC_MARK_CUST, 0) Mark_Cust_cd,

//     NVL(ENC_MARK_CUST_NAME, 0) Mark_Cust_NM,

//     TO_CHAR(ENC_LAST_ORD_DWNLD, 'DD-MON-YYYY') Download_Dt_Latest,

//     NVL(ENC_DELV_TOLERENCE, 0) Tolerance,

//     NVL(ENC_ORDER_EDGE, 0) Order_Edge,

//     NVL(ENC_MATNR_INFO, 0) Order_Spec_Info,

//     NVL(ENC_SEC1_ACT, 0) Actual_Thick,

//     NVL(ENC_SEC2_ACT, 0) Actual_Width,

//     NVL(ENC_SEC3_ACT, 0) Actual_Length,

//     NVL(ENC_DESPATCH_WK, 0) Dispatch_Wk,

//     NVL(ENC_ORD_CRT_BY, 0) Ordr_Crt_By

//     from v_end_cust_ord_epa

//     where enc_cd_epa='${data?.epa}'

//     `;

//     if (data.orderStatus && data.orderStatus?.length > 0) {
//       sql += ` and enc_st_order='${data?.orderStatus}'`;
//       binds["orderStatus"] = data?.orderStatus;
//     }
//     if (data.orderItem && data.orderItem?.length > 0) {
//       sql += ` and ENC_NO_ITEM='${data?.orderItem}'`;
//       binds["orderItem"] = data?.orderItem;
//     }
//     if (data.materialNo && data.materialNo?.length > 0) {
//       sql += ` and ENC_NO_MATNR='${data?.materialNo}'`;
//       binds["materialNo"] = data?.materialNo;
//     }
//     if (data.order && data.order?.length > 0) {
//       sql += ` AND ENC_ID_ORDER = '${data?.order}'`;
//       binds["order"] = data?.order;
//     }
//     if (data.custCd && data.custCd?.length > 0) {
//       sql += ` AND ENC_CD_END_CUST = '${data?.custCd}'`;
//       binds["custCd"] = data?.custCd;
//     }
//     if (data.trackingNo && data.trackingNo?.length > 0) {
//       sql += ` AND ENC_NO_TRACKING = '${data?.trackingNo}'`;
//       binds["trackingNo"] = data?.trackingNo;
//     }
//     if (data.orderType && data.orderType?.length > 0) {
//       sql += ` AND ENC_ORDER_TYPE = '${data?.orderType}'`;
//       binds["orderType"] = data?.orderType;
//     }
//     if (data.prodCd && data.prodCd?.length > 0) {
//       sql += ` AND ENC_CD_PROD = '${data?.prodCd}'`;
//       binds["prodCd"] = data?.prodCd;
//     }
//     if (data.qltyCd && data.qltyCd?.length > 0) {
//       sql += ` AND ENC_CD_QLTY = '${data?.qltyCd}'`;
//       binds["qltyCd"] = data?.qltyCd;
//     }
//     if (data.tdc && data.tdc?.length > 0) {
//       sql += ` AND ENC_NO_TDC = '${data?.tdc}'`;
//       binds["tdc"] = data?.tdc;
//     }
//     if (data?.orderDateFr && data?.orderDateTo) {
//       sql += ` AND ENC_DT_ORD_CREATE BETWEEN NVL('${data?.orderDateFr}','01-JAN-1900') AND NVL('${data?.orderDateTo}','31-DEC-9999')`;
//       binds.orderDateFr = data?.orderDateFr;
//       binds.orderDateTo = data?.orderDateTo;
//     }
//     if (data?.deliveryDateFr && data?.deliveryDateTo) {
//       sql += ` AND ENC_DT_DELV BETWEEN NVL('${data?.deliveryDateFr}','01-JAN-1900') AND NVL('${data?.deliveryDateTo}','31-DEC-9999')`;
//       binds.deliveryDateFr = data?.deliveryDateFr;
//       binds.deliveryDateTo = data?.deliveryDateTo;
//     }
//     if (data?.ThickFr && data?.ThickFr != "") {
//       sql += ` AND ENC_SEC1_MIN >= nvl('${data?.ThickFr}', enc_sec1_min)`;
//       binds["ThickFr"] = data?.ThickFr;
//     }
//     if (data?.ThickTo && data?.ThickTo !== "") {
//       sql += `AND ENC_SEC1_MAX <= nvl('${data?.ThickTo}', ENC_SEC1_MAX) `;
//       binds["ThickTo"] = data?.ThickTo;
//     }
//     if (data?.widthFr && data?.widthFr != "") {
//       sql += ` AND ENC_SEC2_MIN >= nvl('${data?.widthFr}', ENC_SEC2_MIN)`;
//       binds["widthFr"] = data?.widthFr;
//     }
//     if (data?.widthTo && data?.widthTo !== "") {
//       sql += `AND ENC_SEC2_MAX <= nvl('${data?.widthTo}', ENC_SEC2_MAX)`;
//       binds["widthTo"] = data?.widthTo;
//     }
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
export const getEpaCodeData08 = async (data: any) => {
  try {
    const sql: any = `SELECT
    DISTINCT SOI_CD_EPA
  FROM
    V_SCO_ORDER_ITEM`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getOrderData08 = async () => {
  try {
    const sql: any = `SELECT
    DISTINCT SOI_ID_ORDER
  FROM
    V_SCO_ORDER_ITEM`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getData08 = async (data: any) => {
  try {
    let binds: any = {};

    let sql: any = `SELECT
    SOI_ID_ORDER ORDER_ID,
    SOI_NO_ITEM ITEM_NO,
    SOI_NO_END_MATNR END_MATNR_NO,
    SOI_END_PROD_DESC END_PROD_DESC,
    SOI_CD_PROD CD_PROD,
    SOI_CD_QLTY CD_QLTY,
    SOI_SEC1_MIN THICKNESS_MIN,
    SOI_SEC1_MAX THICKNESS_MAX,
    SOI_SEC2_MIN WIDTH_MIN,
    SOI_SEC2_MAX WIDTH_MAX,
    SOI_LENGTH_MIN LENGTH_MIN,
    SOI_LENGTH_MAX LENGTH_MAX,
    SOI_QUANTITY QUANTITY,
    SOI_PRICE PRICE,
    SOI_CD_BASE_QLTY CD_BASE_QLTY,
    SOI_CD_EPA CD_EPA,
    SOI_NO_TRACKING TRACKING_NO,
    SOI_DT_DELIVERY DELIVERY_DT,
    SOI_CD_STATUS CD_STATUS,
    SOI_ID_USER ID_USER,
    SOI_DT_ORDER ORDER_DT,
    SOI_CD_PUR_GRP CD_PUR_GRP,
    SOI_CD_TYPE_ORDER CD_TYPE_ORDER,
    SOI_NO_INP_MATNR NO_INP_MATNR,
    SOI_NO_TDC TDC_NO,
    SOI_VAL_START_DT VAL_START_DT,
    SOI_VAL_END_DT VAL_END_DT,
    SOI_UOM UOM,
    SOI_CD_COMP CD_COMP,
    SOI_CD_PROCESS CD_PROCESS,
    SOI_IDIA IDIA,
    SOI_ODIA ODIA,
    SOI_MAT_CHAR MAT_CHAR,
    SOI_INP_MATNR1
    FROM
    V_SCO_ORDER_ITEM`;

    if (data.epa && data.epa?.length > 0) {
      sql += ` Where SOI_CD_EPA = '${data?.epa}'`;
      binds["epa"] = data?.epa;
    }
    if (data.order && data.order?.length > 0) {
      sql += ` AND SOI_ID_ORDER = '${data?.order}'`;
      binds["order"] = data?.order;
    }
    if (data.endmaterialNo && data.endmaterialNo?.length > 0) {
      sql += ` AND SOI_NO_END_MATNR = '${data?.endmaterialNo}'`;
      binds["endmaterialNo"] = data?.endmaterialNo;
    }
    if (data.inpmaterialNo && data.inpmaterialNo?.length > 0) {
      sql += ` AND SOI_NO_INP_MATNR = '${data?.inpmaterialNo}'`;
      binds["inpmaterialNo"] = data?.inpmaterialNo;
    }
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
// export const getOrderStatus07 = async () => {
//   try {
//     const sql: any = `SELECT DISTINCT enc_st_order FROM v_end_cust_ord_epa`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getCustomer07 = async () => {
//   try {
//     const sql: any = `SELECT DISTINCT ENC_CD_END_CUST FROM v_end_cust_ord_epa`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const getOrderType07 = async () => {
//   try {
//     const sql: any = `SELECT DISTINCT ENC_ORDER_TYPE FROM v_end_cust_ord_epa`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
export const getEpaPlant06 = async () => {
  try {
    const sql = `SELECT
    DISTINCT(ESP_CD_EPA) PLANT
    FROM
    V_EPA_SECONDS_PRIME_TDC`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getTdcsec06 = async () => {
  try {
    const sql = `SELECT
    DISTINCT ESP_TDC_DOWNGRADE
    FROM
    V_EPA_SECONDS_PRIME_TDC`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getSECONDSTdc06 = async (data: any) => {
  try {
    let binds: any = {};

    let sql = `SELECT
    NVL (ESP_CD_EPA, '') CD_EPA,
    NVL (ESP_QLTY_PRIME, '') QLTY_PRIME,
    NVL (ESP_QLTY_DOWNGRADE, '') QLTY_DOWNGRADE,
    NVL (ESP_TDC_PRIME, '') TDC_PRIME,
    NVL (ESP_TDC_DOWNGRADE, '') TDC_DOWNGRADE,
    NVL (ESP_SEC1_FROM, '') SEC1_FROM,
    NVL (ESP_SEC1_TO, '') SEC1_TO,
    NVL (ESP_SEC2_FROM, '') SEC2_FROM,
    NVL (ESP_SEC2_TO, '') SEC2_TO,
    NVL (ESP_SHEET_IND, '') SHEET_IND,
    NVL (ESP_NO_MATNR, '') NO_MATNR,
    NVL (ESP_WT_MIN, '') WT_MIN,  
    NVL (ESP_WT_MAX, '') WT_MAX,
    NVL (ESP_CRT_USR, '') S_CRT_USR,  
    NVL (ESP_CRT_DT, '') S_CRT_DT,
    NVL (ESP_UPD_USR, '') S_UPD_USR,  
    NVL (ESP_UPD_DT, '') S_UPD_DT,
    NVL (ESP_STATUS, '') STATUS
  FROM
  V_EPA_SECONDS_PRIME_TDC`;
    if (data?.epa) {
      sql += ` WHERE ESP_CD_EPA = '${data?.epa}'`;
    }
    if (data.tdcsc && data.tdcsc?.length > 0) {
      sql += `AND ESP_TDC_DOWNGRADE = '${data?.tdcsc}'`;
    }
    return await query(sql);
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerError("Error");
  }
};
export const getActTdc06 = async () => {
  try {
    const sql = `SELECT
    DISTINCT TDM_ACT_TDC
   FROM
    V_TDC_MAP`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getEndTdc06 = async () => {
  try {
    const sql = `SELECT
    DISTINCT TDM_END_TDC
   FROM
    V_TDC_MAP`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getTdcMap06 = async (data: any) => {
  try {
    let binds: any = {};
    let sql = `SELECT
    TDM_ACT_TDC ACT_TDC,
    TDM_END_TDC END_TDC,
    TDM_CRT_ID CRT_ID,
    TDM_CRT_DT CRT_DATE,
    TDM_UPD_ID UPD_ID,
    TDM_UPD_DT UPD_DT,
    TDM_CD_STATUS CD_STATUS,
    TDM_CD_EPA CD_EPA,
    TDM_CD_COMP CD_COMP
    FROM
    V_TDC_MAP`;

    if (data?.acttdc) {
      sql += ` WHERE TDM_ACT_TDC ='${data?.acttdc}'`;
    }
    if (data.endTDC && data.endTDC?.length > 0) {
      sql += ` AND TDM_END_TDC = '${data?.endTDC}'`;
    }
    return await query(sql);
  } catch (error: any) {
    console.log("err", error);
    throw new Error.InternalServerError("Error");
  }
};
export const callProcedure06 = async (data: any) => {
  try {
    const sql = `call MSTB001(
      ls_act_tdc => :ls_act_tdc,
      ls_end_tdc => :ls_end_tdc,
      ls_flag    => :ls_flag,
      lb_status => :lb_status,
      ls_user   => :ls_user,
      ls_cd_epa => :ls_cd_epa,
      ls_tdc_prime => :ls_tdc_prime,
      ls_tdc_downgrade => :ls_tdc_downgrade,      
      ls_sec1_from => :ls_sec1_from,
      ls_sec1_to         => :ls_sec1_to,
      ls_sec2_from      => :ls_sec2_from,
      ls_sec2_to      => :ls_sec2_to,
      ls_sheet_ind      => :ls_sheet_ind,
      ls_no_matnr      => :ls_no_matnr,
      ls_wt_min          => :ls_wt_min,
      ls_wt_max        => :ls_wt_max,
      ls_qlty_prime         => :ls_qlty_prime,
      ls_qlty_downgrade      => :ls_qlty_downgrade,
      ls_message => :ls_message
      )`;
    const binds = {
      ls_act_tdc: data?.ls_tdc_prime ? data?.ls_tdc_prime : "",
      ls_end_tdc: data?.ls_tdc_downgrade ? data?.ls_tdc_downgrade : "",
      ls_flag: data?.ls_flag ? data?.ls_flag : "",
      lb_status: data?.lb_status ? data?.lb_status : "",
      ls_user: data?.ls_user ? data?.ls_user : "",
      ls_cd_epa: data?.ls_cd_epa ? data?.ls_cd_epa : "",
      ls_tdc_prime: data?.ls_tdc_prime ? data?.ls_tdc_prime : "",
      ls_tdc_downgrade: data?.ls_tdc_downgrade ? data?.ls_tdc_downgrade : "",
      ls_sec1_from: data?.ls_sec1_from ? data?.ls_sec1_from : "",
      ls_sec1_to: data?.ls_sec1_to ? data?.ls_sec1_to : "",
      ls_sec2_from: data?.ls_sec2_from ? data?.ls_sec2_from : "",
      ls_sec2_to: data?.ls_sec2_to ? data?.ls_sec2_to : "",
      ls_sheet_ind: data?.ls_sheet_ind ? data?.ls_sheet_ind : "",
      ls_no_matnr: data?.ls_no_matnr ? data?.ls_no_matnr : "",
      ls_wt_min: data?.ls_wt_min ? data?.ls_wt_min : "",
      ls_wt_max: data?.ls_wt_max ? data?.ls_wt_max : "",
      ls_qlty_prime: data?.ls_qlty_prime ? data?.ls_qlty_prime : "",
      ls_qlty_downgrade: data?.ls_qlty_downgrade ? data?.ls_qlty_downgrade : "",
      ls_message: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    return await query(sql, binds);
  } catch (error: any) {
    console.log("error", error);
    throw new Error.InternalServerError("Error");
  }
};
