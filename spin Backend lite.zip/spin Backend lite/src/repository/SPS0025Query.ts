import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getPlantData = async (data?: any) => {
  try {
    return getCommonPlantData();
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getBatchData = async (data?: any) => {
  try {
    let sql: any = `select distinct EICA_ID_COIL  from v_input_coil_aud`;
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getBatchData2 = async (data?: any) => {
  try {
    let sql: any = `select distinct EOMA_ID_BATCH from v_epa_prodn_aud`;
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getInputCoilAudit = async (data?: any) => {
  try {
    let sql: any = `select EICA_ID_COIL,EICA_COLUMN_NAME,
                      EICA_OLD_VALUE,EICA_NEW_VALUE,
                      EICA_USERID,EICA_TIMESTAMP_CHNG,
                      EICA_ACTION from v_input_coil_aud 
                      where EICA_ID_COIL = '${data?.batchId}' 
                      --and EICA_NEW_VALUE = '${data?.plant}'
                      `;
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getProductionAudit = async (data?: any) => {
  try {
    let sql: any = `select EOMA_ID_BATCH,EOMA_COLUMN_NAME,
                      EOMA_OLD_VALUE,EOMA_NEW_VALUE,
                      EOMA_USERID,TO_CHAR(EOMA_TIMESTAMP_CHNG, 'DD-MM-YYYY HH24:MI:SS') EOMA_TIMESTAMP_CHNG,
                      EOMA_ACTION  from v_epa_prodn_aud 
                      where EOMA_ID_BATCH = '${data?.batchId}' 
                      --and EOMA_NEW_VALUE = '${data?.plant}'
                      order by 6 asc
                      `;
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getCustOrdAudit = async (data?: any) => {
  try {
    let sql: any = `SELECT ENCA_ID_ORDER,ENCA_NO_ITEM,
                      ENCA_COLUMN_NAME,ENCA_OLD_VALUE,
                      ENCA_NEW_VALUE,ENCA_USERID,
                      ENCA_TIMESTAMP_CHNG,ENCA_ACTION 
                      FROM v_end_cust_ord_epa_aud
                       WHERE ENCA_ID_ORDER = '${data?.orderId}' 
                       --AND ENCA_NEW_VALUE = '${data?.plant}'
                       `;
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
