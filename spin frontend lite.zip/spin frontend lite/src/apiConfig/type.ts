export interface LoginData {
    userDetails: string
}