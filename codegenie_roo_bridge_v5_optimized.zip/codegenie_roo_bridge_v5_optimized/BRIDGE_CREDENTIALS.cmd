@echo off
REM ================================================================
REM EDIT THIS FILE ONCE ON YOUR COMPANY LAPTOP.
REM Do not share it after adding your credentials.
REM ================================================================

set "CODEGENIE_ADID=YOUR_ADID"
set "CODEGENIE_APIKEY=YOUR_CODEGENIE_API_KEY"

set "CODEGENIE_PROXY=http://127.0.0.1:13124"
set "CODEGENIE_APPLICATION_NAME=Code Genie"
set "CODEGENIE_TIMEOUT=300"

REM Python environment that already worked in your tests.
set "PY=C:\CompanyGenAIBridge\.venv\Scripts\python.exe"
