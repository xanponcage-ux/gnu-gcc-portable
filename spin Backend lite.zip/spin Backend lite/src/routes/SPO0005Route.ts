import { Router } from "express";
import {
  getData,
  getTableData,
  callDeleteProcedure,
} from "../controllers/SPO0005Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPO0005Route = Router();

SPO0005Route.route("/SPO0005/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPO0005Route.route("/SPO0005/getTableData").post(
  authenticationMiddleware.bearer,
  getTableData
);

SPO0005Route.route("/SPO0005/callDeleteProcedure").post(
  authenticationMiddleware.bearer,
  callDeleteProcedure
);

export default SPO0005Route;
