import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import testQuery from "../infrastructure/database/testquery";

export const execQueryScreenAccess = async (req: any) => {
  try {
    let sql = `SELECT COUNT(1) FROM v_codes WHERE cd_type = 'TK028' AND cd_value = :0`;
    let binds = [`${req.body.user}`];
    return await query(sql, binds);
  } catch (error) {
    throw new Error.InternalServerError("Error");
  }
};

export const execQuery = async (req: any) => {
  try {
    let sql = req;
    return await testQuery(sql);
  } catch (error: any) {
    throw new Error.DBError2(error);
  }
};

export const confirmExecQuery = async (req: any) => {
  try {
    let sql = req;
    console.log(sql);
    return await testQuery(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.DBError2(error);
  }
};

export const testConnection = async () => {
  try {
    let sql = `SELECT * FROM V_CODES`;
    return await testQuery(sql);
  } catch (error) {
    return error;
  }
};
