// const SPC0003Query = require("../repository/SPC0003Query");
import {
  getPackingCode03,
  getOilingcode03,
  savePackingOiling,
  getPackCdList,
  getPackSeq,
  getWidthTolData,
} from "../repository/SPC0003Query";

export default class SPC0003Model {
  getPackingCode03(data: any) {
    return getPackingCode03(data);
  }
  getOilingCode03(data: any) {
    return getOilingcode03(data);
  }
  savePackingOiling(data: any) {
    return savePackingOiling(data);
  }
  getPackCdList() {
    return getPackCdList();
  }
  getPackSeq(data: any) {
    return getPackSeq(data);
  }
  getWidthTolData(data: any) {
    return getWidthTolData(data);
  }
}
