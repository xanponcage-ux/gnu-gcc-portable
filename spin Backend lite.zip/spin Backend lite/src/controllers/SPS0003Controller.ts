import { Request, Response } from "express";
import SPS0003Model from "../models/SPS0003Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getBatchData = async (req: Request, res: Response) => {
  try {
    const results1 = await ResponceData(
      await SPS0003Model.prototype.getBatchData(req.body)
    );
    return res.status(200).json(results1);
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const callPkgProc = async (req: Request, res: Response) => {
  try {
    let data = req.body;

    let resultProc;
    let cntY = 0;
    let failedBatches: any[] = [];
    for (let i = 0; i < data.length; i++) {
      resultProc = await SPS0003Model.prototype.callPkgProc(data[i]);
      // console.log("resultProc: ", resultProc);
      if (resultProc?.substr(0, 1) === "Y") cntY++;
      else {
        resultProc += resultProc;
        failedBatches.push(data[i]?.batchId);
      }
    }
    // console.log("cntY: ", cntY);
    if (cntY === data?.length && data.length > 1) {
      resultProc = "Y-Packing scheduled for all Batches";
      return res.status(200).json(resultProc);
    } else if (cntY !== data?.length && data.length > 1) {
      return res
        .status(200)
        .json("N-Packing scheduled for all Batches except " + failedBatches);
    }
    return res.status(200).json(resultProc);
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
