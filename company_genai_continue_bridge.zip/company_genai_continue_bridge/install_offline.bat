@echo off
setlocal
cd /d "%~dp0"

if not exist wheels\ (
  echo The wheels folder is missing. Follow GUIDE.md to prepare it on another Windows computer.
  exit /b 1
)

python -m venv .venv
if errorlevel 1 exit /b 1
call .venv\Scripts\activate.bat
python -m pip install --no-index --find-links=wheels -r requirements.txt
if errorlevel 1 exit /b 1

if not exist .env copy .env.example .env >nul
echo Offline installation complete. Edit .env before running start_bridge.bat.
endlocal
