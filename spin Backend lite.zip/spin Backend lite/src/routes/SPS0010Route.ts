import { Router } from "express";
import {
  indenting,
} from "../controllers/SPS0010Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0010Route = Router();

SPS0010Route.route("/SPS0010/indenting").post(
  authenticationMiddleware.bearer,
  indenting
);


export default SPS0010Route;
