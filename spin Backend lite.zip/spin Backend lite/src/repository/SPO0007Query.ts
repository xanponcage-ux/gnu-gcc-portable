import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data.Plant) {
        return {
          status: await ResponceData(
            await query(`  select CD_VALUE,CD_VALUE || ' - ' ||CD_DESC CD_DESC from V_CODES
            where CD_TYPE='E0001' and CD_VALUE not in ('WF','WL', 'WB', 'VF', 'VG', 'VI', 'VS') order by 1 `)
          ), //'WB', 'VF', 'VG', 'VI', 'VS' not required in status filter
        };
      } else {
        return getCommonPlantData();
      }
    } else if (data?.type === "coilData") {
      let QrygetCoils = ` SELECT EOM_TS_CREATION, EOM_ID_BATCH BATCH_ID, EOM_ID_FIRST_PAR MOTHER_BATCH,
       EOM_CD_STATUS STATUS, EOM_SEC1 THICK, EOM_SEC2 WIDTH,
       EOM_NO_CAST CAST_NO, EOM_MS_PIECE_ACTL NET_WT,
       (SELECT ENC_CD_END_CUST
          FROM V_END_CUST_ORD_EPA
         WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
           AND ENC_CD_EPA = EOM_CD_EPA) CUST_CD,
       (SELECT ENC_CUST_NAME
          FROM V_END_CUST_ORD_EPA
         WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
           AND ENC_CD_EPA = EOM_CD_EPA) CUST_NAME,
       EOM_CD_CURR_PROC CURR_PROC, EOM_CD_NEXT_PROC NEXT_PROC,
       EOM_CD_PREV_PROC PREV_PROC, EOM_IDIA IDIA, EOM_ODIA ODIA, EOM_LENGTH,
       EOM_ID_ORDER_CUS CUS_ORDER, EOM_ID_ORD_ITEM_CUS CUS_ITEM,
       EOM_TDC_ACTL TDC, EOM_NO_PIECES NO_PCS, EOM_CD_EPA PLANT,
       EOM_PLANNED_PROC PLAN_PROC,
       (SELECT F_GET_SAPGRADE ('131',
                               EOM_ID_ORDER_CUS,
                               EOM_ID_ORD_ITEM_CUS
                              )
          FROM DUAL) GRADE
--      (select enc_cd_grade from v_end_cust_ord_epa WHERE ENC_ID_ORDER = EOM_ID_ORDER_CUS
--           AND ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS
--           AND ENC_CD_EPA = EOM_CD_EPA) GRADE
FROM   V_EPA_PRODN
 WHERE EOM_CD_STATUS NOT IN ('WL', 'WB', 'WF', 'VF', 'VG', 'VI', 'VS')`; //Added on 03.02.26, WF, VG, VI, VS batches are not needed for wip label generation

      if (data?.Status && data?.Status?.length > 0) {
        QrygetCoils += ` And EOM_CD_STATUS =NVL('${data.Status}', EOM_CD_STATUS)`;
      }

      // console.log("QrygetCoils: ", QrygetCoils);
      return await query(QrygetCoils);
    } else if (data?.type === "saveLabelInfo") {
      return await saveLabelInfo(data);
    } else if (data?.type === "getLabelCount") {
      return await checkLabelCountWIP(data);
    }
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const saveLabelInfo = async (data: any) => {
  try {
    //console.log("Inside saveLabelInfo");

    let printer = data?.printer;
    const userId = data?.user;
    const isAdmin = await checkAdmnIds(userId);

    if (printer === "ZPL" && !isAdmin) {
      return `N-User-${userId}, not authorised to print ZPL label. Contact Quality team.`;
    }

    let labelCount = Number(await checkLabelCountWIP(data));

    //console.log("isAdmin-saveLabelInfo: ", isAdmin);
    if (labelCount > 0 && !isAdmin) {
      return "N-New Label cannot be generated.Label already generated.Contact Quality team";
    }
    //console.log("labelCount-saveLabelInfo: ", labelCount);

    const seq = printer === "ZPL" ? 0 : labelCount + 2;
    const labelType = printer === "ZPL" ? "WIP-ZPL" : "WIP-HW";

    let sql = `INSERT INTO V_LABEL_INFO (
        TLC_TIMESTAMP,
        TLC_CD_EPA,
        TLC_ID_BATCH,
        TLC_USER,
        TLC_LABEL_TYPE,
        TLC_BATCH_STATUS,
        TLC_FIRST_PAR,
        TLC_LABEL_CRT_ON,
        TLC_LABLE_CRT_BY,
        TLC_PROG_NM,
        TLC_SEQ
    ) VALUES (
        f_nannow_second_telgrm(SYSDATE),
        '${data?.plant}',
        '${data?.batchId}',
        '${data?.user}',
        '${labelType}',
        '${data?.batchStatus}',
        '${data?.firstPar}',
        SYSDATE,
        '${data?.user}',
        'SPO0007',
        '${seq}'
    )`;

    //console.log("sql-saveLabelInfo: ", sql);

    let result = await query(sql);
    //console.log("result: ", result);
    if (Number(result?.rowsAffected) > 0) {
      result = "Y-Label Details Saved";
    }
    return result;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const checkLabelCountWIP = async (data: any) => {
  try {
    //console.log("Inside checkLabelCountWIP");
    const chkCoilQry = ` select count(*) BATCH_COUNT from V_LABEL_INFO 
     where TLC_ID_BATCH = '${data?.batchId}'
     and TLC_CD_EPA = '${data?.plant}' and TLC_LABEL_TYPE = 'WIP-HW' `;
    //console.log("chkCoilQry: ", chkCoilQry);

    let chkCoilQryResult = await ResponceData(await query(chkCoilQry));
    //console.log("chkCoilQryResult: ", chkCoilQryResult);

    const labelCount = chkCoilQryResult?.[0]?.BATCH_COUNT;
    //console.log("labelCount-checkLabelCountWIP: ", labelCount);

    return labelCount;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const checkAdmnIds = async (user: any) => {
  try {
    //console.log("Inside checkAdmnIds");
    const chkIdQry = ` select CD_VALUE AS ADMN_ID_FG from v_codes where cd_type = 'TK037' `;
    //console.log("chkIdQry: ", chkIdQry);

    let adminIdFGList = await ResponceData(await query(chkIdQry));
    adminIdFGList = adminIdFGList;
    //console.log("adminIdFGList: ", adminIdFGList, adminIdFGList?.[0]);

    const isAdmin = adminIdFGList.some((item: any) => item.ADMN_ID_FG === user);
    //console.log("isAdmin-checkAdmnIds: ", isAdmin);

    return isAdmin;
  } catch (error: any) {
    console.log("error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
