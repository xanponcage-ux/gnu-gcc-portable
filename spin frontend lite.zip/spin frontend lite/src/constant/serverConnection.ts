interface ServerType {
  [key: string]: {
    baseURL: string;
  };
}
const SERVER: ServerType = {
  local: {
    baseURL: "http://localhost:5556/",
  },
  dev: {
    baseURL: "https://tslweblindev.corp.tatasteel.com:5553",
  },
  qa: {
    baseURL: "https://tslweblindev.corp.tatasteel.com:5557/",
  },
  prd: {
    baseURL: "https://kpofpmes.corp.tatasteel.com:6660/",
  },
};

export default SERVER;
