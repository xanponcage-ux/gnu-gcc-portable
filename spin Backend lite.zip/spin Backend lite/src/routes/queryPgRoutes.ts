import { Router } from "express";
import {
  execQueryScreenAccess,
  execQuery,
  confirmExecQuery,
  testConnection,
} from "../controllers/queryPgController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const queryPgRoute = Router();

// queryPgRoute
//   .route("/queryPg/getData")
//   .post(authenticationMiddleware.bearer, getData);

queryPgRoute
  .route("/queryPg/execQueryScreenAccess")
  .post(authenticationMiddleware.bearer, execQueryScreenAccess);
queryPgRoute
  .route("/queryPg/execQuery")
  .post(authenticationMiddleware.bearer, execQuery);
queryPgRoute
  .route("/queryPg/confirmExecQuery")
  .post(authenticationMiddleware.bearer, confirmExecQuery);
queryPgRoute
  .route("/queryPg/testConnection")
  .post(authenticationMiddleware.bearer, testConnection);

export default queryPgRoute;
