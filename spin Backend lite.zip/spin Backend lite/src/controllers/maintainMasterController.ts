import { Request, Response } from "express";
import maintainMasterModel from "../models/maintainMasterModel";
import { ResponceData } from "../utils";

export const getEpaCode02 = async (req: Request, res: Response) => {
  try {
    const result1 = await maintainMasterModel.prototype.getEpaCode02();

    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
// export const SPC0002getData02 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if (req.body.data === 0) {
//       result1 = await maintainMasterModel.prototype.getProcLineData02(req.body);
//     }
//     if (req.body.data === 1) {
//       result2 = await maintainMasterModel.prototype.getProcPath02(req.body);
//     }
//     varData = {
//       ...{ procLine: await ResponceData(result1) },
//       ...{ procPath: await ResponceData(result2) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

//For my page

// export const SPC0003getData03 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if (req.body.data === 0) {
//       result1 = await maintainMasterModel.prototype.getPackingCode03(req.body);
//     }
//     if (req.body.data === 1) {
//       result2 = await maintainMasterModel.prototype.getOilingCode03(req.body);
//     }
//     varData = {
//       ...{ PackingCode: await ResponceData(result1) },
//       ...{ Oilingcode: await ResponceData(result2) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const savePackingOiling = async (req: Request, res: Response) => {
//   try {
//     let results = await maintainMasterModel.prototype.savePackingOiling(
//       req.body
//     );
//     return res.status(200).json(results);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

//page no.3
//page no.4
// export const SPC0004getData04 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if (req.body.data === 0) {
//       result1 = await maintainMasterModel.prototype.upcomingpageCode04(
//         req.body
//       );
//     }
//     if (req.body.data === 1) {
//       result2 = await maintainMasterModel.prototype.upcomingpage_02_Code04(
//         req.body
//       );
//     }
//     varData = {
//       ...{ X: await ResponceData(result1) },
//       ...{ Y: await ResponceData(result2) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

export const getPlantData = async (req: Request, res: Response) => {
  try {
    const result1 = await maintainMasterModel.prototype.getPlantData();
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

// export const getData06 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;

//     if (req.body.data === 0) {
//       result1 = await maintainMasterModel.prototype.getSECONDSTdc06(req.body);
//     }
//     if (req.body.data === 1) {
//       result2 = await maintainMasterModel.prototype.getTdcMap06(req.body);
//     }

//     varData = {
//       ...{ SecondsTb: await ResponceData(result1) },
//       ...{ TdcMapTb: await ResponceData(result2) },
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getEpaCode06 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await maintainMasterModel.prototype.getEpaPlant06();
//     const result2 = await maintainMasterModel.prototype.getTdcsec06();
//     const result3 = await maintainMasterModel.prototype.getActTdc06();

//     const varData = {
//       EpaPlant: await ResponceData(result1),
//       TdcSec: await ResponceData(result2),
//       Acttdc: await ResponceData(result3),
//     };
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const callProcedure06 = async (req: Request, res: Response) => {
//   try {
//     const data = req.body;
//     let results: any = {};
//     for (let i in data) {
//       let singleData = data[i];
//       let result1: any = await maintainMasterModel.prototype.callProcedure06(
//         singleData
//       );
//       let outBinds = result1.outBinds.ls_message;

//       results = outBinds;
//     }

//     return res.status(200).json(results);
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
// export const getData02 = async (req: Request, res: Response) => {
//   try {
//     let varData: any = [];
//     let result1;
//     let result2;
//     if(req.body.data === 0) {
//         result1 = await maintainMasterModel.prototype.getProcLineData02(req.body);
//     }
//     if(req.body.data === 1) {
//         result2 = await maintainMasterModel.prototype.getProcPath02(req.body);
//     }
//     varData = {
//       ... { procLine: await ResponceData(result1) },
//       ...{ procPath: await ResponceData(result2) },
//     }
//     return res.status(200).json(varData);
//   } catch (error: any) {
//     console.log("error", error);
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
