/* ------ LINKING/DLINKING SCREEN INSIDE PLANNING --------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import { GetAuthorization } from "../../../utils";
import { TokenType } from "../../../type";
import alertify from "../../../components/alert";
import Loader from "../../../components/preloader";
import { setTheme, useMaterialUIController } from "../../../context";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import SendAndArchiveIcon from "@mui/icons-material/SendAndArchive";
import SaveIcon from "@mui/icons-material/Save";

import { SelectType } from "../../../components/input/type";
import {
  GetPlantDataApi,
  SPS0004BatchTableData,
  SPS0004BatchDlinkTableData,
  SPS0004OrderTableData,
  SPS0004SaveData,
  SPS0004GetChemChk,
} from "../../../apiConfig/insideAuthApi";
import Auth from "../../../components/layout/dashboardLayout/auth";

import { CulmnType } from "../../../type";

const P_SPS0004 = () => {
  const [loading, setLoading] = React.useState<boolean>(false);
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [mBatch, setMBatch] = React.useState<string>("");
  const [tdc, setTdc] = React.useState<string>("");
  const [prodCd, setProdCd] = React.useState<string>("");
  const [thick, setThick] = React.useState<string>("");
  const [width, setWidth] = React.useState<string>("");
  const [batchTable, setBatchTable] = React.useState<any>(null);
  const [batchTableData, setBatchTableData] = React.useState<any>([]);
  const [orderTable, setOrderTable] = React.useState<any>(null);
  const [orderTableData, setOrderTableData] = React.useState<any>([]);
  const [batchDlinkTable, setBatchDlinkTable] = React.useState<any>(null);
  const [batchDlinkTableData, setBatchDlinkTableData] = React.useState<any>([]);
  const [tabValue, setTabValue] = React.useState<number>(0);
  const [saveDisable, setSaveDisable] = React.useState<boolean>(true);

  React.useEffect(() => {
    fetchPlantData();
    setBatchTableData([]);
    setBatchDlinkTableData([]);
    setOrderTableData([]);
    setSaveDisable(true);
  }, []);

  React.useEffect(() => {
    if (batchTableData?.length > 0) {
      // setBatchTable(
      let varBatchData = new Tabulator("#batchTable", {
        data: batchTableData,
        columns: batchTableCol,
        height: 200,
        selectable: 1,
        layout: "fitDataFill",
        pagination: true,
        paginationSize: 10,
        paginationSizeSelector: [10, 20, 40, 60],
        paginationCounter: "rows",
      });
      // );
      setBatchTable(varBatchData);
      varBatchData?.on("rowDeselected", function (row) {
        setOrderTableData([]);
      });
    } else {
      setBatchTable(null);
    }
  }, [batchTableData]);

  const batchTableCol: Array<CulmnType> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Length",
      field: "LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(1);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Net Qty",
      field: "NET_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Gross Wt",
      field: "GROSS_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Packing Cd",
      field: "PACKING_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Oiling Cd",
      field: "OILING_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mcoil Post Treat",
      field: "MCOIL_POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Aim Cust Cd",
      field: "EOM_ID_ORD_CUS_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Aim Cust Item",
      field: "EOM_ID_ITM_CUS_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG Material",
      field: "MAT_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Passed Proc",
      field: "PASS_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      // visible: false,
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchBatchTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      plant: selectedPlant?.split(" - ")[0],
      mBatch: mBatch ? mBatch : "",
      tdc: tdc ? tdc : "",
      prodCd: prodCd ? prodCd : "",
      thick: thick ? thick : "",
      width: width ? width : "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0004BatchTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setBatchTableData(res.data);
          } else {
            setBatchTableData([]);
            alertify.error("No data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (batchDlinkTableData?.length > 0) {
      setBatchDlinkTable(
        new Tabulator("#batchDlinkTable", {
          data: batchDlinkTableData,
          columns: batchDlinkTableCol,
          height: 350,
          selectable: 1,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setBatchDlinkTable(null);
    }
  }, [batchDlinkTableData]);

  const batchDlinkTableCol: Array<CulmnType> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Net Qty",
      field: "NET_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Gross Wt",
      field: "GROSS_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Packing Cd",
      field: "PACKING_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Oiling Cd",
      field: "OILING_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Aim Cust Cd",
      field: "EOM_ID_ORD_CUS_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Aim Cust Item",
      field: "EOM_ID_ITM_CUS_AIM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Id",
      field: "ENC_ID_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Item",
      field: "ENC_NO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Cd",
      field: "ENC_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "ENC_MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Fg Material No",
      field: "ENC_NO_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Fg Material Desc",
      field: "FG_MAT_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const fetchBatchDlinkTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      plant: selectedPlant?.split(" - ")[0],
      mBatch: mBatch ? mBatch : "",
      tdc: tdc ? tdc : "",
      prodCd: prodCd ? prodCd : "",
      thick: thick ? thick : "",
      width: width ? width : "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0004BatchDlinkTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            console.log("res.data: ", res.data);
            setBatchDlinkTableData(res.data);
          } else {
            setBatchDlinkTableData([]);
            alertify.error("No data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (orderTableData?.length > 0) {
      setOrderTable(
        new Tabulator("#ordTable", {
          data: orderTableData,
          columns: orderTableCol,
          height: 200,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 10,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
          selectable: 1,
        })
      );
    } else {
      setOrderTable(null);
    }
  }, [orderTableData]);

  orderTable?.on("rowSelected", function (data: any) {
    let gridData = batchTable.getSelectedRows();
    const dataArr = {
      plant: selectedPlant?.split(" - ")[0],
      batchId: gridData[0]._row.data.BATCH_ID
        ? gridData[0]._row.data.BATCH_ID
        : "",
      tdc: gridData[0]._row.data.TDC ? gridData[0]._row.data.TDC : "",
    };
    console.log("dataArr: ", dataArr);
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0004GetChemChk(token, dataArr)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data[0]?.FM_CHK?.substr(0, 1) === "0") {
            alertify.success(res?.data[0]?.FM_CHK);
            setSaveDisable(false);
          } else {
            alertify.error(res.data[0]?.FM_CHK);
            setSaveDisable(true);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
          setSaveDisable(true);
        })
        .finally(() => {
          setLoading(false);
        });
    });
  });

  const orderTableCol: Array<CulmnType> = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      download: false,
      frozen: true,
      headerSort: false,
      title: "",
    },
    {
      title: "Order Id",
      field: "ENC_ID_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item No",
      field: "ENC_NO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Type",
      field: "ENC_ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Thick Max",
      field: "ENC_SEC1_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Thick Min",
      field: "ENC_SEC1_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Max",
      field: "ENC_SEC2_MAX",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Min",
      field: "ENC_SEC2_MIN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "TDC",
      field: "ENC_NO_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Prod Cd",
      field: "ENC_CD_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Qlty Cd",
      field: "ENC_CD_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "ENC_MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Post Treat",
      field: "ENC_POST_TREAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ship to Party Cd ",
      field: "ENC_CD_SHIP_TO_PRTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Fret Indicator",
      field: "ENC_FRT_IND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Edge",
      field: "ENC_ORDER_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Crt Dt",
      field: "ENC_DT_ORD_CREATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Dispatch Week",
      field: "ENC_DESPATCH_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const fetchOrderTableData = () => {
    if (batchTable === null) {
      alertify.error("Click on search button for Batch details");
      return;
    }
    if (batchTable?.getSelectedRows()?.length === 0) {
      alertify.error("Please Select Row");
      return;
    }
    let gridData = batchTable?.getSelectedRows()[0]?._row?.data;

    const data = {
      thick: gridData?.THICK?.toFixed(3) ?? "",
      width: gridData?.WIDTH ?? "",
      idia: gridData?.IDIA ?? "",
      tdc: gridData?.TDC ?? "",
      mat_no: gridData?.MAT_NO ?? "",
      pass_proc: gridData?.PASS_PROC ?? "",
      length: gridData?.LENGTH ?? "",
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0004OrderTableData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length > 0) {
            setOrderTableData(res.data);
          } else {
            setOrderTableData([]);
            alertify.error("No data found");
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const saveData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    let data = {};
    if (tabValue === 1) {
      if (batchDlinkTable?.length === 0 || batchDlinkTable === null) {
        alertify.error("No Data exists to Save");
        return;
      }
      if (batchDlinkTable?.getSelectedRows()?.length === 0) {
        alertify.error("Please Select Row");
        return;
      }
      let gridData = batchDlinkTable?.getSelectedRows()[0]?._row?.data;

      data = {
        tabValue: tabValue,
        batchId: gridData?.BATCH_ID ?? "",
        ordId: gridData?.ENC_ID_ORDER ?? "",
        item: gridData?.ENC_NO_ITEM ?? "",
        user: user,
      };
    } else if (tabValue === 0) {
      if (orderTable?.length === 0 || orderTable === null) {
        alertify.error("No Data exists to Save");
        return;
      }
      if (orderTable?.getSelectedRows()?.length === 0) {
        alertify.error("Please Select Order");
        return;
      }

      let gridData = orderTable?.getSelectedRows()[0]?._row?.data;

      data = {
        tabValue: tabValue,
        batchId: batchTable?.getSelectedRows()[0]?.getData()?.BATCH_ID ?? "",
        ordId: gridData?.ENC_ID_ORDER ?? "",
        item: gridData?.ENC_NO_ITEM ?? "",
        user: user,
      };
    }

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0004SaveData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.substr(0, 1) === "Y") {
            alertify.success(res.data);
            setSaveDisable(true);
            setBatchDlinkTableData([]);
            setBatchTableData([]);
            setOrderTableData([]);
          } else {
            alertify.error(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setMBatch("");
    setTdc("");
    setProdCd("");
    setThick("");
    setWidth("");
    setBatchTableData([]);
    setBatchDlinkTableData([]);
    setOrderTableData([]);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
    setBatchTableData([]);
    setBatchDlinkTableData([]);
    setOrderTableData([]);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={1.8}>
                        <SelectInput
                          label="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            // fetchPlantData(e);
                            setBatchTableData([]);
                            setBatchDlinkTableData([]);
                            setOrderTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.8}>
                        <Input
                          label="M Batch"
                          value={mBatch}
                          size={"small"}
                          onChange={(e: string) => {
                            setMBatch(e.toUpperCase().slice(0, 10));
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.4}>
                        <Input
                          label="TDC"
                          value={tdc}
                          size={"small"}
                          onChange={(e: string) => {
                            setTdc(e.toUpperCase().slice(0, 4));
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.4}>
                        <Input
                          label="Prod Cd"
                          value={prodCd}
                          size={"small"}
                          onChange={(e: string) => {
                            setProdCd(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.4}>
                        <Input
                          label="Thick"
                          value={thick}
                          size={"small"}
                          onChange={(e: string) => {
                            setThick(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.4}>
                        <Input
                          label="Width"
                          value={width}
                          size={"small"}
                          onChange={(e: string) => {
                            setWidth(e.toUpperCase());
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <ButtonElement
                          onClick={() => {
                            tabValue === 0 && fetchBatchTableData();
                            tabValue === 1 && fetchBatchDlinkTableData();
                            setOrderTableData([]);
                          }}
                        >
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Batch Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Save">
                        <IconButton
                          onClick={saveData}
                          disabled={
                            restricted !== "RL_RW" ||
                            (tabValue === 0 && saveDisable)
                          }
                        >
                          <SaveIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>

                    {tabValue === 0 && (
                      <Grid item>
                        <Tooltip title="Get Fitting Order">
                          <IconButton onClick={fetchOrderTableData}>
                            <SendAndArchiveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      </Grid>
                    )}

                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel(
                              "Linking/ D linking",
                              batchTableData,
                              batchTable
                            )
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                    <Tabs
                      value={tabValue}
                      onChange={handleTabChange}
                      aria-label="basic tabs example"
                    >
                      <Tab label="Linking" />
                      <Tab label="D Linking" />
                    </Tabs>
                  </Box>
                  {tabValue === 0 && batchTableData?.length > 0 && (
                    <div id="batchTable"></div>
                  )}
                  {tabValue === 1 && batchDlinkTableData?.length > 0 && (
                    <div id="batchDlinkTable"></div>
                  )}
                </Box>
              </TableContainer>
            </Grid>

            {tabValue === 0 && (
              <Grid item xs={12}>
                <TableContainer
                  title="Fitting Order Details"
                  headerContainer={<Grid container></Grid>}
                >
                  <Box sx={{ width: "100%" }}>
                    {orderTableData?.length > 0 && <div id="ordTable"></div>}
                  </Box>
                </TableContainer>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0004;
