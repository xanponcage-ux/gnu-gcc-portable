import { Router } from "express";
import { getData, getDispatchData } from "../controllers/SPC0010Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0010Route = Router();

SPC0010Route.route("/SPC0010/getData").post(
  authenticationMiddleware.bearer,
  getData
);
SPC0010Route.route("/SPC0010/getDispatchData").post(
  authenticationMiddleware.bearer,
  getDispatchData
);

export default SPC0010Route;
