import { Request, Response } from "express";
import SPC0013Model from "../models/SPC0013Model";
import { ResponceData } from "../utils";

export const getCastDetails = async (req: Request, res: Response) => {
  try {
    let data = req.body;
    const result = await ResponceData(
      await SPC0013Model.prototype.getCastDetails(data)
    );
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getCoilDetails = async (req: Request, res: Response) => {
  try {
    let data = req.body;
    const result = await ResponceData(
      await SPC0013Model.prototype.getCoilDetails(data)
    );
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getFittingDetails = async (req: Request, res: Response) => {
  try {
    let data = req.body;
    const result = await ResponceData(
      await SPC0013Model.prototype.getFittingDetails(data)
    );
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
