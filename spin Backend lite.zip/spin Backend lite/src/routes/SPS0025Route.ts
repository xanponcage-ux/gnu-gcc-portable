import { Router } from "express";
import {
  SPS0025Controller,
  SPS0025BatchId,
  SPS0025TableApi,
} from "../controllers/SPS0025Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPS0025Route = Router();

SPS0025Route.route("/SPS0025/SPS0025Api").post(
  authenticationMiddleware.bearer,
  SPS0025Controller
);

SPS0025Route.route("/SPS0025/SPS0025BatchApi").post(
  authenticationMiddleware.bearer,
  SPS0025BatchId
);

SPS0025Route.route("/SPS0025/SPS0025TableApi").post(
  authenticationMiddleware.bearer,
  SPS0025TableApi
);

export default SPS0025Route;
