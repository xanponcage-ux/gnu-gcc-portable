export interface ButtonType {
    children: string,
    onClick?: React.MouseEventHandler<HTMLButtonElement>,
    variant?: "text" | "contained" | "outlined",
    sx?: React.CSSProperties,
    confirmPopup?: boolean,
    type?: "button" | "reset" | "submit",
    extra?: {
        loading: boolean
    }
} 