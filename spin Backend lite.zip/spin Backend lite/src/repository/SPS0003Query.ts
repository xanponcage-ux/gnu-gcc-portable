import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getBatchData = async (data?: any) => {
  try {
    // console.log("data:: ", data);
    let sql: any = `SELECT 
        EOM_ID_BATCH BATCH_ID,
        EOM_CD_QLTY_ACTL QLTY_CD,
        EOM_CD_STATUS STATUS,
        EOM_TS_CREATION, 
        EOM_NO_CAST CAST_NO,
        EOM_LENGTH LEN,
        EOM_MS_PIECE_ACTL NET_WT,
        EOM_ODIA ODIA, 
        EOM_SEC1 THICK,
        EOM_SEC2 WIDTH,
        EOM_ID_ORDER_CUS ORD,
        EOM_ID_ORD_ITEM_CUS ITEM,
        EOM_ID_PAR_COIL_NO PARENT_BATCH,
        EOM_ID_FIRST_PAR MOTHER_BATCH,
        EOM_TDC_ACTL TDC,
        EOM_CD_EPA PLANT,
        EOM_PLANNED_PROC PLAN_PROC,
        EOM_NO_MATNR MAT_NO,
        EOM_CD_PACK PACK_CD
        FROM V_EPA_PRODN WHERE EOM_CD_STATUS = 'KB' `;

    if (data?.plant && data?.plant?.length > 0) {
      sql += ` AND EOM_CD_EPA = '${data.plant}'`;
    }
    if (data?.batchId && data?.batchId?.length > 0) {
      sql += ` AND EOM_ID_BATCH = '${data.batchId}'`;
    }
    if (data?.motherBatch && data?.motherBatch?.length > 0) {
      sql += ` AND EOM_ID_FIRST_PAR = '${data.motherBatch}'`;
    }
    // console.log("sql:: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const callPkgProc = async (data: any) => {
  try {
    console.log("data: ", data);
    let sql: any = `call p_pkg_schd(      
        p_batchid    => :p_batchid,
        p_ord    => :p_ord,
        p_item    => :p_item,
        p_pack_cd    => :p_pack_cd,
        p_user    => :p_user,
        p_send_source    => :p_send_source,
        ls_err_msg    => :ls_err_msg )`;

    const binds = {
      p_batchid: data?.batchId ?? "",
      p_ord: data?.order ?? "",
      p_item: data?.item ?? "",
      p_pack_cd: data?.packCd ?? "",
      p_user: data?.user ?? "",
      p_send_source: "S",
      ls_err_msg: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    // console.log("binds:: ", binds);
    let result = await query(sql, binds);
    // console.log("resultQry: ", result);
    return result?.outBinds?.ls_err_msg;
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
