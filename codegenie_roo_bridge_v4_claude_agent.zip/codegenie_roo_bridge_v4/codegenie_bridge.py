# CodeGenie -> OpenAI-compatible local bridge (Roo/Continue/Cline)
# No credentials are stored in this source file.

import json
import os
import time
import unicodedata
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List

# Use the Windows/system trust store when available. This is useful behind
# corporate TLS inspection proxies such as Zscaler.
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI(title="CodeGenie OpenAI-Compatible Bridge v4")

BASE_DIR = Path(__file__).resolve().parent
CODEGENIE_URL = os.getenv(
    "CODEGENIE_URL",
    "https://asia-south1-tsl-generative-ai.cloudfunctions.net/code_genie_api_calls",
).strip()
CODEGENIE_PROXY = os.getenv("CODEGENIE_PROXY", "http://127.0.0.1:13124").strip()
APPLICATION_NAME = os.getenv("CODEGENIE_APPLICATION_NAME", "Code Genie").strip()
REQUEST_TIMEOUT = float(os.getenv("CODEGENIE_TIMEOUT", "300"))
MODEL_FILE = Path(os.getenv("CODEGENIE_MODELS_FILE", str(BASE_DIR / "models.json")))
ALLOW_RAW_MODEL_IDS = os.getenv("CODEGENIE_ALLOW_RAW_MODEL_IDS", "1").strip() not in {"0", "false", "False"}
DEFAULT_MODEL = os.getenv("CODEGENIE_MODEL", "claude-4.5-sonnet").strip()

# Optional launcher overrides. When enabled, these take precedence over
# whatever Roo/Continue/Cline sends in the request.
FORCE_MODEL = os.getenv("CODEGENIE_FORCE_MODEL", "0").strip().lower() in {"1", "true", "yes", "on"}
FORCE_TEMPERATURE = os.getenv("CODEGENIE_FORCE_TEMPERATURE", "0").strip().lower() in {"1", "true", "yes", "on"}
FORCE_MAX_TOKENS = os.getenv("CODEGENIE_FORCE_MAX_TOKENS", "0").strip().lower() in {"1", "true", "yes", "on"}

LAUNCH_TEMPERATURE = os.getenv("CODEGENIE_TEMPERATURE", "1.0").strip()
LAUNCH_MAX_TOKENS = os.getenv("CODEGENIE_MAX_TOKENS", "MAX").strip()


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _json_text(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def _canonical_model_key(value: str) -> str:
    """Normalize UI/model names without changing the final deployment string."""
    s = unicodedata.normalize("NFKC", str(value or "")).strip()
    # Normalize common unicode dash characters that sometimes get pasted into UI fields.
    for ch in ("‐", "‑", "‒", "–", "—", "﹘", "﹣", "－"):
        s = s.replace(ch, "-")
    s = " ".join(s.split())
    return s.lower()


def load_model_catalog() -> List[Dict[str, Any]]:
    try:
        raw = json.loads(MODEL_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except Exception as exc:
        raise RuntimeError(f"Could not read model catalog {MODEL_FILE}: {exc}")

    if isinstance(raw, dict):
        raw = raw.get("models", [])
    if not isinstance(raw, list):
        raise RuntimeError("models.json must contain a list or {'models': [...]} object")
    return [x for x in raw if isinstance(x, dict)]


def resolve_model(requested: str) -> str:
    requested = str(requested or "").strip() or DEFAULT_MODEL
    key = _canonical_model_key(requested)

    # Exact aliases from models.json win. This prevents invisible-character / display-name
    # problems and lets the user map friendly names to CodeGenie's exact deployment_name.
    for item in load_model_catalog():
        deployment = str(item.get("deployment_name") or "").strip()
        aliases = [item.get("id"), item.get("name"), *(item.get("aliases") or [])]
        for alias in aliases:
            if alias and _canonical_model_key(str(alias)) == key:
                if not deployment:
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            f"Model '{requested}' is listed but its CodeGenie deployment_name "
                            "has not been captured yet. Fill it in models.json from the working "
                            "CodeGenie Network payload."
                        ),
                    )
                return deployment

    if ALLOW_RAW_MODEL_IDS:
        # Raw deployment IDs are allowed for easy testing. Normalize only unicode dash characters
        # and surrounding whitespace; do not invent or rewrite provider-specific names.
        normalized = unicodedata.normalize("NFKC", requested).strip()
        for ch in ("‐", "‑", "‒", "–", "—", "﹘", "﹣", "－"):
            normalized = normalized.replace(ch, "-")
        return normalized

    raise HTTPException(status_code=400, detail=f"Unknown model '{requested}'")


def available_models() -> List[Dict[str, Any]]:
    out = []
    for item in load_model_catalog():
        deployment = str(item.get("deployment_name") or "").strip()
        if not deployment:
            continue
        model_id = str(item.get("id") or deployment).strip()
        out.append(
            {
                "id": model_id,
                "object": "model",
                "owned_by": "codegenie",
                "display_name": str(item.get("name") or model_id),
                "deployment_name": deployment,
                "tool_use": item.get("tool_use"),
            }
        )
    # Always expose the known working default even if models.json is missing/broken.
    if not any(m["id"] == DEFAULT_MODEL for m in out):
        out.append({"id": DEFAULT_MODEL, "object": "model", "owned_by": "codegenie"})
    return out



def _is_claude(deployment_name: str) -> bool:
    return str(deployment_name or "").lower().startswith("claude-")


def _message_text(content: Any) -> str:
    """Best-effort extraction of text from OpenAI-style message content."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if isinstance(item.get("text"), str):
                    parts.append(item["text"])
                elif item.get("type") == "text" and isinstance(item.get("text"), str):
                    parts.append(item["text"])
        return "\n".join(p for p in parts if p)
    return str(content)


def _tool_catalog_prompt(tools: Any) -> str:
    """
    CodeGenie's Claude/Bedrock route currently returns text rather than native
    OpenAI tool_calls. Give Claude a compact XML tool protocol that the bridge
    can translate back into OpenAI tool_calls for Roo.
    """
    if not isinstance(tools, list) or not tools:
        return ""

    rows: List[str] = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        fn = tool.get("function") or {}
        name = str(fn.get("name") or "").strip()
        if not name:
            continue
        desc = str(fn.get("description") or "").strip()
        params = fn.get("parameters") or {"type": "object", "properties": {}}
        rows.append(
            f"- {name}: {desc}\n"
            f"  JSON schema: {json.dumps(params, ensure_ascii=False, separators=(',', ':'))}"
        )

    if not rows:
        return ""

    return (
        "\n\n==== BRIDGE TOOL PROTOCOL (CLAUDE/CODEGENIE) ====\n"
        "The upstream gateway does not expose native tool calls for this Claude route. "
        "When you need a tool, emit ONLY tool requests using XML tags so the local bridge "
        "can convert them into native OpenAI tool_calls for Roo.\n"
        "Format each tool call as:\n"
        "<TOOL_NAME><ARG_NAME>VALUE</ARG_NAME></TOOL_NAME>\n"
        "You may emit multiple tool calls in one response. Do not invent tool names or "
        "argument names. After tool results are returned, continue the task normally.\n\n"
        "AVAILABLE TOOLS:\n"
        + "\n".join(rows)
        + "\n==== END BRIDGE TOOL PROTOCOL ====\n"
    )


def convert_messages_for_claude(messages: List[Dict[str, Any]], tools: Any) -> List[Dict[str, Any]]:
    """
    Convert Roo/OpenAI messages into the Bedrock-Converse-like content shape
    expected by CodeGenie's Claude route.

    We intentionally represent prior tool calls/results as text because the
    current CodeGenie Claude route is not returning Bedrock toolUse blocks.
    """
    converted: List[Dict[str, Any]] = []
    system_parts: List[str] = []
    tool_name_by_id: Dict[str, str] = {}

    tool_prompt = _tool_catalog_prompt(tools)

    for msg in messages:
        if not isinstance(msg, dict):
            continue

        role = str(msg.get("role") or "")
        content = msg.get("content")

        if role == "system":
            txt = _message_text(content)
            if txt:
                system_parts.append(txt)
            continue

        if role == "assistant":
            blocks: List[Dict[str, str]] = []
            txt = _message_text(content)
            if txt:
                blocks.append({"text": txt})

            calls = msg.get("tool_calls") or []
            if isinstance(calls, list) and calls:
                rendered = []
                for call in calls:
                    if not isinstance(call, dict):
                        continue
                    call_id = str(call.get("id") or "")
                    fn = call.get("function") or {}
                    name = str(fn.get("name") or "")
                    args = str(fn.get("arguments") or "{}")
                    if call_id:
                        tool_name_by_id[call_id] = name
                    rendered.append(
                        f"TOOL CALL REQUESTED\nid={call_id}\nname={name}\narguments={args}"
                    )
                if rendered:
                    blocks.append({"text": "\n\n".join(rendered)})

            if blocks:
                converted.append({"role": "assistant", "content": blocks})
            continue

        if role == "tool":
            call_id = str(msg.get("tool_call_id") or "")
            tool_name = tool_name_by_id.get(call_id, "tool")
            txt = _message_text(content)
            converted.append(
                {
                    "role": "user",
                    "content": [
                        {
                            "text": (
                                f"TOOL RESULT\nid={call_id}\nname={tool_name}\n"
                                f"result:\n{txt}"
                            )
                        }
                    ],
                }
            )
            continue

        # Treat all other ordinary messages as user messages.
        txt = _message_text(content)

        if system_parts:
            system_text = "\n\n".join(system_parts)
            if tool_prompt:
                system_text += tool_prompt
            txt = (
                "SYSTEM INSTRUCTIONS:\n"
                + system_text
                + "\n\nUSER REQUEST:\n"
                + txt
            )
            system_parts = []
            tool_prompt = ""

        converted.append({"role": "user", "content": [{"text": txt}]})

    # Safety case: system prompt with no user message.
    if system_parts:
        system_text = "\n\n".join(system_parts)
        if tool_prompt:
            system_text += tool_prompt
        converted.insert(
            0,
            {
                "role": "user",
                "content": [{"text": "SYSTEM INSTRUCTIONS:\n" + system_text}],
            },
        )

    return converted


def _coerce_xml_arg(value: str, schema: Dict[str, Any]) -> Any:
    value = value.strip()
    typ = schema.get("type")
    if typ in {"object", "array"}:
        try:
            return json.loads(value)
        except Exception:
            return value
    if typ == "integer":
        try:
            return int(value)
        except Exception:
            return value
    if typ == "number":
        try:
            return float(value)
        except Exception:
            return value
    if typ == "boolean":
        if value.lower() in {"true", "1", "yes"}:
            return True
        if value.lower() in {"false", "0", "no"}:
            return False
    return value


def _extract_xml_tool_calls(text: str, tools: Any) -> List[Dict[str, Any]]:
    """
    Parse Roo-style XML tool requests emitted as Claude text and turn them into
    OpenAI tool_calls. Works generically from the tool schemas Roo supplied.
    """
    if not text or not isinstance(tools, list):
        return []

    calls: List[Dict[str, Any]] = []

    for tool in tools:
        if not isinstance(tool, dict):
            continue
        fn = tool.get("function") or {}
        name = str(fn.get("name") or "").strip()
        if not name:
            continue

        # Tool names are controlled by Roo, but escape them anyway.
        tool_pat = re.compile(
            rf"<{re.escape(name)}(?:\s[^>]*)?>(.*?)</{re.escape(name)}>",
            re.IGNORECASE | re.DOTALL,
        )
        params = fn.get("parameters") or {}
        props = params.get("properties") or {}

        for match in tool_pat.finditer(text):
            inner = match.group(1)
            args: Dict[str, Any] = {}

            if isinstance(props, dict):
                for prop_name, prop_schema in props.items():
                    prop_pat = re.compile(
                        rf"<{re.escape(str(prop_name))}(?:\s[^>]*)?>(.*?)</{re.escape(str(prop_name))}>",
                        re.IGNORECASE | re.DOTALL,
                    )
                    pm = prop_pat.search(inner)
                    if pm:
                        raw = pm.group(1)
                        raw = (
                            raw.replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&amp;", "&")
                            .replace("&quot;", '"')
                            .replace("&#39;", "'")
                        )
                        args[str(prop_name)] = _coerce_xml_arg(
                            raw, prop_schema if isinstance(prop_schema, dict) else {}
                        )

            # Fallback for parameterless tools.
            calls.append(
                {
                    "id": f"call_{uuid.uuid4().hex[:24]}",
                    "type": "function",
                    "function": {
                        "name": name,
                        "arguments": json.dumps(args, ensure_ascii=False, separators=(",", ":")),
                    },
                }
            )

    # Preserve textual order when multiple different tools were emitted.
    def position(call: Dict[str, Any]) -> int:
        name = call["function"]["name"]
        m = re.search(rf"<{re.escape(name)}(?:\s[^>]*)?>", text, re.IGNORECASE)
        return m.start() if m else 10**9

    calls.sort(key=position)
    return calls


def _strip_xml_tool_calls(text: str, tools: Any) -> str:
    cleaned = text or ""
    if isinstance(tools, list):
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            fn = tool.get("function") or {}
            name = str(fn.get("name") or "").strip()
            if not name:
                continue
            cleaned = re.sub(
                rf"<{re.escape(name)}(?:\s[^>]*)?>.*?</{re.escape(name)}>",
                "",
                cleaned,
                flags=re.IGNORECASE | re.DOTALL,
            )
    # Remove the wrapper Claude sometimes emits.
    cleaned = re.sub(r"</?assemble_information[^>]*>", "", cleaned, flags=re.IGNORECASE)
    return cleaned.strip()


def normalize_codegenie_response(
    data: Dict[str, Any],
    deployment_name: str,
    request_tools: Any,
) -> Dict[str, Any]:
    """Normalize both OpenAI-style and CodeGenie Claude/Bedrock-style responses."""
    if isinstance(data, dict) and "choices" in data:
        return data

    # Claude route observed from CodeGenie:
    # {"response":{"message":{"content":[{"text":"..."}],"role":"assistant"}},"tokens":7209}
    wrapper = data.get("response") if isinstance(data, dict) else None
    if not isinstance(wrapper, dict):
        raise HTTPException(status_code=502, detail="CodeGenie returned an unexpected response shape")

    # Some gateway failures are returned as {"response": "ERROR: ..."}.
    if isinstance(wrapper, str):
        raise HTTPException(status_code=502, detail=wrapper)

    message = wrapper.get("message") or {}
    blocks = message.get("content") or []
    text_parts: List[str] = []
    native_tool_calls: List[Dict[str, Any]] = []

    if isinstance(blocks, list):
        for block in blocks:
            if not isinstance(block, dict):
                continue
            if isinstance(block.get("text"), str):
                text_parts.append(block["text"])

            # Future-proof: if CodeGenie ever returns Bedrock toolUse natively,
            # translate it directly.
            tu = block.get("toolUse")
            if isinstance(tu, dict):
                native_tool_calls.append(
                    {
                        "id": str(tu.get("toolUseId") or f"call_{uuid.uuid4().hex[:24]}"),
                        "type": "function",
                        "function": {
                            "name": str(tu.get("name") or ""),
                            "arguments": json.dumps(
                                tu.get("input") or {},
                                ensure_ascii=False,
                                separators=(",", ":"),
                            ),
                        },
                    }
                )

    text = "\n".join(text_parts).strip()
    tool_calls = native_tool_calls or _extract_xml_tool_calls(text, request_tools)

    if tool_calls:
        content = _strip_xml_tool_calls(text, request_tools)
        finish_reason = "tool_calls"
    else:
        content = text
        finish_reason = "stop"

    total_tokens = data.get("tokens")
    usage = {}
    if isinstance(total_tokens, int):
        usage = {"total_tokens": total_tokens}

    return {
        "id": f"chatcmpl-{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": deployment_name,
        "choices": [
            {
                "index": 0,
                "finish_reason": finish_reason,
                "logprobs": None,
                "message": {
                    "role": "assistant",
                    "content": content if content else None,
                    "tool_calls": tool_calls or None,
                },
            }
        ],
        "usage": usage,
    }


def _catalog_model_max(deployment_name: str) -> Any:
    """Read an optional model-specific maximum output token value from models.json."""
    key = _canonical_model_key(deployment_name)
    for item in load_model_catalog():
        dep = str(item.get("deployment_name") or "").strip()
        if dep and _canonical_model_key(dep) == key:
            val = item.get("max_output_tokens")
            try:
                val = int(val)
                return val if val > 0 else None
            except Exception:
                return None
    return None


def build_form(body: Dict[str, Any]) -> Dict[str, str]:
    messages = body.get("messages")
    if not isinstance(messages, list) or not messages:
        raise HTTPException(status_code=400, detail="messages must be a non-empty array")

    client_model = str(body.get("model") or DEFAULT_MODEL).strip()
    requested_model = DEFAULT_MODEL if FORCE_MODEL else client_model
    deployment_name = resolve_model(requested_model)

    if FORCE_TEMPERATURE:
        try:
            temperature = float(LAUNCH_TEMPERATURE)
        except (TypeError, ValueError):
            temperature = 1.0
    else:
        temperature = body.get("temperature")
        if not isinstance(temperature, (int, float)):
            temperature = 1.0

    temperature = max(0.0, min(1.0, float(temperature)))

    tools = body.get("tools")
    if _is_claude(deployment_name):
        upstream_messages = convert_messages_for_claude(messages, tools)
    else:
        upstream_messages = messages

    form: Dict[str, str] = {
        "adid": required_env("CODEGENIE_ADID"),
        "messages": _json_text(upstream_messages),
        "deployment_name": deployment_name,
        "temperature": str(temperature),
        "apikey": required_env("CODEGENIE_APIKEY"),
        "application_name": APPLICATION_NAME,
    }

    # Output-token behavior.
    mt = None

    if FORCE_MAX_TOKENS:
        launch_value = str(LAUNCH_MAX_TOKENS or "MAX").strip().upper()

        if launch_value in {"MAX", "NONE", "DEFAULT", "UNLIMITED", "-1", "0", ""}:
            # Prefer the exact model maximum captured in models.json.
            mt = _catalog_model_max(deployment_name)
        else:
            try:
                parsed = int(launch_value)
                if parsed > 0:
                    mt = parsed
            except (TypeError, ValueError):
                mt = None
    else:
        raw_mt = body.get("max_tokens")
        if raw_mt is None:
            raw_mt = body.get("max_completion_tokens")
        try:
            parsed = int(raw_mt) if raw_mt is not None else None
            if parsed is not None and parsed > 0:
                mt = parsed
        except (TypeError, ValueError):
            mt = None

    if mt is not None:
        form["max_tokens"] = str(mt)

    # GPT/OpenAI-compatible routes support native OpenAI tool schemas.
    # Claude currently uses the bridge's XML tool shim instead, so we do not
    # forward the OpenAI tools field upstream for Claude.
    if not _is_claude(deployment_name):
        if isinstance(tools, list) and tools:
            form["tools"] = _json_text(tools)

    print(
        "[ROO REQUEST]",
        f"client_model={client_model!r}",
        f"selected_model={requested_model!r}",
        f"deployment={deployment_name!r}",
        f"temperature={temperature}",
        f"max_tokens={form.get('max_tokens', 'provider-controlled')}",
        f"messages={len(messages)}",
        f"message_json_chars={len(form['messages'])}",
        f"tools={len(tools) if isinstance(tools, list) else 0}",
        f"tool_mode={'xml-shim' if _is_claude(deployment_name) else 'native'}",
        f"stream={bool(body.get('stream'))}",
    )
    return form

def call_codegenie(form: Dict[str, str]) -> Dict[str, Any]:
    session = requests.Session()
    if CODEGENIE_PROXY:
        session.proxies.update({"http": CODEGENIE_PROXY, "https": CODEGENIE_PROXY})

    multipart = [(key, (None, value)) for key, value in form.items()]
    try:
        response = session.post(CODEGENIE_URL, files=multipart, timeout=REQUEST_TIMEOUT)
    except Exception as exc:
        print("[CODEGENIE CONNECTION ERROR]", type(exc).__name__, str(exc))
        raise HTTPException(status_code=502, detail=f"CodeGenie connection failed: {exc}")

    print("[CODEGENIE] Upstream HTTP status:", response.status_code)
    if not response.ok:
        detail = response.text[:3000]
        print("========== CODEGENIE UPSTREAM ERROR ==========")
        print(f"HTTP STATUS: {response.status_code}")
        print(detail)
        print("==============================================")
        raise HTTPException(status_code=502, detail=f"CodeGenie HTTP {response.status_code}: {detail}")

    try:
        data = response.json()
    except Exception:
        print("[CODEGENIE NON-JSON]", response.text[:3000])
        raise HTTPException(status_code=502, detail="CodeGenie returned non-JSON data")

    if not isinstance(data, dict):
        print("[CODEGENIE UNEXPECTED RESPONSE]", str(data)[:3000])
        raise HTTPException(status_code=502, detail="CodeGenie returned an unexpected response shape")
    return data


def _normalize_tool_calls(tool_calls: Any) -> Any:
    if not isinstance(tool_calls, list):
        return tool_calls
    normalized = []
    for i, tc in enumerate(tool_calls):
        if not isinstance(tc, dict):
            continue
        item = dict(tc)
        item.setdefault("index", i)
        normalized.append(item)
    return normalized


def as_sse(data: Dict[str, Any]) -> StreamingResponse:
    """Convert CodeGenie's complete response into OpenAI-compatible SSE chunks."""
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    model = data.get("model") or DEFAULT_MODEL
    response_id = data.get("id") or f"chatcmpl-{uuid.uuid4().hex}"
    created = data.get("created") or int(time.time())
    finish_reason = choice.get("finish_reason")

    def chunks() -> Iterable[str]:
        first = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
        }
        yield "data: " + json.dumps(first, separators=(",", ":")) + "\n\n"

        content = message.get("content")
        if content not in (None, ""):
            chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"content": content}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(chunk, separators=(",", ":")) + "\n\n"

        tool_calls = _normalize_tool_calls(message.get("tool_calls"))
        if tool_calls:
            chunk = {
                "id": response_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"tool_calls": tool_calls}, "finish_reason": None}],
            }
            yield "data: " + json.dumps(chunk, separators=(",", ":")) + "\n\n"

        final_chunk = {
            "id": response_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
        }
        yield "data: " + json.dumps(final_chunk, separators=(",", ":")) + "\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(chunks(), media_type="text/event-stream")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "gateway": CODEGENIE_URL,
        "proxy": CODEGENIE_PROXY or "DIRECT",
        "default_model": DEFAULT_MODEL,
        "forced_model": FORCE_MODEL,
        "temperature": LAUNCH_TEMPERATURE if FORCE_TEMPERATURE else "client-controlled",
        "max_output_tokens": (
            "MAX/provider-controlled"
            if FORCE_MAX_TOKENS and str(LAUNCH_MAX_TOKENS).strip().upper() in {"MAX", "NONE", "DEFAULT", "UNLIMITED", "-1", "0", ""}
            else (LAUNCH_MAX_TOKENS if FORCE_MAX_TOKENS else "client-controlled")
        ),
        "models_file": str(MODEL_FILE),
        "credentials_configured": bool(os.getenv("CODEGENIE_ADID") and os.getenv("CODEGENIE_APIKEY")),
        "bridge_token_limit": "none",
    }


@app.get("/models")
@app.get("/v1/models")
def models():
    return {"object": "list", "data": available_models()}


@app.post("/chat/completions")
@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Request body must be JSON")

    form = build_form(body)
    data = call_codegenie(form)

    deployment_name = form.get("deployment_name", DEFAULT_MODEL)
    normalized = normalize_codegenie_response(
        data=data,
        deployment_name=deployment_name,
        request_tools=body.get("tools"),
    )

    if body.get("stream"):
        return as_sse(normalized)
    return JSONResponse(content=normalized)
