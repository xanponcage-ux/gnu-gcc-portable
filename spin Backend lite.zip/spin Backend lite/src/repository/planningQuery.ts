import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData01 = async (data: any) => {
  try {
    let binds: any = {
      epaCode: data?.code,
    };
    let sql: any = `SELECT
    nvl(cir_id_coil,'') "Coil Id",
    nvl(cir_sr_plant,'') "Sr Plant",
    nvl(cir_dest_plant,'') "Dest Plant",
    nvl(cir_req_status,'') "Status",
    nvl('CIR_REQ_BY','') "Req By",
    TO_CHAR(cir_req_on,'DD-MON-YYYY') "Req On",
    nvl(cir_remarks,'') "Remarks",
    nvl(cir_created_by,'') "Created By",
    TO_CHAR(cir_created_on,'DD-MON-YYYY') "Created On",
    nvl(cir_updated_by,'') "Updated By",
    TO_CHAR(cir_updated_on,'DD-MON-YYYY') "Updated On",
    nvl(cir_active_flag,0) "Active Flag",
    nvl(cir_cd_prod,' ') "Prod Code",
    nvl(cir_dest_desc,'') "Dest Desciption"
FROM
    v_coil_indent_req
WHERE
    cir_sr_plant =:epacode`;
    if (data.destPlant && data.destPlant?.length > 0) {
      sql += ` AND CIR_DEST_PLANT = :destPlant`;
      binds["destPlant"] = data?.destPlant;
    }
    if (data.coilId && data.coilId?.length > 0) {
      sql += ` AND CIR_ID_COIL = :coilId`;
      binds["coilId"] = data?.coilId;
    }
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
// export const deleteScheduling = async (data: any) => {
//   try {
//     const sql = `DELETE FROM v_schd_temp where tst_prog_id = 'SPS0005'`;
//     return await query(sql);    
//   } catch (error: any) {
//     throw new Error.InternalServerErrorMsg(error);
//   }
// };
// export const scheduling = async (data: any) => {
//   try {
//     if (data?.type === "getData") {
//       if (data.Plant) {
//         return {
//           batch: await ResponceData(
//             await query(`
//           select distinct EOM_ID_BATCH 
//           from v_epa_prodn where eom_cd_status in ('VB','VF')
//           AND EOM_CD_EPA = ${data.Plant}
//           `)
//           ),
//           process: await ResponceData(
//             await query(`
//           select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
//           FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
//           `)
//           ),
//           status: await ResponceData(
//             await query(`
//           select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
//           WHERE CD_TYPE='TK006'
//           `)
//           ),
//           order: await ResponceData(
//             await query(`
//           SELECT distinct EOM_ID_ORDER
//           FROM v_epa_prodn a 
//           WHERE EOM_CD_EPA = ${data.Plant}
//           AND eom_ms_gross_cal >= 0
//           `)
//           ),         
//           plannedPath: await ResponceData(
//             await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
//             FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} 
//             AND INSTR(PPH_CD_PROC_PATH,'${data.proc}')>0 ORDER  BY 1`)
//           ),
//           orderTypeData: await ResponceData(await query(`SELECT CD_VALUE 
//           FROM V_CODES WHERE CD_TYPE='TB005' ORDER BY 1`)),
//           }
//       } else {
//         return getCommonPlantData();
//       }
//     } else if (data?.type === "materialData") {
//       let QrygetCoils = `SELECT eom_id_batch, eom_cd_prod, eom_cd_qlty_actl, 
//       (SELECT DISTINCT NVL (iql_grade_desc, '.') grade_desc
//                   FROM v_quality
//                  WHERE iql_cd_qlty = eom_cd_qlty_actl) grade_desc, eom_sec1,
//       eom_sec2, eom_length, eom_idia, '' planned_width,
//       eom_no_matnr1 materil_no1, '' material_desc1,
//       eom_matnr1_qty eom_matnr1_qty, eom_no_matnr2 materil_no2,
//       '' material_desc2, eom_matnr2_qty, eom_no_matnr3 materil_no3,
//       '' material_desc3, eom_matnr3_qty, eom_no_matnr4 materil_no4,
//       '' material_desc4, eom_matnr4_qty, eom_tdc_actl, eom_cd_yrd,
//       eom_id_loc_x, eom_id_loc_y, eom_id_pos, eom_no_pieces,
//       (SELECT DISTINCT NVL (tco_test_para_val, 0) uts
//                   FROM v_tc_coil_test
//                  WHERE tco_prod_no = eom_id_batch
//                    AND tco_cast_no = eom_no_cast
//                    AND tco_test_para IN ('UTS')
//                    AND ROWNUM = 1) uts,
//       (SELECT DISTINCT NVL (tco_test_para_val, 0) ys
//                   FROM v_tc_coil_test
//                  WHERE tco_prod_no = eom_id_batch
//                    AND tco_cast_no = eom_no_cast
//                    AND tco_test_para IN ('LYS', 'YS')
//                    AND ROWNUM = 1) ys,
//       eom_ms_piece_actl,
//       NVL (eom_ms_gross_cal, 0) + NVL (eom_inv_loss, 0) gross_cal,
//       eom_ms_scrap, eom_id_order_cus, eom_id_ord_item_cus, '' ord_typ,
//       eom_cd_status,
//       (SELECT DISTINCT eic_wo_no millord
//                   FROM v_input_coil
//                  WHERE eic_id_coil = eom_id_batch
//                    AND eic_cd_epa = eom_cd_epa
//                    AND ROWNUM = 1) millord,
//       (SELECT DISTINCT eic_item_no mill_item
//                   FROM v_input_coil
//                  WHERE eic_id_coil = eom_id_batch
//                    AND eic_cd_epa = eom_cd_epa
//                    AND ROWNUM = 1) mill_item,    
//       eom_no_matnr materil_no,
//       (SELECT maktx
//          FROM tskepadba.v_makt
//         WHERE mandt = '600'
//           AND matnr = eom_no_matnr
//           AND ROWNUM = 1) material_desc,
//       (SELECT eom_oper_comment
//          FROM v_epa_prodn
//         WHERE eom_id_batch = a.eom_id_batch
//           AND eom_cd_epa <> '${data.Plant}'
//           AND ROWNUM = 1) prv_spc_opr_comnts,
//       ROUND ((SYSDATE - eom_ts_creation), 0) age_days,
//       (SELECT eic_mk_customer
//          FROM v_input_coil
//         WHERE eic_cd_plant = a.eom_cd_epa
//           AND eic_id_coil = a.eom_id_batch) mk_customer,
//       eom_no_cast cast_no
//         FROM v_epa_prodn a
//         WHERE eom_cd_epa = '${data.Plant}'
//           AND eom_cd_status IN (select CD_VALUE  from v_codes WHERE CD_TYPE='TK006')
//           AND eom_ms_gross_cal >= 0 
//           AND eom_id_batch = eom_id_first_par `;

//       if (
//         data?.Status &&
//         Array.isArray(data?.Status) &&
//         data?.Status.length > 1
//       ) {
//         if (
//           data?.Status &&
//           Array.isArray(data?.Status) &&
//           data?.Status.length > 1
//         ) {
//           let dt = data?.Status.map((d: any) => `'${d}'`).join();
//           QrygetCoils += ` AND eom_cd_status in(` + dt + `) `;
//         }
//       } else {
//         if (data?.Status && data?.Status?.length > 0) {
//           QrygetCoils += ` AND eom_cd_status = nvl('${
//             Array.isArray(data?.Status) ? data?.Status[0] : data?.Status
//           }', eom_cd_status) `;
//         }
//       }
//       if (data?.BatchId && data?.BatchId?.length > 0) {
//         QrygetCoils += ` AND EOM_ID_BATCH = '${data?.BatchId}' `;
//       }
//       if (data?.ThickFR && data?.ThickFR?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFR}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFR}',EOM_SEC1))`;
//       }
//       if (data?.WidthFr && data?.WidthFr?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC2 BETWEEN NVL('${data?.WidthFr}',EOM_SEC2) AND NVL('${data?.WidthTo}',NVL('${data?.WidthFr}',EOM_SEC2))`;
//       }
//       if (data?.Tdc && data?.Tdc?.length > 0) {
//         QrygetCoils += ` AND EOM_TDC_ACTL = '${data?.Tdc}' `;
//       }
//       if (data?.ProdCd && data?.ProdCd?.length > 0) {
//         QrygetCoils += ` AND EOM_CD_PROD = '${data?.ProdCd}' `;
//       }
//       if (data?.FromDt && data?.FromDt?.length > 0) {
//         QrygetCoils += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.FromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.ToDt}',NVL('${data.FromDt}',TRUNC(EOM_TS_CREATION)))`;
//       }
//       if (data?.Idia && data?.Idia?.length > 0) {
//         QrygetCoils += ` AND EOM_IDIA = '${data?.Idia}' `;
//       }
//       QrygetCoils += " order by EOM_TS_CREATION";
//       return await query(QrygetCoils);
//     } else if (data?.type === "computeData") {
//      let sql = `call TPLB0001(
//         p_plant => :p_plant,
//         p_mcoil => :p_mcoil,
//         p_process_ln  => :p_process_ln,
//         p_subProc_ln  => :p_subProc_ln,
//         p_planPath  => :p_planPath,
//         p_order => :p_order,
//         p_ordItm  => :p_ordItm,
//         p_no_slt  => :p_no_slt,
//         p_no_part => :p_no_part,
//         p_ctl_pkt => :p_ctl_pkt,
//         p_thk => :p_thk,
//         p_width => :p_width,
//         p_length  => :p_length,
//         p_plan_wt => :p_plan_wt,
//         p_aim_wt  => :p_aim_wt,
//         p_setupno => :p_setupno, 
//         p_user  => :p_user,
//         p_row_seq => :p_row_seq,
//         p_remarks => :p_remarks,
//         p_fgGrade => :p_fgGrade,
//         p_ctl_pkt_pcs => :p_ctl_pkt_pcs,
//         p_schid => :p_schid,
//         p_pack_cd => :p_pack_cd,
//         p_oil_cd => :p_oil_cd,
//         p_prog_id => :p_prog_id,
//         ls_out_flag => :ls_out_flag
//       )`;

//       const binds = {
//         p_plant: data ?.p_plant,
//         p_mcoil: data ?.p_mcoil,
//         p_process_ln: data ?.p_process_ln,
//         p_subProc_ln: data ?.p_subProc_ln,
//         p_planPath: data ?.p_planPath,
//         p_order: data ?.p_order,
//         p_ordItm: data ?.p_ordItm,
//         p_no_slt: data ?.p_no_slt,
//         p_no_part: (data ?.p_no_part) ? data ?.p_no_part : 1,
//         p_ctl_pkt: data ?.p_ctl_pkt,
//         p_thk: data ?.p_thk,
//         p_width: data ?.p_width,
//         p_length: data ?.p_length,
//         p_plan_wt: data ?.p_plan_wt,
//         p_aim_wt: data ?.p_aim_wt,
//         p_setupno: data ?.p_setupno,
//         p_user: data ?.p_user,
//         p_row_seq: data ?.p_row_seq,
//         p_remarks: data ?.p_remarks,
//         p_fgGrade: data ?.p_fgGrade,
//         p_ctl_pkt_pcs: data ?.p_ctl_pkt_pcs,
//         p_schid: data ?.p_schedule_id,
//         p_pack_cd: data ?.p_pack_cd,
//         p_oil_cd: data ?.p_oil_cd,
//         p_prog_id: "SPS0005",
//         ls_out_flag: { type: oracledb.STRING, dir: oracledb.BIND_OUT, maxSize: 500 }
//       };    
//       return await query(sql, binds);
//     } else if (data?.type === "confirmData") {
//       let currData = data;
//       var sql = `call TPLB0002(
//         p_plant => :p_plant,
//         p_schd_no => :p_schd_no,
//         p_user  => :p_user,
//         ls_out_flag => :ls_out_flag
//       )`;

//       const binds = {
//         p_plant: currData?.data?.plantId,
//         p_schd_no: currData?.data?.scheId,
//         p_user: currData?.data?.UserID,
//         ls_out_flag: {
//           type: oracledb.STRING,
//           dir: oracledb.BIND_OUT,
//           maxSize: 500,
//         },
//       }; 
//       return await query(sql, binds);
//     } else if (data?.type === "packingCode") {
//       if (data.Plant) {
//         //console.log("Mark Code===>", data.MarkCust);
//         return {
//           packingCode: await ResponceData(
//             await query(`
//            SELECT TPM_PACK_CD PACK_CD FROM V_PACK_MASTER
//            WHERE TPM_CD_EPA = '${data.Plant}' 
//            AND TPM_MARK_CUST = '${data.MarkCust}'
//            `)),
//           oilingCode: await ResponceData(await query(`
//           SELECT TOM_OIL_CD OIL_CD FROM V_OILING_MASTER
//           WHERE TOM_CD_EPA = '${data.Plant}'  
//           AND TOM_MARK_CUST = '${data.MarkCust}'
//           AND TOM_CUST_TDC = '${data.Tdc}'
//          `)),
//         };
//       }
//     } else if (data?.type === "getSubProcData") {
//       let qry = `select CD_DESC1 SUB_PROC_LINE, CD_DESC1 || ' - ' || CD_DESC SUB_PROC_LINE_DESC 
//         from V_CODES where CD_TYPE = 'TK015' and CD_VALUE = '${data.procLine}'`;
//       return {
//         subProcLine: await ResponceData(await query(qry)),
//       };
//     }
//     else if (data ?.type === 'getOrdTDCList') {
//       let qry = `SELECT
//                       eom_tdc_actl   fitting_tdc
//                   FROM
//                       v_epa_prodn
//                   WHERE
//                       eom_cd_epa = '${data?.Plant}'
//                       AND eom_id_batch = '${data?.Coil_ID}' -- COIL ID
//                   UNION
//                   SELECT
//                       tdm_end_tdc   fitting_tdc
//                   FROM
//                       v_tdc_map
//                   WHERE
//                       tdm_act_tdc = '${data.Coil_TDC}' -- COIL TDC
//                   UNION
//                   SELECT
//                       esp_tdc_downgrade   fitting_tdc
//                   FROM
//                       v_epa_seconds_prime_tdc
//                   WHERE
//                       esp_cd_epa = '${data?.Plant}'
//                       AND esp_tdc_prime = '${data.Coil_TDC}'  -- COIL TDC
//                       AND esp_status = 'A'`
//       return {
//         ordTDCList: await ResponceData(await query(qry)),       
//       }  
//     }
//     else if (data ?.type === 'checkPackingFlag') {
//       let qry = `select LENGTH(substr('${data?.planPath}',1,LENGTH('${data?.planPath}')-2)) LN_PRC_CNT
//                  FROM DUAL`                    
//       return {
//         selectedPlanPath: await ResponceData(await query(qry)),       
//       }
//   }
//   }
//   catch (error: any) {
//     throw new Error.InternalServerError(error ?.toString());
//   }
// };
export const getCoilData01 = async () => {
  try {
    const sql: any = `SELECT
    DISTINCT EIC_ID_COIL
  FROM
    V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getVCoilData01 = async (data: any) => {
  let binds: any = {
    epaCode: data?.code,
  };
  try {
    let sql: any = `SELECT NVL(EIC_ID_COIL, '') "Coil Id", NVL(EIC_NO_INVOICE, 0) "Invoice No", TO_CHAR(EIC_DT_INVOICE,'DD-MON-YYYY')"Invoice Date"
    ,NVL(EIC_NO_DELIVERY, 0) "Delivary No",NVL(EIC_CD_PROD, '') "Prod Cd",NVL(EIC_CD_QLTY_ACTL, '') "Qlty Cd",NVL('', ' ') "Grade_Desc",NVL(EIC_SEC1, 0) "Thick", NVL(EIC_SEC2, 0) "Width",NVL(EIC_TDC_ACTL, '') "TDC"
    ,NVL(EIC_NO_MATNR, 0) "Material no",NVL(EIC_NO_CAST, '') "Cast_No"
    ,NVL(EIC_CD_EDGE, '') "Edge",NVL(EIC_MS_PIECE_ACTL, 0) "Invoice Weight" ,(EIC_MS_PIECE_ACTL-nvl(EIC_MS_SCRAP,0)) "Residual Weight",NVL(EIC_ID_LOC_X, 0) EIC_ID_LOC_X, NVL(EIC_ID_LOC_Y, 0) EIC_ID_LOC_Y,NVL(EIC_ID_POS, 0) EIC_ID_POS,NVL(EIC_CD_YRD, 0) EIC_CD_YRD
    ,NVL(EIC_REMARKS, ' ') EIC_REMARKS,NVL(EIC_MS_PIECE_ACTL, 0) "SPC Wt", NVL(EIC_CD_STATUS, '') EIC_CD_STATUS, NVL(EIC_CD_EPA, '') EIC_CD_EPA , NVL(EIC_ID_OP_SCRAP, '') "Operator ID", NVL(EIC_MARK_CUST, '') "Customer Code"
     --,(select NAME1 from v_kna1 where mandt='600' AND KUNNR = LPAD(EIC_MARK_CUST ,10,'0') AND ROWNUM=1) "CustNM"
    ,NVL('', 0) "CustNM"
    ,NVL('', ' ') "Salvaging Remarks"
    ,NVL(EIC_PASSED_PROC, '') "Mill Passed Process"
    ,round((sysdate-EIC_DT_INVOICE)) "Invoice Age"
    ,round((sysdate-nvl(EIC_DT_LOADING,sysdate))) "Age at SPC", TO_CHAR(EIC_DT_LOADING, 'DD-MON-YYYY') "Arrival Dt"
    ,ROUND(nvl(EIC_DT_LOADING,sysdate)-nvl(EIC_DT_INVOICE,sysdate)) "Transit Lead Time(Days)"
    ,(select  round((sysdate-nvl(min(EOM_TS_CREATION), sysdate)))  from v_epa_prodn where eom_cd_epa =EIC_CD_EPA and eom_id_first_par=EIC_ID_COIL and eom_id_batch <> eom_id_first_par) "Processing Date"
    FROM V_INPUT_COIL
    WHERE EIC_CD_EPA=:epaCode`;
    if (data.coilId && data.coilId?.length > 0) {
      sql += ` AND EIC_ID_COIL = :coilId`;
      binds["coilId"] = data?.coilId;
    }
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const updateCoilStatus01 = async (data: any) => {
  try {
    let sql: any = "";
    if (data.status === "A") {
      sql = `UPDATE V_COIL_INDENT_REQ
      SET CIR_REQ_STATUS = 'AC',
            --CIR_UPDATED_BY = USER,  
            --CIR_UPDATED_ON = SYSDATE,
            CIR_CREATED_BY = USER,
            CIR_CREATED_ON = SYSDATE,
            CIR_REMARKS = :NBT_REMARKS
      WHERE CIR_ID_COIL = :NBT_COIL_ID`;
    } else {
      sql = `UPDATE V_COIL_INDENT_REQ
      SET CIR_REQ_STATUS = 'RJ',
          --CIR_UPDATED_BY = USER,  
          --CIR_UPDATED_ON = SYSDATE, 
          CIR_CREATED_BY = USER,
          CIR_CREATED_ON = SYSDATE,				               
          CIR_REMARKS = :NBT_REMARKS
     WHERE CIR_ID_COIL = :NBT_COIL_ID`;
    }
    const binds = {
      NBT_REMARKS: data.NBT_REMARKS,
      NBT_COIL_ID: data.NBT_COIL_ID,
    };
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};

export const getProdData01 = async () => {
  try {
    const sql: any = `SELECT
    DISTINCT EIC_CD_PROD
  FROM
    V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getQltyData01 = async () => {
  try {
    const sql: any = `SELECT
    DISTINCT EIC_CD_QLTY_ACTL
  FROM
    V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
export const getTdcData01 = async () => {
  try {
    const sql: any = `SELECT
    DISTINCT EIC_TDC_ACTL
  FROM
    V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerError("Error");
  }
};
// export const getOrderData = async (data: any) => {
//   try {
//     let sql: any = `SELECT
//                   enc_id_order,
//                   enc_no_item,
//                   (SELECT f_get_SAPGRADE('${data.plant}',enc_id_order,enc_no_item) FROM DUAL) PLANGRADE,
//                   ENC_CD_QLTY,
//                   ENC_IDIA,
//                   enc_cd_epa,
//                   enc_ord_quantity,
//                   NVL(TO_CHAR(enc_dt_delv, 'dd-mm-yyyy'),' ') enc_dt_delv,
//                   enc_mark_cust,
//                   enc_mark_cust_name,
//                   enc_no_tdc,
//                   enc_sec1_min,    
//                   enc_sec1_max, 
//                   enc_sec2_min,
//                   enc_sec2_max,
//                   enc_length_max,
//                   nvl(SUM(DECODE(eom_cd_status, 'WL', eom_ms_gross_cal)),0) desp,
//                   nvl(SUM(DECODE(eom_cd_status, 'WB', eom_ms_gross_cal)), 0) displ,
//                   nvl(SUM(DECODE(substr(eom_cd_status, 2, 1), 'B', eom_ms_gross_cal)), 0) linked,
//                   enc_cust_name,
//                   enc_order_type,
//                   enc_cd_end_cust,
//                   enc_no_matnr,
//                   enc_cd_prod,
//                   ENC_MAX_PIECE_WT,
//                   ENC_MIN_PIECE_WT,
//                   ( SELECT
//                           nvl(maktx, ' ')
//                       FROM
//                           v_makt
//                       WHERE
//                           mandt = '600'
//                           AND matnr = enc_no_matnr
//                   ) material_desc,
//                   TO_CHAR(enc_dt_ord_create) enc_dt_ord_create,
//                   enc_ord_desc,
//                   nvl(enc_roaddest_desc,' ') enc_roaddest_desc,
//                   nvl(enc_raildest_desc,' ') enc_raildest_desc,
//                   enc_cd_qlty
//               FROM
//                   v_end_cust_ord_epa,
//                   v_epa_prodn
//               WHERE
//                 enc_cd_epa = '131'
//                 AND enc_order_type = nvl('${data?.orderType}', enc_order_type)
//                 AND enc_st_order = 'A'
//                 --AND enc_id_order LIKE '002%'
//                 AND eom_id_order_cus (+) = enc_id_order
//                 --AND enc_slit_plan='SLIT' 
//                 AND eom_id_ord_item_cus (+) = enc_no_item
//                 `;
//     if (data?.orderId && data?.orderId?.length > 0) {
//       sql += ` and enc_id_order = ${data?.orderId}`;
//     }

//     if (data?.orderItem && data?.orderItem?.length > 0) {
//       sql += ` and ENC_NO_ITEM =  ${data?.orderItem}`;
//     }

//     if (data?.orderTDC && data?.orderTDC?.length > 0) {
//       sql += ` and enc_no_tdc = '${data?.orderTDC}'`;
//     }

//     if (data?.orderType && data?.orderType?.length > 0) {
//       sql += ` and enc_order_type = '${data?.orderType}'`;
//     }

//     if (data?.orderThick && data?.orderThick?.length > 0) {
//       sql += ` and ${data?.orderThick}  between  enc_sec1_min and enc_sec1_max `;
//     }

//     if (data?.orderWidth && data?.orderWidth?.length > 0) {
//       sql += ` and ${data?.orderWidth}  between  enc_sec2_min and enc_sec2_max `;
//     }

//     sql += ` GROUP BY
//             enc_id_order,
//             enc_no_item,
//             ENC_CD_QLTY,
//             ENC_IDIA,
//             enc_ord_quantity,
//             enc_no_tdc,
//             enc_cd_epa,
//             enc_sec1_min,   
//             enc_sec1_max,    
//             enc_sec2_min,
//             enc_sec2_max,
//             enc_length_max,
//             enc_cust_name,
//             enc_order_type,
//             enc_cd_prod,
//             enc_order_type,
//             enc_dt_ord_create,
//             enc_dt_delv,
//             enc_mark_cust,
//             enc_mark_cust_name,
//             enc_ord_desc,
//             enc_roaddest_desc,
//             enc_raildest_desc,
//             enc_cd_end_cust,
//             enc_no_matnr,
//             enc_cd_qlty,
//             ENC_MAX_PIECE_WT,
//             ENC_MIN_PIECE_WT`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };
// export const indenting = async (data: any) => {
//   try {
//     let binds: any = {
//       Plant: data.Plant,
//       //Status: req.body.Status,
//     };
//     if (data?.type === "getData") {
//       if (data.Plant) {
//         return {
//           batch: await ResponceData(
//             await query(`
//           select distinct EOM_ID_BATCH
//           from v_epa_prodn where eom_cd_status in (select CD_VALUE from v_codes WHERE CD_TYPE='TK004')
//           AND EOM_CD_EPA = ${data.Plant}
//           `)
//           ),
//           process: await ResponceData(
//             await query(`
//           select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
//           FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
//           `)
//           ),
//           status: await ResponceData(
//             await query(`
//           select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
//           WHERE CD_TYPE='TK004'
//           `)
//           ),
//           checkReqStatus: await ResponceData(
//             await query(`SELECT CD_VALUE FROM V_CODES
//           WHERE CD_TYPE='TK004'
//           AND SUBSTR(CD_DESC1,1,2)='RI'`)
//           ),
//           checkCancelStatus: await ResponceData(
//             await query(`SELECT CD_VALUE FROM V_CODES
//             WHERE CD_TYPE='TK004'
//             AND SUBSTR(CD_DESC1,1,2)='IN'`)
//           ),
//           order: await ResponceData(
//             await query(`
//           SELECT distinct EOM_ID_ORDER
//           FROM v_epa_prodn a
//           WHERE EOM_CD_EPA = ${data.Plant}
//           AND eom_ms_gross_cal >= 0
//           `)
//           ),
//           plannedPath: await ResponceData(
//             await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
//            FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} ORDER  BY 1`)
//           ),
//         };
//       } else {
//         return getCommonPlantData();
//       }
//     } else if (data?.type === "IndentCoilDetails") {
//       let QrygetCoils = `SELECT
//       eom_cd_epa         plant,
//       eom_id_batch       coil_id,
//       eom_ms_gross_cal   coil_wt,
//       eom_sec1           thk,
//       eom_sec2           width,
//       eom_tdc_actl       tdc,
//       eom_cd_prod        prod_cd,
//       eom_cd_status      status,
//       round(SYSDATE - eom_ts_creation) coil_age,
//       eom_no_cast        cast_no,
//       eom_no_matnr       coil_mat,
//       (
//           SELECT
//               maktx
//           FROM
//               v_makt
//           WHERE
//               mandt = '600'
//               AND matnr = eom_no_matnr
//       ) coil_mat_desc,
//       TO_CHAR(eom_ts_creation,'dd-mm-yyyy hh24:MI:SS') coil_arrival_dt,
//       (
//           SELECT
//               tpm_pack_cd
//           FROM
//               v_pack_master
//           WHERE
//               tpm_cd_epa = eom_cd_epa
//               AND tpm_mark_cust = eom_mk_customer
//       ) packing,
//       (
//           SELECT
//               tom_cust_tdc
//           FROM
//               v_oiling_master
//           WHERE
//               tom_cd_epa = eom_cd_epa
//               AND tom_mark_cust = eom_mk_customer
//               AND tom_cust_tdc = eom_tdc_actl
//       ) oiling
//   FROM
//       v_epa_prodn
//   WHERE
//       eom_cd_epa = '${data.Plant}'
//       AND eom_cd_status IN (
//           SELECT
//               cd_value
//           FROM
//               v_codes
//           WHERE
//               cd_type = 'TK004'
//       )
//       AND eom_ms_gross_cal >= 0
//       AND eom_id_batch = eom_id_first_par `;

//       if (
//         data?.Status &&
//         Array.isArray(data?.Status) &&
//         data?.Status.length > 1
//       ) {
//         if (
//           data?.Status &&
//           Array.isArray(data?.Status) &&
//           data?.Status.length > 1
//         ) {
//           let dt = data?.Status.map((d: any) => `'${d}'`).join();
//           QrygetCoils += ` AND eom_cd_status in(` + dt + `) `;
//         }
//       } else {
//         if (data?.Status && data?.Status?.length > 0) {
//           QrygetCoils += ` AND eom_cd_status = nvl('${
//             Array.isArray(data?.Status) ? data?.Status[0] : data?.Status
//           }', eom_cd_status) `;
//         }
//       }
//       if (data?.BatchId && data?.BatchId?.length > 0) {
//         QrygetCoils += ` AND EOM_ID_BATCH = '${data?.BatchId}' `;
//       }

//       if (data?.ThickFR?.length > 0 && data?.ThickTo?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFR}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFR}',EOM_SEC1))`;
//       } else if (data?.ThickFR?.length > 0 || data?.ThickTo?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC1 = '${
//           data?.ThickFR?.length > 0 ? data?.ThickFR : data?.ThickTo
//         }'`;
//       }
//       if (data?.WidthFr?.length > 0 && data?.WidthTo?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC2 BETWEEN NVL('${data?.WidthFr}',EOM_SEC2) AND NVL('${data?.WidthTo}',NVL('${data?.WidthFr}',EOM_SEC2))`;
//       } else if (data?.WidthFr?.length > 0 || data?.WidthTo?.length > 0) {
//         QrygetCoils += ` AND EOM_SEC2 = '${
//           data?.WidthFr?.length > 0 ? data?.WidthFr : data?.WidthTo
//         }'`;
//       }
//       if (data?.Tdc && data?.Tdc?.length > 0) {
//         QrygetCoils += ` AND EOM_TDC_ACTL = '${data?.Tdc}' `;
//       }
//       if (data?.prodCd && data?.prodCd?.length > 0) {
//         QrygetCoils += ` AND EOM_CD_PROD = '${data?.prodCd}' `;
//       }
//       if (data?.fromDt && data?.fromDt?.length > 0) {
//         QrygetCoils += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.toDt}',NVL('${data.fromDt}',TRUNC(EOM_TS_CREATION)))`;
//       }
//       QrygetCoils += " order by EOM_TS_CREATION";

//       return await query(QrygetCoils);
//     } else if (data?.type === "procedureCall") {
//       var sql = `call TPLB0003(
//         p_plant => :p_plant,
//         p_coil_id => :p_coil_id,
//         ls_out_flag => :ls_out_flag
//       )`;
//       const binds = {
//         p_plant: data?.plantId,
//         p_coil_id: data?.coilId,
//         ls_out_flag: {
//           type: oracledb.STRING,
//           dir: oracledb.BIND_OUT,
//           maxSize: 500,
//         },
//       };
//       return await query(sql, binds);
//     } else if (data?.type === "deleteIndent") {
//       var sql = `call TPLB003A(
//         p_plant => :p_plant,
//         p_coil_id => :p_coil_id,
//         ls_out_flag => :ls_out_flag
//       )`;
//       const binds = {
//         p_plant: data?.plantId,
//         p_coil_id: data?.coilId,
//         ls_out_flag: {
//           type: oracledb.STRING,
//           dir: oracledb.BIND_OUT,
//           maxSize: 500,
//         },
//       };

//       return await query(sql, binds);
//     }
//   } catch (error: any) {
//     throw new Error.InternalServerError(error?.toString());
//   }
// };
// export const scheduleID = async () => {
//   try {
//     let sql: any = `SELECT EPA_SCH_SEQ.NEXTVAL SCH_ID FROM DUAL`;
//     return await query(sql);
//   } catch (error: any) {
//     throw new Error.InternalServerError("Error");
//   }
// };

// export const scheduleDeletion = async (data: any) => {
//   try {
//     if (data?.type === "getData") {
//       if (data.Plant) {
//         return {
//           batch: await ResponceData(
//             await query(`
//           select distinct EOM_ID_BATCH 
//           from v_epa_prodn where eom_cd_status in ('VB','VF')
//           AND EOM_CD_EPA = ${data.Plant}
//           `)
//           ),
//           // select distinct(RSP_PDI) SCHID from V_SL_PDI_BUSI where RSP_CD_EPA =${data.Plant}
//           scheduleId: await ResponceData(
//             await query(`
//           select distinct(PDS_PDI) from v_pr_data_ip_slt where PDS_CD_EPA = ${data.Plant}
//           `)
//           ),
//           process: await ResponceData(
//             await query(`
//           select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
//           FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant}  ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
//           `)
//           ),

//           status: await ResponceData(
//             await query(`
//           select CD_VALUE VALUE, CD_VALUE||' - '||CD_DESC LABEL from v_codes
//             WHERE CD_TYPE='TK005'
//           `)
//           ),
//           plannedPath: await ResponceData(
//             await query(`SELECT PPH_CD_PROC_PATH, PPH_DESC
//            FROM   V_EPA_PROC_PATH WHERE  PPH_CD_EPA = ${data.Plant} ORDER  BY 1`)
//           ),
//         };
//       } else {
//         return getCommonPlantData();
//       }
//     } else if (data?.type === "schedConfirmData") {
//       var Qrygetschs = "";
//       if (data.data?.process == "S") {
//         // Query is used only for Slit line process
//         // Query for Draft Schedule
//         Qrygetschs = `SELECT PDS_CD_EPA plant, 
//         PDS_CURR_PROC CD_PROCESS,
//         PDS_ID_COIL Coilid,
//         PDS_PDI PDI_ID , 
//         PDS_thick fgthick,
//         PDS_width fgwidth,
//         --PDS_QLTY_CD fg_qlty_cd , 
//         --PDS_prod_cd fg_prod_cd , 
//         PDS_CURR_PROC curr_proc,
//         PDS_length fg_length,
//         PDS_cast_no cast_no,
//         PDS_PLANNED_PROC paln_proc ,PDS_SLIT_WIDTH slit_width ,
//         PDS_NO_SLIT slits,
//         PDS_OUT_TDC          SCH_TDC,
//         PDS_NO_PART part ,
//         PDS_ORDER order_id,PDS_ITEM_NO item,
//         PDS_REC_CRT_BY crt_by,TO_CHAR(PDS_REC_CRT_DT, 'dd-mm-yyyy hh24:MI:SS') crt_no
//         , PDS_TDC TDC
//         , PDS_PACK_CODE PACK_CD
//         , PDS_OIL_TYPE  OIL_TYPE
//         , PDS_COMBINATION COMBINATION
//         , PDS_IDIA IDIA
//         , PDS_ODIA ODIA
//         ,PDS_SCH_WT  SCH_WT
//         ,PDS_PLAN_WT PLAN_WT
//         ,PDS_MASS  INV_WT
//         ,ENC_ORDER_EDGE ORD_EDGE
//         ,PDS_SCHD_ID SCH_ID
//         ,ENC_MARK_CUST_NAME cust_nm
//         ,(select eic_idia from v_input_coil where eic_cd_Epa=a.PDS_CD_EPA and eic_id_coil =a.PDS_ID_COIL ) inp_idia
//         ,(select EIC_CD_EDGE from v_input_coil where eic_cd_Epa=a.PDS_CD_EPA and eic_id_coil =a.PDS_ID_COIL ) inp_edge
//         ,(select EIC_MK_CUSTOMER from v_input_coil where eic_cd_Epa=a.PDS_CD_EPA and eic_id_coil =a.PDS_ID_COIL ) inp_customer
//         ,PDS_SETUP_CODE setup, PDS_GRADE_DESC GRADE_DEC, PDS_CD_STATUS CD_STATUS, PDS_THICK TNP_THICK, PDS_WIDTH INP_WIDTH
//         ,(SELECT EOM_CD_STATUS FROM V_EPA_PRODN
//           WHERE EOM_ID_BATCH  = PDS_ID_COIL
//           AND EOM_CD_ePA      = PDS_CD_EPA  ) CR_STATUS
//           from V_PR_DATA_IP_SLT A, V_END_CUST_ORD_EPA , V_EPA_PRODN C
//           where PDS_CD_EPA = EOM_CD_EPA
//           AND PDS_ID_COIL = EOM_ID_BATCH
//           AND PDS_CD_EPA = '${data.data?.plant}'
//           AND PDS_CD_EPA = ENC_cD_EPA
//           AND PDS_ORDER = ENC_ID_ORDER
//           AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS ='WC'
//           AND EOM_CD_YRD ='HJ' --- this confirms that stock is in TSDPL Premise
//           AND EOM_CD_STATUS LIKE '%C'
//           UNION
//           SELECT
//                   PDS_CD_EPA           PLANT,
//                   PDS_CURR_PROC        CD_PROCESS,
//                   PDS_ID_COIL          COILID,
//                   PDS_PDI              PDI_ID,
//                   PDS_THICK            FGTHICK,
//                   PDS_WIDTH            FGWIDTH,
//                           --PDS_QLTY_CD fg_qlty_cd , 
//                           --PDS_prod_cd fg_prod_cd , 
//                   PDS_CURR_PROC        CURR_PROC,
//                   PDS_LENGTH           FG_LENGTH,
//                   PDS_CAST_NO          CAST_NO,
//                   PDS_PLANNED_PROC     PALN_PROC,
//                   PDS_SLIT_WIDTH       SLIT_WIDTH,
//                   PDS_NO_SLIT          SLITS,
//                   PDS_OUT_TDC          SCH_TDC,
//                   PDS_NO_PART          PART,
//                   PDS_ORDER            ORDER_ID,
//                   PDS_ITEM_NO          ITEM,
//                   PDS_REC_CRT_BY       CRT_BY,
//                   TO_CHAR(PDS_REC_CRT_DT,'dd-mm-yyyy hh24:MI:SS') CRT_NO,
//                   PDS_TDC              TDC,
//                   PDS_PACK_CODE        PACK_CD,
//                   PDS_OIL_TYPE         OIL_TYPE,
//                   PDS_COMBINATION      COMBINATION,
//                   PDS_IDIA             IDIA,
//                   PDS_ODIA             ODIA,
//                   PDS_SCH_WT           SCH_WT,
//                   PDS_PLAN_WT          PLAN_WT,
//                   PDS_MASS             INV_WT,
//                   ENC_ORDER_EDGE       ORD_EDGE,
//                   PDS_SCHD_ID          SCH_ID,
//                   ENC_MARK_CUST_NAME   CUST_NM,
//                   (
//                       SELECT
//                           EIC_IDIA
//                       FROM
//                           V_INPUT_COIL
//                       WHERE
//                           EIC_CD_EPA = A.PDS_CD_EPA
//                           AND EIC_ID_COIL = A.PDS_ID_COIL
//                   ) INP_IDIA,
//                   (
//                       SELECT
//                           EIC_CD_EDGE
//                       FROM
//                           V_INPUT_COIL
//                       WHERE
//                           EIC_CD_EPA = A.PDS_CD_EPA
//                           AND EIC_ID_COIL = A.PDS_ID_COIL
//                   ) INP_EDGE,
//                   (
//                       SELECT
//                           EIC_MK_CUSTOMER
//                       FROM
//                           V_INPUT_COIL
//                       WHERE
//                           EIC_CD_EPA = A.PDS_CD_EPA
//                           AND EIC_ID_COIL = A.PDS_ID_COIL
//                   ) INP_CUSTOMER,
//                   PDS_SETUP_CODE       SETUP,
//                   PDS_OUT_GRADE_DESC   GRADE_DEC,
//                   PDS_CD_STATUS        CD_STATUS,
//                   PDS_THICK            TNP_THICK,
//                   PDS_WIDTH            INP_WIDTH,
//                   (
//                       SELECT
//                           EOM_CD_STATUS
//                       FROM
//                           V_EPA_PRODN
//                       WHERE
//                           EOM_ID_BATCH = PDS_ID_COIL
//                           AND EOM_CD_EPA = PDS_CD_EPA
//                   ) CR_STATUS
//               FROM
//                   V_PR_DATA_IP_SLT A,
//                   V_END_CUST_ORD_EPA,
//                   V_EPA_PRODN C
//               WHERE
//                   PDS_CD_EPA = EOM_CD_EPA
//                   AND PDS_ID_COIL = EOM_ID_BATCH
//           AND PDS_CD_EPA = '${data.data?.plant}'
//           AND PDS_CD_EPA = ENC_CD_EPA
//           AND PDS_ORDER = ENC_ID_ORDER
//           AND PDS_ITEM_NO = ENC_NO_ITEM  AND PDS_CD_STATUS ='WC'
//           AND EOM_CD_STATUS ='VS'`
//              if (data.data ?.process && data.data ?.process ?.length > 0) {
//                 Qrygetschs += ` AND PDS_CURR_PROC = '${data.data.process}'`
//               }
//               if (data.data ?.schedId && data.data ?.schedId ?.length > 0) {
//                 Qrygetschs += ` AND PDS_SCHD_ID = '${data.data.schedId}'`
//               }
//               if (data.data ?.prodCd && data.data ?.prodCd ?.length > 0) {
//                 Qrygetschs += `  AND PDS_PROD_CD = '${data.data.prodCd}'`
//               }
//               if (data.data ?.fromDt && data.data ?.fromDt ?.length > 0) {
//                 Qrygetschs += ` And TRUNC(EOM_TS_CREATION) BETWEEN NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)) AND  NVL('${data.data.toDt}',NVL('${data.data.fromDt}',TRUNC(EOM_TS_CREATION)))`
//               }
//             }
//             else{
//               return 1;
//             }
//       return await ResponceData(await query(Qrygetschs));
//     } else if (data?.type === "deleteData") {
//       let results: any = { N: [], Y: [] };
//       for (let i = 0; i < data?.data?.length; i++) {
//         var sql = `call TPLB0004(
//           p_plant => :p_plant,
//           p_coil_id => :p_coil_id,
//           p_proc_line => :p_proc_line,
//           ls_out_flag => :ls_out_flag
//         )`;
//         const binds = {
//           p_plant: data?.data[i].plant ? data?.data[i].plant : "",
//           p_coil_id: data?.data[i].coilId ? data?.data[i].coilId : "",
//           p_proc_line: data?.data[i].pline ? data?.data[i].pline : "",
//           ls_out_flag: {
//             type: oracledb.STRING,
//             dir: oracledb.BIND_OUT,
//             maxSize: 500,
//           },
//         };
//         let output = await query(sql, binds);
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "N") {
//           results["N"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['N'].push(data?.data?.[i].coilId)
//         }
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "Y") {
//           results["Y"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['Y'].push(data?.data?.[i].coilId)
//         }
//       }

//       return results;
//     } else if (data?.type === "confirmData") {
//       let results: any = { N: [], Y: [] };
//       for (let i = 0; i < data?.data?.length; i++) {
//         var sql = `call TPLB004A(
//           p_plant => :p_plant,
//           p_coil_id => :p_coil_id,
//           p_proc_line => :p_proc_line,
//           ls_out_flag => :ls_out_flag
//         )`;
//         const binds = {
//           p_plant: data?.data[i].plant ? data?.data[i].plant : "",
//           p_coil_id: data?.data[i].coilId ? data?.data[i].coilId : "",
//           p_proc_line: data?.data[i].pline ? data?.data[i].pline : "",
//           ls_out_flag: {
//             type: oracledb.STRING,
//             dir: oracledb.BIND_OUT,
//             maxSize: 500,
//           },
//         };
//         let output = await query(sql, binds);
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "N") {
//           results["N"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['N'].push(data?.data?.[i].coilId)
//         }
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "Y") {
//           results["Y"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['Y'].push(data?.data?.[i].coilId)
//         }
//       }
//       return results;
//     }
//   } catch (error: any) {
//     throw new Error.InternalServerError(error?.toString());
//   }
// };

//       return results;
//     } else if (data?.type === "confirmData") {
//       let results: any = { N: [], Y: [] };
//       for (let i = 0; i < data?.data?.length; i++) {
//         var sql = `call TPLB004A(
//           p_plant => :p_plant,
//           p_coil_id => :p_coil_id,
//           p_proc_line => :p_proc_line,
//           ls_out_flag => :ls_out_flag
//         )`;
//         const binds = {
//           p_plant: data?.data[i].plant ? data?.data[i].plant : "",
//           p_coil_id: data?.data[i].coilId ? data?.data[i].coilId : "",
//           p_proc_line: data?.data[i].pline ? data?.data[i].pline : "",
//           ls_out_flag: {
//             type: oracledb.STRING,
//             dir: oracledb.BIND_OUT,
//             maxSize: 500,
//           },
//         };
//         let output = await query(sql, binds);
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "N") {
//           results["N"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['N'].push(data?.data?.[i].coilId)
//         }
//         if (output?.outBinds?.ls_out_flag?.[0].substr(0, 1) === "Y") {
//           results["Y"].push(
//             data?.data?.[i].coilId + " : " + output?.outBinds?.ls_out_flag
//           );
//           //results['Y'].push(data?.data?.[i].coilId)
//         }
//       }
//       return results;
//     }
//   } catch (error: any) {
//     throw new Error.InternalServerError(error?.toString());
//   }
// };
