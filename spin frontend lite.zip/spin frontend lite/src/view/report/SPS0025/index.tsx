import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import alertify from "../../../components/alert";
import { GetAuthorization } from "../../../utils";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Draggable from "react-draggable";
import { TableType, InputChangeType } from "./type";
import Paper, { PaperProps } from "@mui/material/Paper";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
  TextField,
} from "@mui/material";
import {
  SPS0025Api,
  SPS0025BatchApi,
  SPS0025TableApi,
} from "../../../apiConfig/insideAuthApi";
import WarningIcon from "@mui/icons-material/Warning";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import DeleteIcon from "@mui/icons-material/Delete";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import ArchitectureIcon from "@mui/icons-material/Architecture";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { PopupObj, option, popuptype } from "./type";
import { setTheme, useMaterialUIController } from "../../../context";
import { Collapse } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { FormType } from "../../../view/auth/type";
import { AnyARecord } from "dns";
import { validateTime } from "@mui/x-date-pickers/internals";
import { type } from "os";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPS0025 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;

  const [table1, setTable1] = React.useState<any>(null);
  const [loading, setLoading] = React.useState<boolean>(false);

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [tableData1, setTableData1] = React.useState<any>([]);
  const [tableData2, setTableData2] = React.useState<any>([]);
  const [tableData3, setTableData3] = React.useState<any>([]);

  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [selectedAuditType, setSelectedAuditType] = React.useState<string>("");
  const [selectedBatchId, setSelectedBatchId] = React.useState("");
  const [selectedOrderId, setSelectedOrderId] = React.useState<any>("");
  const [plantData, setPlantData] = React.useState<Array<SelectType>>([]);

  const [BatchIdData, setBatchIdData] = React.useState<Array<SelectType>>([]);
  const [OrderIdData, setOrderIdData] = React.useState<Array<SelectType>>([]);

  const [, setScheduleDetailsData] = React.useState<Array<SelectType>>([]);

  const AuditData = [
    { label: "Input Coil Audit", value: "01" },
    { label: "Production Audit", value: "02" },
    { label: "Customer Order Audit", value: "03" },
  ];
  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Material No",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "TDC",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Prod Cd",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key3"),
    },
    key4: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key4"),
    },
    key5: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key5"),
    },
    key6: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key6"),
    },
    key7: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key7"),
    },
    key8: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key8"),
    },
    key9: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key9"),
    },
    key10: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key10"),
    },
    key11: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key11"),
    },
  };
  const [reportData, setReportData] = React.useState<Array<SelectType>>([]);
  const [sourceplantData, setsourceplantData] = React.useState<
    Array<SelectType>
  >([]);

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  const column1: any = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },
    {
      title: "Coil Id",
      field: "EICA_ID_COIL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Column Name",
      field: "EICA_COLUMN_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Old Value",
      field: "EICA_OLD_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "New Value",
      field: "EICA_NEW_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "User Id",
      field: "EICA_USERID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TimeStamp",
      field: "EICA_TIMESTAMP_CHNG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Action",
      field: "EICA_ACTION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const column2: any = [
    {
      title: "Batch Id",
      field: "EOMA_ID_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Column Name",
      field: "EOMA_COLUMN_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Old Value",
      field: "EOMA_OLD_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "New Value",
      field: "EOMA_NEW_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "User Id",
      field: "EOMA_USERID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Timestamp",
      field: "EOMA_TIMESTAMP_CHNG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Action",
      field: "EOMA_ACTION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const column3: any = [
    {
      title: "Order Id",
      field: "ENCA_ID_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Item No",
      field: "ENCA_NO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Column Name",
      field: "ENCA_COLUMN_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Old Value",
      field: "ENCA_OLD_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "New Value",
      field: "ENCA_NEW_VALUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "User Id",
      field: "ENCA_USERID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Timestamp",
      field: "ENCA_TIMESTAMP_CHNG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Action",
      field: "ENCA_ACTION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  React.useEffect(() => {
    SPS0025ApiCall("pageData");
  }, []);

  React.useEffect(() => {
    if (tableData1?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: tableData1,
          columns:
            selectedAuditType === "01"
              ? column1
              : selectedAuditType === "02"
              ? column2
              : selectedAuditType === "03"
              ? column3
              : null,
          maxHeight: 380,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData1]);

  let formData: Array<FormType> = [];

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const SPS0025ApiBatchData = (type: string) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0025BatchApi(token, {
        type: type,
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log(res.data);
            if (type === "01") {
              if (res?.data?.length === 0) {
                alertify.error("No Plant Data found");
                return;
              }
              const varData1: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData1?.push({
                    value: x?.EICA_ID_COIL?.toString(),
                    label: x?.EICA_ID_COIL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setBatchIdData(varData1);
            } else if (type === "02") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                const varData2: Array<SelectType> = [];
                res?.data?.map((x: any, i: number) => (
                  <React.Fragment key={i}>
                    {varData2?.push({
                      value: x?.EOMA_ID_BATCH?.toString(),
                      label: x?.EOMA_ID_BATCH?.toString(),
                      id: i,
                    })}
                  </React.Fragment>
                ));
                setBatchIdData(varData2);
              }
            } else if (type === "03") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                const varData3: Array<SelectType> = [];
                res?.data?.map((x: any, i: number) => (
                  <React.Fragment key={i}>
                    {varData3?.push({
                      value: x?.ENCA_ID_ORDER?.toString(),
                      label: x?.ENCA_ID_ORDER?.toString(),
                      id: i,
                    })}
                  </React.Fragment>
                ));
                setOrderIdData(varData3);
              }
            }
          }
        })
        .catch((e: any) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const SPS0025TablesData = (type: string) => {
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      SPS0025TableApi(token, {
        type: type,
        plant: selectedPlant,
        batchId: selectedBatchId,
        orderId: selectedOrderId,
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log(res.data);
            if (res.data.length === 0) {
              alertify.error("No data Found");
              return;
            } else {
              setTableData1(res.data);
            }
            // if (type === '01') {
            //     console.log(res.data)
            //     if (res.data?.length === 0) {
            //         alertify.error("No data Found")
            //         return

            //     }
            //     else {
            //         setTableData1(res.data)
            //     }

            // }
            // else if (type === '02') {
            //     console.log(res.data)
            //     if (res.data?.length === 0) {
            //         alertify.error("No data Found")
            //         return

            //     }
            //     else {
            //         setTableData2(res.data)
            //     }

            // }
            // else if (type === '03') {
            //     console.log(res.data)
            //     if (res.data?.length === 0) {
            //         alertify.error("No data Found")
            //         return

            //     }
            //     else {
            //         setTableData3(res.data)
            //     }

            // }
          }
        })
        .catch((e: any) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const SPS0025ApiCall = (type: string) => {
    setLoading(true);

    GetAuthorization().then((token: TokenType) => {
      SPS0025Api(token, {
        type: type,
        plant: selectedPlant,
        batchId: selectedBatchId,
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            console.log(res.data);
            if (type === "pageData") {
              if (res?.data?.plant.length === 0) {
                alertify.error("No Plant Data found");
                return;
              }
              const varData1: Array<SelectType> = [];
              res?.data?.plant?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData1?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantData(varData1);
              setSelectedPlant(varData1[0]?.value);

              // const varData2: Array<SelectType> = [];
              // res?.data?.batchId?.map((x: any, i: number) => (
              //     <React.Fragment key={i}>
              //         {varData2?.push({
              //             value: x?.EICA_ID_COIL?.toString(),
              //             label: x?.EICA_ID_COIL?.toString(),
              //             id: i,
              //         })}
              //     </React.Fragment>
              // ));
              // setBatchIdData(varData2)
              //setSelectedBatchId(varData2[0]?.value)

              // const varData3: Array<SelectType> = [];
              // res?.data?.orderId?.map((x: any, i: number) => (
              //     <React.Fragment key={i}>
              //         {varData3?.push({
              //             value: x?.ENCA_ID_ORDER?.toString(),
              //             label: x?.ENCA_ID_ORDER?.toString(),
              //             id: i,
              //         })}
              //     </React.Fragment>
              // ));
              // setOrderIdData(varData3)
              // //setSelectedOrderId(varData3[0]?.value)
              // console.log(varData1, varData2, varData3)
            } else if (type === "getInputCoilAudit") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                setTableData1(res.data);
              }
            } else if (type === "getProductionAudit") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                setTableData2(res.data);
              }
            } else if (type === "getCustOrdAudit") {
              console.log(res.data);
              if (res.data?.length === 0) {
                alertify.error("No data Found");
                return;
              } else {
                setTableData3(res.data);
              }
            }
          }
        })
        .catch((e: any) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    tbl?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setTableData1([]);

    setSelectedAuditType("");
    setSelectedBatchId("");
    setSelectedOrderId("");
  };

  const handleSearch = () => {
    if (!selectedPlant) {
      alertify.error("Please Select Plant");
      return;
    }
    if (!selectedAuditType) {
      alertify.error("Please Select Audit Type");
      return;
    } else if (selectedAuditType === "01" || selectedAuditType === "02") {
      if (!selectedBatchId) {
        alertify.error("Please Select Batch");
        return;
      }
    } else if (selectedAuditType === "03") {
      if (!selectedOrderId) {
        alertify.error("Order Id is Mandatory");
        return;
      }
    }

    SPS0025TablesData(selectedAuditType);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid
                  container
                  spacing={1}
                  sx={{
                    p: 2,
                    backgroundColor: csTheme?.palette.background.paper,
                    borderRadius: 2,
                    gap: 1,
                  }}
                >
                  <Grid item xs={2}>
                    <SelectInput
                      label="Plant*"
                      data={plantData}
                      id={"id"}
                      value={selectedPlant}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedPlant(e);
                        SPS0025ApiCall("plantData");
                        setTableData1([]);
                      }}
                    />
                  </Grid>
                  <Grid item xs={2.5}>
                    <SelectInput
                      label="Audit Type"
                      data={AuditData}
                      value={selectedAuditType}
                      size={"small"}
                      onChange={(e: string) => {
                        setSelectedAuditType(e);
                        setTableData1([]);
                        SPS0025ApiBatchData(e);
                      }}
                    />
                  </Grid>

                  {(selectedAuditType == "01" || selectedAuditType == "02") && (
                    <Grid item xs={2.5}>
                      <SelectInput
                        label="Batch Id *"
                        data={BatchIdData}
                        value={selectedBatchId}
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedBatchId(e);
                          setTableData1([]);
                        }}
                      />
                    </Grid>
                  )}

                  {selectedAuditType == "03" && (
                    <Grid item xs={2.5}>
                      <TextField
                        label="Order Id *"
                        //data={OrderIdData}
                        value={selectedOrderId}
                        size="small"
                        onChange={(e) => {
                          setSelectedOrderId(e.target.value);
                          setTableData1([]);
                        }}
                      />
                    </Grid>
                  )}

                  <Grid item xs={1}>
                    <ButtonElement
                      sx={{ width: "100%" }}
                      onClick={() => handleSearch()}
                    >
                      Search
                    </ButtonElement>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Table Details"
                headerContainer={
                  <Tooltip title="Download">
                    <IconButton
                      onClick={() => {
                        downloadExcel("SPS0025", tableData1, table);
                      }}
                    >
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData1?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
            {
              <Grid sx={{ display: "None" }}>
                <div id="table1"></div>
              </Grid>
            }
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0025;
