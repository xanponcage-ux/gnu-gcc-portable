import { Router } from "express";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";
import {
  getBatchData,
  getBatchDLinkData,
  getChemChk,
  getFittingOrderData,
  saveData,
} from "../controllers/SPS0004Controller";

const SPS0004Route = Router();

SPS0004Route.route("/SPS0004/getBatchData").post(
  authenticationMiddleware.bearer,
  getBatchData
);

SPS0004Route.route("/SPS0004/getBatchDLinkData").post(
  authenticationMiddleware.bearer,
  getBatchDLinkData
);

SPS0004Route.route("/SPS0004/getFittingOrderData").post(
  authenticationMiddleware.bearer,
  getFittingOrderData
);

SPS0004Route.route("/SPS0004/saveData").post(
  authenticationMiddleware.bearer,
  saveData
);

SPS0004Route.route("/SPS0004/getChemChk").post(
  authenticationMiddleware.bearer,
  getChemChk
);

export default SPS0004Route;
