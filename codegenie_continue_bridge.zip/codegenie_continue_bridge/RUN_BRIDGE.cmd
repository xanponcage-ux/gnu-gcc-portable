@echo off
setlocal

REM ============================================================
REM EDIT ONLY THESE TWO VALUES.
REM Do not put quotes inside the values.
REM ============================================================
set "CODEGENIE_ADID=YOUR_ADID"
set "CODEGENIE_APIKEY=YOUR_CODEGENIE_API_KEY"

REM Verified company route for the CodeGenie Cloud Function.
set "CODEGENIE_PROXY=http://127.0.0.1:13124"
set "CODEGENIE_MODEL=gpt-4o-mini"
set "CODEGENIE_APPLICATION_NAME=Code Genie"
set "CODEGENIE_MAX_TOKENS=4096"

REM Reuse the Python environment already created earlier.
set "PY=C:\CompanyGenAIBridge\.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo ERROR: Python environment not found:
  echo %PY%
  echo.
  echo Change PY above to a Python environment containing fastapi, uvicorn and requests.
  pause
  exit /b 1
)

echo Starting CodeGenie bridge on http://127.0.0.1:8765
"%PY%" -m uvicorn codegenie_bridge:app --host 127.0.0.1 --port 8765
