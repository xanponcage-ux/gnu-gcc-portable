import * as dotenv from "dotenv";
import express = require("express");
import * as bodyParser from "body-parser";
import cors = require("cors");
import { middleware } from "express-ctx";
import env from "./env";

import oracledb from "oracledb";
import usersRoute from "./routes/userRoutes";
import commonRoute from "./routes/commonRoutes";
import qualityRoute from "./routes/qualityRoutes";
import gateEntryRoute from "./routes/gateEntryRoutes";
import operationRoute from "./routes/operationRoutes";
import planningRoute from "./routes/planning";
import dispatchRoutes from "./routes/dispatchRoutes";
import masterRoute from "./routes/maintainMasterRoutes";
import reportRoute from "./routes/reportRoutes";

// ----Dashboard ---
import DashboardRoute from "./routes/DashboardRoute";

// ---- PLANNING ---
import SPS0004Route from "./routes/SPS0004Route";
import SPS0005Route from "./routes/SPS0005Route";
import SPS0010Route from "./routes/SPS0010Route";
import SPS0015Route from "./routes/SPS0015Route";
import SPS0003Route from "./routes/SPS0003Route";

// ---- REPORT ---
import SPC0009Route from "./routes/SPC0009Route";
import SPC0001Route from "./routes/SPC0001Route";
import SPC0007Route from "./routes/SPC0007Route";
import SPC0008Route from "./routes/SPC0008Route";
import SPS0020Route from "./routes/SPS0020Route";
import SPS0025Route from "./routes/SPS0025Route";
import SPC0010Route from "./routes/SPC0010Route";
import SPC0011Route from "./routes/SPC0011Route";
import SPC0012Route from "./routes/SPC0012Route";
import SPC0014Route from "./routes/SPC0014Routes";
import SPC0016Route from "./routes/SPC0016Route";
import SPC0017Route from "./routes/SPC0017Route";
import SPC0021Route from "./routes/SPC0021Routes";

// ---- QUALITY MANAGEMENT ---
import SPQ001Route from "./routes/SPQ001Route";
import SCQ001Route from "./routes/SCQ001Route";
import SCQ002Route from "./routes/SCQ002Route";

// ---- MAINTAIN MASTER  ---
import SPC0002Route from "./routes/SPC0002Route";
import SPC0003Route from "./routes/SPC0003Route";
import SPC0004Route from "./routes/SPC0004Route";
import SPC0006Route from "./routes/SPC0006Route";

import SPC0015Route from "./routes/SPC0015Route";

// ---- COMMON ---
import SPC0005Route from "./routes/SPC0005Route";
import SPC0013Route from "./routes/SPC0013Route";

// ---- COMMON ---
import SPCG001Route from "./routes/SPCG001Route";

// ---- OPERATION ---
import SPO0001Route from "./routes/SPO0001Route";
import SPO0003Route from "./routes/SPO0003Route";
import SPO0004Route from "./routes/SPO0004Route";
import SPO0005Route from "./routes/SPO0005Route";
import SPO0007Route from "./routes/SPO0007Route";
import SPO0008Route from "./routes/SPO0008Routes";

// ---- DISPATCH ---
import SPO0002Route from "./routes/SPO0002Route";
import SCO006Route from "./routes/SCO006Route";

import queryPgRoute from "./routes/queryPgRoutes";

// process.once("SIGTERM", closePoolAndExit).once("SIGINT", closePoolAndExit);

export class App {
  public app: express.Application;
  pool: any;

  constructor() {
    this.app = express();
    // this.getPool();
    //this.closePoolAndExit();
  }

  enableCors() {
    var whitelist = env.whitelistdUrl;
    const options: cors.CorsOptions = {
      methods: "GET,POST,PUT,DELETE",
      origin: function (origin: string | null | undefined, callback) {
        if (
          whitelist?.indexOf("*") !== -1 ||
          (origin && whitelist.indexOf(origin) !== -1)
        ) {
          callback(null, true);
        } else {
          callback(new Error("Not allowed by CORS"));
        }
      },
    };
    this.app.use(cors(options));
    //this.app.use("/swagger", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
  }

  listen() {
    //this.enableCors();
    var https = require("https");
    var fs = require("fs");
    // var https_options = {
    //   key: fs.readFileSync("/etc/ssl/wildcorptslnew.key"),
    //   cert: fs.readFileSync("/etc/ssl/ServerCertificate.crt"),
    //   ca: [fs.readFileSync("/etc/ssl/Root.crt")],
    // };
    var https_options = {
      key: fs.readFileSync("/etc/ssl/wildcorptslnew.key"),
      cert: fs.readFileSync("/etc/ssl/ServerCertificate.crt"),
      ca: [fs.readFileSync("/etc/ssl/ChainCert.crt")],
    };

    https.createServer(https_options, this.app).listen(`${env.appport}`, () => {
      console.log(`${"Galvpro"} running → PORT ${env.appport}`);
      console.log(`Server Run Port: ${env.appport}`);
      this.middler();
      this.routes();
    });
  }

  localhost_listen() {
    this.app.listen(env.appport, () => {
      console.log(`${"Galvpro"} running → PORT ${env.appport}`);
      console.log(`Server Run Port: ${env.appport}`);
      this.middler();
      this.routes();
    });
  }

  middler() {
    this.enableCors();
    this.app.use(middleware);
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
  }

  routes() {
    this.app.use("/api", usersRoute);
    this.app.use("/api", commonRoute);
    this.app.use("/api", qualityRoute);
    this.app.use("/api", gateEntryRoute);
    this.app.use("/api", operationRoute);
    this.app.use("/api", planningRoute);
    this.app.use("/api", dispatchRoutes);
    this.app.use("/api", masterRoute);
    this.app.use("/api", reportRoute);

    // ----Dashboard ---
    this.app.use("/api", DashboardRoute);

    // ---- PLANNING ---
    this.app.use("/api", SPS0004Route);
    this.app.use("/api", SPS0005Route);
    this.app.use("/api", SPS0010Route);
    this.app.use("/api", SPS0015Route);
    this.app.use("/api", SPS0003Route);

    // ---- REPORT ---
    this.app.use("/api", SPC0001Route);
    this.app.use("/api", SPC0007Route);
    this.app.use("/api", SPC0008Route);
    this.app.use("/api", SPC0009Route);
    this.app.use("/api", SPC0010Route);
    this.app.use("/api", SPS0020Route);
    this.app.use("/api", SPS0025Route);
    this.app.use("/api", SPC0011Route);
    this.app.use("/api", SPC0012Route);
    this.app.use("/api", SPC0014Route);
    this.app.use("/api", SPC0016Route);
    this.app.use("/api", SPC0017Route);
    this.app.use("/api", SPC0021Route);

    // ---- QUALITY MANAGEMENT ---
    this.app.use("/api", SPQ001Route);
    this.app.use("/api", SCQ001Route);
    this.app.use("/api", SCO006Route);
    this.app.use("/api", SCQ002Route);

    // ---- MAINTAIN MASTER  ---
    this.app.use("/api", SPC0002Route);
    this.app.use("/api", SPC0003Route);
    this.app.use("/api", SPC0004Route);
    this.app.use("/api", SPC0006Route);
    this.app.use("/api", SPC0015Route);

    // ---- COMMON ---
    this.app.use("/api", SPC0005Route);
    this.app.use("/api", SPC0013Route);

    // ---- COMMON ---
    this.app.use("/api", SPCG001Route);

    // ---- OPERATION ---
    this.app.use("/api", SPO0001Route);
    this.app.use("/api", SPO0003Route);
    this.app.use("/api", SPO0004Route);
    this.app.use("/api", SPO0005Route);
    this.app.use("/api", SPO0007Route);
    this.app.use("/api", SPO0008Route);

    // ---- DISPATCH ---
    this.app.use("/api", SPO0002Route);

    this.app.use("/api", queryPgRoute);

    this.app.use(
      (
        err: any,
        req: express.Request,
        res: express.Response,
        next: express.NextFunction
      ) => {
        console.error("Error from Global err handler: ", err);

        res.status(500).json({
          success: false,
          message: "Internal Server Error.",
        });
      }
    );
  }
}
