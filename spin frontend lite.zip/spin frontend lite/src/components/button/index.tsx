import Button from "@mui/material/Button";
import { ButtonType } from "./type";
import React from "react";
import { Dialog, DialogActions, DialogTitle } from "@mui/material";

const ButtonElement = (props: ButtonType) => {
  const [open, setOpen] = React.useState(false);
  const handleClose = () => {
    setOpen(false);
  };
  let varData = { ...props };
  delete varData.confirmPopup;
  return (
    <React.Fragment>
      <Dialog
        open={open && (props?.confirmPopup ?? false)}
        keepMounted
        onClose={handleClose}
        aria-describedby="alert-dialog"
      >
        <DialogTitle>{"Do you want to " + props.children + "?"}</DialogTitle>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">
            Close
          </Button>
          <Button
            color="secondary"
            onClick={(e: any) => {
              setOpen(false);
              if (props?.onClick) {
                props?.onClick(e);
              }
            }}
          >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <Button
        {...varData}
        color="secondary"
        onClick={props?.confirmPopup ? () => setOpen(true) : props.onClick}
        variant={props?.variant ? props.variant : "contained"}
        disabled={props?.extra?.loading}
      >
        {props?.extra?.loading ? "Loading..." : props.children}
      </Button>
    </React.Fragment>
  );
};

export default ButtonElement;
