// const SPC0011Query = require("../repository/SPC0011Query");
import * as repo from "../repository/SPC0011Query";

export default class SPC0011Model {
  getData(data: any) {
    return repo.getData(data);
  }
  getTableData(data: any) {
    return repo.getTableData(data);
  }
}
