import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import {
  SPC0011GetDataApi,
  SPC0011GetTableDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { setTheme, useMaterialUIController } from "../../../context";
import { SelectType } from "../../../components/input/type";
import { DatePickerInput } from "../../../components/input";
import { InputChangeType } from "./type";
import { FormType } from "../../auth/type";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0011 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<any>("");
  const [process, setProcess] = React.useState<Array<SelectType>>([]);
  const [selectedProc, setSelectedProc] = React.useState<any>("");
  const [status, setStatus] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<any>("");
  const [batch, setBatch] = React.useState<any>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Schd From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "Schd To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0011GetDataApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlant(varData);
              setSelectedPlant(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcess(varprocessData);

              const varStatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varStatusData?.push({
                    value: x?.CD_VALUE?.toString(),
                    label: x?.CD_VALUE?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatus(varStatusData);
            }
          }
        })
        .catch((e) => {
          console.log("errorr: ", e);
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0011" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setSelectedProc("");
    setSelectedStatus("");
    setBatch("");
    setTableData("");
    setInputObj(varInput);
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table1", {
          data: tableData,
          columns: tableCol,
          height: 340,
          layout: "fitDataFill",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData]);

  const fetchTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!(selectedProc?.length > 0)) {
      alertify.error("Please select Process!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0011GetTableDataApi(token, {
        type: "tableData",
        plant: selectedPlant,
        process: selectedProc,
        status: selectedStatus,
        batch: batch,
        schDtFrom: DateFormat(inputObj.key1.value),
        schDtTo: DateFormat(inputObj.key2.value),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              // console.log(res.data);
              setTableData(res.data);
              console.log("table data: ", tableData);
            } else {
              setTableData([]);
              alertify.error("No data found");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // Columns not visible for K - packing

  function isVisibleK() {
    return selectedProc != "K";
  }

  const tableCol: any = [
    {
      formatter: "rowSelection",
      hozAlign: "center",
      frozen: true,
      headerSort: false,
      title: "",
      selectable: true,
    },

    {
      field: "BATCH",
      title: "Batch",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CURR_PROC",
      title: "Proccess",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "OUT_TDC",
      title: "FG TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "THICK",
      title: "FG Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "WIDTH",
      title: "FG Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "LENGTH",
      title: "FG Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "OUT_GRADE_DESC",
      title: "Grade Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "IDIA",
      title: "Idia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "ODIA",
      title: "Odia",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "NO_PART",
      title: "No of part",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "COMBINATION",
      title: "Combination",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "ODR",
      title: "Order",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "ITEM_NO",
      title: "Item",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "MK_CUST",
      title: "Mark Cust",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "CD_STATUS",
      title: "PDI Status",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PDI",
      title: "PDI No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SCH_CRT_DT",
      title: "Schd Creation Dt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SCH_CRT_BY",
      title: "Schd Created By",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   field: "PLAN_WT",
    //   title: "Plan Wt",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "SCH_WT",
      title: "Sch Wt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },

    {
      field: "CAST_NO",
      title: "Cast No",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   field: "NO_PACK",
    //   title: "No of Pkt",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   field: "NO_SHEETS",
    //   title: "Sheet per Pkt",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "MASS",
      title: "Coil Mass",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    // {
    //   field: "FREIGHT_MODE",
    //   title: "freight Mode",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "NXT_PROC",
      title: "Next Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "PLANNED_PROC",
      title: "Planned Proc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "PACK_CODE",
      title: "Pack Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      field: "SETUP_CODE",
      title: "Setup Code",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },

    // {
    //   field: "ID_PARENT_BATCH",
    //   title: "Parent Batch",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "SCHD_ID",
      title: "Schd ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "REWK_IND",
      title: "Rewk Ind",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "REC_CRT_DT",
      title: "Rec Creation Dt",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "REC_CRT_BY",
      title: "Rec Created By",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },

    {
      field: "RM_MATNR",
      title: "RM Matnr",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "FG_MATNR",
      title: "FG Matnr",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },

    {
      field: "YIELD",
      title: "Yield",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "UTS",
      title: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },

    // {
    //   field: "PART_NUMBER",
    //   title: "Part No",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      field: "CUST_DESC",
      title: "Cust Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "SHIP_TO_PARTY",
      title: "Ship to Party",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "DESTINATION",
      title: "Destination",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "TDC",
      title: "Input TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "THICK",
      title: "Input Thick",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "WIDTH",
      title: "Input Width",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "LENGTH",
      title: "Input Length",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      field: "PLANT",
      title: "Plant",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "UNCOIL_DIR",
      title: "Uncoil Dir",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "MAT_OIL",
      title: "Material Oil",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "OIL_TYPE_COIL",
      title: "Oil Type Coil",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "SLP_REMARKS",
      title: "SLP Remarks",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "EDGE_COND",
      title: "Edeg Cond",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "GRADE_DESC",
      title: "Grade Desc",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "OIL_MAX_QTY",
      title: "Oil Max Qty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "OIL_MIN_QTY",
      title: "Oil Min Qty",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "OIL_TYPE",
      title: "Oil Type",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "EDGE_WAVINESS",
      title: "Edge Waviness",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "CENTRE_BUCKLE",
      title: "Centre Buckle",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "CROSSBOW",
      title: "Crossbow",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "CAMBER",
      title: "Camber",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "BURR_HEIGHT",
      title: "Burr Height",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "SURF_REQ",
      title: "Surf Req",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "HORIZONTAL_GAP",
      title: "Horizontal Gap",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "VERTICAL_GAP",
      title: "Vertical Gap",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
    {
      field: "WIDTH_TOL",
      title: "Width Tol",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      visible: isVisibleK(),
    },
  ];

  if (selectedProc === "N" || selectedProc === "T") {
    const newColumn = [
      {
        field: "NO_PACK",
        title: "No of Pkt",
        headerFilter: "input",
        headerFilterPlaceholder: "search...",
      },
      {
        field: "NO_SHEETS",
        title: "Sheet per Pkt",
        headerFilter: "input",
        headerFilterPlaceholder: "search...",
      },
    ];

    const index = tableCol.findIndex((col) => col.field === "CAST_NO");

    //insert after cast no
    tableCol.splice(index + 1, 0, ...newColumn);
  } else if (selectedProc === "S") {
    const newColumn = {
      field: "NO_SLIT",
      title: "No of Slit",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    };

    const index = tableCol.findIndex((col) => col.field === "NO_PART");

    tableCol.splice(index + 1, 0, newColumn);
  }

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2.5}>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            fetchEpaData(e);
                            setTableData("");
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <SelectInput
                          label="Process"
                          data={process}
                          value={selectedProc}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProc(e);
                            setTableData("");
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <SelectInput
                          label="Status"
                          data={status}
                          value={selectedStatus}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedStatus(e);
                            setTableData("");
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <Input
                          id={"Batch"}
                          value={batch}
                          label="Batch"
                          size={"small"}
                          onChange={(e: string) => {
                            setBatch(e);
                            setTableData("");
                          }}
                        />
                      </Grid>

                      <Grid item xs={3.5}>
                        <Box component="span">
                          {" "}
                          {/* Date */}
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i < 2 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData("");
                                        // setCtlTableData("");
                                        // setSltTableData("");
                                      }}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>

                      <Grid item xs={1}>
                        <ButtonElement
                          onClick={() => {
                            fetchTableData();
                            // fetchCtlTableData();
                            // fetchSltTableData();
                          }}
                        >
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>

            {/* <Grid item xs={12}>
            <TableContainer
              title="CTL Details"
              headerContainer={
                <Grid container>
                  <Grid item>
                    <Tooltip title="Download">
                      <IconButton
                      //   onClick={downloadExcel}
                      >
                        <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                </Grid>
              }
            >
              <Box sx={{ width: "100%" }}>
                {ctlTableData?.length > 0 && (
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <div id="ctlTable"></div>
                      <br />
                      <p
                        color="black"
                        style={{
                          color: "black",
                          paddingLeft: "1rem",
                          marginTop: "-1rem",
                        }}
                      >
                        Showing 1 to {ctlTableData?.length} of{" "}
                        {ctlTableData?.length} entries
                      </p>
                    </Grid>
                  </Grid>
                )}
              </Box>
            </TableContainer>
          </Grid> */}

            {/* <Grid item xs={12}>
            <TableContainer
              title="SLIT Details"
              headerContainer={
                <Grid container>
                  <Grid item>
                    <Tooltip title="Download">
                      <IconButton
                      //   onClick={downloadExcel}
                      >
                        <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid>
                </Grid>
              }
            >
              <Box sx={{ width: "100%" }}>
                {sltTableData?.length > 0 && (
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <div id="sltTable"></div>
                      <br />
                      <p
                        color="black"
                        style={{
                          color: "black",
                          paddingLeft: "1rem",
                          marginTop: "-1rem",
                        }}
                      >
                        Showing 1 to {sltTableData?.length} of{" "}
                        {sltTableData?.length} entries
                      </p>
                    </Grid>
                  </Grid>
                )}
              </Box>
            </TableContainer>
          </Grid> */}
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0011;
