import { Request, Response } from "express";
import SPC0007Model from "../models/SPC0007Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData07 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0007Model.prototype.getData07(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getOrderId07 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0007Model.prototype.getOrderId07();
    const result2 = await SPC0007Model.prototype.getEpa07();
    const result3 = await SPC0007Model.prototype.getOrderStatus07();
    const result4 = await SPC0007Model.prototype.getCustomer07();
    const result5 = await SPC0007Model.prototype.getOrderType07();
    const varData = {
      epa: await ResponceData(result2),
      order: await ResponceData(result1),
      orderStatus: await ResponceData(result3),
      customer: await ResponceData(result4),
      orderType: await ResponceData(result5),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
