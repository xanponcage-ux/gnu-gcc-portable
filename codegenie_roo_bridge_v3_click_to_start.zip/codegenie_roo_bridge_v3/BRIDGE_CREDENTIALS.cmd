@echo off
REM ============================================================
REM EDIT THIS FILE ONCE ON YOUR COMPANY LAPTOP.
REM Do not share the values.
REM ============================================================

set "CODEGENIE_ADID=YOUR_ADID"
set "CODEGENIE_APIKEY=YOUR_CODEGENIE_API_KEY"

REM Company/Zscaler proxy used by the working CodeGenie request.
set "CODEGENIE_PROXY=http://127.0.0.1:13124"
set "CODEGENIE_APPLICATION_NAME=Code Genie"
set "CODEGENIE_TIMEOUT=300"

REM Python environment that already works on your laptop.
set "PY=C:\CompanyGenAIBridge\.venv\Scripts\python.exe"
