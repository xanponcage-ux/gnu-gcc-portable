@echo off
curl.exe -sS -X POST http://127.0.0.1:8765/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"gpt-4o-mini\",\"messages\":[{\"role\":\"user\",\"content\":\"You must call get_test_value. Do not answer directly.\"}],\"max_tokens\":-1,\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"get_test_value\",\"description\":\"Returns a test value\",\"parameters\":{\"type\":\"object\",\"properties\":{},\"required\":[]}}}]}"
echo.
pause
