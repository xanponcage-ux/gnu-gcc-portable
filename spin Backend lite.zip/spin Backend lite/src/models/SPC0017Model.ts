import { getData, getStatusData } from "../repository/SPC0017Query";

export default class SPC0017Model {
  async getData(data: any) {
    return getData(data);
  }
  async getStatusData(data: any) {
    return getStatusData(data);
  }
}
