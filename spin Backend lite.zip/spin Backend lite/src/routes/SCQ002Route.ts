import { Router } from "express";
import { SCQ002Api } from "../controllers/SCQ002Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";
import multer from "multer";
import { uploadSampleImage } from "../controllers/sftpUpload";

const SCQ002Route = Router();

SCQ002Route.route("/SCQ002/SCQ002Api").post(
  authenticationMiddleware.bearer,
  SCQ002Api
);

const router = Router();
const upload = multer({ dest: "tmp/" });

SCQ002Route.route("/SCQ002/uploadImageToSftp").post(
  authenticationMiddleware.bearer,
  upload.single("file"),
  uploadSampleImage
);

export default SCQ002Route;
