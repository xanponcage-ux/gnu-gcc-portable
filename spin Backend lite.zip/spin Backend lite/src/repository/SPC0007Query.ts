import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";

export const getData07 = async (data: any) => {
  try {
    let binds: any = {
      order: data?.epa,
    };
    let sql: any = `select ENC_ID_ORDER OrderNo,
      NVL(ENC_NO_ITEM, '') OrdItem,    
      NVL(ENC_ORDER_TYPE, '') OrdType,    
      NVL(ENC_CD_PROD, '') Prod_cd,     
      NVL(ENC_CD_QLTY, '') Qlty_Cd,     
      NVL(ENC_SEC1_MIN, '') Thick_Min,     
      NVL(ENC_SEC1_MAX, '') Thick_Max,     
      NVL(ENC_SEC2_MIN, '') Width_Min,     
      NVL(ENC_SEC2_MAX, '') Width_Max,     
      NVL(ENC_LENGTH_MIN, '') Length_Min,     
      NVL(ENC_LENGTH_MAX, '') Length_Max,     
      NVL(ENC_NO_TDC, '') TDC,     
      NVL(ENC_CD_GRADE, '') Grade,     
      NVL(ENC_NO_MATNR, '') FG_Material,     
      NVL(ENC_ORD_DESC, '') Order_Desc,     
      NVL(ENC_ORD_QUANTITY, '') Ord_Qnty,     
      TO_CHAR(ENC_DT_ORD_CREATE, 'DD-MON-YYYY') Order_Creation_dt,     
      TO_CHAR(ENC_DT_DELV, 'DD-MON-YYYY') Delivary_Dt,     
      NVL(ENC_ST_ORDER, '') Order_Status,     
      NVL(TO_CHAR(ENC_DT_ORD_REL, 'DD-MON-YYYY'), ' ') Order_Release_dt,     
      NVL(ENC_CD_END_CUST, 0) Cust_Code,     
      NVL(TO_CHAR(ENC_DT_ORD_CLOSE, 'DD-MON-YYYY'), ' ') Order_Close_dt,     
      NVL(TO_CHAR(ENC_TS_ORD_DWNLD, 'DD-MON-YYYY'), 0) Download_Dt,     
      NVL(ENC_NO_TRACKING, 0) Tracking_No,     
      NVL(ENC_CD_EPA, '') PlantCD,     
      NVL(ENC_CUST_NAME, ' ') Cust_NM,     
      NVL(ENC_IDIA, 0) Idia,     
      NVL(ENC_MIN_PIECE_WT, 0) PIece_Wt_Min,     
      NVL(ENC_MAX_PIECE_WT, 0) PIece_Wt_Max,     
      NVL(ENC_AIM_PIECE_WT, 0) PIece_Wt_Aim,     
      NVL(ENC_CD_SHIP_TO_PRTY, 0) Ship_To_P_cd,     
      NVL(ENC_SHIP_TO_PRTY_DESC, 0) Ship_To_P_desc,     
      NVL(ENC_ODIA, 0) ODia,     
      NVL(ENC_ROAD_DEST, 0) ENC_ROAD_DEST,     
      NVL(ENC_ROADDEST_DESC, ' ') Road_Desc,     
      NVL(ENC_RAIL_DEST, 0) ENC_RAIL_DEST,     
      NVL(ENC_RAILDEST_DESC, ' ') Rail_Desc,     
      NVL(TO_CHAR(ENC_CUST_REQ_DT, 'DD-MON-YYYY'), '') Cust_Ask_Dt,     
      NVL(ENC_MK_SPEC, 0) Cust_SPec,     
      NVL(ENC_MARK_CUST, 0) Mark_Cust_cd,     
      NVL(ENC_MARK_CUST_NAME, 0) Mark_Cust_NM,     
      TO_CHAR(ENC_LAST_ORD_DWNLD, 'DD-MON-YYYY') Download_Dt_Latest,     
      NVL(ENC_DELV_TOLERENCE, 0) Tolerance,     
      NVL(ENC_ORDER_EDGE, 0) Order_Edge,     
      NVL(ENC_MATNR_INFO, 0) Order_Spec_Info,     
      NVL(ENC_SEC1_ACT, 0) Actual_Thick,     
      NVL(ENC_SEC2_ACT, 0) Actual_Width,     
      NVL(ENC_SEC3_ACT, 0) Actual_Length,     
      NVL(ENC_DESPATCH_WK, 0) Dispatch_Wk,     
      NVL(ENC_ORD_CRT_BY, 0) Ordr_Crt_By,
      ENC_POST_TREAT POST_TREAT
      from v_end_cust_ord_epa
     
      where enc_cd_epa='${data?.epa}'
     
      `;

    if (data.orderStatus && data.orderStatus?.length > 0) {
      sql += ` and enc_st_order='${data?.orderStatus}'`;
      binds["orderStatus"] = data?.orderStatus;
    }
    if (data.orderItem && data.orderItem?.length > 0) {
      sql += ` and ENC_NO_ITEM='${data?.orderItem}'`;
      binds["orderItem"] = data?.orderItem;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` and ENC_NO_MATNR='${data?.materialNo}'`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.order && data.order?.length > 0) {
      sql += ` AND ENC_ID_ORDER = '${data?.order}'`;
      binds["order"] = data?.order;
    }
    if (data.custCd && data.custCd?.length > 0) {
      sql += ` AND ENC_CD_END_CUST = '${data?.custCd}'`;
      binds["custCd"] = data?.custCd;
    }
    if (data.trackingNo && data.trackingNo?.length > 0) {
      sql += ` AND ENC_NO_TRACKING = '${data?.trackingNo}'`;
      binds["trackingNo"] = data?.trackingNo;
    }
    if (data.orderType && data.orderType?.length > 0) {
      sql += ` AND ENC_ORDER_TYPE = '${data?.orderType}'`;
      binds["orderType"] = data?.orderType;
    }
    if (data.prodCd && data.prodCd?.length > 0) {
      sql += ` AND ENC_CD_PROD = '${data?.prodCd}'`;
      binds["prodCd"] = data?.prodCd;
    }
    if (data.qltyCd && data.qltyCd?.length > 0) {
      sql += ` AND ENC_CD_QLTY = '${data?.qltyCd}'`;
      binds["qltyCd"] = data?.qltyCd;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND ENC_NO_TDC = '${data?.tdc}'`;
      binds["tdc"] = data?.tdc;
    }
    if (data?.orderDateFr && data?.orderDateTo) {
      sql += ` AND ENC_DT_ORD_CREATE BETWEEN NVL('${data?.orderDateFr}','01-JAN-1900') AND NVL('${data?.orderDateTo}','31-DEC-9999')`;
      binds.orderDateFr = data?.orderDateFr;
      binds.orderDateTo = data?.orderDateTo;
    }
    if (data?.deliveryDateFr && data?.deliveryDateTo) {
      sql += ` AND ENC_DT_DELV BETWEEN NVL('${data?.deliveryDateFr}','01-JAN-1900') AND NVL('${data?.deliveryDateTo}','31-DEC-9999')`;
      binds.deliveryDateFr = data?.deliveryDateFr;
      binds.deliveryDateTo = data?.deliveryDateTo;
    }
    if (data?.ThickFr && data?.ThickFr != "") {
      sql += ` AND ENC_SEC1_MIN >= nvl('${data?.ThickFr}', enc_sec1_min)`;
      binds["ThickFr"] = data?.ThickFr;
    }
    if (data?.ThickTo && data?.ThickTo !== "") {
      sql += `AND ENC_SEC1_MAX <= nvl('${data?.ThickTo}', ENC_SEC1_MAX) `;
      binds["ThickTo"] = data?.ThickTo;
    }
    if (data?.widthFr && data?.widthFr != "") {
      sql += ` AND ENC_SEC2_MIN >= nvl('${data?.widthFr}', ENC_SEC2_MIN)`;
      binds["widthFr"] = data?.widthFr;
    }
    if (data?.widthTo && data?.widthTo !== "") {
      sql += `AND ENC_SEC2_MAX <= nvl('${data?.widthTo}', ENC_SEC2_MAX)`;
      binds["widthTo"] = data?.widthTo;
    }
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getOrderId07 = async () => {
  try {
    const sql = `SELECT
      DISTINCT ENC_ID_ORDER
    FROM
      V_END_CUST_ORD_EPA`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getEpa07 = async () => {
  try {
    const sql = `SELECT
      DISTINCT ENC_CD_EPA
    FROM
      V_END_CUST_ORD_EPA`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getOrderStatus07 = async () => {
  try {
    const sql: any = `SELECT DISTINCT enc_st_order FROM v_end_cust_ord_epa`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getCustomer07 = async () => {
  try {
    const sql: any = `SELECT DISTINCT ENC_CD_END_CUST FROM v_end_cust_ord_epa`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getOrderType07 = async () => {
  try {
    const sql: any = `SELECT DISTINCT ENC_ORDER_TYPE FROM v_end_cust_ord_epa`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
