import styled from "@emotion/styled";
import { Box } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import { Theme } from "src/theme/type";

export const UIBox = styled(Box)(({ theme }: Theme) => ({
  "& .header": {
    backgroundColor: theme?.palette.primary.main,
    borderRadius: "10px",
    padding: 0,
    margin: "12px",
    width: "calc(100% - 24px)",
    minHeight: "40px",
    marginBottom: "0px",
    fontSize:"10px",
    zIndex: 1,
    "& p": {
      color: theme?.palette.text.primaryRev,
    },
  },
  "& .MuiGrid-item.body-container": {
    marginTop: "-15px",
    padding: "15px",
    paddingTop: "30px",
    backgroundColor: theme?.palette.background.paper,
    borderRadius: "10px",

  },
}));

export const AccordionUI = styled(Accordion)((props: any) => ({
  "& .MuiAccordionSummary-content": {
    margin: 0,
    padding: 0,
    // fontFamily: "Verdana", // Use theme font
    // fontSize: "7px", // Use theme font size 
  },
  "& .MuiAccordionDetails-root": {
    margin: 0,
    padding: `${props?.expanded && props?.title ? "10px" : 0}`,
    },
  "& .MuiButtonBase-root.MuiAccordionSummary-root": {
    minHeight: 0,
    borderRadius: "5px",
    color: "white",
  },
}));
