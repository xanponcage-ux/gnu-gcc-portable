import * as SPC0007Query from "../repository/SPC0007Query";
// const SPC0007Query = require("../repository/SPC0007Query");

export default class SPC0007Model {
  getData07(data: any) {
    return SPC0007Query.getData07(data);
  }
  getOrderId07() {
    return SPC0007Query.getOrderId07();
  }
  getEpa07() {
    return SPC0007Query.getEpa07();
  }
  getOrderStatus07() {
    return SPC0007Query.getOrderStatus07();
  }
  getCustomer07() {
    return SPC0007Query.getCustomer07();
  }
  getOrderType07() {
    return SPC0007Query.getOrderType07();
  }
}
