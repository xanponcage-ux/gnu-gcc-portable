import { Request, Response } from "express";
import QualityModel from "../models/qualityModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

// export const getData01 = async (req: Request, res: Response) => {
//   try {
//     const result1 = await QualityModel.prototype.getData01(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

export const getEpaData01 = async (req: Request, res: Response) => {
  try {
    const result1 = await QualityModel.prototype.getEpaCodeData01();
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

// export const SCQ001Api = async (req: Request, res: Response) => {
//   try {
//     // console.log("hi Controller", req.body);
//     const result1 = await QualityModel.prototype.SCQ001Modal(req.body);
//     if (
//       req.body?.route === "procedureCall" &&
//       result1?.outBinds?.ls_out_flag[0] === "N"
//     ) {
//       console.log("falied", result1);
//       return res.status(200).json(result1);
//     }
//     console.log("Next Step");
//     if (
//       req.body?.route === "procedureCall" &&
//       (req.body?.data?.p_radio_value === 8 ||
//         req.body?.data?.p_radio_value === 9)
//     ) {
//       console.log("Entered-");
//       for (let i in req.body?.data?.reasonData) {
//         let reasonValues = ["", ""];
//         reasonValues = req.body?.data?.reasonData[i]?.Column2.split("-");
//         let varData = {
//           route: "saveData",
//           p_plant: req.body?.data?.p_plant,
//           p_batch: req.body?.data?.p_batch,
//           p_curr_proc: req.body?.data?.p_curr_proc,
//           p_rsn_cd: reasonValues[0],
//           p_rsn_cat: req.body?.data?.reasonData[i]?.Column1,
//           p_rsn_desc: reasonValues[1],
//           p_scr_qty: req.body?.data?.reasonData[i]?.Column4,
//           ln_rsn: req.body?.data?.P_RADIO_VALUE === 8 ? "B" : "A",
//         };
//         console.log("test", varData);
//         console.log(await QualityModel.prototype.SCQ001Modal(varData));
//       }
//     }
//     // console.log("Final result", result1);
//     return res.status(200).json(result1);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const SCQ002Api = async (req: Request, res: Response) => {
//   try {
//     const result1 = await QualityModel.prototype.SCQ002Modal(req.body);
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };
