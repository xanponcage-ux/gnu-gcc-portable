import { Router } from "express";
import { getOrderProgData } from "../controllers/SPC0012Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0012Route = Router();

SPC0012Route.route("/SPC0012/getOrdProgData").post(
  authenticationMiddleware.bearer,
  getOrderProgData
);


export default SPC0012Route;