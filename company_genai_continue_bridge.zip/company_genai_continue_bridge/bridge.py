"""OpenAI-compatible localhost adapter for the Tata Steel OneIT GenAI gateway.

The adapter deliberately listens on loopback only. Company credentials are read
from environment variables and are never returned to the VS Code extension.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account
from pydantic import BaseModel, ConfigDict, Field


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
LOGGER = logging.getLogger("company-genai-bridge")


class Settings:
    api_key = os.getenv("TATA_GENAI_API_KEY", "").strip()
    adid = os.getenv("TATA_ADID", "").strip()
    credentials_file = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
    endpoint = os.getenv(
        "TATA_GENAI_ENDPOINT",
        "https://tslgenaiapidev.corp.tatasteel.com/genai",
    ).strip()
    auth_audience = os.getenv(
        "TATA_GENAI_AUTH_AUDIENCE",
        "https://genai-api-development-one-it-423929642383.asia-south1.run.app",
    ).strip()
    default_model = os.getenv("TATA_GENAI_MODEL", "gpt-4o-mini").strip()
    bridge_token = os.getenv("BRIDGE_LOCAL_TOKEN", "").strip()
    request_timeout = float(os.getenv("TATA_GENAI_TIMEOUT_SECONDS", "180"))
    verify_tls = os.getenv("TATA_GENAI_VERIFY_TLS", "true").lower() not in {
        "0",
        "false",
        "no",
    }
    ca_bundle = os.getenv("TATA_GENAI_CA_BUNDLE", "").strip()

    @classmethod
    def validate(cls) -> list[str]:
        missing = []
        for variable, value in (
            ("TATA_GENAI_API_KEY", cls.api_key),
            ("TATA_ADID", cls.adid),
            ("GOOGLE_APPLICATION_CREDENTIALS", cls.credentials_file),
            ("BRIDGE_LOCAL_TOKEN", cls.bridge_token),
        ):
            if not value or value.startswith("REPLACE_"):
                missing.append(variable)
        if cls.credentials_file and not Path(cls.credentials_file).expanduser().is_file():
            missing.append("GOOGLE_APPLICATION_CREDENTIALS (file not found)")
        return missing


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str | None = None
    messages: list[dict[str, Any]] = Field(default_factory=list)
    temperature: float | None = None
    max_tokens: int | None = None
    max_completion_tokens: int | None = None
    stream: bool = False
    tools: list[dict[str, Any]] | None = None
    tool_choice: Any | None = None


def _verify_local_token(authorization: str | None) -> None:
    expected = Settings.bridge_token
    if not expected:
        raise HTTPException(503, "BRIDGE_LOCAL_TOKEN is not configured")
    supplied = ""
    if authorization and authorization.lower().startswith("bearer "):
        supplied = authorization[7:].strip()
    if supplied != expected:
        raise HTTPException(401, "Invalid local bridge token")


def _normalise_content(content: Any) -> str:
    """Convert OpenAI text content into the gateway's accepted text form."""
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return json.dumps(content, ensure_ascii=False)
    parts: list[str] = []
    for item in content:
        if not isinstance(item, dict):
            parts.append(str(item))
        elif item.get("type") in {"text", "input_text"}:
            parts.append(str(item.get("text", "")))
        else:
            # The supplied company sample handles image uploads separately. Keep
            # unsupported multimodal blocks visible instead of silently losing them.
            parts.append(json.dumps(item, ensure_ascii=False))
    return "\n".join(part for part in parts if part)


def _normalise_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for message in messages:
        clean = dict(message)
        if "content" in clean:
            clean["content"] = _normalise_content(clean["content"])
        result.append(clean)
    return result


class GatewayClient:
    def __init__(self) -> None:
        creds = service_account.IDTokenCredentials.from_service_account_file(
            str(Path(Settings.credentials_file).expanduser()),
            target_audience=Settings.auth_audience,
        )
        self.session = AuthorizedSession(creds)

    def chat(self, request: ChatRequest) -> dict[str, Any]:
        model = request.model or Settings.default_model
        max_tokens = request.max_completion_tokens or request.max_tokens or 4096
        payload: dict[str, str] = {
            "deployment_name": model,
            "temperature": str(request.temperature if request.temperature is not None else 0.1),
            "adid": Settings.adid,
            "apikey": Settings.api_key,
            "messages": json.dumps(_normalise_messages(request.messages)),
            "grounding": "0",
            "max_tokens": str(max_tokens),
        }
        if request.tools:
            payload["tools"] = json.dumps(request.tools)
        if request.tool_choice is not None:
            payload["tool_choice"] = json.dumps(request.tool_choice)

        verify: bool | str = Settings.verify_tls
        if Settings.ca_bundle:
            verify = str(Path(Settings.ca_bundle).expanduser())

        response = self.session.post(
            Settings.endpoint,
            data=payload,
            timeout=Settings.request_timeout,
            verify=verify,
        )
        try:
            body = response.json()
        except ValueError as exc:
            raise RuntimeError(
                f"Gateway returned HTTP {response.status_code} with non-JSON content"
            ) from exc
        if not response.ok:
            # Avoid logging request headers or payload because they contain secrets.
            message = body.get("message") or body.get("detail") or str(body)
            raise RuntimeError(f"Gateway returned HTTP {response.status_code}: {message}")
        return _to_openai_response(body, model)


def _to_openai_response(body: dict[str, Any], model: str) -> dict[str, Any]:
    """Accept either GPT-style or Gemini-style gateway responses."""
    if isinstance(body.get("choices"), list):
        result = dict(body)
        result.setdefault("id", f"chatcmpl-{uuid.uuid4().hex}")
        result.setdefault("object", "chat.completion")
        result.setdefault("created", int(time.time()))
        result.setdefault("model", model)
        return result

    candidates = body.get("candidates") or []
    if not candidates:
        raise RuntimeError(f"Gateway response has no choices or candidates: {body}")

    candidate = candidates[0]
    parts = ((candidate.get("content") or {}).get("parts") or [])
    text_parts = [part.get("text", "") for part in parts if isinstance(part, dict)]
    content = "\n".join(part for part in text_parts if part)
    finish_reason = candidate.get("finish_reason") or candidate.get("finishReason") or "stop"
    usage = body.get("usage_metadata") or {}
    return {
        "id": body.get("response_id") or f"chatcmpl-{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": body.get("model_version") or model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": str(finish_reason).lower(),
            }
        ],
        "usage": {
            "prompt_tokens": usage.get("prompt_token_count", 0),
            "completion_tokens": usage.get("candidates_token_count", 0),
            "total_tokens": usage.get("total_token_count", 0),
        },
    }


def _sse_response(result: dict[str, Any]):
    """Emit a valid one-message OpenAI SSE stream.

    The company gateway itself is non-streaming, so the bridge returns one
    complete delta followed by [DONE].
    """
    choice = result["choices"][0]
    message = choice.get("message") or {}
    delta: dict[str, Any] = {"role": "assistant"}
    if message.get("content") is not None:
        delta["content"] = message.get("content")
    if message.get("tool_calls") is not None:
        delta["tool_calls"] = message.get("tool_calls")
    chunk = {
        "id": result["id"],
        "object": "chat.completion.chunk",
        "created": result["created"],
        "model": result["model"],
        "choices": [{"index": 0, "delta": delta, "finish_reason": None}],
    }
    yield f"data: {json.dumps(chunk)}\n\n"
    final_chunk = dict(chunk)
    final_chunk["choices"] = [
        {
            "index": 0,
            "delta": {},
            "finish_reason": choice.get("finish_reason") or "stop",
        }
    ]
    yield f"data: {json.dumps(final_chunk)}\n\n"
    yield "data: [DONE]\n\n"


app = FastAPI(title="Company GenAI Local Bridge", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["vscode-webview://*"],
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/health")
def health() -> dict[str, Any]:
    missing = Settings.validate()
    return {"status": "ok" if not missing else "configuration_required", "missing": missing}


@app.get("/v1/models")
def models(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    _verify_local_token(authorization)
    names = [Settings.default_model, "gpt-4o-mini", "gemini-2.0-flash"]
    unique_names = list(dict.fromkeys(name for name in names if name))
    return {
        "object": "list",
        "data": [
            {"id": name, "object": "model", "created": 0, "owned_by": "company"}
            for name in unique_names
        ],
    }


@app.post("/v1/chat/completions")
async def chat_completions(
    request: ChatRequest,
    authorization: str | None = Header(default=None),
):
    _verify_local_token(authorization)
    missing = Settings.validate()
    if missing:
        raise HTTPException(503, f"Missing or invalid configuration: {', '.join(missing)}")
    try:
        result = await asyncio.to_thread(GatewayClient().chat, request)
    except Exception as exc:
        LOGGER.exception("Gateway call failed (credentials and prompt are not logged)")
        return JSONResponse(
            status_code=502,
            content={
                "error": {
                    "message": str(exc),
                    "type": "gateway_error",
                    "code": "company_gateway_failure",
                }
            },
        )
    if request.stream:
        return StreamingResponse(_sse_response(result), media_type="text/event-stream")
    return result


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("bridge:app", host="127.0.0.1", port=8765, reload=False)
