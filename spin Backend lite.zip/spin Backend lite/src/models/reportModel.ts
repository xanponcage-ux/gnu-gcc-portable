const reportQuery = require("../repository/reportQuery");
const commonPlantQuery = require("../repository/plantQuery");

export default class reportModel {
  //   getPlantCode(data: any) {
  //     return commonPlantQuery.getCommonPlantData(data);
  //   }
  //   getReportType(data: any) {
  //     return reportQuery.getReportType(data);
  //   }
  //   getSourcePlant(data: any) {
  //     return reportQuery.getSourcePlant(data);
  //   }
  //   getTableData(data: any) {
  //     return reportQuery.getTableData(data);
  //   }
  //   getyieldwisedata(data: any) {
  //     return reportQuery.getyieldwisedata(data);
  //   }
  //   getSecondsData(data: any) {
  //     return reportQuery.getSecondsData(data);
  //   }
  //   getScrapData(data: any) {
  //     return reportQuery.getScrapData(data);
  //   }
  //   getEpa08() {
  //     return reportQuery.getEpa08();
  //   }
  //   getOrderData08() {
  //     return reportQuery.getOrderData08();
  //   }
  //   getNoEnd08() {
  //     return reportQuery.getNoEnd08();
  //   }
  //   getNoInp08() {
  //     return reportQuery.getNoInp08();
  //   }
  // getData08(data: any) {
  //     return reportQuery.getData08(data);
  // }
  // getInvData(data: any) {
  //     return reportQuery.getInvData(data);
  // }
  // getInvMonData(data: any) {
  //     return reportQuery.getInvMonData(data);
  // }
//   getData(data: any) {
//     return reportQuery.getData(data);
//   }
//   getDispatchData(data: any) {
//     return reportQuery.getDispatchData(data);
//   }
  //   getPlantData(data: any) {
  //     return reportQuery.getPlantData(data);
  //   }

  //   getBatchData(data: any) {
  //     return reportQuery.getBatchData(data);
  //   }

  //   getBatchData2(data: any) {
  //     return reportQuery.getBatchData2(data);
  //   }
  //   getInputCoilAudit(data: any) {
  //     return reportQuery.getInputCoilAudit(data);
  //   }

  //   getProductionAudit(data: any) {
  //     return reportQuery.getProductionAudit(data);
  //   }

  //   getCustOrdAudit(data: any) {
  //     return reportQuery.getCustOrdAudit(data);
  //   }
}
