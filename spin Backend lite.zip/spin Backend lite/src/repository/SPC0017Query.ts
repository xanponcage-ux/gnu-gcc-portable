import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";

export const getData = async (data: any) => {
  try {
    let sql: string = `
        SELECT CHR_ID_COIL BATCH_ID, EOM_CD_STATUS STATUS, EOM_MS_PIECE_ACTL NET_WT,
       CHR_TS_HOLD HOLD_DATE_TIME, CHR_CD_RSN_HOLD HOLD_CD,
       (SELECT CD_DESC
          FROM V_EPA_HOLD_RSN
         WHERE CD_HOLD = A.CHR_CD_RSN_HOLD AND ROWNUM = 1) HOLD_DESC,
       TO_CHAR (CHR_TS_HOLD, 'DD-MM-YYYY HH24:MI:SS') HOLD_DT,
       CHR_ID_OP_HOLD HOLD_BY, CHR_OPR_REMARKS HOLD_REM_BY_OPR,
       TO_CHAR (CHR_TS_RELEASE, 'DD-MM-YYYY HH24:MI:SS') RELEASE_DT,
       CHR_ID_OP_RELEASE RELEASE_BY, CHR_RLS_REMARKS RELEASE_REMARK,      
       EOM_TDC_ACTL, EOM_SEC1 THICK, EOM_SEC2 WIDTH, EOM_CD_PROD PROD_CD,
       EOM_CD_QLTY_ACTL QLTY_CD, EOM_ID_PAR_COIL_NO PARENT_BATCH, EOM_ID_FIRST_PAR MOTHER_BATCH,
       CHR_REMARKS CHR_REMARKS
  FROM V_COIL_HOLD_RLS A JOIN V_EPA_PRODN B ON A.CHR_ID_COIL = B.EOM_ID_BATCH
WHERE CHR_REMARKS = 'Downgraded'
    AND CHR_CD_RSN_HOLD NOT IN ('M01', 'L01')
`;

    // Add conditional filters
    console.log("SQL Query", sql);

    if (data.action_cd && data.action_cd?.length > 0) {
      sql += ` AND CHR_REMARKS = '${data?.action_cd}'`;
    }

    if (data.plant && data.plant?.length > 0) {
      sql += ` AND CHR_CD_EPA = '${data?.plant}'`;
    }

    if (data.batchId && data.batchId.length > 0) {
      sql += ` AND CHR_ID_COIL = '${data?.batchId}'`;
    }

    if (data.motherBatch && data.motherBatch.length > 0) {
      sql += ` AND EOM_ID_FIRST_PAR = '${data.motherBatch}'`;
    }

    if (data.status && data.status.length > 0) {
      sql += ` AND EOM_CD_STATUS = ${data?.status}`;
    }

    // // Add the subquery for latest hold date
    // sql += ` AND CHR_TS_HOLD = (
    //     SELECT MAX(CHR_TS_HOLD)
    //     FROM V_COIL_HOLD_RLS
    //     WHERE CHR_CD_EPA = '${data.plant || '131'}'
    //     AND CHR_ID_COIL = A.CHR_ID_COIL
    //     AND CHR_REMARKS = 'Downgraded'
    //     AND CHR_CD_RSN_HOLD NOT IN ('M01', 'L01')
    //   ) ORDER BY CHR_TS_HOLD DESC`;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getStatusData = async (data: any) => {
  try {
    const sql = `
      SELECT DISTINCT EOM_CD_STATUS AS STATUS 
      FROM V_EPA_PRODN 
      WHERE EOM_CD_STATUS IS NOT NULL
      ORDER BY EOM_CD_STATUS`;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
