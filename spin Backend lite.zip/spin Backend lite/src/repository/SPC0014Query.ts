import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";

export const getData = async (data: any) => {
  try {
    let sql: string = `SELECT   TIMESTAMP timedt, werks plant, lgort LOCATION, charg fg_batch,
         matnr fg_material, fg_qty net_wt, moth_batch parent_batch,
         moth_matnr parent_material, status status, error_cd err_remarks,
         l_sco_no, l_sco_item_no, passed_proc, pack_cd, oil_type,
         sco_order sco_order, sco_item sco_item, budat budat, pcode fg_pcode,
         qcode fg_qcode, sec1 fg_thk, sec2 fg_width, LENGTH fg_length,
         no_pcs no_of_pcs, cast_no cast_no, idia, odia, tdcno fg_tdc,
         scrp_matnr, cust_order, cust_item, source_plant, stage_cd,
         action_cd rec_type, pi_status, ack_timestamp pi_ack_time,
         final_timestamp final_time, pi_source_pgm, prc1, prc2, prc3, prc4, prc5,
         prc6, prc7, prc8, prc9, prc10,
         grs_qty, 
         scr_qty, 
         cs_indicator, 
         sco_rate, 
         pi_ib_message_id, 
         pi_ob_message_id, 
         creation_timestamp, 
         pick_timestamp
         FROM ymsdt_sco_grn
         WHERE mandt = '600' 
         AND STATUS NOT IN ('X', 'L') `;

    // Add conditional filters
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` and charg = '${data.batchId}'`;
    }

    if (data.motherBatch && data.motherBatch?.length > 0) {
      sql += ` and moth_batch = '${data.motherBatch}'`;
    }

    if (data.action_cd && data.action_cd?.length > 0) {
      sql += ` and action_cd='${data?.action_cd}'`;
      // action_cd = 'S' --'I'      -- FG , S= SCRAP , REVERSAL -R
    }

    if (data.status && data.status?.length > 0) {
      sql += ` and status='${data?.status}'`;
    }

    // if (data?.dateFrom && data?.dateTo) {
    //   sql += `and TO_DATE(SUBSTR(timestamp, 1, 10), 'YYYY-MM-DD')
    //   BETWEEN TO_DATE('${data?.dateFrom}', 'YYYY-MM-DD') AND TO_DATE('${data?.dateTo}', 'YYYY-MM-DD')  `;
    //   binds.dateFrom = data?.dateFrom;
    //   binds.dateTo = data?.dateTo;
    // }

    sql += ` ORDER BY TIMESTAMP desc, moth_batch `;
    console.log("sql: ", sql);

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getStatusData = async (data: any) => {
  try {
    let sql: any = ` SELECT DISTINCT STATUS FROM YMSDT_SCO_GRN WHERE STATUS NOT IN ('X', 'L') `;

    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
