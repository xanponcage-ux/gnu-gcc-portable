const SCQ001Query = require("../repository/SCQ001Query");
import {
  SCQ001GetFilterData,
  SCQ001GetData,
  SCQ001SaveData,
  SCQ001GetPopUpData,
  SCQ001DiversionRes,
} from "../repository/SCQ001Query";

export default class SCQ001Model {
  SCQ001GetFilterData(data: any) {
    return SCQ001GetFilterData(data);
  }
  SCQ001GetData(data: any) {
    return SCQ001GetData(data);
  }
  SCQ001SaveData(data: any) {
    return SCQ001SaveData(data);
  }
  SCQ001Api(data: any) {
    return SCQ001GetPopUpData(data);
  }
  SCQ001DiversionRes(data: any) {
    return SCQ001DiversionRes(data);
  }
}
