import { Router } from "express";
import { piechart1,piechart2,linegraph1,linegraph2 } from "../controllers/DashboardController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const DashboardRoute = Router();

DashboardRoute.route("/Dashboard/piechart1").get(
  authenticationMiddleware.bearer,
  piechart1
);

DashboardRoute.route("/Dashboard/piechart2").get(
  authenticationMiddleware.bearer,
  piechart2
);

DashboardRoute.route("/Dashboard/linegraph1").get(
  authenticationMiddleware.bearer,
  linegraph1
);

DashboardRoute.route("/Dashboard/linegraph2").get(
  authenticationMiddleware.bearer,
  linegraph2
);

export default DashboardRoute;
