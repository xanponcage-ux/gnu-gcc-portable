import { Router } from "express";
import {
  //   savePackingOiling,
  //   SPC0003getData03,
  //   SPC0004getData04,
  //   getData06,
  //   getEpaCode06,
  //   callProcedure06,
  getPlantData,
  // getData02
} from "../controllers/maintainMasterController";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const masterRoute = Router();

// - THESE ROUTES DECLARED IN COMMON ROUTES FILES
// masterRoute.route('/maintainmaster/getData').post(authenticationMiddleware.bearer, getData02);
masterRoute
  .route("/maintainmaster/getPlantData")
  .get(authenticationMiddleware.bearer, getPlantData);
//page -- 3
// masterRoute
//   .route("/maintainmaster/savePackingOiling")
//   .post(authenticationMiddleware.bearer, savePackingOiling);
// masterRoute
//   .route("/maintainmaster/getcodingData")
//   .post(authenticationMiddleware.bearer, SPC0003getData03);
//page -- 4
// masterRoute
//   .route("/maintainmaster/getcoding_02_Data")
//   .post(authenticationMiddleware.bearer, SPC0004getData04);
// masterRoute
//   .route("/maintainmaster/getData06")
//   .post(authenticationMiddleware.bearer, getData06);
// masterRoute
//   .route("/maintainmaster/getEpaCode06")
//   .get(authenticationMiddleware.bearer, getEpaCode06);
// masterRoute
//   .route("/maintainmaster/procedure06")
//   .post(authenticationMiddleware.bearer, callProcedure06);

export default masterRoute;
