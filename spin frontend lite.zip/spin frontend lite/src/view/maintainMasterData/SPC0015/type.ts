export interface InputDownType {
    key1: string,
    key2: string,
    key3: string,
    key4: string,
    key5: string,
    key6: string,
    key7: string,
    key8: string,
    key9: string,
}


export interface TableType {
    SSM_CD_EPA: string;    
    SSM_SUBRANGE_CD: string;  
    SSM_SUBRANGE_DESC: string;
    SSM_CD_STATUS: string;
    SSM_CRT_DT: string;
    SSM_CRT_BY: string;
    SSM_UPD_DT: string;
    SSM_UPD_BY: string;
}
