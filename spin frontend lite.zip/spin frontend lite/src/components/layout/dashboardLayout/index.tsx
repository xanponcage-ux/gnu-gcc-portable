import DefaultNavbar from './DefaultNavbar'
import { DashboardProps } from './type';

function DashboardLayout(props: DashboardProps) {

    return (
        <DefaultNavbar>
            {props.children}
        </DefaultNavbar>
    );
}
export default DashboardLayout;