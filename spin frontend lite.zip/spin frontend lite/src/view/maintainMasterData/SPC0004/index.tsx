import React from "react";
import DashboardLayout from "src/components/layout/dashboardLayout";
import Tabulator from "src/components/table";
import TableContainer from "src/components/tableContainer";
import { Input, RadioInput, SelectInput } from "src/components/input";
import { CulmnType } from "src/type";
import alertify from "src/components/alert";
import { useMaterialUIController } from "src/context";
import { DateFormat } from "src/utils";
import { GetAuthorization } from "src/utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
  iconButtonClasses,
} from "@mui/material";
import LibraryAddIcon from "@mui/icons-material/LibraryAdd";
import DeleteIcon from "@mui/icons-material/Delete";
import CreateIcon from "@mui/icons-material/Create";
import {
  SPC0004GetDataApi,
  // SPC001GetPlantData,
  GetPlantDataApi,
} from "src/apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "src/components/preloader";
import { SelectType } from "src/components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "src/theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "src/components/input";
import ButtonElement from "src/components/button";
import { TokenType } from "src/type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import { ColumnDefinition } from "tabulator-tables";
import Auth from "../../../components/layout/dashboardLayout/auth";

const formatDate = (date: any) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const M_SPC0004 = () => {
  const csTheme: csTheme = useTheme();
  //user id
  const [controller, dispatch] = useMaterialUIController();
  const { user } = controller;
  //
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [isEditable, setIsEditable] = React.useState<boolean>(false);

  const [value, setValue] = React.useState<number>(0);

  const column: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      headerSort: false,
      // cellClick:(e:any,cell:any)=>{
      //   const row = cell.getRow();
      //   const isChecked=row.getData().editable;
      //   row.update({editable:!isChecked});
      // }
    },
    {
      title: "Plant",
      field: "TYR_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "integer",
      editorParams: {
        elementAttributes: {
          maxlength: "3",
        },
      },

      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
        return value;
      },
    },
    {
      title: "TYR_APP Group",
      field: "TYR_APP_GRP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "string",

      cellEdited: function (cell: any) {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "P.NO",
      field: "TYR_PNO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "integer",
      editorParams: {
        elementAttributes: {
          maxlength: "6",
        },
      },
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },

    {
      title: "Name",
      field: "TYR_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "string",
      cellEdited: function (cell: any) {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Email",
      field: "TYR_EMAIL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Tell. No",
      field: "TYR_TELNO",
      validator: "integer",
      headerFilter: "input",
      editor: isEditable ? "input" : true,
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editorParams: {
        elementAttributes: {
          maxlength: "10",
        },
      },

      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Created ID",
      field: "TYR_CRT_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Created On",
      field: "TYR_CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Updated ID",
      field: "TYR_UPD_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Updated On",
      field: "TYR_UPD_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Active Status",
      field: "TYR_ACT_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
      hozAlign: "center",
      editorParams: {
        elementAttributes: {
          maxlength: "1",
        },
      },
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Mark Customer",
      field: "TYR_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
    },
  ];

  const pathColumn: Array<CulmnType> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      headerSort: false,
    },
    {
      title: "Plant",
      field: "EYM_CD_EPA",
      headerFilter: "input",
      frozen: true,
      width: 150,
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "integer",
      editorParams: {
        elementAttributes: {
          maxlength: "3",
        },
      },
      cellEdited: (cell: any) => {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Category",
      field: "EYM_CATEGORY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "number" : true,
      validator: "integer",
      editorParams: {
        elementAttributes: {
          maxlength: "6",
        },
      },

      cellEdited: (cell: any) => {
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },
    {
      title: "Category Type",
      field: "EYM_CAT_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
      validator: "letter",
      editorParams: {
        elementAttributes: {
          maxlength: "4",
        },
      },
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
        let row = cell.getRow();
        const data = row.getData();
        data.TPM_UPD_ID = user; // Set updated by as user
        data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        data.TOM_UPD_ID = user; // Set updated by as user
        data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
        row.update(data);
      },
    },

    {
      title: "Yield",
      field: "EYM_YIELD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
      validator: "integer",
      hozAlign: "center",
      editorParams: {
        elementAttributes: {
          maxlength: "5",
        },
      },
      cellEdited: (cell: any) => {
        const value = cell.getValue().toUpperCase();
        cell.setValue(value);
      },
    },
    {
      title: "No_matnir",
      field: "EYM_NO_MATNR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Matnr_code",
      field: "EYM_MATNR_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Process Seq",
      field: "EYM_PRC_SEQ",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "center",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Process",
      field: "EYM_PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order From",
      field: "EYM_OD_FROM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Order to",
      field: "EYM_OD_TO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },

    {
      title: "Section from",
      field: "EYM_SEC3_FROM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Section To",
      field: "EYM_SEC3_TO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Eym_idia",
      field: "EYM_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Remark",
      field: "EYM_REMARK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "EYM_PROD",
      field: "EYM_PROD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "EYM_TDC_REM",
      field: "EYM_TDC_REM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "Grade",
      field: "EYM_GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
    {
      title: "QUALITY",
      field: "EYM_QLTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      editor: isEditable ? "input" : true,
    },
  ];

  

  // 

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    setSelectedCode("");
    setSelectedProcess("");
    fetchEpaData();
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    console.log(tableData);

    if (tableData?.length > 0) {
      let varTable = new Tabulator("#table", {
        data: tableData,
        columns: value === 0 ? column : pathColumn,
        height: 600,
        layout: "fitDataFill",
      });
      varTable.on("rowSelected", function (row) {
        console.log(row);
        const data = row.getData();

        data.editable = !data.editable;
        if (data.editable) {
          //if(cell.getValue())
          data.TPM_UPD_ID = user; // Set updated by as user
          data.TPM_UPD_DT = formatDate(new Date()); // Set updated on as current date
          data.TOM_UPD_ID = user; // Set updated by as user
          data.TOM_UPD_DT = formatDate(new Date()); // Set updated on as current date
          row.update(data); // Update the row
        }
      });
      setTable(varTable);
    } else {
      setTable(null);
    }
  }, [tableData, isEditable]);


  const fetchEpaData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlantCodeData(varData);
            setSelectedCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data: any) => {
    console.log("j=hi");
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0004GetDataApi(token, {
        data: data,
        process: selectedProcess,

        code: selectedCode?.split(" - ")[0],
      })
        .then((res: any) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (data === 0) {
              setTableData(res.data?.X); // PackingCode
            } else {
              setTableData(res.data?.Y);
            }
          }
        })
        .catch((e: any) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something went wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  //

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    const fileName =
      value === 0 ? "SPC0003_Packing_Code.xlsx" : "SPC0003_Oiling_Code.xlsx";

    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const Delete = () => {
    if (tableData.length === 0) {
      alertify.error("No data to delete");
      return;
    }
    const selectedRows = table.getSelectedRows();
    if (selectedRows.length > 0) {
      selectedRows.forEach((row: any) => {
        row.delete();
      });
      alertify.success(`${selectedRows.length} rows deleted`);
    } else {
      alertify.error("No row selected");
    }
  };

  const Edit = () => {
    setIsEditable(true);
    alertify.success("Edit mode enabled. You can now edit the table.");
  };

  const Add = () => {
    // Edit();
    setIsEditable(true);
    const date = formatDate(new Date());
    let arr = [...tableData];
    arr.push({
      TPM_CD_EPA: "",
      TPM_MARK_CUST: "",
      TPM_PACK_SEQ: "",
      TPM_PACK_CD: "",
      TPM_CRT_ID: user,
      CRT_DT: date,
      TOM_CRT_ID: user,
      TOM_CRT_DT: date,
      TPM_UPD_ID: "",
      TPM_UPD_DT: "",
    });
    setTableData(arr);
  };

  const Save = () => {
    setIsEditable(false);
    alertify.success("Saved successfully!");
  };

  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setTableData([]);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={10}>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <SelectInput
                        label="Plant*"
                        data={plantCodeData}
                        id={"id"}
                        value={selectedCode}
                        size={"small"}
                        onChange={(e: string) => {
                          setSelectedCode(e);
                        }}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <ButtonElement onClick={() => fetchData(value)}>
                        Search
                      </ButtonElement>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <>
                  <Tooltip title="Add">
                    <IconButton onClick={Add} disabled={restricted !== "RL_RW"}>
                      <LibraryAddIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  {/* <Tooltip title="Edit">
                  <IconButton onClick={}>
                    <CreateIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip> */}
                  <Tooltip title="Save">
                    <IconButton
                      onClick={Save}
                      disabled={restricted !== "RL_RW"}
                    >
                      <SaveIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton
                      onClick={Delete}
                      disabled={restricted !== "RL_RW"}
                    >
                      <DeleteIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Download">
                    <IconButton onClick={downloadExcel}>
                      <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                </>
              }
            >
              <Box sx={{ width: "100%" }}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Yield Approver" />
                    <Tab label="Yield Master" />
                  </Tabs>
                </Box>
                {value === 0 && tableData?.length > 0 && <div id="table"></div>}
                {value === 1 && tableData?.length > 0 && <div id="table"></div>}
              </Box>
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default M_SPC0004;
