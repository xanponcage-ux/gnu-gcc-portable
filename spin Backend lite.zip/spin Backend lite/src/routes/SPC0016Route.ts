import { Router } from "express";
import { getData, getStatusData } from "../controllers/SPC0016Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPC0016Route = Router();

SPC0016Route.route("/SPC0016/getData").post(
  authenticationMiddleware.bearer,
  getData
);

SPC0016Route.route("/SPC0016/getStatusData").get(
  authenticationMiddleware.bearer,
  getStatusData
);

export default SPC0016Route;
