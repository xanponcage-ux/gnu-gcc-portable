/* ------ PRODUCTION REPORT SCREEN INSIDE OPERATION --------*/

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, SelectInput } from "../../../components/input";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Box, Tooltip } from "@mui/material";
import {
  SPO0001GetDataApi,
  SPO0001GetProdDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { setTheme, useMaterialUIController } from "../../../context";
import { TableType, InputChangeType } from "./type";
import { FormType } from "../../../view/auth/type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPO0001 = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [table1, setTable1] = React.useState<any>(null);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedCode, setSelectedCode] = React.useState<any>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [tableData, setTableData] = React.useState<any>([]);
  const [processData, setProcessData] = React.useState<Array<SelectType>>([]);
  const [selectedProcess, setSelectedProcess] = React.useState<any>("");
  const [selectedMBatch, setSelectedMBatch] = React.useState<any>("");
  const [restricted, setRestricted] = React.useState(null);
  const [order, setOrder] = React.useState<any>("");
  const [item, setItem] = React.useState<any>("");
  const [batchId, setBatchId] = React.useState<any>("");

  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setSelectedMBatch("");
    setProcessData([]);
    setTableData([]);
    setInputObj(varInput);
  };

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "Material No",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "Production From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
    key3: {
      config: {
        type: "input",
        label: "Production To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key3"),
    },
  };
  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    let columns: any;
    if (tableData?.length > 0) {
      if (selectedProcess === "S") {
        columns = column;
      } else if (selectedProcess === "K") {
        columns = column3;
      } else {
        columns = column2;
      }
      setTable(
        new Tabulator("#table1", {
          data: tableData,
          columns: columns,
          height: 400,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [20, 40, 60, 80],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
    return () => {
      table?.destroy();
    };
  }, [tableData]);

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0001GetDataApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcessData(varprocessData);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = () => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    if (!(selectedProcess?.length > 0)) {
      alertify.error("Please select Process!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPO0001GetProdDataApi(token, {
        type: "prodData",
        plant: selectedCode,
        process: selectedProcess ? selectedProcess : "",
        batchId: batchId ? batchId : "",
        mBatch: selectedMBatch,
        prodDateFrom: DateFormat(inputObj.key2.value),
        prodDateTo: DateFormat(inputObj.key3.value),
        order: order ? order : "",
        item: item ? item : "",
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length > 0) {
              setTableData(res.data);
            } else {
              setTableData([]);
              alertify.error("No data found");
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // Columns for SLIT
  const column: any = [
    // {
    //   formatter: "rowSelection",
    //   hozAlign: "center",
    //   frozen: true,
    //   headerSort: false,
    //   title: "",
    //   selectable: true,
    // },
    {
      title: "Batch Id",
      field: "ID_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Parent Batch",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   title: "Parent Batch",
    //   field: "PARENT_BATCH",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      field: "Grade",
      title: "Grade",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Aim TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Actl TDC",
      field: "ACTL_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "FG Width",
      field: "BATCH_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "BATCH_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Gross Wt",
      field: "GROSS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "No Pcs",
      field: "NO_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Edge",
      field: "ORDER_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Slit Position",
      field: "SLIT_POS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Curr Proc",
      field: "CURR_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Next Proc",
      field: "NEXT_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Planned Proc",
      field: "PLANNED_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Actual Proc",
      field: "ACTUAL_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Part No",
      field: "PART_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Id",
      field: "ORD_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ORD_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Mark Cust Code",
      field: "MARK_CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Name",
      field: "CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Code",
      field: "CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ship To Party Cd",
      field: "SHIP_TO_PARTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Ship To Party",
      field: "SHIP_TO_PARTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Road dest Cd",
      field: "ROAD_DEST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Road Dest Desc",
      field: "ROAD_DEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail dest Cd",
      field: "RAIL_DEST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Rail Dest Desc",
      field: "RAIL_DEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "ID PDI",
      field: "ID_PDI",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sched Id",
      field: "ID_SCHEDULE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Oil Type",
      field: "OILTYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Oil Min Qty",
      field: "OILMINQTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Pack Code",
      field: "PACK_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Date",
      field: "PROD_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Shift",
      field: "SHIFT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Type",
      field: "ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Sco Order",
      field: "SCO_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sco Item",
      field: "SCO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "LYS",
      field: "LYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Elongation",
      field: "ELONG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Prod Start Time",
      field: "BATCHSTART",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod End Time",
      field: "BATCHEND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Packing Start Time",
      field: "PROCSTART",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Packing End Time",
      field: "PROCEND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Max Speed",
      field: "MAXSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Avg Speed",
      field: "AVGSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "RECOILERTENSION",
      field: "RECOILERTENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    ,
    {
      title: "RECOILERTAPER",
      field: "RECOILERTAPER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Remarks",
      field: "REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SLP Remarks",
      field: "SLP_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cust Desc",
      field: "CUST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Flag",
      field: "HOLD_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Code",
      field: "HOLD_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Hold Desc",
      field: "HOLD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade Desc",
      field: "GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Trim",
      field: "TRIM1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Edge Waviness",
      field: "EDGE_WAVINESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Centre Buckle",
      field: "CENTRE_BUCKLE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Cross BOW",
      field: "CROSSBOW",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Bur Height",
      field: "BURR_HEIGHT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Surf Seq",
      field: "SURF_SEQ",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Horizontal Gap",
      field: "HORIZONTAL_GAP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Vertical Gap",
      field: "VERTICAL_GAP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width Total",
      field: "WIDTH_TOTAL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Oil Type",
      field: "OIL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cal Mass",
      field: "CAL_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Oil Max Qty",
      field: "OILMAXQTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actl Slit Width",
      field: "SLIT_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actl Thick",
      field: "ACTUAL_THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actl Idia",
      field: "ACTUAL_IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Coil Edge Cond",
      field: "COIL_EDGE_COND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "TELESCOPICITY",
      field: "TELESCOPICITY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Zig Zag Wind",
      field: "ZIG_ZAG_WIND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cutter Mark",
      field: "CUTTER_MARK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Oil Condition",
      field: "OIL_CON",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "NO Slit",
      field: "NO_SLIT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Load Date",
      field: "LOAD_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Net Wt",
      field: "MOTHER_NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Mother Width",
      field: "MOTHER_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Mother Thick",
      field: "MOTHER_THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "No Cuts",
      field: "NO_CUTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Total Time",
      field: "TOT_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Run Time",
      field: "RUN_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Setup Time",
      field: "SETUP_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Stop Time",
      field: "STOP_TIME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Scrap Pup Coil",
      field: "SCRAP_PUP_COIL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Uncoiler Pressure",
      field: "UNCOIL_PRES",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Pres In Tension Unit",
      field: "PRES_TEN_UNIT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Uncoiler Back Tension",
      field: "UNCOIL_BACK_TEN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Cut Set Used",
      field: "CUT_SET_USED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mcoil Uncoil Dir",
      field: "MCOIL_UNCOIL_DIR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },

    {
      title: "Centering Rolls Position (mm)",
      field: "CENTERING_ROLLS_POSITION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Feeding Roll #2 Torque (%)",
      field: "FEEDING_ROLL_TORQUE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Deburring Rolls Actual Penetration (mm)",
      field: "DEBURRING_ROLLS_ACTUAL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Deburring Rolls Unit Tension (N/mm2)",
      field: "DEBURRING_ROLLS_UNIT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Deburring Rolls Overspeed (%)",
      field: "DEBURRING_ROLLS_OVERSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Scrap Chopper Overspeed (%)",
      field: "SCRAP_CHOPPER_OVERSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Scrap Chopper Rolls Overspeed (%)",
      field: "SCRAP_CHOPPER_ROLLS_OVERSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Slitter Overspeed (%)",
      field: "SLITTER_OVERSPEED",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Position (mm)",
      field: "TENSION_BRIDLE_ROLL_#1_POSITION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Position (mm)",
      field: "TENSION_BRIDLE_ROLL_#2_POSITION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Position (mm)",
      field: "TENSION_BRIDLE_ROLL_#3_POSITION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Penetration (mm)",
      field: "TENSION_BRIDLE_ROLL_#1_PENETRATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Penetration (mm)",
      field: "TENSION_BRIDLE_ROLL_#2_PENETRATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Penetration (mm)",
      field: "TENSION_BRIDLE_ROLL_#3_PENETRATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Set Pressure %",
      field: "TENSION_BRIDLE_ROLL_#1_SET_PRESSURE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Set Pressure %",
      field: "TENSION_BRIDLE_ROLL_#2_SET_PRESSURE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Set Pressure %",
      field: "TENSION_BRIDLE_ROLL_#3_SET_PRESSURE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Load Factor %",
      field: "TENSION_BRIDLE_ROLL_#1_LOAD_FACTOR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Load Factor %",
      field: "TENSION_BRIDLE_ROLL_#2_LOAD_FACTOR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Load Factor %",
      field: "TENSION_BRIDLE_ROLL_#3_LOAD_FACTOR",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Set Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#1_SET_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Set Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#2_SET_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Set Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#3_SET_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #1 Actual Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#1_ACTUAL_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #2 Actual Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#2_ACTUAL_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Tension Bridle Roll #3 Actual Tension (dN)",
      field: "TENSION_BRIDLE_ROLL_#3_ACTUAL_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Deflector Roll Position (mm)",
      field: "DEFLECTOR_ROLL_POSITION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Recoiler Actual Unit Tension (N/mm²)",
      field: "RECOILER_ACTUAL_UNIT_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Recoiler Unit Applied Tension (dN)",
      field: "RECOILER_UNIT_APPLIED_TENSION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Recoiler Unit Taper Diameter (mm)",
      field: "RECOILER_UNIT_TAPER_DIAMETER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Feeding Car Distance (mm)",
      field: "FEEDING_CAR_DISTANCE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Recoiler Separators Penetration (mm)",
      field: "RECOILER_SEPARATORS_PENETRATION",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Intended Cust",
      field: "INP_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Intended Cust Cd",
      field: "INP_CUSTOMER_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  //Columns for CTL
  const column2: any = [
    {
      title: "Batch Id",
      field: "ID_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Parent Batch",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Mother Batch",
      field: "MOTHER_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Qlty Cd",
      field: "QLTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Aim TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Actl TDC",
      field: "ACTL_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "FG Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "FG Width",
      field: "BATCH_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Length",
      field: "BATCH_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
    },
    {
      title: "Gross Wt",
      field: "GROSS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "No Pcs",
      field: "NO_PCS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Order Edge",
      field: "ORDER_EDGE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Flag",
      field: "HOLD_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Code",
      field: "HOLD_CODE",
      headerFilter: "input",
      hozAlign: "right",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Desc",
      field: "HOLD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Curr Proc",
      field: "CURR_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Next Proc",
      field: "NEXT_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Planned Proc",
      field: "PLANNED_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Actual Proc",
      field: "ACTUAL_PROC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order",
      field: "ORD_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Item",
      field: "ORD_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Code",
      field: "MARK_CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Name",
      field: "CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Cust Code",
      field: "CUST_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Road Dest Cd",
      field: "ROAD_DEST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Road Dest Desc",
      field: "ROAD_DEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rail Dest Cd",
      field: "RAIL_DEST_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Rail Dest Desc",
      field: "RAIL_DEST_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship To Party",
      field: "SHIP_TO_PARTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Ship To Party Cd",
      field: "SHIP_TO_PARTY_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "ID PDI",
      field: "ID_PDI",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sched Id",
      field: "ID_SCHEDULE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Oil Type",
      field: "OIL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pack Code",
      field: "PACK_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Date",
      field: "PROD_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Order Type",
      field: "ORDER_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Shift",
      field: "SHIFT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Sco Order",
      field: "SCO_ORDER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Sco Item",
      field: "SCO_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "LYS",
      field: "LYS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "UTS",
      field: "UTS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Elongation",
      field: "ELONG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Prod Start Date",
      field: "BATCHSTART",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod End Date",
      field: "BATCHEND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Remarks",
      field: "REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "SLP Remarks",
      field: "SLP_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    // {
    //   title: "Cust Desc",
    //   field: "CUST_DESC",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Grade Desc",
      field: "GRADE_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Trim",
      field: "TRIM1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   title: "Parent Batch",
    //   field: "PARENT_BATCH",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Intended Cust",
      field: "INP_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Intended Cust Cd",
      field: "INP_CUSTOMER_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const column3: any = [
    {
      title: "Batch Id",
      field: "ID_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "ID PDI",
      field: "ID_PDI",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Start Date",
      field: "PROCSTART",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod End Date",
      field: "PROCEND",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },

    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Net Wt",
      field: "NET_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Gross Wt",
      field: "GROSS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      hozAlign: "right",
    },
    {
      title: "Thick",
      field: "THICK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Width",
      field: "BATCH_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Length",
      field: "BATCH_LENGTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell?.getValue()?.toFixed(3);
        return value;
      },
    },
    {
      title: "Order",
      field: "ORD_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Item",
      field: "ORD_ITEM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Odia",
      field: "ODIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pkg Dt",
      field: "PKG_DATE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Shift",
      field: "SHIFT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Create Dt",
      field: "CRT_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Create By",
      field: "CRT_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Pack Code",
      field: "PACK_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const downloadExcel = (name: string, data: any, tbl: any) => {
    if (data?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = name + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2.5}>
                      <Grid item xs={2.25}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            fetchEpaData(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Process*"
                          data={processData}
                          value={selectedProcess}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProcess(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={4}>
                        <Grid container spacing={2}>
                          {formData.map(
                            (x: FormType, i: number) =>
                              i >= 1 &&
                              i < 3 && (
                                <Grid item key={x?.key} xs={6}>
                                  <DatePickerInput
                                    id={x?.key}
                                    value={
                                      x?.data?.value?.length > 0
                                        ? x?.data?.value
                                        : null
                                    }
                                    {...x?.data?.config}
                                    // onChange={x?.data?.onChange}
                                    onChange={(e: string) => {
                                      if (x?.data?.onChange) {
                                        x.data.onChange(e);
                                      }
                                      setTableData([]);
                                    }}
                                  />
                                </Grid>
                              )
                          )}
                        </Grid>
                      </Grid>
                      <Grid item xs={2}>
                        <Input
                          id={"BatchId"}
                          value={batchId}
                          label="Batch Id"
                          size={"small"}
                          onChange={(e: string) => {
                            setBatchId(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Input
                          id={"MBatch"}
                          value={selectedMBatch}
                          label="MBatch"
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedMBatch(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Input
                          id={"Order"}
                          value={order}
                          label="Order"
                          size={"small"}
                          onChange={(e: string) => {
                            setOrder(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Input
                          id={"Item"}
                          value={item}
                          label="Item"
                          size={"small"}
                          onChange={(e: string) => {
                            setItem(e);
                            setTableData([]);
                          }}
                        />
                      </Grid>
                      {/* <Grid item xs={2}>
                      <SelectInput
                        label="Planned Path"
                        data={plannedPathData}
                        value={plannedPath}
                        size={"small"}
                        onChange={(e: string) => setPlannedPath(e)}
                      />
                    </Grid> */}

                      <Grid item xs={1.5}>
                        <ButtonElement onClick={() => fetchData()}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title={"Production Details"}
                headerContainer={
                  <Grid container>
                    {/* <Grid item>
                    <Tooltip title={"Delete Scheduling"}>
                      <IconButton
                        onClick={() => {
                          handleDeleteClick();
                        }}
                      >
                        <DeleteIcon sx={{ color: "#ffffff" }} />
                      </IconButton>
                    </Tooltip>
                  </Grid> */}
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton
                          onClick={() =>
                            downloadExcel(
                              "Production Details",
                              tableData,
                              table1
                            )
                          }
                        >
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {tableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table1"></div>
                        <br />
                        {/* <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {tableData?.length} of{" "}
                          {tableData?.length} entries
                        </p> */}
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPO0001;
