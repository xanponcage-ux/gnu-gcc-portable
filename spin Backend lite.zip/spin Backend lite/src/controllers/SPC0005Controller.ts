import { Request, Response } from "express";
import SPC0005Model from "../models/SPC0005Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData05 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    let result3;
    if (req.body.data === 0) {
      result1 = await SPC0005Model.prototype.getSpecLimit05(req.body);
    }
    if (req.body.data === 1) {
      result2 = await SPC0005Model.prototype.getQualityData05(req.body);
    }
    if (req.body.data === 2) {
      result3 = await SPC0005Model.prototype.getTdcMain05(req.body);
    }
    varData = {
      ...{ specLimit: await ResponceData(result1) },
      ...{ tdcQlty: await ResponceData(result2) },
      ...{ tdcMain: await ResponceData(result3) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const getTdcCode05 = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0005Model.prototype.getTdcCode05();
    const result2 = await SPC0005Model.prototype.getQltyCode05();
    const result3 = await SPC0005Model.prototype.getTdcMainCode05();
    const varData = {
      tdc: await ResponceData(result1),
      tdcMain: await ResponceData(result3),
      qlty: await ResponceData(result2),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
