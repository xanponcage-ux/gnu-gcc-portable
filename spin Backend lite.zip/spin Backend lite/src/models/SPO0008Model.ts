import * as repository from "../repository/SPO0008Query";

export default class SPO0007Model {
  getTroubleType() {
    return repository.getTroubleType();
  }
  eqpMast() {
    return repository.EqpMastQuery();
  }
  eqpCode() {
    return repository.EqpCodeQuery();
  }
  getAgencyList() {
    return repository.agencyCodeQuery();
  }
  delUsr(usr: any) {
    return repository.delUser(usr);
  }
  facCode() {
    return repository.FacCodeQuery();
  }
  delay(
    fao_tm_stop_st: any,
    fao_tm_stop_en: any,
    fao_cd_process: any,
    FAO_CD_SH_OUTAGE: any,
    fao_cd_eqp_mast: any,
    fao_cd_fac_mast: any,
    FAO_CD_TRBL_TYP: any,
    process: any
  ) {
    return repository.delayDataQuery(
      fao_tm_stop_st,
      fao_tm_stop_en,
      fao_cd_process,
      FAO_CD_SH_OUTAGE,
      fao_cd_eqp_mast,
      fao_cd_fac_mast,
      FAO_CD_TRBL_TYP,
      process
    );
  }
  reason() {
    return repository.getRsnQuery();
  }
  eqpFac(tom_cd_outage: any, tom_cd_process: any) {
    return repository.eqpFacQuery(tom_cd_outage, tom_cd_process);
  }
  updbrk(
    FAO_TM_STOP_EN: any,
    FAO_CD_OUTAGE: any,
    RSNSDOLD: any,
    FAO_REMARKS: any,
    REMARKSCDOLD: any,
    FAO_CD_FAC_MAST: any,
    FAO_CD_EQP_MAST: any,
    OutageRsnDesc: any,
    FAO_CD_PROCESS: any,
    FAO_DT_OUTAGE: any,
    FAO_TM_STOP_ST: any,
    FAO_CD_SH_OUTAGE: any
  ) {
    return repository.updBrkQuery(
      FAO_TM_STOP_EN,
      FAO_CD_OUTAGE,
      RSNSDOLD,
      FAO_REMARKS,
      REMARKSCDOLD,
      FAO_CD_FAC_MAST,
      FAO_CD_EQP_MAST,
      OutageRsnDesc,
      FAO_CD_PROCESS,
      FAO_DT_OUTAGE,
      FAO_TM_STOP_ST,
      FAO_CD_SH_OUTAGE
    );
  }
  insertbrk(
    FAO_TM_STOP_EN: any,
    FAO_CD_OUTAGE: any,
    RSNSDOLD: any,
    FAO_REMARKS: any,
    REMARKSCDOLD: any,
    FAO_CD_FAC_MAST: any,
    FAO_CD_EQP_MAST: any,
    OutageRsnDesc: any,
    FAO_CD_PROCESS: any,
    FAO_DT_OUTAGE: any,
    PersonalNo: any,
    FAO_TM_STOP_ST: any,
    FAO_CD_SH_OUTAGE: any
  ) {
    return repository.insertBrkQuery(
      FAO_TM_STOP_EN,
      FAO_CD_OUTAGE,
      RSNSDOLD,
      FAO_REMARKS,
      REMARKSCDOLD,
      FAO_CD_FAC_MAST,
      FAO_CD_EQP_MAST,
      OutageRsnDesc,
      FAO_CD_PROCESS,
      FAO_DT_OUTAGE,
      PersonalNo,
      FAO_TM_STOP_ST,
      FAO_CD_SH_OUTAGE
    );
  }
  deletebrk(
    FAO_TM_STOP_ST: any,
    FAO_DT_OUTAGE: any,
    FAO_CD_PROCESS: any,
    FAO_CD_EQP_MAST: any
  ) {
    return repository.deleteBrkQuery(
      FAO_TM_STOP_ST,
      FAO_DT_OUTAGE,
      FAO_CD_PROCESS,
      FAO_CD_EQP_MAST
    );
  }
  updRsn(
    data: any
    // FAO_REMARKS: any,
    // FAO_CD_OUTAGE: any,
    // FAO_TM_STOP_ST: any,
    // FAO_DT_OUTAGE: any,
    // FAO_CD_PROCESS: any,
    // FAO_CD_EQP_MAST: any,
    // FAO_CD_FAC_MAST: any
  ) {
    return repository.updateRsnQuery(
      data
      //   FAO_REMARKS,
      //   FAO_CD_OUTAGE,
      //   FAO_TM_STOP_ST,
      //   FAO_DT_OUTAGE,
      //   FAO_CD_PROCESS,
      //   FAO_CD_EQP_MAST,
      //   FAO_CD_FAC_MAST
    );
  }
}
