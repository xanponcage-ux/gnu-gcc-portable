import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data.Plant) {
        return {
          batch: await ResponceData(
            await query(`
              select distinct EOM_ID_BATCH 
              from v_epa_prodn where eom_cd_status in ('VB','VF')
              AND EOM_CD_EPA = ${data.Plant}
              `)
          ),
          ordTypeData: await ResponceData(
            await query(
              `SELECT DISTINCT ENC_ORDER_TYPE FROM V_END_CUST_ORD_EPA 
                  WHERE ENC_CD_EPA=${data.Plant} and ENC_ST_ORDER='A' ORDER  BY 1`
            )
          ),
          custData: await ResponceData(
            await query(
              `SELECT DISTINCT ENC_CD_END_CUST,ENC_CD_END_CUST||' - '||ENC_CUST_NAME ENC_CUST_NAME 
                  FROM V_END_CUST_ORD_EPA WHERE ENC_CD_EPA=${data.Plant} AND  ENC_ST_ORDER='A' AND TRIM(ENC_CD_END_CUST) IS NOT NULL ORDER BY 1`
            )
          ),
        };
      } else {
        return getCommonPlantData();
        // return await query(`
        //     SELECT DISTINCT EPL_CD_EPA, EPL_CD_EPA||'-'||EPL_EPA_DESC EPL_CD_EPA_DESC
        //     FROM V_EPA_PROC_LINE
        //     where EPL_BUSI_ROLE IN (SELECT DISTINCT (SUBSTR(uug_id_usergrp,2,4)) FROM v_user_user_group
        //     WHERE uug_id_users = '${data.pno}') AND EPL_ACTIVE_PLANT_FL='A' ORDER BY EPL_CD_EPA
        //   `);
      }
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getDispatchData = async (data: any) => {
  try {
    let binds: any = {
      plant: data?.epa,
    };
    if (data?.type === "dispatchSummary") {
      let sqlDisSummary = `
        SELECT TO_CHAR(EOM_TS_CREATION, 'YYYY-MM-DD') DT_LOAD, SUM(EOM_MS_PIECE_ACTL) MS_WT, 0 SCRAP_WT
              FROM V_EPA_PRODN,V_END_CUST_ORD_EPA--sapr3.ympct_tub_matl@crmrup--Commented by vikash via cmr 2013/08/65/J1/T2
             WHERE EOM_CD_EPA = ${data.plant} 
          AND EOM_CD_STATUS='WL'
        AND NVL(EOM_ID_ORDER_CUS,' ')= ENC_ID_ORDER(+) 
        AND NVL(EOM_ID_ORD_ITEM_CUS,0) = ENC_NO_ITEM(+) 
       `;
      if (data?.dispatchDateFr && data?.dispatchDateFr?.length > 0) {
        sqlDisSummary += `AND TO_DATE(SUBSTR(EOM_TS_CREATION,1,10),'YYYY-MM-DD') BETWEEN '${data.dispatchDateFr}' AND NVL('${data.dispatchDateTo}','${data.dispatchDateFr}')`;
      }
      if (data?.tdc && data?.tdc?.length > 0) {
        sqlDisSummary += `AND (EOM_TDC_ACTL=NVL('${data.tdc}',EOM_TDC_ACTL) OR EOM_TDC_ACTL IS NULL)`;
      }
      if (data?.qltyCd && data?.qltyCd?.length > 0) {
        sqlDisSummary += `AND (EOM_CD_QLTY_ACTL=NVL('${data.qltyCd}',EOM_CD_QLTY_ACTL) OR EOM_CD_QLTY_ACTL IS NULL)`;
      }
      if (data?.ThickFr && data?.ThickFr?.length > 0) {
        sqlDisSummary += `AND EOM_SEC1 BETWEEN NVL('${data.ThickFr}',EOM_SEC1) AND NVL('${data.ThickTo}',NVL('${data.ThickFr}',EOM_SEC1))`;
      }
      sqlDisSummary += ` GROUP BY TO_CHAR(EOM_TS_CREATION, 'YYYY-MM-DD')`;
      return await query(sqlDisSummary);
    } else if (data?.type === "dispatchDetails") {
      //   let sql: any = `   SELECT EOM_ID_BATCH,EOM_CD_PROD, TO_CHAR(EOM_TS_CREATION, 'DD-MON-YY HH24:MI:SS') DT_LOAD,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS,
      //     EOM_CD_QLTY_ACTL,EOM_SEC1 THICK,EOM_SEC2 WIDTH,EOM_TDC_ACTL,EOM_NO_INVOICE,TO_CHAR(EOM_DT_INVOICE, 'DD-MON-YY HH24:MI:SS') EOM_DT_INVOICE,EOM_NO_PIECES,
      //     EOM_MS_PIECE_ACTL NET_WT,EOM_MS_GROSS_CAL GROSS_WT,EOM_LENGTH,EOM_CD_EPA,EOM_NO_MATNR,
      //     (select MAKTX from V_MAKT where MANDT = '600' and MATNR = EOM_NO_MATNR and rownum = 1 ) MATNR_DESC, EOM_MK_CUSTOMER,
      //     EOM_ID_FIRST_PAR,ENC_ORDER_TYPE,ENC_ORD_DESC, TO_CHAR(ENC_DT_ORD_CREATE, 'DD-MON-YY HH24:MI:SS') ENC_DT_ORD_CREATE,ENC_DESPATCH_WK ,ENC_CUST_NAME,ENC_MARK_CUST_NAME,
      //     ENC_IDIA,ENC_FRT_IND,EOM_DELV_NO,(SELECT MIN(EPR_TS_CREATION) FROM V_EPA_LINE_PRODN WHERE EPR_CD_EPA = EOM_CD_EPA
      //     AND EPR_ID_BATCH = EOM_ID_BATCH) BTCH_CRT_DATE
      //     FROM V_EPA_PRODN,V_END_CUST_ORD_EPA
      //     WHERE  EOM_ID_ORDER_CUS    = ENC_ID_ORDER(+)
      //     AND EOM_ID_ORD_ITEM_CUS = ENC_NO_ITEM(+)
      //     AND EOM_CD_EPA = '${data?.epa}'
      // --  AND EOM_CD_STATUS = 'WL'
      // --  AND EOM_ID_ORDER_CUS   = NVL(:NBT_ORDER,EOM_ID_ORDER_CUS)
      // --  AND EOM_ID_ORD_ITEM_CUS = NVL(:NBT_ITEM,EOM_ID_ORD_ITEM_CUS)
      //     AND TO_CHAR(TRUNC(EOM_TS_CREATION),'YYYY-MM-DD') = '${data?.dt_load}'
      //     `;

      //     let sql: any = `SELECT   eom_id_batch, eom_cd_prod PROD_CD,
      //        TO_CHAR (eom_ts_creation, 'DD-MON-YY HH24:MI:SS') btch_crt_date, --dt_load,
      //        eom_id_order_cus, eom_id_ord_item_cus, eom_cd_qlty_actl,
      //        eom_sec1 thick, eom_sec2 width, eom_tdc_actl TDC, eom_no_invoice,
      //        TO_CHAR (eom_dt_invoice, 'DD-MON-YY HH24:MI:SS') eom_dt_invoice,
      //        eom_no_pieces, eom_ms_piece_actl net_wt, eom_ms_gross_cal gross_wt,
      //        eom_length LENGTH, eom_cd_epa, eom_no_matnr,
      //        (SELECT maktx
      //           FROM v_makt
      //          WHERE mandt = '600'
      //            AND matnr = eom_no_matnr
      //            AND ROWNUM = 1) matnr_desc,
      //        eom_mk_customer, eom_id_first_par, enc_order_type, enc_ord_desc,
      //        TO_CHAR (enc_dt_ord_create,
      //                 'DD-MON-YY HH24:MI:SS') enc_dt_ord_create, enc_despatch_wk,
      //        enc_cust_name, enc_mark_cust_name, enc_idia, enc_frt_ind,
      //        eom_delv_no,
      //        --(SELECT MIN (epr_ts_creation)
      //          -- FROM v_epa_line_prodn
      //          --WHERE epr_cd_epa = eom_cd_epa
      //           -- AND epr_id_batch = eom_id_batch)
      //           '' dt_load
      //   FROM v_epa_prodn, v_end_cust_ord_epa
      //  WHERE eom_id_order_cus = enc_id_order(+)
      //    AND eom_id_ord_item_cus = enc_no_item(+)
      //    AND eom_cd_epa = '131'
      //    AND EOM_CD_STATUS = 'WL'
      //    --  AND EOM_ID_ORDER_CUS   = NVL(:NBT_ORDER,EOM_ID_ORDER_CUS)
      //    --  AND EOM_ID_ORD_ITEM_CUS = NVL(:NBT_ITEM,EOM_ID_ORD_ITEM_CUS)
      //    AND TO_CHAR(TRUNC(EOM_TS_CREATION),'YYYY-MM-DD') = '${data?.dt_load}'`;

      let sql: any = ` SELECT TO_CHAR(eom_dt_loading, 'DD-MON-YYYY') disp_dt, eom_id_batch batch_id, eom_sec1 thick, eom_sec2 width, eom_length LEN, eom_tdc_actl TDC, 
  (select tma_tdc_grd_desc from v_tdc_main where tma_tdc_no = eom_tdc_actl) tdc_grade_desc, 
  eom_cd_prod prod_cd, eom_id_order_cus ord, eom_id_ord_item_cus item, eom_ms_piece_actl net_wt, eom_ms_gross_cal gross_wt, enc_ship_to_prty_desc ship_to_party,
   enc_roaddest_desc road_dest, eom_no_invoice inv_no, TO_CHAR (eom_dt_invoice, 'DD-MON-YY') inv_dt,
           TO_CHAR (eom_ts_creation, 'DD-MON-YY HH24:MI:SS') btch_crt_date , (sysdate - eom_ts_creation) batch_age,
           enc_order_type ord_type, TO_CHAR (enc_ts_ord_dwnld, 'DD-MON-YY HH24:MI:SS')  ord_crt_dt, enc_despatch_wk desp_wk, enc_cd_end_cust cust_code,
           enc_cust_name cust_name, 
           EOM_MK_CUSTOMER mark_cust_name, eom_no_pieces no_pcs,
           enc_cd_ship_to_prty party_cd, 
           eom_idia idia, eom_odia odia, 
           enc_frt_ind frt_ind, 
           eom_delv_no delv_no, '' service_cntr,
           eom_no_matnr disp_mat_no, (SELECT maktx FROM v_makt WHERE mandt = '600' AND matnr = eom_no_matnr AND ROWNUM = 1) disp_mat_desc,
           (select LISTAGG(CAD_DEF2_COMM,' ; ') from v_coil_card
             where CAD_ID_COIL= eom_id_first_par 
             and (CAD_DEF2_COMM like '@SLP%' OR CAD_DEF2_COMM LIKE 'SLP%')) slp_remark, 
           eom_id_par_coil_no parent_batch, eom_id_first_par mother_batch,
           (select eic_ms_piece_actl from v_input_coil where eic_id_coil = eom_id_par_coil_no and eic_cd_epa = eom_cd_epa) mother_coil_mass,
           eom_cd_yrd yard, eom_id_loc_x loc_x, eom_id_loc_x loc_y, eom_id_pos loc_z, eom_cd_epa plant
           FROM v_epa_prodn, v_end_cust_ord_epa
     WHERE eom_id_order_cus = enc_id_order(+)
       AND eom_id_ord_item_cus = enc_no_item(+)
       AND eom_cd_epa = '131'
       AND EOM_CD_STATUS = 'WL' `;

      if (data.prodCd && data.prodCd?.length > 0) {
        sql += `AND (EOM_CD_PROD = NVL('${data?.prodCd}',EOM_CD_PROD) OR EOM_CD_PROD IS NULL) `;
        binds["prodCd"] = data?.prodCd;
      }
      if (data.tdc && data.tdc?.length > 0) {
        sql += `AND (EOM_TDC_ACTL = NVL('${data?.tdc}',EOM_TDC_ACTL) OR EOM_TDC_ACTL IS NULL) `;
        binds["tdc"] = data?.tdc;
      }
      if (data.qltyCd && data.qltyCd?.length > 0) {
        sql += `AND (EOM_CD_QLTY_ACTL = NVL('${data?.qltyCd}',EOM_CD_QLTY_ACTL) OR EOM_CD_QLTY_ACTL IS NULL) `;
        binds["qltyCd"] = data?.qltyCd;
      }
      if (data?.dispatchDateFr || data?.dispatchDateTo) {
        // sql += ` AND TO_DATE(SUBSTR(eom_dt_loading,1,10),'YYYY-MM-DD') BETWEEN '${data?.dispatchDateFr}' AND '${data?.dispatchDateTo}')`;
        sql += ` AND TO_DATE(SUBSTR(eom_dt_loading,1,10),'DD-MON-YY') BETWEEN NVL('${data?.dispatchDateFr}','01-JAN-1900') AND NVL('${data?.dispatchDateTo}','31-DEC-9999')`;
        binds.dispatchDateFr = data?.dispatchDateFr;
        binds.dispatchDateTo = data?.dispatchDateTo;
      }
      if (data?.ThickFr && data?.ThickFr != "") {
        sql += ` AND EOM_SEC1 BETWEEN NVL('${data?.ThickFr}',EOM_SEC1) AND NVL('${data?.ThickTo}',NVL('${data?.ThickFr}',EOM_SEC1))`;
        binds["ThickFr"] = data?.ThickFr;
        binds["ThickTo"] = data?.ThickTo;
      }
      if (data?.widthFr && data?.widthFr != "") {
        sql += ` AND EOM_SEC2 BETWEEN NVL('${data?.widthFr}',EOM_SEC2) AND NVL('${data?.widthTo}',NVL('${data?.widthFr}',EOM_SEC2)) `;
        binds["widthFr"] = data?.widthFr;
        binds["widthTo"] = data?.widthTo;
      }

      if (data?.ordType && data?.ordType?.length > 0) {
        sql += `AND (enc_order_type = NVL('${data?.ordType}',enc_order_type)) `;
        binds["ordType"] = data?.ordType;
      }
      if (data?.invoiceNo && data?.invoiceNo?.length > 0) {
        sql += `AND (eom_no_invoice = NVL('${data?.invoiceNo}',eom_no_invoice)) `;
        binds["invoiceNo"] = data?.invoiceNo;
      }
      if (data?.order && data?.order?.length > 0) {
        sql += `AND (eom_id_order_cus = NVL('${data?.order}',eom_id_order_cus)) `;
        binds["order"] = data?.order;
      }
      if (data?.item && data?.item?.length > 0) {
        sql += `AND (eom_id_ord_item_cus = NVL('${data?.item}',eom_id_ord_item_cus)) `;
        binds["item"] = data?.item;
      }
      if (data?.invoiceDtFrom || data?.invoiceDtTo) {
        sql += ` AND TO_DATE(SUBSTR(eom_dt_invoice,1,10),'DD-MON-YY') BETWEEN NVL('${data?.invoiceDtFrom}','01-JAN-1900') AND NVL('${data?.invoiceDtTo}','31-DEC-9999')`;
        binds.invoiceDtFrom = data?.invoiceDtFrom;
        binds.invoiceDtTo = data?.invoiceDtTo;
      }
      sql += ` ORDER BY TO_DATE(SUBSTR(eom_dt_loading,1,10),'YYYY-MM-DD'),EOM_ID_BATCH `;

      // console.log("=>", sql);
      return await query(sql);
    } else if (data?.type === "batchDetails") {
      let sql: any = `SELECT EOM_ID_BATCH,EOM_CD_PROD, TO_CHAR(EOM_TS_CREATION, 'DD-MON-YY HH24:MI:SS') DT_LOAD ,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS , 
          EOM_CD_QLTY_ACTL,EOM_SEC1,EOM_SEC2,EOM_TDC_ACTL,EOM_NO_INVOICE,EOM_DT_INVOICE,
          EOM_NO_PIECES,EOM_MS_PIECE_ACTL mass,EOM_MS_GROSS_CAL gross,
          EOM_LENGTH,EOM_CD_EPA,EOM_NO_MATNR,EOM_MK_CUSTOMER,EOM_ID_FIRST_PAR,ENC_ORDER_TYPE
          FROM V_EPA_PRODN,V_END_CUST_ORD_EPA
          WHERE 
          EOM_ID_ORDER_CUS 		= ENC_ID_ORDER(+)
          AND EOM_ID_ORD_ITEM_CUS = ENC_NO_ITEM(+)
          AND EOM_CD_EPA = '${data?.epa}' 
    --  AND EOM_CD_STATUS = 'WL'
        AND TO_CHAR(TRUNC(EOM_TS_CREATION),'YYYY-MM-DD') = '${data?.dt_load}'    
        `;
      return await query(sql);
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
