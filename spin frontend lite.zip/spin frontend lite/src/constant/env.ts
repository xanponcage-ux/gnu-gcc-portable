let envVar = "local";
if (window?.location?.origin?.includes("tslweblindev.corp.tatasteel.com")) {
  envVar = "dev";
}
if (window?.location?.origin?.includes("tslweblinuat.corp.tatasteel.com")) {
  envVar = "qa";
}
if (window?.location?.origin?.includes("kpofpmes.corp.tatasteel.com")) {
  envVar = "prd";
}
console.log(envVar);
const ENV = {
  server: envVar,
};

export default ENV;
