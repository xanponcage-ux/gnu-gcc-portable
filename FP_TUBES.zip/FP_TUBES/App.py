import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
# from flask_cors import CORS
from fastapi import FastAPI, Request
from routes import api_router
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
# from starlette.middleware.base import BaseHTTPMiddleware

app = FastAPI(title="Python API", redirect_slashes=False)

# IS_PROD = "dev" 
IS_PROD = "prod"

# Configure CORS properly
# app.add_middleware(
#     "origins"= ["http://localhost:3000", "https://tsldev19.corp.tatasteel.com:8226", "https://tslweblindev.corp.tatasteel.com"],  # React default port
#         "methods": ["POST"],
#         "allow_methods": ["POST"],
#         "X-Frame-Options": "DENY",
#         "Access-Control-Allow-Origin": ["http://localhost:3000", "https://tsldev19.corp.tatasteel.com:8226", "https://tslweblindev.corp.tatasteel.com"],
#         "allow_headers": ["Content-Type"]
#     # r"/health": {
#     #     "origins": ["http://localhost:3000", "https://tsldev19.corp.tatasteel.com:8226", "https://tslweblindev.corp.tatasteel.com"],
#     #     "allow_methods": ["GET"],
#     #     "X-Frame-Options": "DENY",
#     #     "methods": ["GET"],
#     #     "Access-Control-Allow-Origin": ["http://localhost:3000", "https://tsldev19.corp.tatasteel.com:8226", "https://tslweblindev.corp.tatasteel.com"],
#     #     "allow_headers": ["Content-Type"]
#     # }
# )

origins = [
    "http://localhost",
    "https://tsldev19.corp.tatasteel.com", 
    "https://tslweblindev.corp.tatasteel.com",
    "https://tsmwebappsk.corp.tatasteel.com",
    "https://tmpisprd.corp.tatasteel.com",
    "https://tslweblinprd.corp.tatasteel.com",
    "https://tslweblinuat.corp.tatasteel.com",
    "https://tsmwebapps01.corp.tatasteel.com",
    "https://tubesmes.corp.tatasteel.com"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,           # Domains allowed to make requests
    allow_methods=["GET", "POST"],             # Allowed HTTP methods (GET, POST, etc.)
    allow_credentials=True,
    allow_headers=["Content-Type"],             # Allowed HTTP request headers
)

# Paths to certificates (use environment variables in prod)
cert_path = r"D:\OneIT\SSL_cert\CertificateBundle.pem"
key_path  = r"D:\OneIT\SSL_cert\private_corp.pem"

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)

app.include_router(api_router, prefix="/api")

if __name__ == '__main__':
    if IS_PROD == 'dev': 
        uvicorn.run(app= "App:app", host='0.0.0.0', port=5000, reload=True)
    elif IS_PROD == 'prod': 
        # app.run(host='tsldev19.corp.tatasteel.com', port=8226,ssl_context=(cert_path, key_path), debug=False)
        uvicorn.run(app= "App:app", host='127.0.0.1', port=7012, ssl_keyfile= key_path, ssl_certfile= cert_path, reload=True)
    else: 
        # app.run(host='tsldev19.corp.tatasteel.com', port=8226,ssl_context=(cert_path, key_path), debug=False)
        uvicorn.run(app= "App:app", host='127.0.0.1', port=7012, ssl_keyfile= key_path, ssl_certfile= cert_path, reload=True)
