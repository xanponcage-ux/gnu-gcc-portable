import API from "../../src/constant/api";
import AxiosApi from "./axiosAPI";
import ENV from "../../src/constant/env";
import { TokenType } from "../../src/type";
import { getFromStorage } from "../../src/utils";

export const RefreshApi = async () => {
  const token: TokenType | null = await getFromStorage("token");
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].RefreshTokenUrl,
    data: { refreshToken: token?.refreshToken },
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const LogoutApi = (token: TokenType) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].Logout,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: { refreshToken: token?.refreshToken },
  });
};

export const AuthCheck = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].AuthCheck,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SPC0001GetInvData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0001GetInvData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0001GetInvMonData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0001GetInvMonData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0002GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0002GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0005GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0005GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0006GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0006GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0006GetEpaCodeApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0006GetEpaCode,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPC0006ProcedureCall = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0006ProcedureCall,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SPC0007GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0007GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0008GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0008GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPQ001GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPQ001GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0002GetEpaDataApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0002GetEpaData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPC0005GetTdcDataApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0005GetTdcData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPC0007GetOrderIdApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0007GetOrderId,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPQ001GetEpaData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPQ001GetEpaData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPC001GetPlantData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC001GetPlantData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const GetPlantDataApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].GetPlantData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

//INTRANSIT REPORT - SPCG001 PG APIS
export const SPCG001GetEpaData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPCG001GetEpaData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPCG001GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPCG001GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPCG001SaveTableDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPCG001SaveTableData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPCG001TabAccessApi = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPCG001TabAccess,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPCG001DeleteCoil = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPCG001DeleteCoil,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const C1FGS001GetEpaData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].C1FGS001GetEpaData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const C1FGS001GetFilterData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].C1FGS001GetFilterData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};
export const SPS0005ConfirmDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0005ConfirmData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPS0005UpdateCoilStatusApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0005UpdateCoilStatus,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPS0005SchedulingApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0005Scheduling,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SCO0006Action = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SCO0006Action,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0005GetOrderDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPS0005GetOrderData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPS0010IndentingApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPS0010IndentingApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPS0005ScheduleID = (token: TokenType) => {
  return AxiosApi({
    url: API[ENV.server].SPS0005ScheduleApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPS0005ToleranceApi = (token: TokenType) => {
  return AxiosApi({
    url: API[ENV.server].SPS0005Tolerance,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SCQ001Api = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ001Api,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SCQ001GetFilterDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ001GetFilterDataApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SCQ001GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ001GetDataApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SCQ001SaveDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ001SaveDataApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SCQ001DiversionResApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ001DiversionRes,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SCQ002Api = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ002Api,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SCQ002UploadImageToSftp = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SCQ002UploadImageToSftp,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPS0015Api = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPS0015Api,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SPO0001GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0001GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0001GetProdDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0001GetProdData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0002GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0002GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0002ConfirmApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0002ConfirmApi,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPC0003GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0003GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0003getPackCodeList = (token: TokenType) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0003getPackCodeList,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPC0003GetPackSeq = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0003GetPackSeq,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0003ProcedureApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0003Procedure,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0004GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0004GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0008GetOrderData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0008GetOrderData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPO0003Api = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0003Api,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0003getHoldRsn = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0003getHoldRsn,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0003getSlitPos = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0003getSlitPos,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0005Api = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0005Api,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPS0020Api = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0020Api,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0010GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0010GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};
export const SPC0010GetDispatchData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0010GetDispatchData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};
export const SPC0010GetInvMonData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0010GetInvMonData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0025Api = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0025Api,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0025BatchApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0025BatchApi,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0025TableApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0025TableApi,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

// export const SPS0004WipSchedullingApi = (token: TokenType, data: any) => {
//   return AxiosApi({
//     method: "POST",
//     url: API[ENV.server].SPS0004WipSchedulling,
//     headers: {
//       Authorization: "Bearer " + token?.accessToken,
//     },
//     data,
//   });
// };

export const SPS0004BatchTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0004BatchTableData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0004BatchDlinkTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0004BatchDlinkTableData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0004OrderTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0004OrderTableData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0004SaveData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0004SaveData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0004GetChemChk = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0004GetChemChk,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0009GetYieldDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0009GetYieldData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPO0004GetTableDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0004GetTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0004GetMotherTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0004GetMotherTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0004GetMBatchDataApi = (token: TokenType) => {
  return AxiosApi({
    url: API[ENV.server].SPO0004GetMBatchData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPO0004saveData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0004saveData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPC0011GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0011GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPC0011GetTableDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0011GetTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0005GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0005GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0005GetTableDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0005GetTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0005DeletePDIApi = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0005DeletePDI,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPC0012GetOrderDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0012GetOrderData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0005DiversionRes = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPS0005DiversionRes,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPC0013getCastDetails = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0013getCastDetails,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0013getCoilDetails = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0013getCoilDetails,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0013getFittingDetails = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPC0013getFittingDetails,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0014GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0014GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0014GetStatusData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0014GetStatusData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPC0015GetDataApi = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0015GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0021GetScDwnData = (token: TokenType, data: any) => {
  console.log("data", data);
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0021GetScDwnData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

// export const SPC0009GetPlantDataApi = (token: TokenType) => {
//   return AxiosApi({
//     method: "GET",
//     url: API[ENV.server].SPC0009GetPlantData,
//     headers: {
//       Authorization: "Bearer " + token?.accessToken,
//     },
//   });
// };

export const SPC0016GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0016GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0016GetStatusData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0016GetStatusData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPC0017GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPC0017GetData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPC0017GetStatusData = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].SPC0017GetStatusData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPO0007GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0007GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

// DELAY MANAGEMENT - OPERATION

export const SPO0008GetTroubleType = (token: TokenType) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008GetTroubleType,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const SPO0008GetData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008GetData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0008UpdData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008UpdData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0008SaveModalData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008SaveModalData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0008SaveTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008SaveTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const SPO0008InsertTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].SPO0008InsertTableData,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const QPexecQueryScreenAccess = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].QPexecQueryScreenAccess,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const QPexecQuery = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].QPexecQuery,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const QPconfirmExecQuery = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].QPconfirmExecQuery,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

export const QPtestConnection = (token: TokenType, data: any) => {
  return AxiosApi({
    url: API[ENV.server].QPtestConnection,
    method: "POST",
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data: data,
  });
};

//Packing wip schd

export const SPS0003GetTableData = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0003GetTableData,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const SPS0003CallPkgProc = (token: TokenType, data: any) => {
  return AxiosApi({
    method: "POST",
    url: API[ENV.server].SPS0003CallPkgProc,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
    data,
  });
};

export const piechart1 = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].piechart1,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

export const piechart2 = (token: TokenType) => {
  return AxiosApi({
    method: "GET",
    url: API[ENV.server].piechart2,
    headers: {
      Authorization: "Bearer " + token?.accessToken,
    },
  });
};

