// const SPS0010Query = require("../repository/SPS0010Query");
import { indenting } from "../repository/SPS0010Query";

export default class SPS0010Model {
  indenting(data: any) {
    return indenting(data);
  }
}
