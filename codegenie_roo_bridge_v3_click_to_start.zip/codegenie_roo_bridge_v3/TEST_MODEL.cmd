@echo off
if "%~1"=="" (
  echo Usage: TEST_MODEL.cmd MODEL_ID
  echo Example: TEST_MODEL.cmd gpt-4o-mini
  exit /b 1
)
set "MODEL=%~1"
curl.exe -sS -X POST http://127.0.0.1:8765/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"%MODEL%\",\"messages\":[{\"role\":\"user\",\"content\":\"Reply only with MODEL_OK\"}],\"max_tokens\":-1}"
echo.
pause
