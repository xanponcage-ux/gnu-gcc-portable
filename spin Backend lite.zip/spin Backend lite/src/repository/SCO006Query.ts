import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getFetchData = async (data: any) => {
  try {
    let statusSql: any = `SELECT CD_VALUE FROM V_CODES
                            WHERE CD_TYPE='TK001'
                            ORDER BY 1`;
    return {
      Status: await ResponceData(await query(statusSql)),
      PlanCode: await ResponceData(await getCommonPlantData()),
    };
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCO006getBatchInformation = async (data: any) => {
  try {
    let sql: any = `SELECT EBS_CD_EPA,EBS_FIRST_PAR
    , AVG(EIC_MS_PIECE_ACTL) INP_MASS
    , ( AVG(F_GETFGWIP('${data?.plant}',A.EBS_FIRST_PAR))
    +NVL((select SUM(EBS_MS_SCRAP) from v_epa_batch_scrap where ebs_cd_epa=a.EBS_CD_EPA and EBS_FIRST_PAR=a.EBS_FIRST_PAR  AND EBS_IND ='A' and  EBS_REC_STATUS ='Y') ,0)) FG
    ,SUM(EBS_MS_SCRAP) SCRAP
    ,EIC_SEC1 RM_THK
    ,EIC_SEC2 RM_WIDTH
    ,EIC_TDC_ACTL RM_TDC
    ,EIC_NO_MATNR RM_MATNR
    --, EBS_CD_PROCESS PROCESS
    FROM V_EPA_BATCH_SCRAP A ,V_INPUT_COIL B
    WHERE EBS_CD_EPA = EIC_CD_ePA
    AND EBS_FIRST_PAR = EIC_ID_COIL
    AND EBS_REC_STATUS ='N'
    AND EBS_IND ='A'  ---- DEFINES SCRAP
  `;
    // if (data?.status && data?.status?.length > 0) {
    //   sql += ` AND EOM_CD_STATUS LIKE NVL('${data?.status}',EOM_CD_STATUS) `;
    // }
    if (data?.batch && data?.batch?.length > 0) {
      sql += ` AND EBS_FIRST_PAR = '${data?.batch}' `;
    }
    // if (data?.coilId && data?.coilId?.length > 0) {
    //   sql += ` AND (EOM_ID_PAR_COIL_NO=${data?.coilId} OR EOM_ID_FIRST_PAR=${data?.coilId})`;
    // }
    sql += ` GROUP BY EBS_CD_EPA,EBS_FIRST_PAR,EIC_SEC1,EIC_SEC2,EIC_TDC_ACTL,EIC_NO_MATNR
    ORDER BY EBS_CD_EPA,EBS_FIRST_PAR`;
    console.log("=>", sql);
    return await ResponceData(await query(sql));
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCO006SaveData = async (data: any) => {
  try {
    console.log("Inside SCO006SaveData:--- ");
    let ouptput = [];
    let varRes: any = {};
    let single_output = true;
    await query(`DELETE FROM V_EPA_BATCH_SCRAP_TEMP WHERE EBS_CD_ePA='131'
    --AND EBS_ID_BATCH = '${data.batch}'
`);
    for (let i = 0; i < data?.data?.length; i++) {
      let sql: any = `
      call TDSB0004 (
      ls_batchid => :ls_batchid,
      ls_process => :ls_process,
      ls_rsn_cat => :ls_rsn_cat,
      ls_rsn_cd_old => :ls_rsn_cd_old,
      ls_rsn_cd_new => :ls_rsn_cd_new,
      lv_scrp_matl => :lv_scrp_matl ,
      ls_sel_fl => :ls_sel_fl,   
      ls_scrap_qty_indv => :ls_scrap_qty_indv ,
      ls_ms_scrp_tot => :ls_ms_scrp_tot ,
      ln_rowind => :ln_rowind,
      ln_totrow => :ln_totrow,
      ls_pageid => :ls_pageid,
      ls_out_flag => :ls_out_flag
      )
      `;
      const binds = {
        ls_batchid: data.batch,
        ls_rsn_cat: data?.data[i].ESR_RSN_CAT,
        ls_process: data?.process,
        ls_rsn_cd_old: data?.data[i].ESR_RSN_CD_BCK ?? data?.data[i].ESR_RSN_CD,
        ls_rsn_cd_new: data?.data[i].ESR_RSN_CD,
        lv_scrp_matl: data?.data[i].SCAP_MATERIAL,
        ls_sel_fl: data?.data[i]?.isSelected,
        ls_scrap_qty_indv: data?.data[i].SCRAP_QTY,
        ls_ms_scrp_tot: data?.scrapTot,
        ln_rowind: i + 1,
        ln_totrow: data?.data?.length,
        ls_pageid: "TDSB0004",
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      // console.log("bindsTemp: ", binds);
      varRes = await query(sql, binds);
      // console.log("varResTemp: ", varRes);
      if (varRes?.outBinds?.ls_out_flag?.includes("N-")) {
        single_output = false;
      }
    }
    console.log("single_output: ", single_output);
    if (single_output) {
      varRes = await query(
        `call TDSB0005 (
      ls_batchid => :ls_batchid,
      ls_pageid => :ls_pageid,
      ls_out_flag => :ls_out_flag
      )
      `,
        {
          ls_batchid: data.batch,
          ls_pageid: "TDSB0004",
          ls_out_flag: {
            type: oracledb.STRING,
            dir: oracledb.BIND_OUT,
            maxSize: 500,
          },
        }
      );
    }
    console.log("varRes-2: ", varRes);
    ouptput.push(data.batch + ": " + varRes.outBinds?.ls_out_flag);
    console.log("ouptput: ", ouptput);
    return { ouptput: varRes.outBinds?.ls_out_flag };
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCO006SaveForm = async (data: any) => {
  try {
    let ouptput = [];
    for (let i = 0; i < data?.data?.length; i++) {
      let sql: any = `
      call TDSB0005 (
      ls_batchid => :ls_batchid,
      ls_out_flag => :ls_out_flag
      )
      `;
      const binds = {
        ls_batchid: data?.data[i].batch,
        ls_out_flag: {
          type: oracledb.STRING,
          dir: oracledb.BIND_OUT,
          maxSize: 500,
        },
      };
      console.log(sql, binds);
      let varRes = await query(sql, binds);
      ouptput.push(data?.data[i]?.batch + ": " + varRes.outBinds?.ls_out_flag);
    }

    return { ouptput: ouptput };
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCO006GetPopUpData = async (data: any) => {
  try {
    return {
      data: await ResponceData(
        await query(`select A.*, A.EBS_SCRP_MATNR SCAP_MATERIAL, A.EBS_MS_SCRAP SCRAP_QTY,b.ESR_RSN_CD, b.ESR_RSN_CD ESR_RSN_CD_BCK,b.ESR_RSN_CAT,B.ESR_RSN_DESC
  from v_epa_batch_scrap a, v_scrp_sec_rsn b
  where EBS_CD_RSN_SCRAP= ESR_RSN_CD
  AND EBS_FIRST_PAR='${data?.type?.FIRST_PAR}'
  and ESR_CD_EPA = ${data?.type?.plant}
  AND EBS_IND ='A'
  order by ESR_RSN_DESC`)
      ),
      matirialCD: await ResponceData(
        await query(`SELECT substr(CD_DESC,1,18) Matnr,CD_DESC MatnrDesc from v_codes
where cd_type='TK011'`)
      ),
      category: await ResponceData(
        await query(`select distinct ESR_RSN_CAT, ESR_RSN_CD, ESR_RSN_DESC from v_scrp_sec_rsn
  where ESR_CD_EPA = ${data?.type?.plant}
  and ESR_STATUS = 'A'
  order by ESR_RSN_DESC`)
      ),
    };
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getProcess = async (data: any) => {
  try {
    let statusSql: any = `SELECT EBS_CD_PROCESS FROM V_EPA_BATCH_SCRAP A
    WHERE EBS_FIRST_PAR='${data.CoilId}'
    AND EBS_DT_SCRAP= (SELECT MAX(EBS_DT_SCRAP) FROM V_EPA_BATCH_SCRAP
    WHERE EBS_FIRST_PAR=A.EBS_FIRST_PAR)`;
    return await ResponceData(await query(statusSql));
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getScrapData = async (data: any) => {
  try {
    let qry: any = `SELECT EBS_ID_BATCH, 
       sum( DECODE (EBS_CD_RSN_SCRAP,'N01', EBS_MS_SCRAP,0)) END_CUT,
       sum(DECODE (EBS_CD_RSN_SCRAP,'N02', EBS_MS_SCRAP,0)) TRIM_LOSS,
       sum(DECODE (EBS_CD_RSN_SCRAP,'N03', EBS_MS_SCRAP,0)) PUP_COIL
      FROM V_EPA_BATCH_SCRAP
      WHERE EBS_ID_BATCH = '${data.batchId}'
      group by ebs_id_batch `;
    return await ResponceData(await query(qry));
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
