const SPC0015Query = require("../repository/SPC0015Query");

export default class SPC0015Model {
    getSubrangeMaster(data: any) {
      return SPC0015Query.getSubrangeMaster(data);
    }
    getPackageSubrange(data: any) {
      return SPC0015Query.getPackageSubrange(data);
    }
    getProcessSubrange(data: any) {
      return SPC0015Query.getProcessSubrange(data);
    }
  }