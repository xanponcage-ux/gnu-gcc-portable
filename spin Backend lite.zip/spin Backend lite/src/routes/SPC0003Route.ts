import { Router } from "express";
import {
  SPC0003getData03,
  getPackCdList,
  getPackSeq,
  savePackingOiling,
} from "../controllers/SPC0003Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0003Route = Router();

SPC0003Route.route("/SPC0003/getcodingData").post(
  authenticationMiddleware.bearer,
  SPC0003getData03
);

SPC0003Route.route("/SPC0003/savePackingOiling").post(
  authenticationMiddleware.bearer,
  savePackingOiling
);

SPC0003Route.route("/SPC0003/getPackCdList").post(
  authenticationMiddleware.bearer,
  getPackCdList
);

SPC0003Route.route("/SPC0003/getPackSeq").post(
  authenticationMiddleware.bearer,
  getPackSeq
);

export default SPC0003Route;
