import React from "react";
import "./App.css";
import { ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

import { Routes } from "./routes";
import { darkTheme, lightTheme } from "./theme";
import { useMaterialUIController } from "./context";
import IdleTimer from "./IdleTimer";

import { setUser } from "./context";
import alertify from "./components/alert";

function App() {
  const [controller, dispatch] = useMaterialUIController();
  const { theme } = controller;

  React.useEffect(() => {
    const handleLogout = () => {
      setUser(dispatch, {
        user: "",
        token: {
          accessToken: "",
          refreshToken: "",
        },
      });
      sessionStorage.clear();
      localStorage.clear();
      alertify.error("You have been logged out due to inactivity.");
      window.close();
      window.location.href = "/";
    };

    const timer = new IdleTimer({
      timeout: 1200, //expire after 20 mins
      onTimeout: () => {
        handleLogout();
        // window.location.href = "#/login";
      },
      onExpired: () => {
        // do something if expired on load
        handleLogout();
        // window.location.href = "#/login";
      },
    });

    const resetTimer = () => {
      // console.log("Inside resetTimer");
      timer.updateExpiredTime();
    };

    const activityEvents = [
      "mousemove",
      "scroll",
      "keydown",
      "click",
      "mousedown",
      "mouseup",
      "focus",
      "cut",
      "copy",
      "paste",
    ];
    activityEvents.forEach((event) => {
      // console.log("event: ", event);
      window.addEventListener(event, resetTimer);
    });

    return () => {
      timer.cleanUp();
      activityEvents.forEach((event) => {
        window.removeEventListener(event, resetTimer);
      });
    };
  }, []);

  return (
    <React.Suspense fallback={<p>Loading...</p>}>
      <ThemeProvider theme={theme === "dark" ? darkTheme : lightTheme}>
        <CssBaseline />
        <Routes />
      </ThemeProvider>
    </React.Suspense>
  );
}

export default App;
