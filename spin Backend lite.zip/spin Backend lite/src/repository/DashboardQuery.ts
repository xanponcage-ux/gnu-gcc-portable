import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

// CHECK THE QUERY IN TEST - NO DATA IS PRESENT FOR FY 27 

export const piechart1 = async () => {
  try {
    const sql = `SELECT
    'PRIME' AS TYPE,
--    ROUND(SUM(TCY_PRIME_WT), 3) AS WEIGHT
    ROUND(NVL((SUM(TCY_PRIME_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 WEIGHT
FROM V_COIL_YIELD
WHERE TCY_CD_EPA = '131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END
UNION ALL
SELECT 
    'SCRAP' AS TYPE,
--    ROUND(SUM(TCY_SCRAP_WT), 3) AS WEIGHT
     ROUND(NVL((SUM(TCY_SCRAP_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 WEIGHT
FROM V_COIL_YIELD
WHERE TCY_CD_EPA = '131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END 
UNION ALL
SELECT 
    'DOWNGRADE' AS TYPE,
--    ROUND(SUM(TCY_SECONDS_WT), 3) AS WEIGHT
     ROUND(NVL((SUM(TCY_SECONDS_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 WEIGHT
FROM V_COIL_YIELD
WHERE TCY_CD_EPA = '131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END 
`;
    // console.log('HIT',sql);
    console.log('Query piechart1',sql);
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};


// CHECK THE QUERY IN TEST - NO DATA IS PRESENT FOR FY 27 
export const piechart2 = async () => {
  try {
    const sql = `
SELECT TCY_YRMON YRMON
,ROUND(NVL((SUM(TCY_PRIME_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 PRIME_PER
,ROUND(NVL((SUM(TCY_SECONDS_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 DOWN_PER
,ROUND(NVL((SUM(TCY_SCRAP_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 SCRAP_PER
 FROM V_COIL_YIELD
WHERE TCY_CD_EPA='131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END
Group by TCY_YRMON
ORDER BY TCY_YRMON `;
console.log('Query piechart2',sql);
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

// Change the Query as needed
export const linegraph1 = async () => {
  try {
    const sql = `  SELECT TCY_YRMON YRMON
,ROUND(NVL((SUM(TCY_PRIME_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 PRIME_PER
,ROUND(NVL((SUM(TCY_SECONDS_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 DOWN_PER
,ROUND(NVL((SUM(TCY_SCRAP_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 SCRAP_PER
 FROM V_COIL_YIELD
WHERE TCY_CD_EPA='131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END
Group by TCY_YRMON
ORDER BY TCY_YRMON `;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};


// Change the Query as needed
export const linegraph2 = async () => {
  try {
    const sql = `  SELECT TCY_YRMON YRMON
,ROUND(NVL((SUM(TCY_PRIME_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 PRIME_PER
,ROUND(NVL((SUM(TCY_SECONDS_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 DOWN_PER
,ROUND(NVL((SUM(TCY_SCRAP_WT)/ SUM(TCY_MC_INV_WT)),0),3)*100 SCRAP_PER
 FROM V_COIL_YIELD
WHERE TCY_CD_EPA='131'
AND TCY_YRMON >=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY') || '04'
        ELSE TO_CHAR(SYSDATE, 'YYYY') || '04'
    END
AND TCY_YRMON <=
    CASE
        WHEN TO_CHAR(SYSDATE, 'MM') IN ('01', '02', '03') THEN TO_CHAR(SYSDATE, 'YYYY') || '03'
        ELSE TO_CHAR(ADD_MONTHS(SYSDATE, 12), 'YYYY') || '03'
    END
Group by TCY_YRMON
ORDER BY TCY_YRMON `;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
