import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { DateFormat, GetAuthorization } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPQ001GetDataApi,
  // SPC001GetPlantData,
  GetPlantDataApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_B1COS002 = () => {
  const csTheme: csTheme = useTheme();
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [value, setValue] = React.useState<number>(0);
  const [epaData, setEpaData] = React.useState<Array<SelectType>>([]);

  const [batchId, setBatchId] = React.useState<string>("");
  const [holdDtFrom, setHoldDtFrom] = React.useState<any>();
  const [holdDtTo, setHoldDtTo] = React.useState<any>();
  const [rlsDtFrom, setRlsDtFrom] = React.useState<any>();
  const [rlsDtTo, setRlsDtTo] = React.useState<any>();

  const tableCol: Array<CulmnType> = [
    {
      title: "Batch Id",
      field: "CHR_ID_COIL",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Date",
      field: "CHR_TS_HOLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rsn Hold Cd",
      field: "CHR_CD_RSN_HOLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold Cd Desc",
      field: "RSN_HOLD_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Hold By",
      field: "CHR_ID_OP_HOLD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release By",
      field: "CHR_ID_OP_RELEASE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Remarks",
      field: "CHR_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Release Date",
      field: "CHR_TS_RELEASE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prev Status Cd",
      field: "CHR_CD_PREV_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    // {
    //   title: "Create DB TS",
    //   field: "CHR_TS_CREATE_DB",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Update DB TS",
    //   field: "CHR_TS_UPDATE_DB",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Piece Upd Dt",
    //   field: "CHR_DT_PIECE_UPD",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Archival Ind",
    //   field: "CHR_ARCHIVAL_IND",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    // {
    //   title: "Final Decision Cd",
    //   field: "CHR_CD_FNL_DECSN",
    //   headerFilter: "input",
    //   headerFilterPlaceholder: "search...",
    // },
    {
      title: "Hold Wt",
      field: "CHR_HOLD_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Rls Wt",
      field: "CHR_RLS_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Opr Remarks",
      field: "CHR_OPR_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Rls Remarks",
      field: "CHR_RLS_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Addl Rls Remarks",
      field: "CHR_RLS_REMARKS1",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Process",
      field: "CHR_CD_PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "CHR_CD_EPA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "Hold Release Report" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: tableCol,
          height: 350,
          layout: "fitDataFill",
          // autoColumns: true,
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  React.useEffect(() => {
    fetchOrderIdData();
  }, []);

  const fetchOrderIdData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: TableType, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setEpaData(varData);
            setSelectedCode(varData[0].value);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";

    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "";

    return date
      .toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
      .replace("Sept", "Sep")
      .toUpperCase()
      .replace(/ /g, "-");
  };

  const fetchData = () => {
    if (!(selectedCode.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPQ001GetDataApi(token, {
        process: selectedProcess,
        batchId: batchId,
        code: selectedCode?.split(" - ")[0],
        holdDtFrom: formatDate(holdDtFrom),
        holdDtTo: formatDate(holdDtTo),
        rlsDtFrom: formatDate(rlsDtFrom),
        rlsDtTo: formatDate(rlsDtTo),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res.data.length === 0) {
            setTableData(res.data);
            alertify.error("No Data Found!");
            return;
          } else if (res?.data) {
            setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };
  const handleClearAll = () => {
    setBatchId("");
    setTableData([]);
    setHoldDtFrom(null);
    setHoldDtTo(null);
    setRlsDtFrom(null);
    setRlsDtTo(null);
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2.5}>
                          <SelectInput
                            id={"id"}
                            data={epaData}
                            value={selectedCode}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedCode(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={2}>
                          <Input
                            id={"batch"}
                            value={batchId}
                            label="Batch Id"
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>
                        <Grid item xs={2}>
                          <Input
                            id={"process"}
                            value={selectedProcess}
                            label="Process"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedProcess(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            id={"HoldDtFrom"}
                            value={holdDtFrom}
                            label="Hold Dt From"
                            size={"small"}
                            onChange={(e: string) => {
                              setHoldDtFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            id={"HoldDtTo"}
                            value={holdDtTo}
                            label="Hold Dt To"
                            size={"small"}
                            onChange={(e: string) => {
                              setHoldDtTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            id={"RlsDtFrom"}
                            value={rlsDtFrom}
                            label="Rls Dt From"
                            size={"small"}
                            onChange={(e: string) => {
                              setRlsDtFrom(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            id={"RlsDtTo"}
                            value={rlsDtTo}
                            label="Rls Dt To"
                            size={"small"}
                            onChange={(e: string) => {
                              setRlsDtTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1}>
                          <ButtonElement onClick={fetchData}>
                            Search
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_B1COS002;
