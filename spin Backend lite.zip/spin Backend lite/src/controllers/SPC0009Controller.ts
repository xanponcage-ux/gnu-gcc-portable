import { Request, Response } from "express";
import SPC0009Model from "../models/SPC0009Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

// export const getPlantData = async (req: Request, res: Response) => {
//   try {
//     const result1 = await SPC0009Model.prototype.getPlantData();
//     return res.status(200).json(await ResponceData(result1));
//   } catch (error: any) {
//     console.log("error", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

export const getYieldData = async (req: Request, res: Response) => {
  try {
    const result1 = await SPC0009Model.prototype.getYieldData(req.body);
    return res.status(200).json(await ResponceData(result1));
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
