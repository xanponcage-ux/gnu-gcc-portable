import React, { Component } from "react";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import { Oval } from 'react-loader-spinner';
import logo from "src/assets/images/Tata_White.png";

export default function Loader() {
  return (
    <Backdrop
      sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
      open={true}
    >
      {/* <CircularProgress color="inherit" /> */}
      <img src={logo} alt="loader" height="50" style={{ position: "absolute" }} />
        <Oval
          height={120}
          width={120}
          color="#00acc1"
          visible={true}
          ariaLabel='oval-loading'
          secondaryColor="white"
          strokeWidth={10}
          strokeWidthSecondary={10}

        />
    </Backdrop>
  );
}