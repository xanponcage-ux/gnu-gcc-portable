import { Request, Response } from "express";
import SPS0010Model from "../models/SPS0010Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import OracleDB from "oracledb";

export const indenting = async (req: Request, res: Response) => {
  try {
    if (req.body?.type === "procedureCall") {
      let coilIds = req.body?.coilId;
      let plantId = req.body?.plantId;
      let type = req.body?.type;
      let output: any = { N: [], Y: [] };
      //let failedCoil = [];

      for (let i = 0; i < coilIds?.length; i++) {
        let coilId = coilIds[i];
        let data = { coilId: coilId, plantId: plantId, type: type };
        const results = await ResponceData(
          await SPS0010Model.prototype.indenting(data)
        );
        if (results?.outBinds?.ls_out_flag[0] !== "Y") {
          output["N"].push(coilId + "-" + results?.outBinds?.ls_out_flag);
        }
      }
      return res.status(200).json(output);
    } else if (req.body?.type === "deleteIndent") {
      let coilIds = req.body?.coilId;
      let plantId = req.body?.plantId;
      let type = req.body?.type;
      let output: any = { N: [], Y: [] };
      for (let i = 0; i < coilIds?.length; i++) {
        let coilId = coilIds[i];
        let data = { coilId: coilId, plantId: plantId, type: type };
        const results = await ResponceData(
          await SPS0010Model.prototype.indenting(data)
        );
        if (results?.outBinds?.ls_out_flag[0] !== "Y") {
          output["N"].push(coilId + "-" + results?.outBinds?.ls_out_flag);
        }
      }
      return res.status(200).json(output);
    } else if (req.body?.type === "deleteIndent") {
      let coilIds = req.body?.coilId;
      let plantId = req.body?.plantId;
      let type = req.body?.type;
      let output: any = { N: [], Y: [] };
      for (let i = 0; i < coilIds?.length; i++) {
        let coilId = coilIds[i];
        let data = { coilId: coilId, plantId: plantId, type: type };
        const results = await ResponceData(
          await SPS0010Model.prototype.indenting(data)
        );
        //console.log(results?.outBinds?.ls_out_flag)
        if (results?.outBinds?.ls_out_flag[0] !== "Y") {
          output["N"].push(coilId + "-" + results?.outBinds?.ls_out_flag);
          //failedCoil.push(coilId)
        } else if (results?.outBinds?.ls_out_flag[0] === "Y") {
        }
      }
      return res.status(200).json(output);
    } else {
      const results = await ResponceData(
        await SPS0010Model.prototype.indenting(req.body)
      );
      return res.status(200).json(results);
    }
  } catch (error: any) {
    console.log("error:", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};


