import { Request, Response } from "express";
import PlanningModel from "../models/planningModel";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";
import OracleDB from "oracledb";

export const getData01 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    if (req.body.data === 0) {
      result1 = await PlanningModel.prototype.getVCoilData01(req.body);
    }
    if (req.body.data === 1) {
      result2 = await PlanningModel.prototype.getData01(req.body);
    }
    varData = {
      ...{ procLine: await ResponceData(result1) },
      ...{ procPath: await ResponceData(result2) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

// export const scheduling = async (req: Request, res: Response) => {
//   try {
//     if (req.body.type === "computeData") {
//       let dataArr = req.body.data;

//       let result = await PlanningModel.prototype.deleteScheduling(dataArr[0]);
//       let count = 0;
//       let results: any = { N: [], YZ: null };
//       for (let i = 0; i < dataArr.length; i++) {
//         let inputData = { type: req?.body?.type, ...req?.body?.data[i] };
//         let output = await PlanningModel.prototype.scheduling(inputData);
//         if (output?.outBinds?.ls_out_flag?.substr(0, 1) === "N") {
//           count = 1;
//           results["N"].push(output?.outBinds?.ls_out_flag);
//           break;
//         }
//       }
//       if (count === 0) {
//         let binds = {
//           p_plant: req?.body?.data[0]?.p_plant,
//           p_schd_no: req?.body?.data[0]?.p_schedule_id,
//           p_user: req?.body?.data[0]?.p_user,
//           ls_out_flag: {
//             type: OracleDB.STRING,
//             dir: OracleDB.BIND_OUT,
//             maxSize: 500,
//           },
//         };
//         let output = await query(
//           `
//           call TPLB0005(
//             p_plant => :p_plant,
//             p_schd_no => :p_schd_no,
//             p_user => :p_user,
//             ls_out_flag => :ls_out_flag
//           )
//         `,
//           binds
//         );
//         results["YZ"] = output?.outBinds?.ls_out_flag;
//       }
//       return res.status(200).json(results);
//     } else if (req.body.type === "confirmData") {
//       let results = await PlanningModel.prototype.scheduling(req.body);
//       let output = results?.outBinds?.ls_out_flag;
//       return res.status(200).json(output);
//     } else {
//       let varData: any = {};
//       varData = await PlanningModel.prototype.scheduling(req.body);

//       return res.status(200).json(await ResponceData(varData));
//     }
//   } catch (error: any) {
//     console.log("error:-", error);
//     return res
//       .status(400)
//       .json({
//         error: error?.message ? error?.message?.toString() : "Errorrrrrr",
//       });
//   }
// };
export const getEpaData01 = async (req: Request, res: Response) => {
  try {
    const result1 = await PlanningModel.prototype.getCoilData01();
    const varData = {
      coilId: await ResponceData(result1),
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const updateCoilStatus01 = async (req: Request, res: Response) => {
  try {
    const results = await PlanningModel.prototype.updateCoilStatus01(req.body);

    return res.status(200).json(await ResponceData(results));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

// export const getOrderData = async (req: Request, res: Response) => {
//   try {
//     const results = await ResponceData(
//       await PlanningModel.prototype.getOrderData(req.body)
//     );
//     return res.status(200).json(results);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const scheduleID = async (req: Request, res: Response) => {
//   try {
//     const results = await ResponceData(
//       await PlanningModel.prototype.scheduleID()
//     );

//     return res.status(200).json(results);
//   } catch (error: any) {
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const indenting = async (req: Request, res: Response) => {
//   try {
//     if (req.body?.type === "procedureCall") {
//       let coilIds = req.body?.coilId;
//       let plantId = req.body?.plantId;
//       let type = req.body?.type;
//       let output: any = { N: [], Y: [] };
//       //let failedCoil = [];

//         for(let i=0;i<coilIds?.length;i++){
//           let coilId = coilIds[i]
//           let data = {coilId : coilId, plantId: plantId,type:type}
//           const results = await ResponceData(await PlanningModel.prototype.indenting(data));
//            if(results?.outBinds?.ls_out_flag[0] !== 'Y'){
//             output['N'].push(coilId +'-'+results?.outBinds?.ls_out_flag)
//            }
//         }
//         return res.status(200).json(output);
//    }

//    else if (req.body?.type === 'deleteIndent'){

//     let coilIds = req.body?.coilId;
//       let plantId = req.body?.plantId;
//       let type = req.body?.type
//       let output:any ={'N':[], 'Y': []};
//       for(let i=0;i<coilIds?.length;i++){
//         let coilId = coilIds[i]
//         let data = {coilId : coilId, plantId: plantId,type:type}
//         const results = await ResponceData(await PlanningModel.prototype.indenting(data));
//         if(results?.outBinds?.ls_out_flag[0] !== 'Y'){
//           output['N'].push(coilId +'-'+results?.outBinds?.ls_out_flag)
//         }
//       }
//       return res.status(200).json(output);
//     } else if (req.body?.type === "deleteIndent") {
//       let coilIds = req.body?.coilId;
//       let plantId = req.body?.plantId;
//       let type = req.body?.type;
//       let output: any = { N: [], Y: [] };
//       for (let i = 0; i < coilIds?.length; i++) {
//         let coilId = coilIds[i];
//         let data = { coilId: coilId, plantId: plantId, type: type };
//         const results = await ResponceData(
//           await PlanningModel.prototype.indenting(data)
//         );
//         //console.log(results?.outBinds?.ls_out_flag)
//         if (results?.outBinds?.ls_out_flag[0] !== "Y") {
//           output["N"].push(coilId + "-" + results?.outBinds?.ls_out_flag);
//           //failedCoil.push(coilId)
//         } else if (results?.outBinds?.ls_out_flag[0] === "Y") {
//         }
//       }
//       return res.status(200).json(output);
//     } else {
//       const results = await ResponceData(
//         await PlanningModel.prototype.indenting(req.body)
//       );
//       return res.status(200).json(results);
//     }
//   } catch (error: any) {
//     console.log("error:", error);
//     return res
//       .status(400)
//       .json({ error: error?.message ? error?.message?.toString() : "Error" });
//   }
// };

// export const scheduleDeletion = async (req: Request, res: Response) => {
//   try {
//     const results = await ResponceData(
//       await PlanningModel.prototype.scheduleDeletion(req.body)
//     );
//     return res.status(200).json(results);
//   }
//   catch (error: any) {
//     return res.status(400).json({ error: error?.message ? error?.message?.toString() : 'Error' });
//   }
// };
