const maintainMasterQuery = require("../repository/maintainMasterQuery");

export default class maintainMasterModel {
    getEpaCode02() {
        return maintainMasterQuery.getEpaCode02();
      }
      // getProcLineData02(data: any) {
      //   return maintainMasterQuery.getProcLineData02(data);
      // }
      // getProcPath02(data: any) {
      //   return maintainMasterQuery.getProcPath02(data);
      // }
    //              for page -03
      // getPackingCode03(data: any) {
      //   return maintainMasterQuery.getPackingCode03(data);
      // }
      // getOilingCode03(data: any) {
      //   return maintainMasterQuery.getOilingcode03(data);
      // }
      // savePackingOiling(data: any) {
      //   return maintainMasterQuery.savePackingOiling(data);
      // }

      // upcomingpageCode04(data: any) {
      //   return maintainMasterQuery.upcomingpageCode04(data);
      // }
      // upcomingpage_02_Code04(data: any) {
      //   return maintainMasterQuery.upcomingpage_02_Code04(data);
      // }
      getPlantData() {
        return maintainMasterQuery.getPlantData();
      }
    //   getEpaPlant06() {
    //     return maintainMasterQuery.getEpaPlant06();
    // }
    // getTdcsec06() {
    //     return maintainMasterQuery.getTdcsec06();
    // }
    // getSECONDSTdc06(data: any) {
    //     return maintainMasterQuery.getSECONDSTdc06(data);
    // }
    // getActTdc06() {
    //     return maintainMasterQuery.getActTdc06();
    // }
    getEndTdc06() {
        return maintainMasterQuery.getEndTdc06();
    }
    // getTdcMap06(data: any) {
    //     return maintainMasterQuery.getTdcMap06(data);
    // }
    // callProcedure06(data: any) {
    //     return maintainMasterQuery.callProcedure06(data)
    // }
  }