import { Router } from "express";
import { getData07, getOrderId07 } from "../controllers/SPC0007Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0007Route = Router();

SPC0007Route.route("/SPC0007/getOrderData").post(
  authenticationMiddleware.bearer,
  getData07
);

SPC0007Route.route("/SPC0007/getOrderId").get(
  authenticationMiddleware.bearer,
  getOrderId07
);

export default SPC0007Route;
