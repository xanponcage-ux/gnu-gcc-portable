import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const getData = async (data: any) => {
  try {
    if (data?.type === "getData") {
      if (data?.Plant) {
        return {
          process: await ResponceData(
            await query(`
            select EPL_CD_PROCESS, EPL_CD_PROCESS||' - '||EPL_PROC_LINE_DESC EPL_PROC_LINE_DESC
            FROM V_EPA_PROC_LINE WHERE EPL_CD_EPA= ${data.Plant} AND EPL_CD_PROCESS != 'W' ORDER BY EPL_NO_PROC_SEQ, EPL_CD_PROCESS
            `)
          ),
          status: await ResponceData(
            await query(
              `select cd_value, cd_desc from v_codes where cd_type = 'TK018' `
            )
          ),
        };
      } else {
        return getCommonPlantData();
      }
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const getTableData = async (data: any) => {
  try {
    if (data.type === "tableData") {
      let sql = "";
      if (
        data.plant &&
        (data?.process === "N" ||
          data?.process === "T" ||
          data?.process === "E")
      ) {
        sql = `SELECT 
                  PDC_CD_EPA AS PLANT, 
                  PDC_ID_COIL AS BATCH, 
                  PDC_CURR_PROC AS CURR_PROC, 
                  PDC_WIDTH AS WIDTH,
                  PDC_THICK AS THICK, 
                  PDC_CUT_LENGTH AS LENGTH, 
                  PDC_TDC AS TDC, 
                  PDC_MASS AS MASS, 
                  PDC_ODIA AS ODIA, 
                  PDC_IDIA AS IDIA,
                  PDC_CAST_NO AS CAST_NO,  
                  PDC_MK_CUST AS MK_CUST, 
                  PDC_CUST_DESC AS CUST_DESC, 
                  PDC_SHIP_TO_PARTY AS SHIP_TO_PARTY,
                  PDC_DESTINATION AS DESTINATION, 
                  PDC_FREIGHT_MODE AS FREIGHT_MODE, 
                  PDC_NXT_PROC AS NXT_PROC,
                  PDC_PLANNED_PROC AS PLANNED_PROC, 
                  PDC_ORDER AS ODR, 
                  PDC_ITEM_NO AS ITEM_NO,
                  PDC_OUT_TDC AS OUT_TDC, 
                  PDC_OUT_GRADE_DESC AS OUT_GRADE_DESC, 
                  PDC_PACK_CODE AS PACK_CODE, 
                  PDC_PDI AS PDI,
                  PDC_SETUP_CODE AS SETUP_CODE, 
                  PDC_ID_PARENT_BATCH AS ID_PARENT_BATCH,
                  TO_CHAR(PDC_SCH_CRT_DT, 'DD-MM-YYYY HH24:MI:SS') AS SCH_CRT_DT, 
                  PDC_SCH_CRT_BY AS SCH_CRT_BY,
                  PDC_COMBINATION AS COMBINATION, 
                  PDC_SCHD_ID AS SCHD_ID, 
                  PDC_REWK_IND AS REWK_IND,
                  TO_CHAR(PDC_REC_CRT_DT, 'DD-MM-YYYY HH24:MI:SS') AS REC_CRT_DT, 
                  PDC_REC_CRT_BY AS REC_CRT_BY, 
                  PDC_PLAN_WT AS PLAN_WT,
                  PDC_SCH_WT AS SCH_WT, 
                  PDC_RM_MATNR AS RM_MATNR, 
                  PDC_FG_MATNR AS FG_MATNR, 
                  PDC_CD_STATUS AS CD_STATUS,
                  PDC_YIELD AS YIELD, 
                  PDC_UTS AS UTS, 
                  PDC_NO_PART AS NO_PART, 
                  PDC_PART_NUMBER AS PART_NUMBER,
                  PDC_NO_PACK AS NO_PACK,
                  PDC_NO_SHEETS AS NO_SHEETS,
                  NULL AS NO_SLIT,
                  PDC_UNCOIL_DIR AS UNCOIL_DIR, 
                  PDC_MAT_OIL AS MAT_OIL, 
                  PDC_OIL_TYPE_COIL AS OIL_TYPE_COIL, 
                  PDC_SLP_REMARKS AS SLP_REMARKS, 
                  PDC_EDGE_COND AS EDGE_COND,  
                  PDC_GRADE_DESC AS GRADE_DESC, 
                  PDC_OIL_MAX_QTY AS OIL_MAX_QTY, 
                  PDC_OIL_MIN_QTY AS OIL_MIN_QTY, 
                  PDC_OIL_TYPE AS OIL_TYPE, 
                  PDC_EDGE_WAVINESS AS EDGE_WAVINESS, 
                  PDC_CENTRE_BUCKLE AS CENTRE_BUCKLE, 
                  PDC_CROSSBOW AS CROSSBOW, 
                  PDC_CAMBER AS CAMBER, 
                  PDC_BURR_HEIGHT AS BURR_HEIGHT, 
                  PDC_SURF_REQ AS SURF_REQ, 
                  PDC_HORIZONTAL_GAP AS HORIZONTAL_GAP, 
                  PDC_VERTICAL_GAP AS VERTICAL_GAP, 
                  PDC_WIDTH_TOL AS WIDTH_TOL 
              FROM 
                  V_PR_DATA_IP_CTL 
              WHERE 
                  PDC_CD_STATUS IN ('WC','WS','WW','US','UP')
                  AND PDC_CD_EPA = '131' `;

        if (data?.process && data?.process?.length > 0) {
          sql += ` AND PDC_CURR_PROC LIKE NVL('${data.process}', PDC_CURR_PROC)`;
        }

        if (data?.status && data?.status?.length > 0) {
          sql += ` AND PDC_CD_STATUS LIKE NVL('${data.status}', PDC_CD_STATUS)`;
        }

        if (data?.schDtFrom && data?.schDtFrom.length !== "") {
          if (data?.schDtTo == "") {
            data.schDtTo = data.schDtFrom;
          }
          sql += ` AND PDC_SCH_CRT_DT BETWEEN 
              TO_DATE('${data.schDtFrom}', 'DD-MON-YY') AND TO_DATE('${data.schDtTo}', 'DD-MON-YY') + 1 - INTERVAL '1' SECOND`;
        }

        if (data?.batch && data?.batch?.length !== "") {
          sql += ` AND PDC_ID_COIL LIKE NVL('${data.batch}', PDC_ID_COIL)`;
        }
        sql += ` ORDER BY BATCH, SCH_CRT_DT`;
        // console.log("sqlCTL: ", sql);
      }

      // sql += ` UNION ALL `;

      if (data?.plant && data?.process === "S") {
        sql = ` SELECT 
          PDS_CD_EPA AS PLANT, 
          PDS_ID_COIL AS BATCH, 
          PDS_CURR_PROC AS CURR_PROC, 
          PDS_WIDTH AS WIDTH,
          PDS_THICK AS THICK, 
          PDS_LENGTH AS LENGTH, 
          PDS_TDC AS TDC, 
          PDS_MASS AS MASS, 
          PDS_ODIA AS ODIA, 
          PDS_IDIA AS IDIA,
          PDS_CAST_NO AS CAST_NO, 
          PDS_MK_CUST AS MK_CUST, 
          PDS_CUST_DESC AS CUST_DESC, 
          PDS_SHIP_TO_PARTY AS SHIP_TO_PARTY,
          PDS_DESTINATION AS DESTINATION, 
          PDS_FREIGHT_MODE AS FREIGHT_MODE, 
          PDS_NXT_PROC AS NXT_PROC,
          PDS_PLANNED_PROC AS PLANNED_PROC, 
          PDS_ORDER AS ODR, 
          PDS_ITEM_NO AS ITEM_NO,
          PDS_OUT_TDC AS OUT_TDC, 
          PDS_OUT_GRADE_DESC AS OUT_GRADE_DESC, 
          PDS_PACK_CODE AS PACK_CODE, 
          PDS_PDI AS PDI,
          PDS_SETUP_CODE AS SETUP_CODE, 
          PDS_ID_PARENT_BATCH AS ID_PARENT_BATCH,
          TO_CHAR(PDS_SCH_CRT_DT, 'DD-MM-YYYY HH24:MI:SS') AS SCH_CRT_DT, 
          PDS_SCH_CRT_BY AS SCH_CRT_BY,
          PDS_COMBINATION AS COMBINATION, 
          PDS_SCHD_ID AS SCHD_ID, 
          PDS_REWK_IND AS REWK_IND,
          TO_CHAR(PDS_REC_CRT_DT, 'DD-MM-YYYY HH24:MI:SS') AS REC_CRT_DT, 
          PDS_REC_CRT_BY AS REC_CRT_BY, 
          PDS_PLAN_WT AS PLAN_WT,
          PDS_SCH_WT AS SCH_WT, 
          PDS_RM_MATNR AS RM_MATNR, 
          PDS_FG_MATNR AS FG_MATNR, 
          PDS_CD_STATUS AS CD_STATUS,
          PDS_YIELD AS YIELD, 
          PDS_UTS AS UTS, 
          PDS_NO_PART AS NO_PART, 
          PDS_PART_NUMBER AS PART_NUMBER,
          NULL AS NO_PACK,
          NULL AS NO_SHEETS,
          PDS_NO_SLIT AS NO_SLIT,
          PDS_UNCOIL_DIR AS UNCOIL_DIR, 
          PDS_MAT_OIL AS MAT_OIL, 
          PDS_OIL_TYPE_COIL AS OIL_TYPE_COIL, 
          PDS_SLP_REMARKS AS SLP_REMARKS, 
          PDS_EDGE_COND AS EDGE_COND, 
          PDS_GRADE_DESC AS GRADE_DESC, 
          PDS_OIL_MAX_QTY AS OIL_MAX_QTY, 
          PDS_OIL_MIN_QTY AS OIL_MIN_QTY, 
          PDS_OIL_TYPE AS OIL_TYPE, 
          PDS_EDGE_WAVINESS AS EDGE_WAVINESS, 
          PDS_CENTRE_BUCKLE AS CENTRE_BUCKLE, 
          PDS_CROSSBOW AS CROSSBOW, 
          PDS_CAMBER AS CAMBER, 
          PDS_BURR_HEIGHT AS BURR_HEIGHT, 
          PDS_SURF_REQ AS SURF_REQ, 
          PDS_HORIZONTAL_GAP AS HORIZONTAL_GAP, 
          PDS_VERTICAL_GAP AS VERTICAL_GAP, 
          PDS_WIDTH_TOL AS WIDTH_TOL
      FROM 
          V_PR_DATA_IP_SLT 
      WHERE 
          PDS_CD_STATUS IN ('WC','WS','WW','US','UP')
          AND PDS_CD_EPA = '131'`;

        if (data?.process && data?.process?.length > 0) {
          sql += ` AND PDS_CURR_PROC LIKE NVL('${data.process}', PDS_CURR_PROC)`;
        }

        if (data?.status && data?.status?.length > 0) {
          sql += ` AND PDS_CD_STATUS LIKE NVL('${data.status}', PDS_CD_STATUS)`;
        }

        if (data?.schDtFrom && data?.schDtFrom.length !== "") {
          if (data?.schDtTo == "") {
            data.schDtTo = data.schDtFrom;
          }
          sql += ` AND PDS_SCH_CRT_DT BETWEEN 
      TO_DATE('${data.schDtFrom}', 'DD-MON-YY') AND TO_DATE('${data.schDtTo}', 'DD-MON-YY') + 1 - INTERVAL '1' SECOND`;
        }

        if (data?.batch && data?.batch?.length !== "") {
          sql += ` AND PDS_ID_COIL LIKE NVL('${data.batch}', PDS_ID_COIL)`;
        }
        sql += ` ORDER BY BATCH, SCH_CRT_DT`;
        // console.log("sqlSLT: ", sql);
      }

      // sql += ` UNION ALL `;
      else if (data?.plant && data?.process === "K") {
        sql = `  SELECT
          CID_CD_EPA AS PLANT,
          CID_ID_COIL AS BATCH,
          CID_CURR_PROC AS CURR_PROC,
          CID_WIDTH AS WIDTH,
          CID_THICK AS THICK,
          CID_LENGTH AS LENGTH,
          CID_OUT_TDC AS TDC,
          CID_MASS AS MASS,
          CID_ODIA AS ODIA,
          CID_IDIA AS IDIA,
          CID_CAST_NO AS CAST_NO,
          CID_MK_CUST AS MK_CUST,
          CID_CUST_DESC AS CUST_DESC,
          CID_SHIP_TO_PARTY AS SHIP_TO_PARTY,
          CID_DESTINATION AS DESTINATION,
          CID_FREIGHT_MODE AS FREIGHT_MODE,
          CID_NXT_PROC AS NXT_PROC,
          CID_PLANNED_PROC AS PLANNED_PROC,
          CID_ORDER AS ODR,
          CID_ITEM_NO AS ITEM_NO,
          CID_OUT_TDC AS OUT_TDC,
          CID_GRADE_DESC AS OUT_GRADE_DESC,
          CID_PACK_CODE AS PACK_CODE,
          CID_PDI AS PDI,
          NULL AS SETUP_CODE,
          CID_ID_INPUT_COIL AS ID_PARENT_BATCH,
          TO_CHAR(CID_SCH_CONF_DT, 'DD-MM-YYYY HH24:MI:SS') AS SCH_CRT_DT,
          CID_SCH_CONF_BY AS SCH_CRT_BY,
          NULL AS COMBINATION,
          CID_SCHD_ID AS SCHD_ID,
          NULL AS REWK_IND,
          TO_CHAR(NULL, 'DD-MM-YYYY HH24:MI:SS') AS REC_CRT_DT,
          NULL AS REC_CRT_BY,
          NULL AS PLAN_WT,
          CID_MASS AS SCH_WT,
          NULL AS RM_MATNR,
          NULL AS FG_MATNR,
          CID_CD_STATUS AS CD_STATUS,
          CID_YIELD AS YIELD,
          CID_UTS AS UTS,
          NULL AS NO_PART,
          CID_PART_NUMBER AS PART_NUMBER,
          NULL AS NO_PACK,
          NULL AS NO_SHEETS,
          NULL AS NO_SLIT
      FROM
          V_PR_DATA_IP_CPL
      WHERE
          CID_CD_STATUS IN ('WC','WS','WW','US','UP')
          AND CID_CD_EPA = '131' `;

        if (data?.process && data?.process?.length > 0) {
          sql += ` AND CID_CURR_PROC LIKE NVL('${data.process}', CID_CURR_PROC)`;
        }

        if (data?.status && data?.status?.length > 0) {
          sql += ` AND CID_CD_STATUS LIKE NVL('${data.status}', CID_CD_STATUS)`;
        }

        // if (data?.schDtFrom && data?.schDtFrom.length !== "") {
        //   if (data?.schDtTo == "") {
        //     data.schDtTo = data.schDtFrom;
        //   }
        //   sql += ` AND PDS_SCH_CRT_DT BETWEEN
        //       TO_DATE('${data.schDtFrom}', 'DD-MON-YY') AND TO_DATE('${data.schDtTo}', 'DD-MON-YY') + 1 - INTERVAL '1' SECOND`;
        // }

        if (data?.batch && data?.batch?.length !== "") {
          sql += ` AND CID_ID_COIL LIKE NVL('${data.batch}', CID_ID_COIL)`;
        }

        sql += ` ORDER BY BATCH, SCH_CRT_DT`;
        // console.log("sqlK: ", sql);
      }

      return await query(sql);
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerError(error?.toString());
  }
};
