export interface TokenType {
    accessToken: string,
    refreshToken: string,
    user: string
}

export interface CulmnType {
    formatter?: any, //table type
    titleFormatter?: any, //table type
    hozAlign?: any, //table type
    download?: boolean,
    headerSort?: boolean,
    frozen?: boolean,
    title: string,
    field?: string,
    width?: number,
    cellClick?: any; //table type
    editor?: any,
    editorParams?: any,
    headerFilter?: any, //table type
    headerFilterPlaceholder?: string,
    validator?:any,
    cellEdited?:any,
    visible?:boolean,
    validatorParams?:any,
    // bottomCalc?: string,
    // columns?: string,
}