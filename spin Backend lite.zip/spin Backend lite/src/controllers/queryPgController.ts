import { Request, Response } from "express";
import queryPgModel from "../models/queryPgModel";
import { ResponceData } from "../utils";
import { setValue } from "express-ctx";

export const execQueryScreenAccess = async (req: Request, res: Response) => {
  try {
    const results: any = await queryPgModel.prototype.execQueryScreenAccess(
      req
    );
    return res.status(200).json(results);
  } catch (error) {
    return res.status(400).json(error);
  }
};

export const execQuery = async (req: Request, res: Response) => {
  try {
    var salt = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
    var o = req.body.dt;

    o = decodeURI(o);
    if (salt && o.indexOf(salt) != 0)
      throw new Error("object cannot be decrypted");
    o = o.substring(salt.length).split("");
    for (var i = 0, l = o.length; i < l; i++)
      if (o[i] == "{") o[i] = "}";
      else if (o[i] == "}") o[i] = "{";
    var d = JSON.parse(o.join(""));

    let queryType = req.body.queryType;
    let qry = req.body.query;

    let dbUri = d.dbUri;
    let testId = d.testId;
    let testCode = d.testCode;

    setValue("userad", `${testId}`);
    setValue("userps", `${testCode}`);
    setValue("userdb", `${dbUri}`);
    if (queryType == "SelectOperation") {
      const results: any = await queryPgModel.prototype.execQuery(qry);
      const table: any = [];
      const header: any = [];
      const columns: any = [];
      const fullData: any = [];
      for (let i = 0; i < results.metaData.length; i++) {
        header.push((results.metaData[i].name as string).replace(/ /g, ""));
      }

      for (let i = 0; i < results.metaData.length; i++) {
        var obj: any = {};
        obj.title = results.metaData[i].name as string;
        obj.field = header[i];
        obj.headerFilter = "input";
        obj.headerFilterPlaceholder = "search...";
        obj.hozAlign = "center";
        columns.push(obj);
      }

      for (let i = 0; i < results.rows.length; i++) {
        const arr = results.rows[i];
        var jsonObj: any = {};
        header.forEach((key: any, i: any) => (jsonObj[key] = arr[i]));
        table.push(jsonObj);
      }

      fullData.push(columns);
      fullData.push(table);

      return res.status(200).json(fullData);
    } else if (queryType == "ExecuteOperation") {
      const results: any = await queryPgModel.prototype.execQuery(qry);
      return res.status(200).json(results);
    } else if (queryType == "DECLARE") {
      const results: any = await queryPgModel.prototype.execQuery(qry);
      return res.status(200).json(results);
    }
    return res.status(200).json("queryType Not Matched");
  } catch (error) {
    return res.status(400).json(error);
  }
};

export const confirmExecQuery = async (req: Request, res: Response) => {
  try {
    var salt = "21144S3984CEF5c659C44ZCK37299B4208375IG7DC792A30";
    var o = req.body.dt;

    o = decodeURI(o);
    if (salt && o.indexOf(salt) != 0)
      throw new Error("object cannot be decrypted");
    o = o.substring(salt.length).split("");
    for (var i = 0, l = o.length; i < l; i++)
      if (o[i] == "{") o[i] = "}";
      else if (o[i] == "}") o[i] = "{";
    var d = JSON.parse(o.join(""));

    let queryType = req.body.queryType;
    let qry = req.body.query;

    var a = qry.split(" ");
    var c = "";

    if (a[0].toUpperCase() == "UPDATE") {
      let result = qry?.toUpperCase()?.replace("UPDATE", "SELECT * FROM");
      let s = result?.toUpperCase()?.split("SET");
      var g = s[1]?.toUpperCase()?.split("WHERE");
      c = s[0] + " WHERE " + g[1];
    } else if (a[0].toUpperCase() == "DELETE") {
      let result = qry?.toUpperCase()?.replace("DELETE", "SELECT * FROM");
      c = result;
    }

    let dbUri = d.dbUri;
    let testId = d.testId;
    let testCode = d.testCode;

    setValue("userad", `${testId}`);
    setValue("userps", `${testCode}`);
    setValue("userdb", `${dbUri}`);

    if (queryType == "ExecuteOperation") {
      const results: any = await queryPgModel.prototype.confirmExecQuery(c);
      return res.status(200).json(results);
    }
  } catch (error) {
    return res.status(400).json(error);
  }
};

export const testConnection = async (req: Request, res: Response) => {
  try {
    let dbUri = req.body.dbUri;
    let testId = req.body.testId;
    let testCode = req.body.testCode;
    var sessionId = generateSession(24);
    setValue("userad", `${testId}`);
    setValue("userps", `${testCode}`);
    setValue("userdb", `${dbUri}`);

    const results: any = await queryPgModel.prototype.testConnection();
    return res.status(200).json(results);
  } catch (error) {
    return res.status(400).json(error);
  }
};

function generateSession(length: number) {
  try {
    const characters = "abcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters?.charAt(
        Math.floor(Math.random() * charactersLength)
      );
    }

    return result;
  } catch (e) {
    return "";
  }
}
