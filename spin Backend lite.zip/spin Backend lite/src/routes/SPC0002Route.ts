import { Router } from "express";
import { getData02 } from "../controllers/SPC0002Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";
import { Post } from "../typed/typed";

const SPC0002Route = Router();

SPC0002Route.route("/SPC0002/getData").post(
  authenticationMiddleware.bearer,
  getData02
);

export default SPC0002Route;
