const SPC0009Query = require("../repository/SPC0009Query");

export default class SPC0009Model {
  // getPlantData() {
  //   return SPC0009Query.getPlantData();
  // }

  getYieldData(data: any) {
    return SPC0009Query.getYieldData(data);
  }
}
