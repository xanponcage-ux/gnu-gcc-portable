class InvalidArgumentError extends Error {
  constructor(mensagem: string) {
    super(mensagem);
    this.name = "InvalidArgumentError";
  }
}

class InternalServerError extends Error {
  constructor(mensagem: string) {
    super(mensagem);
    this.name = "InternalServerError";
  }
}

class InternalServerErrorMsg extends Error {
  constructor(error: any) {
    super(error.message);
    this.name = error?.message;
    this.message = error?.message?.replace(/ORA-+[0-9]+: /, "");
  }
}

class NotAuthorized extends Error {
  constructor() {
    const mensagem = "Não foi possível acessar esse recurso";
    super(mensagem);
    this.name = "NotAuthorized";
  }
}

class DBError extends Error {
  constructor(message: any) {
    super(message);
    this.name = message;
    this.message = message?.replace(/ORA-+[0-9]+: /, "");
  }
}

class DBError2 extends Error {
  constructor(error: any) {
    super(error.message);
    this.name = error.message;
    this.message = error.message?.replace(/ORA-+[0-9]+: /, "");
  }
}

export default {
  InvalidArgumentError,
  InternalServerError,
  InternalServerErrorMsg,
  NotAuthorized,
  DBError,
  DBError2,
};
