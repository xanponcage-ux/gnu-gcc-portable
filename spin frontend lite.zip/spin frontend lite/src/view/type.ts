import { Dayjs } from "dayjs"
import { SelectType } from "src/components/input/type"

export interface input {
    config: {
        type: string,
        label?: string,
        sideLabel?: string,
        eIcon?: JSX.Element,
        sIcon?: JSX.Element,
        autoFocus?: boolean,
        disabled?: boolean,
        readOnly?: boolean
        size?: "small" | "medium"
    },
    value: string,
    data?: Array<SelectType>,
    onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement>
}
export interface dateInput {
    config: {
        type: string,
        label?: string,
        sideLabel?: string,
        eIcon?: JSX.Element,
        sIcon?: JSX.Element,
        autoFocus?: boolean,
        disabled?: boolean
    },
    value: string,
    onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement | Dayjs>
}

export interface LoopMsg {
    id: string,
    msg: string,
}