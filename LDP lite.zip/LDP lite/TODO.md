# LD13S002 Duplication from LD09S002

## Completed:

All steps done.

## Test:

Restart server, POST /api/LD13S002/getcoils with auth and body e.g. {"plant": "yourplant"}.

Updated after creates.
