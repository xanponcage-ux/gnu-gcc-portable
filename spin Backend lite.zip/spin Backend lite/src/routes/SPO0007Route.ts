import { Router } from "express";
import { getData } from "../controllers/SPO0007Controller";
import authenticationMiddleware from "../middlewares/authenticationMiddleware";

const SPO0007Route = Router();

SPO0007Route.route("/SPO0007/getData").post(
  authenticationMiddleware.bearer,
  getData
);

export default SPO0007Route;
