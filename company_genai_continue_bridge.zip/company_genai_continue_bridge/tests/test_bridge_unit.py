import importlib
import json
import os
import sys


os.environ.setdefault("TATA_GENAI_API_KEY", "test-key")
os.environ.setdefault("TATA_ADID", "123456")
os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", __file__)
os.environ.setdefault("BRIDGE_LOCAL_TOKEN", "test-local-token")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
bridge = importlib.import_module("bridge")


def test_gpt_response_is_preserved():
    body = {
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}}]
    }
    result = bridge._to_openai_response(body, "gpt-4o-mini")
    assert result["choices"][0]["message"]["content"] == "ok"
    assert result["object"] == "chat.completion"


def test_gemini_response_is_converted():
    body = {
        "candidates": [{"content": {"parts": [{"text": "hello"}]}, "finishReason": "STOP"}],
        "usage_metadata": {"prompt_token_count": 3, "candidates_token_count": 2, "total_token_count": 5},
    }
    result = bridge._to_openai_response(body, "gemini-2.0-flash")
    assert result["choices"][0]["message"]["content"] == "hello"
    assert result["usage"]["total_tokens"] == 5


def test_stream_contains_done_and_tools():
    result = {
        "id": "chatcmpl-test",
        "created": 1,
        "model": "gpt-4o-mini",
        "choices": [{
            "message": {
                "role": "assistant",
                "content": None,
                "tool_calls": [{"id": "x", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}],
            },
            "finish_reason": "tool_calls",
        }],
    }
    text = "".join(bridge._sse_response(result))
    assert "tool_calls" in text
    assert "data: [DONE]" in text


def test_gateway_payload_forwards_code_tools():
    captured = {}

    class FakeResponse:
        ok = True
        status_code = 200

        @staticmethod
        def json():
            return {
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "done"},
                        "finish_reason": "stop",
                    }
                ]
            }

    class FakeSession:
        def post(self, endpoint, **kwargs):
            captured["endpoint"] = endpoint
            captured.update(kwargs)
            return FakeResponse()

    client = bridge.GatewayClient.__new__(bridge.GatewayClient)
    client.session = FakeSession()
    request = bridge.ChatRequest(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "inspect the file"}],
        tools=[
            {
                "type": "function",
                "function": {"name": "read_file", "parameters": {"type": "object"}},
            }
        ],
    )
    result = client.chat(request)
    assert captured["data"]["deployment_name"] == "gpt-4o-mini"
    assert json.loads(captured["data"]["tools"])[0]["function"]["name"] == "read_file"
    assert result["choices"][0]["message"]["content"] == "done"
