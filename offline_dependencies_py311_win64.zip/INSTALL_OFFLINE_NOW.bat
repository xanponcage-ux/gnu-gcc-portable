@echo off
setlocal
cd /d "%~dp0"

if not exist requirements.txt (
  echo requirements.txt is missing.
  echo Extract this ZIP INSIDE the company_genai_continue_bridge folder.
  pause
  exit /b 1
)

if not exist .venv\Scripts\python.exe (
  echo Creating the Python environment...
  python -m venv .venv
  if errorlevel 1 goto :failed
)

echo Installing packages from the local wheels folder only...
.venv\Scripts\python.exe -m pip install --no-index --find-links=wheels -r requirements.txt
if errorlevel 1 goto :failed

echo.
echo SUCCESS: Offline dependencies are installed.
echo Next run start_bridge.bat and keep that window open.
pause
exit /b 0

:failed
echo.
echo Installation failed. Run python --version and send a photo of the result.
pause
exit /b 1
