import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { ResponceData } from "../utils";
import { getCommonPlantData } from "./plantQuery";

export const SCQ001GetFilterData = async (data: any) => {
  try {
    if (data?.type === "SCQ001GetFilterData") {
      return {
        PlanCode: await ResponceData(await getCommonPlantData()),

        Status: await ResponceData(
          await query(` SELECT CD_VALUE FROM V_CODES
            WHERE CD_TYPE='TK001'
            ORDER BY 1 `)
        ),
      };
    }
  } catch (error: any) {
    throw new Error.InternalServerError(error?.toString());
  }
};

export const SCQ001GetData = async (data: any) => {
  try {
    //if (data?.data.plant) {
    if (data?.type === "SCQ001getBatchData") {
      let sql: any = `SELECT EOM_ID_BATCH,EOM_CD_EPA,EOM_CD_PROD,EOM_CD_QLTY_AIM,EOM_MS_GROSS_ACTL,EOM_SEC1,EOM_CD_QLTY_ACTL,EOM_TDC_AIM,
      EOM_SEC2,EOM_MS_PIECE_ACTL,EOM_TDC_ACTL,EOM_LENGTH,EOM_MS_GROSS_CAL,EOM_CD_CURR_PROC,
      EOM_CD_STATUS,EOM_CD_NEXT_PROC,EOM_ID_ORDER_CUS,EOM_ID_ORD_ITEM_CUS, EOM_OPER_COMMENT
      ,EOM_ID_PAR_COIL_NO, EOM_ID_FIRST_PAR,(select ENC_CUST_NAME from v_end_cust_ord_epa 
        where ENC_CD_EPA = EOM_CD_EPA  and ENC_ID_ORDER  = EOM_ID_ORDER_CUS 
        and ENC_NO_ITEM = EOM_ID_ORD_ITEM_CUS and ROWNUM = 1) ENC_CUST_NAME
      ,EOM_NO_PIECES
      FROM V_EPA_PRODN A
      WHERE EOM_CD_EPA= '${data?.data.plant}'
      AND EOM_ID_BATCH  IN (SELECT CHR_ID_COIL FROM V_COIL_HOLD_RLS
        WHERE CHR_ID_COIL= A.EOM_ID_BATCH
        AND CHR_CD_RSN_HOLD NOT IN ('M01','L01')
      ) `;
      if (data?.data.status && data?.data.status?.length > 0) {
        sql += ` AND EOM_CD_STATUS LIKE '${data?.data.status}'`;
      }
      if (data?.data.batchId && data?.data.batchId?.length > 0) {
        sql += ` AND EOM_ID_BATCH = '${data?.data.batchId}' `;
      }
      if (data?.data.coilId && data?.data.coilId?.length > 0) {
        sql += ` AND (EOM_ID_PAR_COIL_NO='${data?.data.coilId}' 
                 OR EOM_ID_FIRST_PAR='${data?.data.coilId}')`;
      }
      return await ResponceData(await query(sql));
    } else if (data?.type === "getDowngradeTdc") {
      let sql: any = `
                SELECT DISTINCT ESP_TDC_DOWNGRADE
                FROM V_EPA_SECONDS_PRIME_TDC
                WHERE ESP_CD_EPA='131'
                AND ESP_TDC_PRIME= '${data.data?.PrimeTdc}'
                ORDER BY 1 `;
      return {
        DowngradeTdc: await ResponceData(await query(sql)),
      };
    } else if (data?.type === "getAddlProcess") {
      let sql: any = `
                SELECT CD_VALUE, CD_DESC FROM V_CODES WHERE CD_TYPE = 'TK020' `;
      return {
        AddlProcess: await ResponceData(await query(sql)),
      };
    } else if (data?.type === "getHoldRsnCode") {
      let qryHoldRsnCode = `SELECT   TO_CHAR (ch.chr_ts_hold, 'DD-MM-YYYY HH24:MI:SS') AS chr_ts_hold,
                            ch.chr_cd_rsn_hold, vh.cd_desc
                            FROM v_coil_hold_rls ch JOIN v_epa_hold_rsn vh
                                  ON ch.chr_cd_rsn_hold = vh.cd_hold
                            WHERE ch.chr_id_coil = '${data?.data.BatchNo}'
                            and CHR_ID_OP_RELEASE IS NULL
                          ORDER BY cd_hold`;
      return { hold_rsn_cd: await ResponceData(await query(qryHoldRsnCode)) };
    } else if (data?.type == "getRemarks") {
      return {
        RemarkLists: await ResponceData(
          await query(`SELECT CD_DESC FROM V_CODES WHERE CD_TYPE = 'TK016'`)
        ),
      };
    } else if (data?.type === "getReasonCategory") {
      let qry = `SELECT DISTINCT ESR_RSN_CAT,ESR_RSN_CD,ESR_RSN_DESC FROM V_SCRP_SEC_RSN
                WHERE ESR_CD_EPA='131'
                AND ESR_STATUS='A'
                AND ESR_RSN_CAT = '${data?.rsnCat}'
                ORDER BY 1 `;
      return {
        REASON_DESP: await ResponceData(await query(qry)),
      };
    } else if (data?.type === "getDiversionTdc") {
      console.log("DivData: ", data);
      let sql: any = `select TDM_END_TDC DIV_TDC from v_tdc_map where TDM_ACT_TDC = '${data?.data?.PrimeTdc}'
                      and TDM_CD_EPA = '131'
                      and TDM_CD_STATUS = 'A'`;
      console.log("sql-DivData: ", sql);
      // let sql: any = ` SELECT TIC_TDC_NO FROM v_coil_tdc
      //                 where tic_id_coil='${data?.data?.BatchId}' `;
      return {
        DiversionTdc: await ResponceData(await query(sql)),
      };
    }
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ001ColumnData = async (data: any) => {
  try {
    let Column1: any = await ResponceData(await query(``));
    let Column2: any = await ResponceData(await query(``));
    let Column3: any = await ResponceData(await query(``));
    return { Column1: Column1, Column2: Column2, Column3: Column3 };
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ001GetPopUpData = async (data: any) => {
  try {
    if (data?.type === "Downgrade") {
      return await ResponceData(
        await query(`SELECT DISTINCT ESP_TDC_DOWNGRADE
        FROM V_EPA_SECONDS_PRIME_TDC
        WHERE ESP_CD_EPA='131'
        --AND ESP_TDC_PRIME= '${data?.PrimeTdc}'
        ORDER BY 1`)
      );
    } else if (data?.type === "getReasonCategory") {
      let reason_category = await ResponceData(
        await query(
          `SELECT DISTINCT ESR_RSN_CAT, ESR_RSN_YIELD FROM V_SCRP_SEC_RSN WHERE ESR_CD_EPA='131' AND ESR_STATUS='A' ORDER BY ESR_RSN_YIELD`
        )
      );

      let material_no = await ResponceData(
        await query(`
        SELECT SUBSTR (cd_desc, 1, 18) matnr, cd_desc matnrdesc
          FROM v_codes
         WHERE cd_type = 'TK011'`)
      );

      return { REASON_CATEGORY: reason_category, material_no: material_no };
    }
    // else if (data?.type === "Downgrade") {
    // }
    else if (data?.type == "getRemarks") {
      return await ResponceData(
        await query(`SELECT CD_DESC FROM V_CODES WHERE CD_TYPE = 'TK016'`)
      );
    } else if (data?.type == "getHoldNo") {
      return await ResponceData(
        await query(`SELECT   TO_CHAR (ch.chr_ts_hold, 'DD-MM-YYYY HH24:MI:SS') AS chr_ts_hold,
          ch.chr_cd_rsn_hold, vh.cd_desc
          FROM v_coil_hold_rls ch JOIN v_epa_hold_rsn vh
                ON ch.chr_cd_rsn_hold = vh.cd_hold
          WHERE ch.chr_id_coil = '${data?.BatchNo}'
          ORDER BY cd_hold`)
      );
    } else if (data?.type == "getRsnCodeData") {
      let binds = {
        rsnCat: data?.rsnCat,
      };
      let reason_desp = `SELECT DISTINCT ESR_RSN_CAT,ESR_RSN_CD,ESR_RSN_DESC FROM V_SCRP_SEC_RSN
    WHERE ESR_CD_EPA='131'
    AND ESR_STATUS='A'
    AND ESR_RSN_CAT = '${data?.rsnCat}'
    ORDER BY 1 `;
      return { REASON_DESP: await ResponceData(await query(reason_desp)) };
    }
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getRsnCodeData = async (data: any) => {
  try {
    let binds = {
      rsnCat: data?.rsnCat,
    };

    let reason_desp = await ResponceData(
      await query(
        `SELECT DISTINCT ESR_RSN_CAT,ESR_RSN_CD,ESR_RSN_DESC FROM V_SCRP_SEC_RSN
           WHERE ESR_CD_EPA='131'
           AND ESR_STATUS='A'
           AND ESR_RSN_CAT = '${data?.rsnCat}'
           ORDER BY 1 `
      )
    );
    return { REASON_DESP: reason_desp };
  } catch (error) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ001SaveData = async (inputData: any) => {
  try {
    let data = inputData?.data;

    console.log("SCQ001SaveData - data: ", data);

    // For Scrap
    if (data?.p_radio_value === "9") {
      // console.log("Inside radio 9");
      let countY = 0;
      let len = data?.reasonData?.length;
      // console.log("Reason Data: ", data?.reasonData);
      await query(`DELETE FROM V_EPA_BATCH_SCRAP_TEMP WHERE EBS_CD_ePA='131'`);
      for (let i = 0; i < len; i++) {
        let sql1: any = `call TDSB0004 (
          ls_batchid => :ls_batchid,
          ls_process => :ls_process,
          ls_rsn_cat => :ls_rsn_cat,
          ls_rsn_cd_old => :ls_rsn_cd_old,
          ls_rsn_cd_new => :ls_rsn_cd_new,
          lv_scrp_matl => :lv_scrp_matl,
          ls_sel_fl => :ls_sel_fl,
          ls_scrap_qty_indv => :ls_scrap_qty_indv,
          ls_ms_scrp_tot => :ls_ms_scrp_tot,
          ln_rowind => :ln_rowind,
          ln_totrow => :ln_totrow,
          ls_pageid => :ls_pageid,
          ls_out_flag => :ls_out_flag
          )`;
        const binds = {
          ls_batchid: data?.p_batch ? data?.p_batch : "",
          ls_process: data?.p_curr_proc ? data?.p_curr_proc : "",
          ls_rsn_cat: data?.reasonData[i]?.Column1
            ? data?.reasonData[i]?.Column1
            : "",
          ls_rsn_cd_old: data?.reasonData[i]?.Column2?.split("-")[0]
            ? data?.reasonData[i]?.Column2?.split("-")[0]
            : "",
          ls_rsn_cd_new: data?.reasonData[i]?.Column2?.split("-")[0]
            ? data?.reasonData[i]?.Column2?.split("-")[0]
            : "",
          lv_scrp_matl: data?.reasonData[i]?.Column5?.split("-")[0]
            ? data?.reasonData[i]?.Column5?.split("-")[0]
            : "",
          ls_sel_fl: "Y1",
          ls_scrap_qty_indv: data?.reasonData[i]?.Column4
            ? data?.reasonData[i]?.Column4
            : "",
          ls_ms_scrp_tot: data?.p_gross_cal ? String(data?.p_gross_cal) : "",
          ln_rowind: String(i + 1),
          ln_totrow: String(len),
          ls_pageid: "SCQ001",
          ls_out_flag: {
            type: oracledb.STRING,
            dir: oracledb.BIND_OUT,
            maxSize: 2000,
          },
        };
        // console.log("sql1: ", sql1);
        // console.log("binds1: ", binds);

        const result = await query(sql1, binds);
        // console.log("Result ===> ", result);
        if (result?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
          countY += 1;
        }
        console.log("countY: ", countY);
        // await query(sql1, binds);
      }

      // console.log("countY: ", countY);
      if (countY === len) {
        console.log("Inside equal");

        // let sql: any = `call TRMQ0005(
        //   p_plant => :p_plant,
        //   p_radio_value => :p_radio_value,
        //   p_batch => :p_batch,
        //   p_addl_proc => :p_addl_proc,
        //   p_sec_tdc => :p_sec_tdc,
        //   p_hold_rsn_cd => :p_hold_rsn_cd,
        //   p_remarks => :p_remarks,
        //   p_remarks1 => :p_remarks1,
        //   p_gross_wt => :p_gross_wt,
        //   p_no_sheet => :p_no_sheet,
        //   p_new_net_wt => :p_new_net_wt,
        //   ls_out_flag => :ls_out_flag
        // )`;
        // const binds = {
        //   p_plant: data.p_plant ? data.p_plant : "",
        //   p_radio_value: data.p_radio_value ? data.p_radio_value : "",
        //   p_batch: data.p_batch ? data.p_batch : "",
        //   p_sec_tdc: data.p_sec_tdc ? data.p_sec_tdc : "",
        //   p_hold_rsn_cd: data.p_rls_hold_code ? data.p_rls_hold_code : "",
        //   p_remarks: data.p_rls_remarks ? data.p_rls_remarks : "",
        //   p_remarks1: data.p_rls_remarks1 ? data.p_rls_remarks1 : "",
        //   p_addl_proc: data.p_addl_process ? data.p_addl_process : "",
        //   p_gross_wt: data?.p_gross_wt ? data?.p_gross_wt : "",
        //   p_no_sheet: data?.p_no_sheet ? data?.p_no_sheet : "",
        //   p_new_net_wt: data?.p_new_net_wt ? data?.p_new_net_wt : "",
        //   ls_out_flag: {
        //     type: oracledb.STRING,
        //     dir: oracledb.BIND_OUT,
        //     maxSize: 500,
        //   },
        // };
        // console.log("sqlQry: ", sql);
        const result5 = await SCQ001Decision(data); //query(sql, binds);
        console.log("result5: ", result5);
        return result5;
      } else {
        return "Couldn't Scrap";
      }
    }
    // For Downgrade
    else if (data?.p_radio_value === "5") {
      console.log("Inside radio 5");

      await query(
        ` DELETE FROM V_EPA_BATCH_SECONDS_TEMP WHERE EBS_ID_BATCH = '${data?.p_batch}' `
      );

      // console.log("Inside radio 8 after delete qry");

      let countY = 0;
      let len = data?.reasonData?.length;
      // console.log("Reason Data: ", data?.reasonData);

      for (let i = 0; i < len; i++) {
        let sql1: any = `call TDSB0003 (
          ls_batchid  => :ls_batchid,
          ls_process  => :ls_process,
          ls_rsn_cat  => :ls_rsn_cat,
          ls_rsn_cd  => :ls_rsn_cd,
          ls_downgrd_qty_indv  => :ls_downgrd_qty_indv,
          ls_downgrd_qty_tot  => :ls_downgrd_qty_tot,
          lv_sec_matl  => :lv_sec_matl,
          ln_rowind  => :ln_rowind,
          ln_totrow  => :ln_totrow,
          ls_pageid  => :ls_pageid,
          ls_out_flag  => :ls_out_flag
        )`;

        const binds = {
          ls_batchid: data?.p_batch ? data?.p_batch : "",
          ls_process: data?.p_curr_proc ? data?.p_curr_proc : "",
          ls_rsn_cat: data?.reasonData[i]?.Column1
            ? data?.reasonData[i]?.Column1
            : "",
          ls_rsn_cd: data?.reasonData[i]?.Column2?.split("-")[0]
            ? data?.reasonData[i]?.Column2?.split("-")[0]
            : "",
          ls_downgrd_qty_indv: data?.reasonData[i]?.Column4
            ? data?.reasonData[i]?.Column4
            : "",
          ls_downgrd_qty_tot: data?.p_gross_cal
            ? String(data?.p_gross_cal)
            : "",
          lv_sec_matl: "0",
          ln_rowind: String(i + 1),
          ln_totrow: String(len),
          ls_pageid: "SCQ001",
          ls_out_flag: {
            type: oracledb.STRING,
            dir: oracledb.BIND_OUT,
            maxSize: 2000,
          },
        };

        // console.log("sql1: ", sql1);
        // console.log("binds1: ", binds);

        const result = await query(sql1, binds);
        // console.log(":===> ", result);

        if (result?.outBinds?.ls_out_flag?.substr(0, 1) === "Y") {
          countY += 1;
        }
        // console.log("countY: ", countY);
      }

      if (countY === len) {
        // console.log("Inside equal");

        // let sql = `call TRMQ0005(
        //   p_plant => :p_plant,
        //   p_radio_value => :p_radio_value,
        //   p_batch => :p_batch,
        //   p_addl_proc => :p_addl_proc,
        //   p_sec_tdc => :p_sec_tdc,
        //   p_hold_rsn_cd => :p_hold_rsn_cd,
        //   p_remarks => :p_remarks,
        //   p_remarks1 => :p_remarks1,
        //   p_gross_wt => :p_gross_wt,
        //   p_no_sheet => :p_no_sheet,
        //   p_new_net_wt => :p_new_net_wt,
        //   ls_out_flag => :ls_out_flag
        // )`;

        // const binds = {
        //   p_plant: data.p_plant || "",
        //   p_radio_value: data.p_radio_value || "",
        //   p_batch: data.p_batch || "",
        //   p_sec_tdc: data.p_sec_tdc || "",
        //   p_hold_rsn_cd: data.p_rls_hold_code || "",
        //   p_remarks: data.p_rls_remarks || "",
        //   p_remarks1: data.p_rls_remarks1 || "",
        //   p_addl_proc: data.p_addl_process || "",
        //   p_gross_wt: data?.p_gross_wt ? data?.p_gross_wt : "",
        //   p_no_sheet: data?.p_no_sheet ? data?.p_no_sheet : "",
        //   p_new_net_wt: data?.p_new_net_wt ? data?.p_new_net_wt : "",
        //   ls_out_flag: {
        //     type: oracledb.STRING,
        //     dir: oracledb.BIND_OUT,
        //     maxSize: 500,
        //   },
        // };

        // console.log("sqlQry: ", sql);
        // console.log("binds5: ", binds);
        // const result5 = await query(sql, binds);
        const result6 = await SCQ001Decision(data); //query(sql, binds);

        console.log("result6-Downgarde: ", result6);
        return result6;
      } else {
        return "Couldn't Downgrade";
      }
    } else {
      // console.log("Inside Last part");
      //   let sql: any = `call TRMQ0005(
      //   p_plant => :p_plant,
      //   p_radio_value => :p_radio_value,
      //   p_batch => :p_batch,
      //   p_addl_proc => :p_addl_proc,
      //   p_sec_tdc => :p_sec_tdc,
      //   p_hold_rsn_cd => :p_hold_rsn_cd,
      //   p_remarks => :p_remarks,
      //   p_remarks1 => :p_remarks1,
      //   p_gross_wt => :p_gross_wt,
      //   p_no_sheet => :p_no_sheet,
      //   p_new_net_wt => :p_new_net_wt,
      //   ls_out_flag => :ls_out_flag
      // )`;
      //   const binds = {
      //     p_plant: data.p_plant ? data.p_plant : "",
      //     p_radio_value: data.p_radio_value ? String(data.p_radio_value) : "",
      //     p_batch: data.p_batch ? data.p_batch : "",
      //     p_sec_tdc: data.p_sec_tdc ? data.p_sec_tdc : "",
      //     p_hold_rsn_cd: data.p_rls_hold_code ? data.p_rls_hold_code : "",
      //     p_remarks: data.p_rls_remarks ? data.p_rls_remarks : "",
      //     p_remarks1: data.p_rls_remarks1 ? data.p_rls_remarks1 : "",
      //     p_addl_proc: data.p_addl_process ? data.p_addl_process : "",
      //     p_gross_wt: data?.p_gross_wt ? data?.p_gross_wt : "",
      //     p_no_sheet: data?.p_no_sheet ? data?.p_no_sheet : "",
      //     p_new_net_wt: data?.p_new_net_wt ? data?.p_new_net_wt : "",
      //     ls_out_flag: {
      //       type: oracledb.STRING,
      //       dir: oracledb.BIND_OUT,
      //       maxSize: 2000,
      //     },
      //   };
      // console.log("sql-Last: ", sql);
      // console.log("binds-Last: ", binds);
      const results = await SCQ001Decision(data);
      // const results = await query(sql, binds);
      console.log("results-Last: ", results);
      return results;
    }
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ001Decision = async (data: any) => {
  try {
    let sql: any = `call TRMQ0005(
      p_plant => :p_plant,
      p_radio_value => :p_radio_value,
      p_batch => :p_batch,
      p_addl_proc => :p_addl_proc,
      p_sec_tdc => :p_sec_tdc,
      p_hold_rsn_cd => :p_hold_rsn_cd,
      p_remarks => :p_remarks,
      p_remarks1 => :p_remarks1,
      p_gross_wt => :p_gross_wt,
      p_no_sheet => :p_no_sheet,
      p_new_net_wt => :p_new_net_wt,
      p_div_tdc   => :p_div_tdc,
      ls_out_flag => :ls_out_flag
    )`;
    const binds = {
      p_plant: data.p_plant ? data.p_plant : "",
      p_radio_value: data.p_radio_value ? data.p_radio_value : "",
      p_batch: data.p_batch ? data.p_batch : "",
      p_sec_tdc: data.p_sec_tdc ? data.p_sec_tdc : "",
      p_hold_rsn_cd: data.p_rls_hold_code ? data.p_rls_hold_code : "",
      p_remarks: data.p_rls_remarks ? data.p_rls_remarks : "",
      p_remarks1: data.p_rls_remarks1 ? data.p_rls_remarks1 : "",
      p_addl_proc: data.p_addl_process ? data.p_addl_process : "",
      p_gross_wt: data?.p_gross_wt ? data?.p_gross_wt : "",
      p_no_sheet: data?.p_no_sheet ? data?.p_no_sheet : "",
      p_new_net_wt: data?.p_new_net_wt ? data?.p_new_net_wt : "",
      p_div_tdc: data?.p_div_tdc ? data?.p_div_tdc : "",
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };
    console.log("sql - SCQ001Decision: ", sql);
    console.log("binds - SCQ001Decision: ", binds);

    return await query(sql, binds);
  } catch (error: any) {
    console.log("error-SCQ001Decision : ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const SCQ001DiversionRes = async (data: any) => {
  try {
    let sql: any = `call TRMQ0007(
      coilid => :coilid,             
      qltycd => :qltycd,              
      tdcno => :tdcno,                
      ls_out_flag => :ls_out_flag       
    )`;
    const binds = {
      coilid: data?.data?.coilid ? data?.data?.coilid : "",
      qltycd: data?.data?.qltycd ? data?.data?.qltycd : "",
      tdcno: data?.data?.tdcno ? data?.data?.tdcno : "",
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };

    const result = await query(sql, binds);
    return result;
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
