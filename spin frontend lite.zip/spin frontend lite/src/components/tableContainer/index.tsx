import React from "react";
import { Grid, Typography, useTheme } from "@mui/material";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import { UIBox, AccordionUI } from "./style";
import { PropType } from "./type";
import { csTheme } from "src/theme/type";

const TableContainer = (props: PropType) => {
  const csTheme: csTheme = useTheme();
  const [isExpand, setIsExpand] = React.useState(true);
  return (
    <UIBox px={1} py={0}>
      <Grid container spacing={0}>
        <Grid item xs={12} className="header">
          <AccordionUI expanded={isExpand} title={props.title ? true : false}>
            {props?.title && (
              <AccordionSummary
                aria-controls="panel1-content"
                //id="panel1-header"
                sx={{
                  backgroundColor: csTheme?.palette.primary.main,
                  cursor: "default",
                  margin: 0,
                  height: "30px"
                }}
              >
                <Grid
                  container
                  direction="row"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Grid
                    item
                    onClick={() => setIsExpand(!isExpand)}
                    sx={{ mal: "10px", cursor: "pointer" }}
                  >
                    <Typography
                      sx={{ margin: "10px", cursor: "pointer" }}
                      onClick={() => setIsExpand(!isExpand)}
                    >
                      <i
                        className={
                          !isExpand
                            ? "fa-solid fa-angle-down"
                            : "fa-solid fa-angle-up"
                        }
                        style={{ marginRight: 3 }}
                      ></i>{" "}
                      {props.title}
                    </Typography>
                  </Grid>
                  <Grid item>{props.headerContainer}</Grid>
                </Grid>
              </AccordionSummary>
            )}
            <AccordionDetails sx={{ pt: 2 }}>{props.children}</AccordionDetails>
          </AccordionUI>
        </Grid>
      </Grid>
    </UIBox>
  );
};

export default TableContainer;
