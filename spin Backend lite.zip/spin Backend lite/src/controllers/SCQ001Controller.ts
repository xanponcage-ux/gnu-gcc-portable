import { Request, Response } from "express";
import SCQ001Model from "../models/SCQ001Model";
import { ResponceData } from "../utils";

export const SCQ001GetFilterData = async (req: Request, res: Response) => {
  try {
    const result = await SCQ001Model.prototype.SCQ001GetFilterData(req.body);
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const SCQ001GetData = async (req: Request, res: Response) => {
  try {
    const result = await SCQ001Model.prototype.SCQ001GetData(req.body);
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const SCQ001SaveData = async (req: Request, res: Response) => {
  try {
    const result = await SCQ001Model.prototype.SCQ001SaveData(req.body);
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
export const SCQ001Api = async (req: Request, res: Response) => {
  try {
    const result = await SCQ001Model.prototype.SCQ001Api(req.body);
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const SCQ001DiversionRes = async (req: Request, res: Response) => {
  try {
    const result = await SCQ001Model.prototype.SCQ001DiversionRes(req.body);
    return res.status(200).json(result);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
