Purpose
=======
This bridge exposes the Tata Steel company GenAI gateway as an OpenAI-compatible local endpoint:

  http://127.0.0.1:8765/v1/chat/completions

It reuses the same gateway contract found in FP_TUBES/Gen AI API Usage.ipynb and routes/checkDeffect.py.

Files
=====
continue_bridge.py  - bridge server
RUN_TEST.cmd        - starts the bridge; edit the 3 credential variables first
TEST_CHAT.cmd       - sends a simple test request after the bridge is running

Important
=========
The service-account JSON must contain an ACTIVE Google key. If the key ID is inactive, the bridge will report Invalid JWT Signature before the model is called.

The uploaded FP_TUBES copy contains a different service-account key from svc-genai-api-dev-oneit8.json, but that bundled key also does not match the active key suffixes observed during the current diagnostics.
