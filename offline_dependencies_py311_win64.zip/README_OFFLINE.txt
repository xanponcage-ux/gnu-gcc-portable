OFFLINE DEPENDENCIES FOR WINDOWS 64-BIT + PYTHON 3.11

1. Confirm in Command Prompt:
      python --version
   It must show Python 3.11.x for this bundle.

2. Open this folder on the company laptop:
      C:\CompanyGenAIBridge\company_genai_continue_bridge

3. Extract this ZIP directly into that folder.

4. After extraction, the same folder must contain:
      bridge.py
      requirements.txt
      INSTALL_OFFLINE_NOW.bat
      wheels\

5. Double-click INSTALL_OFFLINE_NOW.bat.

6. When it says SUCCESS, run start_bridge.bat and keep it open.

7. Open another Command Prompt in the same folder and run test_bridge.bat.

Do not run install.bat again; it tries to access blocked pypi.org.
