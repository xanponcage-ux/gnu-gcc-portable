# Company GenAI coding assistant in VS Code

This package connects the Continue VS Code extension to the company OneIT
GenAI gateway through a secure localhost adapter. It does **not** use
`neu_model.keras`; that 285 MB file is a steel-defect image classifier and is
unrelated to code generation or editing.

## What you need

- Windows laptop with Python 3.10 or newer.
- VS Code with permission to install a `.vsix` extension.
- Network/VPN access to the company GenAI endpoint.
- OneIT/security approval to send the source code you work on to this gateway.

This preconfigured package already contains the API key, AD ID, service-account
file, endpoint, authentication audience and localhost token from the supplied
company project. The ZIP must therefore be handled as a sensitive credential
bundle. Do not upload it to GitHub, email it, place it in OneDrive/a shared
folder, or give it to another person.

## 1. Place the files on the company laptop

1. Extract this package to a location such as:

   ```text
   C:\CompanyGenAIBridge
   ```

2. The preconfigured service-account file and `.env` are already included. The
   final structure includes:

   ```text
   C:\CompanyGenAIBridge\bridge.py
   C:\CompanyGenAIBridge\requirements.txt
   C:\CompanyGenAIBridge\.env
   C:\CompanyGenAIBridge\svc-genai-api-dev-oneit.json
   ```

3. Do not place this folder inside a project repository or OneDrive/shared
   folder.

## 2. Install the Python packages

Open Command Prompt in `C:\CompanyGenAIBridge` and run:

```bat
install.bat
```

This creates an isolated `.venv`; it does not require administrator rights.

### If `pip install` is blocked

On another Windows computer with the **same Python major/minor version and CPU
architecture**, place this package in a folder, open Command Prompt there, and
run:

```bat
python -m pip download -r requirements.txt -d wheels
```

Transfer the resulting `wheels` folder to `C:\CompanyGenAIBridge`, then run on
the company laptop:

```bat
install_offline.bat
```

If company policy does not allow third-party Python packages, stop and ask IT
to approve these exact packages rather than bypassing the restriction.

## 3. Verify the preconfigured paths

Open `.env` and confirm this path matches the folder where you extracted the
package:

```dotenv
GOOGLE_APPLICATION_CREDENTIALS=C:/CompanyGenAIBridge/svc-genai-api-dev-oneit.json
```

If you use exactly `C:\CompanyGenAIBridge`, no credential editing is required.
The endpoint in the original project is labelled development; request the
approved production endpoint before using this for production source code.
Restrict access to `.env` and the JSON file using Windows file properties if
other users can sign into the laptop.

The local token is not the company API key. It only prevents another local
process from casually calling the bridge.

## 4. Start and test the bridge

Double-click `start_bridge.bat`, or run it from Command Prompt. Keep its window
open while using the coding assistant.

In a second Command Prompt run:

```bat
test_bridge.bat
```

Success means:

- Health status is `ok`.
- Chat status is `200`.
- The JSON response contains an assistant message.

If the test fails, see Troubleshooting below before configuring VS Code.

## 5. Install Continue in VS Code

If the VS Code Marketplace works, install **Continue - open-source AI code
agent** normally.

If Marketplace access is blocked:

1. On an allowed computer, download the official Continue `.vsix` from the
   Visual Studio Marketplace or the extension's official release page.
2. Transfer the `.vsix` to the company laptop through the approved method.
3. In VS Code open Extensions, select the `...` menu, choose **Install from
   VSIX...**, and select the file.

Use only a company-approved extension version. Continue can read project files
that you explicitly give it as context.

## 6. Configure Continue

1. Open Continue in VS Code.
2. Open its local configuration file from the Continue settings/menu.
3. Copy the contents of `config.yaml.example` into the configuration. Its
   localhost token is already filled and matches `.env`; do not change only one
   of them.
4. Save and run **Developer: Reload Window** from the VS Code Command Palette.
5. Select `Company GPT-4o Mini` as the active model.

The custom `apiBase` is supported by Continue's OpenAI-compatible provider:
https://docs.continue.dev/customize/model-providers/top-level/openai

## 7. Protect files from being sent as context

For every code project, copy `.continueignore.example` to `.continueignore` in
the project root. Add project-specific secrets, data exports and confidential
documents as needed.

Also make sure `.gitignore` excludes `.env`, service-account JSON files,
certificates and private keys. Never ask the assistant to open these files.

## 8. Make your first code change

Start cautiously with one small file:

1. Open the project in VS Code.
2. Start the bridge.
3. Open the relevant source file and select the code to change.
4. In Continue use **Edit** and enter a precise request, for example:

   ```text
   In the selected React component, add validation so Order and Item are both
   required before Submit. Preserve the existing API payload keys. Show the
   proposed diff and do not modify unrelated formatting.
   ```

5. Review the diff line by line before accepting it.
6. Run the project's formatter, tests and build.
7. Commit only after manual review.

For a multi-file task, first use Chat/Plan mode:

```text
Inspect the selected frontend component and backend route. Explain which files
must change to add Order and Item filters. Do not edit anything yet.
```

After checking its analysis, ask it to implement one bounded change at a time.

## Chat, Edit and Agent mode

- **Chat** and **Edit** should work whenever the gateway returns normal text.
- **Agent mode** requires the company `gpt-4o-mini` deployment to preserve
  OpenAI tool calls. The supplied company notebook says custom tools are
  supported for `gpt-4o-mini`, but this must be verified against the current
  gateway.
- If Agent mode only writes explanations instead of invoking tools, use Edit
  mode. The bridge cannot create tool-calling ability if the company gateway
  strips tool definitions or tool-call responses.
- Do not enable autonomous execution for shell commands or accept-all changes
  on company repositories.

## Troubleshooting

### `configuration_required`

Check `.env`, confirm all four required values are present, and confirm the JSON
path exists. Restart the bridge after editing `.env`.

### HTTP 401 or 403 from the company gateway

- Confirm VPN/corporate-network access.
- Confirm the service account, API key and your AD ID are authorised together.
- Confirm the `TATA_GENAI_AUTH_AUDIENCE` supplied by OneIT.
- Do not repeatedly retry a disabled/revoked credential; contact the gateway
  owner.

### Certificate verification error

Ask IT for the corporate root/intermediate CA in PEM format and set:

```dotenv
TATA_GENAI_CA_BUNDLE=C:\CompanyGenAIBridge\company-ca-chain.pem
```

Keep `TATA_GENAI_VERIFY_TLS=true`. Do not solve certificate errors by disabling
verification.

### Cannot reach `127.0.0.1:8765`

Keep `start_bridge.bat` running. Check whether endpoint-security software blocks
localhost listeners and request an exception if required. The server binds only
to loopback and is not reachable from another computer.

### Continue shows 404 on `/responses`

Confirm the configuration contains:

```yaml
useResponsesApi: false
```

This forces `/v1/chat/completions`, which the bridge implements.

### Continue receives an answer but cannot edit files

Test Edit mode first. If only Agent mode fails, the likely issue is tool-call
support in the selected gateway deployment. Ask OneIT whether the currently
approved `gpt-4o-mini` deployment forwards the OpenAI `tools` and `tool_choice`
fields and returns `message.tool_calls`.

## Security checklist

- Confirm that the included credentials are authorised for you and for
  source-code use.
- Obtain the production endpoint rather than relying indefinitely on a dev URL.
- Keep the bridge on `127.0.0.1`; do not change it to `0.0.0.0`.
- Never commit `.env`, service-account JSON or company certificates.
- Maintain `.continueignore` in every project.
- Review every diff and command before approval.
- Do not send production data, passwords, customer information or restricted
  source code unless the gateway's data-handling policy explicitly permits it.
- Stop the bridge when you finish coding.
