/* ---------- INDENT REQUEST SCREEN --------------- */

import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import {
  Input,
  RadioInput,
  SelectInput,
  // MutipleInput,
} from "../../../components/input";
import DeleteIcon from "@mui/icons-material/Delete";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPS0010IndentingApi,
  // SPS0005UpdateCoilStatusApi,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";
import { useTheme } from "@mui/material/styles";
import { csTheme } from "../../../theme/type";
import SaveIcon from "@mui/icons-material/Save";
import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import { TableType } from "./type";
import { LoopMsg } from "../../type";
import { setTheme, useMaterialUIController } from "../../../context";
// import Multiselect from "multiselect-react-dropdown";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPS0010_indent = () => {
  const csTheme: csTheme = useTheme();
  const [controller, dispatch] = useMaterialUIController();
  const { theme, user } = controller;
  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [selectedProcess, setSelectedProcess] = React.useState<string>("");
  const [destPlant, setDestPlant] = React.useState<string>("");
  const [plantCodeData, setPlantCodeData] = React.useState<Array<SelectType>>(
    []
  );
  const [statusData, setStatusData] = React.useState<any>([]);
  const [orderData, setOrderData] = React.useState<Array<SelectType>>([]);
  const [selectedOrder, setSelectedOrder] = React.useState<string>("");
  const [plannedPath, setPlannedPath] = React.useState<Array<SelectType>>([]);
  const [processData, setProcessData] = React.useState<Array<SelectType>>([]);
  const [selectedStatus, setSelectedStatus] = React.useState<string>("");
  const [selectedCode, setSelectedCode] = React.useState<string>("");
  const [coilData, setCoilData] = React.useState<Array<SelectType>>([]);
  const [selectedCoil, setSelectedCoil] = React.useState<string>("");
  const [thickness, setThickness] = React.useState<string>("");
  const [thicknessTo, setThicknessTo] = React.useState<string>("");
  const [hight, setHight] = React.useState<string>("");
  const [width, setWidth] = React.useState<string>("");
  const [widthTo, setWidthTo] = React.useState<string>("");
  const [tdc, setTdc] = React.useState<string>("");
  const [statusCheckData, setStatusCheckData] = React.useState<any>({
    requestStatus: [],
    cancelStatus: [],
  });
  const [value, setValue] = React.useState<number>(0);
  const [prodCd, setProdCd] = React.useState<any>("");

  const [selectedRows, setSelectedRows] = React.useState<any>([]);
  const [secndTable, setSecndTable] = React.useState<any>(null);
  const [secndTableData, setSecndTableData] = React.useState<any>([]);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "From Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "To Date",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  // const radioButton = function (
  //   cell: any,
  //   formatterParams: any,
  //   onRendered: any
  // ) {
  //   //plain text value
  //   var editor = document.createElement("form");
  //   // editor.setAttribute("type", "select");
  //   let reasonData: any = [
  //     {
  //       VALUE: "A",
  //       LABEL: "Accept",
  //     },
  //     {
  //       VALUE: "R",
  //       LABEL: "Reject",
  //     },
  //   ];
  //   for (var i = 0; i < reasonData.length; i++) {
  //     var opt = document.createElement("input");
  //     opt.type = "radio";
  //     opt.name = "status";
  //     opt.value = reasonData[i].VALUE;

  //     var acceptLabel = document.createElement("label");
  //     acceptLabel.innerHTML = reasonData[i].LABEL;
  //     acceptLabel.appendChild(opt);
  //     editor.appendChild(acceptLabel);
  //   }
  //   //create and style input
  //   // editor.style.padding = "3px";
  //   editor.style.width = "100%";
  //   editor.style.boxSizing = "border-box";
  //   // editor.value = cell.getValue() ? cell.getValue() : "";

  //   onRendered(function () {
  //     editor.focus();
  //   });
  //   return editor;
  // };

  const column: Array<any> = [
    {
      title: "",
      formatter: "rowSelection",
      // formatter: function (cell) {
      //   var value = cell.getData().STATUS;
      //   if (value === "VI") {
      //     return "";
      //   } else {
      //     return "<input type='checkbox'>";
      //   }
      // },

      //Removing this cause added VI status check is required for pdi deletion
      // formatter: function (cell: any, formatterParams: any) {
      //   const row = cell.getRow();
      //   const status = row.getData().STATUS;
      //   if (status === "VS" || status === "VG") {
      //     return "<input type='checkbox'>";
      //   }
      //   return "";
      // },

      titleFormatter: "rowSelection",
      // titleFormatter: function (cell) {
      //   var rows = cell.getTable().getRows();
      //   var isAllSelected = true;
      //   for (var i = 0; i < rows.length; i++) {
      //     var status = rows[i].getData().STATUS;
      //     if (status === "VI") {
      //       isAllSelected = false;
      //       break;
      //     }
      //   }
      //   return "<input type='checkbox'>";
      // },
      cellClick: function (e, cell) {
        // Toggle row selection on checkbox click
        const row = cell.getRow();
        const checkbox = cell
          .getElement()
          .querySelector("input[type='checkbox']");
        if (checkbox && checkbox.checked) {
          row.toggleSelect();
        }
        // if (cell.getValue() === "<input type='checkbox' />") {
        //   row.toggleSelect();
        // }
      },
      hozAlign: "center",
      download: false,
      headerSort: false,
      frozen: true,
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Weight",
      field: "COIL_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Coil Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Process",
      field: "PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: false,
    },
    {
      title: "Planned Location",
      field: "PROC_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Schedule Flag (Y/N)",
      field: "SCHEDULE_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Indent Flag (Y/N)",
      field: "INDENT_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade Desc",
      field: "PLAN_GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thickness",
      field: "THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Cd",
      field: "ENC_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "ENC_MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Dispatch Week",
      field: "ENC_DESPATCH_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Destination",
      field: "ENC_SHIP_TO_PRTY_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Slp_Remarks",
      field: "SLP_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Age",
      field: "COIL_AGE",
      headerFilter: "input",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value && Number(value) > 30 && Number(value) < 60) {
          cell.getElement().style["background-color"] = "yellow";
          //cell.getElement().style["color"] = "#FFFFFF";
        } else if (value && Number(value) > 60) {
          cell.getElement().style["background-color"] = "red";
          //cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material No",
      field: "COIL_MAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Arrival Date",
      field: "COIL_ARRIVAL_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Material Description",
      field: "COIL_MAT_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];
  // const pathColumn: Array<any> = [
  //   {
  //     title: "Coil Id",
  //     field: "CoilId",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Status",
  //     field: "Status",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Prod Cd",
  //     field: "ProdCode",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Active Flag",
  //     field: "ActiveFlag",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Sr Plant",
  //     field: "SrPlant",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dest Plant",
  //     field: "DestPlant",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Dest Desciption",
  //     field: "DestDesciption",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Remarks",
  //     field: "Remarks",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Req By",
  //     field: "ReqBy",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Req On",
  //     field: "ReqOn",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Created By",
  //     field: "CreatedBy",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Created On",
  //     field: "CreatedOn",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "center",
  //   },
  //   {
  //     title: "Updated By",
  //     field: "UpdatedBy",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     hozAlign: "right",
  //   },
  //   {
  //     title: "Updated On",
  //     field: "UpdatedOn",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //   },
  //   {
  //     title: "Accept/Reject",
  //     field: "PPH_NO_PROC_PATH",
  //     headerFilter: "input",
  //     headerFilterPlaceholder: "search...",
  //     formatter: radioButton,
  //     cellClick: function (e: any, cell: any) {
  //       console.log("cell", cell);
  //       updateCoilStatusData(cell.getValue());
  //     },
  //   },
  // ];

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    // setValue(newValue);
    setSelectedCode("");
    setSelectedProcess("");
    fetchEpaData();
  };

  React.useEffect(() => {
    fetchEpaData();
  }, []);

  React.useEffect(() => {
    if (tableData?.length > 0) {
      let varData = new Tabulator("#table", {
        data: tableData,
        // columns: value === 0 ? column : pathColumn,
        columns: column,
        height: 200,
        layout: "fitDataFill",
        pagination: true,
        paginationSize: 20,
        paginationSizeSelector: [10, 20, 40, 60],
        paginationCounter: "rows",
      });
      setTable(varData);
    } else {
      setTable(null);
    }
  }, [tableData]);

  table?.on("rowSelected", function (selectedData: any) {
    console.log("Inside");
    // setSelectedRows((prevSelectedRows) => [
    //   ...prevSelectedRows,
    //   selectedData._row,
    // ]);

    // setSecndTableData((prevData) => [...prevData, selectedData.getData()]);

    // const selectedRow = selectedData.getData();
    // if (!secndTableData.some((row) => row.COIL_ID === selectedRow.COIL_ID)) {
    //   setSecndTableData((prevData) => [...prevData, selectedRow]);
    // }

    const selectedRow = selectedData.getData();
    // VI Status coil should not be selected in second table
    setSecndTableData((prevData) => {
      if (
        selectedRow.STATUS !== "VI" &&
        !prevData.some((row) => row.COIL_ID === selectedRow.COIL_ID)
      ) {
        return [...prevData, selectedRow];
      }
      return prevData;
    });
  });

  // table?.on("rowSelected", function (selectedData: any) {
  //   console.log(selectedData);
  //   setSecndTableData(selectedData._row);
  //   console.log(secndTable);
  // });

  // React.useEffect(() => {
  //   if (selectedRows.length > 0) {
  //     setSecndTable(
  //       new Tabulator("#table2", {
  //         data: selectedRows,
  //         columns: column2,
  //         height: 350,
  //         movableRows: true,
  //         layout: "fitDataFill",
  //       })
  //     );
  //   } else {
  //     setSecndTable(null);
  //   }
  //   return () => secndTable?.destroy();
  // }, [selectedRows]);

  React.useEffect(() => {
    if (secndTableData?.length > 0) {
      setSecndTable(
        new Tabulator("#table2", {
          data: secndTableData,
          columns: column2,
          height: 250,
          movableRows: true,
          movableColumns: true,
          layout: "fitDataFill",
        })
      );
    } else {
      setSecndTable(null);
    }
    return () => secndTable?.destroy();
  }, [secndTableData]);

  const handleDelete = () => {
    const selectedRows = secndTable.getSelectedRows();
    const selectedData = selectedRows.map((row) => row.getData());
    setSecndTableData((prevData) => {
      const updatedData = prevData.filter(
        (row) =>
          !selectedData.some(
            (selectedRow) => selectedRow.COIL_ID === row.COIL_ID
          )
      );
      return updatedData;
    });
  };

  const procedureCall = (row: any) => {
    if (row?.length === 0) {
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0010IndentingApi(token, {
        type: "procedureCall",
        plantId: selectedCode,
        coilId: row,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res.data?.N.length === 0) {
              alertify.success("Y- Indent Successful");
              fetchData(0);
            } else {
              let failedCoils = res?.data?.N.join();
              alertify.error("All coils confirmed except " + failedCoils);
              fetchData(0);
            }
            //table?.deselectRow();
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  // const updateCoilStatusData = (data: string) => {
  //   // const dataArr: any = [];
  //   // const gridData = table?.getSelectedRows();
  //   // if (!(gridData?.length > 0)) {
  //   //   alertify.error("Please select a row!");
  //   //   return;
  //   // }

  //   // gridData.map((x: any) => {
  //   //   dataArr.push({
  //   //     P_REASON_CODE     : inputObj?.key46?.value,
  //   //   });
  //   // });
  //   console.log("data", data);
  //   setLoading(true);
  //   GetAuthorization().then((token) => {
  //     SPS0005UpdateCoilStatusApi(token, { status: data })
  //       .then((res) => {
  //         let msg = "";
  //         if (res?.statusText !== "" && res?.statusText !== "OK") {
  //           alertify.error(res?.data?.err ? res.data.err : res?.toString());
  //         } else if (res?.data) {
  //           res.data?.res_n?.map((x: LoopMsg) => {
  //             msg = msg + `${x.id}: ${x.msg} ,`;
  //           });
  //           if (res.data?.res_n?.length > 0) {
  //             alertify.error(
  //               msg + (res.data?.res_y?.length > 0 ? "rest are confirmed." : "")
  //             );
  //           } else if (res.data?.res_y?.length > 0) {
  //             alertify.success(`Success`);
  //             setTableData([]);
  //             fetchData(value);
  //           } else {
  //             console.log("error here");
  //             alertify.error("Something Wents wrong!");
  //           }
  //         } else {
  //           console.log("error");
  //           alertify.error("Something Wents wrong!");
  //         }
  //       })
  //       .catch((e: any) => {
  //         console.log("error", e);
  //         alertify.error(
  //           e?.error?.message ? e.error.message : "Something Wents wrong!"
  //         );
  //       })
  //       .finally(() => {
  //         setLoading(false);
  //       });
  //   });
  // };

  const handleDeleteIndent = () => {
    const gridData = table?.getSelectedRows();
    if (gridData?.length === 0) {
      alertify.error("Please select a row!");
      return;
    }
    let coilIds: Array<string> = [];
    let check = true;
    console.log(statusCheckData);
    for (let i = 0; i < gridData.length; i++) {
      if (
        !statusCheckData?.cancelStatus.includes(
          gridData[i]?._row?.getData().STATUS
        )
      ) {
        check = false;
        break;
      }
      coilIds.push(gridData[i]?._row?.getData().COIL_ID);
    }
    if (!check) {
      alertify.error("Indent deletion is not allowed");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0010IndentingApi(token, {
        type: "deleteIndent",
        plantId: selectedCode,
        coilId: coilIds,
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            // console.log(res.data);
            if (res.data?.N.length === 0) {
              alertify.success("Y- Deletion Successfull");
              fetchData(0);
            } else {
              let failedCoils = res?.data?.N.join();
              alertify.error("All coils deleted except " + failedCoils);
              fetchData(0);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const confirmData = (data: any) => {
    // const gridData = table?.getSelectedRows();
    const gridData = secndTable?.getSelectedRows();

    if (gridData?.length === 0) {
      alertify.error("Please select a row!");
      return;
    }
    let coilIds: Array<string> = [];
    let check = true;
    console.log(statusCheckData);
    for (let i = 0; i < gridData.length; i++) {
      if (
        !statusCheckData?.requestStatus.includes(
          gridData[i]?._row?.getData().STATUS
        )
      ) {
        check = false;
        break;
      }
      coilIds.push(gridData[i]?._row?.getData().COIL_ID);
    }
    if (!check) {
      alertify.error("Indent Request is not allowed");
      setSecndTableData([]);
      return;
    }
    procedureCall(coilIds);
  };

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  const fetchEpaData = (plant?: any) => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0010IndentingApi(token, {
        type: "getData",
        pno: user,
        ...(plant?.length > 0 && { Plant: plant }),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (!plant) {
              const varData: Array<SelectType> = [];
              res?.data?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varData?.push({
                    value: x?.EPL_CD_EPA?.toString(),
                    label: x?.EPL_CD_EPA_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlantCodeData(varData);
              setSelectedCode(varData[0].value);
              fetchEpaData(varData[0].value);
            } else {
              const varbatchData: Array<SelectType> = [];
              res?.data?.batch?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varbatchData?.push({
                    value: x?.EOM_ID_BATCH?.toString(),
                    label: x?.EOM_ID_BATCH?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setCoilData(varbatchData);
              const varorderData: Array<SelectType> = [];
              res?.data?.order?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varorderData?.push({
                    value: x?.EOM_ID_ORDER?.toString(),
                    label: x?.EOM_ID_ORDER?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setOrderData(varorderData);
              const varprocessData: Array<SelectType> = [];
              res?.data?.process?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varprocessData?.push({
                    value: x?.EPL_CD_PROCESS?.toString(),
                    label: x?.EPL_PROC_LINE_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setProcessData(varprocessData);
              const varstatusData: Array<SelectType> = [];
              res?.data?.status?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusData?.push({
                    value: x?.VALUE?.toString(),
                    label: x?.LABEL?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setStatusData(varstatusData);
              const varstatusReqData: Array<any> = [];
              res?.data?.checkReqStatus?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varstatusReqData?.push(x?.CD_VALUE)}
                </React.Fragment>
              ));
              const varStatusCancelData: Array<any> = [];
              res?.data?.checkCancelStatus?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varStatusCancelData?.push(x?.CD_VALUE)}
                </React.Fragment>
              ));
              setStatusCheckData({
                requestStatus: varstatusReqData,
                cancelStatus: varStatusCancelData,
              });
              var varPlannedPath: Array<SelectType> = [];
              res?.data?.plannedPath?.map((x: any, i: number) => (
                <React.Fragment key={i}>
                  {varPlannedPath?.push({
                    value: x?.PPH_CD_PROC_PATH?.toString(),
                    label: x?.PPH_DESC?.toString(),
                    id: i,
                  })}
                </React.Fragment>
              ));
              setPlannedPath(varPlannedPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(e?.error?.message ? e.error.message : e?.toString());
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchData = (data: any) => {
    if (!(selectedCode?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0010IndentingApi(token, {
        type: "IndentCoilDetails",
        data: data,
        Plant: selectedCode,
        process: selectedProcess,
        BatchId: selectedCoil,
        Status: selectedStatus,
        Tdc: tdc,
        ThickFR: thickness,
        ThickTo: thicknessTo,
        WidthFr: width,
        WidthTo: widthTo,
        prodCd: prodCd,
        fromDt: DateFormat(inputObj.key1.value),
        toDt: DateFormat(inputObj.key2.value),
      })
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            if (res?.data?.length === 0) {
              alertify.error("No Data Found");
              return;
            } else if (data === 0) {
              // console.log("res.data: ", res.data);
              setTableData(res.data);
              setSecndTableData([]);
            } else {
              setTableData(res.data?.procPath);
            }
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = () => {
    if (tableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPS0005_" + ".xlsx";
    table.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };
  const handleClearAll = () => {
    setSelectedCode("");
    setSelectedProcess("");
    setTableData([]);
    setSecndTableData([]);
    setInputObj(varInput);
    setSelectedStatus("");
  };
  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const column2: Array<any> = [
    {
      title: "",
      formatter: "rowSelection",
      titleFormatter: "rowSelection",
      hozAlign: "center",
      download: false,
      headerSort: false,
      frozen: true,
    },
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Weight",
      field: "COIL_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Coil Status",
      field: "STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Process",
      field: "PROCESS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      // visible: false,
    },
    {
      title: "Planned Location",
      field: "PROC_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Schedule Flag (Y/N)",
      field: "SCHEDULE_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Indent Flag (Y/N)",
      field: "INDENT_FLAG",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Prod Cd",
      field: "PROD_CD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "TDC",
      field: "TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Grade Desc",
      field: "PLAN_GRADE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Thickness",
      field: "THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Width",
      field: "WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue().toFixed(3);
        return value;
      },
    },
    {
      title: "Idia",
      field: "IDIA",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Cd",
      field: "ENC_MARK_CUST",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Mark Cust Name",
      field: "ENC_MARK_CUST_NAME",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Dispatch Week",
      field: "ENC_DESPATCH_WK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Destination",
      field: "ENC_SHIP_TO_PRTY_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Slp_Remarks",
      field: "SLP_REMARKS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Age",
      field: "COIL_AGE",
      headerFilter: "input",
      hozAlign: "right",
      formatter: function (cell: any) {
        var value = cell.getValue();
        if (value && Number(value) > 30 && Number(value) < 60) {
          cell.getElement().style["background-color"] = "yellow";
          //cell.getElement().style["color"] = "#FFFFFF";
        } else if (value && Number(value) > 60) {
          cell.getElement().style["background-color"] = "red";
          //cell.getElement().style["color"] = "#FFFFFF";
        }
        return value;
      },
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material No",
      field: "COIL_MAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Cast No",
      field: "CAST_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Coil Arrival Date",
      field: "COIL_ARRIVAL_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Material Description",
      field: "COIL_MAT_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Plant",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              {loading ? <Loader /> : null}
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={2.5}>
                        <SelectInput
                          label="Plant*"
                          data={plantCodeData}
                          id={"id"}
                          value={selectedCode}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCode(e);
                            setTableData([]);
                            setSecndTableData([]);
                            //fetchEpaData(e);
                            //setScheduleDetailsData([]);
                            //setTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2.5}>
                        <SelectInput
                          label="Process"
                          data={processData}
                          value={selectedProcess}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedProcess(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <SelectInput
                          label="Status"
                          data={statusData}
                          value={selectedStatus}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedStatus(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={2}>
                        <SelectInput
                          label="Coil Id"
                          data={coilData}
                          id={"id"}
                          value={selectedCoil}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedCoil(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={1.5}>
                        <Input
                          label="Thick From"
                          value={thickness}
                          size={"small"}
                          type={"number"}
                          onChange={(e: string) => {
                            setThickness(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={1.5}>
                        <Input
                          label="Thick To"
                          value={thicknessTo}
                          size={"small"}
                          type={"number"}
                          onChange={(e: string) => {
                            setThicknessTo(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={1.5}>
                        <Input
                          label="Width From"
                          value={width}
                          size={"small"}
                          type={"number"}
                          onChange={(e: string) => {
                            setWidth(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={1.5}>
                        <Input
                          label="Width To"
                          value={widthTo}
                          size={"small"}
                          type={"number"}
                          onChange={(e: string) => {
                            setWidthTo(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      {/* <Grid item xs={1}>
                  <Input
                    label="Height"
                    value={hight}
                    size={"small"}
                    onChange={(e: string) => setHight(e)}
                  />
                </Grid> */}
                      <Grid item xs={1}>
                        <Input
                          label="Tdc"
                          value={tdc}
                          size={"small"}
                          onChange={(e: string) => {
                            setTdc(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={1.5}>
                        <Input
                          label="Prod Cd"
                          id={"prodCd"}
                          value={prodCd}
                          onChange={(e: string) => {
                            setProdCd(e);
                            setTableData([]);
                            setSecndTableData([]);
                          }}
                        />
                      </Grid>
                      <Grid item xs={4}>
                        {/* From Date */}
                        <Box component="span">
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i < 2 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      // onChange={x?.data?.onChange}
                                      onChange={(e: string) => {
                                        if (x?.data?.onChange) {
                                          x.data.onChange(e);
                                        }
                                        setTableData([]);
                                        setSecndTableData([]);
                                      }}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>
                      <Grid item xs={1}>
                        <ButtonElement onClick={() => fetchData(value)}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>
            <Grid item xs={12}>
              <TableContainer
                title="Details"
                headerContainer={
                  <Grid container>
                    {/* <Grid item>
                      {
                        // value === 0 &&
                        <Tooltip title="Request Indent">
                          <IconButton
                            onClick={() => {
                              confirmData(value);
                            }}
                            disabled={restricted !== "RL_RW"}
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      }
                    </Grid> */}

                    <Grid item>
                      {
                        // value === 0 &&
                        <Tooltip title={"Delete Indent"}>
                          <IconButton
                            onClick={() => {
                              handleDeleteIndent();
                            }}
                            disabled={restricted !== "RL_RW"}
                          >
                            <DeleteIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      }
                    </Grid>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {/* <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                  >
                    <Tab label="Indent Coil" />
                    <Tab label="Accept/Reject Coil Request/Send Coil" />
                  </Tabs>
                </Box> */}
                  {
                    //value === 0 &&
                    tableData?.length > 0 && (
                      <Grid container spacing={2}>
                        <Grid item xs={12}>
                          <div id="table"></div>
                        </Grid>
                      </Grid>
                    )
                  }
                  {/* {
                    // value === 1 &&
                    tableData?.length > 0 && <div id="table"></div>
                  } */}
                </Box>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Batch Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      {
                        // value === 0 &&
                        <Tooltip title="Request Indent">
                          <IconButton
                            onClick={() => {
                              confirmData(value);
                            }}
                            disabled={restricted !== "RL_RW"}
                          >
                            <SaveIcon sx={{ color: "#ffffff" }} />
                          </IconButton>
                        </Tooltip>
                      }
                    </Grid>
                    <Grid item>
                      <Tooltip title={"Delete row"}>
                        <IconButton
                          onClick={handleDelete}
                          disabled={restricted !== "RL_RW"}
                        >
                          <DeleteIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {secndTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table2"></div>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPS0010_indent;
