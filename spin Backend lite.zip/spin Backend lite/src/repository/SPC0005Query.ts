import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";
import { getCommonPlantData } from "./plantQuery";

export const getSpecLimit05 = async (data: any) => {
  try {
    let binds: any = {};

    let sql = `SELECT
        NVL(TSL_CD_TEST, '') TSL_CD_TEST,
        NVL(TSL_FL_CHNG_SAP, '') TSL_FL_CHNG_SAP,
        NVL(TSL_PARA_MAX, 0) TSL_PARA_MAX,
        NVL(TSL_PARA_MIN, 0) TSL_PARA_MIN,
        NVL(TSL_PARA_UNIT, '') TSL_PARA_UNIT,
        NVL(TSL_RFD_ID, ' ') TSL_RFD_ID,
        NVL(TSL_SR_COMPANY, '') TSL_SR_COMPANY,
        NVL(TSL_SR_COMP_FLAG, ' ') TSL_SR_COMP_FLAG,
        NVL(TSL_TDC_NO, '') TSL_TDC_NO,
        NVL(TSL_TEST_PARA, '') TSL_TEST_PARA
      FROM
      V_TDC_SPEC_LIMIT`;
    if (data?.tdc) {
      sql += ` WHERE TSL_TDC_NO = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.testPara && data.testPara?.length > 0) {
      sql += ` AND TSL_TEST_PARA = :testPara`;
      binds["testPara"] = data?.testPara;
    }
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getQualityData05 = async (data: any) => {
  try {
    let binds: any = {};
    let sql = `SELECT
        IQL_CD_QLTY CD_QLTY,
        IQL_GRADE GRADE,
        IQL_GRADE_DESC GRADE_DESC,
        to_char(IQL_TS_CREATE, 'DD-MON-YY HH24:MI:SS') TS_CREATE,
        IQL_CD_SPEC_TOL CD_SPEC_TOL,
        IQL_DS_QLTY DS_QLTY,
        IQL_PS_INDICATOR PS_INDICATOR
      FROM
        V_QUALITY`;
    if (data?.qltyCode) {
      sql += ` WHERE IQL_CD_QLTY = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }

    if (data.grade && data.grade?.length > 0) {
      sql += ` AND IQL_GRADE = :grade`;
      binds["grade"] = data?.grade;
    }
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcMain05 = async (data: any) => {
  try {
    let binds: any = {};
    let sql = `SELECT
      TMA_TDC_NO TDC_NO,
      TMA_TDC_DESC TDC_DESC,
      TMA_CD_QLTY CD_QLTY,
      TMA_GRADE GRADE,
      TMA_TDC_GRD_DESC TDC_GRD_DESC,
      TMA_SEC1_AIM_FR SEC1_AIM_FR,
      TO_CHAR(ROUND(TMA_SEC1_AIM_TO, 3), '9990.000') SEC1_AIM_TO,
      TMA_SEC2_AIM_FR SEC2_AIM_FR,
      TMA_SEC2_AIM_TO SEC2_AIM_TO,
      TMA_CD_END_USE CD_END_USE,
      TMA_END_USE_DESC END_USE_DESC,
      TMA_SEC1_TOL_MIN SEC1_TOL_MIN,
      TMA_SEC1_TOL_MAX SEC1_TOL_MAX,
      TMA_HR_TDC_NO HR_TDC_NO,
      TMA_CD_PROD CD_PROD,
      TMA_RFD_ID RFD_ID,
      TMA_CD_QLTY CD_QLTY,
      TMA_CD_PROD CD_PROD
     
    FROM
      V_TDC_MAIN`;
    if (data?.tdc) {
      sql += ` WHERE TMA_TDC_NO = :tdc`;
      binds["tdc"] = data?.tdc;
    }

    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND TMA_CD_QLTY = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }

    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcCode05 = async () => {
  try {
    const sql = `SELECT
      DISTINCT TSL_TDC_NO
     FROM
      V_TDC_SPEC_LIMIT`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getQltyCode05 = async () => {
  try {
    const sql = `SELECT
      DISTINCT IQL_CD_QLTY
     FROM
      V_QUALITY`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcMainCode05 = async () => {
  try {
    const sql = `SELECT
      DISTINCT TMA_TDC_NO
     FROM
      V_TDC_MAIN`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};
