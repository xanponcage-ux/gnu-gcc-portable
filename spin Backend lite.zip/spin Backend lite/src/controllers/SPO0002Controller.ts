import { Request, Response } from "express";
import SPO0002Model from "../models/SPO0002Model";
import { ResponceData } from "../utils";
import query from "../infrastructure/database/querys";

export const getData = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    varData = await SPO0002Model.prototype.getData(req.body);
    return res.status(200).json(await ResponceData(varData));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};

export const confirmPacking = async (req: Request, res: Response) => {
  try {
    let varData: any = {};
    var results: any = {};
    var batch: any = {};
    varData = await SPO0002Model.prototype.ConfirmPacking(req.body);
    let insertMsg = varData.outBinds.ls_out_flag;
    if (insertMsg === "Y") {
      let result: any = await SPO0002Model.prototype.confirm(req.body);
      let outBinds = result.outBinds.ls_out_flag;
      results = outBinds;
    } else {
      results = insertMsg;
    }
    return res.status(200).json(await ResponceData(results));
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
