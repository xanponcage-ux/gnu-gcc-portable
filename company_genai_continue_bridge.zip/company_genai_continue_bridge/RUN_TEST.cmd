@echo off
setlocal

REM ===== EDIT THESE 3 VALUES =====
set "GENAI_KEYFILE=C:\Users\806760\Downloads\svc-genai-api-dev-oneit8.json"
set "GENAI_ADID=YOUR_ADID"
set "GENAI_APIKEY=YOUR_API_KEY"

REM ===== COMPANY ROUTING / MODEL =====
set "GENAI_PROXY=http://127.0.0.1:13124"
set "GENAI_MODEL=gpt-4o-mini"
set "GENAI_GROUNDING=0"

REM Use the Python environment that already has google-auth/FastAPI if present.
set "PY=C:\CompanyGenAIBridge\.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo ERROR: Python environment not found at %PY%
  pause
  exit /b 1
)

"%PY%" -m uvicorn continue_bridge:app --host 127.0.0.1 --port 8765
