import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, SelectInput } from "../../../components/input";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import { GetAuthorization, DateFormat } from "../../../utils";
import { Grid, IconButton, Tooltip } from "@mui/material";
import {
  GetPlantDataApi,
  SPC0021GetScDwnData,
} from "../../../apiConfig/insideAuthApi";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import Loader from "../../../components/preloader";
import { SelectType } from "../../../components/input/type";

import { DatePickerInput } from "../../../components/input";
import ButtonElement from "../../../components/button";
import { TokenType } from "../../../type";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import Auth from "../../../components/layout/dashboardLayout/auth";

const R_SPC0021 = () => {
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");
  const [batchId, setBatchId] = React.useState<string>("");
  const [motherBatch, setMotherBatch] = React.useState<string>("");

  const [table, setTable] = React.useState<any>(null);
  const [tableData, setTableData] = React.useState<any>([]);

  const actionList: Array<SelectType> = [
    { value: "A", label: "SCRAP", id: 1 },
    { value: "B", label: "DOWNGRADE", id: 2 },
  ];

  const [selectedAction, setSelectedAction] = React.useState<string>(
    actionList[0].value
  );

  const [selectedDate, setselectedDate] = React.useState<string>("");

  const [selectedDateFrm, setSelectedDateFrm] = React.useState<string>("");

  const [selectedDateTo, setSelectedDateTo] = React.useState<string>("");

  React.useEffect(() => {
    setLoading(true);
    fetchPlantData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const getTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }

    if (!(selectedAction?.length > 0)) {
      alertify.error("Please select Action!");
      return;
    }

    const formateDate = (date) => {
      if (!date) return null;
      const d = new Date(date);

      // console.log(d);
      return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
        .toISOString()
        .split("T")[0];
    };

    const data = {
      plant: selectedPlant,
      action_cd: selectedAction ? selectedAction : "",
      batchId: batchId ? batchId : "",
      motherBatch: motherBatch ? motherBatch : "",
      // prodDate: DateFormat(selectedDate) ? DateFormat(selectedDate) : "",
      prodDtFrm: formateDate(selectedDateFrm)
        ? formateDate(selectedDateFrm)
        : "",
      prodDtTo: formateDate(selectedDateTo) ? formateDate(selectedDateTo) : "",
    };

    // console.log(data);

    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPC0021GetScDwnData(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (!res?.data || res.data.length === 0) {
            alertify.error("No Data Found!");
            setTableData([]);
          } else if (res?.data) {
            setTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  React.useEffect(() => {
    if (tableData?.length > 0) {
      setTable(
        new Tabulator("#table", {
          data: tableData,
          columns: tableCol,
          height: 350,
          layout: "fitDataFill",
          pagination: true,
          paginationSize: 20,
          paginationSizeSelector: [10, 20, 40, 60],
          paginationCounter: "rows",
        })
      );
    } else {
      setTable(null);
    }
  }, [tableData]);

  const tableCol: Array<CulmnType> = [
    {
      title: "Coil Id",
      field: "COIL_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Scrap Wt",
      field: "SCRAP_WT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      bottomCalc: "sum",
      bottomCalcParams: { precision: 3 },
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Reason Code",
      field: "RSN_CODE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Reason Desc",
      field: "RSN_DESC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Reason Cat",
      field: "RSN_CAT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Batch Id",
      field: "BATCH_ID",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Parent Batch",
      field: "PARENT_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Coil Thk",
      field: "COIL_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Coil Width",
      field: "COIL_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell?.getValue();
        if (value) {
          return value?.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Coil Tdc",
      field: "COIL_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Scrapped By",
      field: "SCRAPPED_BY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Scrap Date",
      field: "EBS_DT_SCRAP",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
    {
      title: "Posting Status",
      field: "POSTING_STATUS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
    },
  ];

  const handleClearAll = () => {
    setBatchId("");
    setMotherBatch("");
    setSelectedAction("");
    setTableData([]);
    setSelectedDateFrm("");
    setSelectedDateTo("");
  };

  const downloadExcel = () => {
    if (tableData?.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    // var date = new Date();
    var fileName = "Scrap/Downgrade Reason Report" + ".xlsx";
    table?.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Filter"
              headerContainer={
                <Tooltip title="Clear All">
                  <IconButton onClick={handleClearAll}>
                    <ClearAllIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Grid container spacing={2}>
                        <Grid item xs={2}>
                          <SelectInput
                            id={"id"}
                            value={selectedPlant}
                            data={plant}
                            label="Plant*"
                            size={"small"}
                            onChange={(e: string) => {
                              setSelectedPlant(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2.1}>
                          <SelectInput
                            label="Action*"
                            data={actionList}
                            value={selectedAction}
                            onChange={(e: string) => {
                              setSelectedAction(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1.8}>
                          <Input
                            id={"batchId"}
                            value={batchId}
                            label="Batch Id"
                            size={"small"}
                            onChange={(e: string) => {
                              setBatchId(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1.8}>
                          <Input
                            id={"motherBatch"}
                            value={motherBatch}
                            label="Mother Batch"
                            size={"small"}
                            onChange={(e: string) => {
                              setMotherBatch(e.toUpperCase().slice(0, 10));
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        {/* <Grid item xs={2}>
                                                    <DatePickerInput
                                                        label="Prod Date"
                                                        // id={x?.key}
                                                        value={selectedDate}
                                                        onChange={(e: string) => {
                                                            setselectedDate(e);
                                                            setTableData([]);
                                                        }}
                                                    />
                                                </Grid> */}

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Prod Date From"
                            // id={x?.key}
                            value={selectedDateFrm}
                            onChange={(e: string) => {
                              setSelectedDateFrm(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={2}>
                          <DatePickerInput
                            label="Prod Date To"
                            // id={x?.key}
                            value={selectedDateTo}
                            onChange={(e: string) => {
                              setSelectedDateTo(e);
                              setTableData([]);
                            }}
                          />
                        </Grid>

                        <Grid item xs={1}>
                          <ButtonElement onClick={getTableData}>
                            Submit
                          </ButtonElement>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </TableContainer>
          </Grid>
          <Grid item xs={12}>
            <TableContainer
              title="Details"
              headerContainer={
                <Tooltip title="Download">
                  <IconButton onClick={downloadExcel}>
                    <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                  </IconButton>
                </Tooltip>
              }
            >
              {tableData?.length > 0 && <div id="table"></div>}
            </TableContainer>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default R_SPC0021;
