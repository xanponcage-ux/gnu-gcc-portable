import { dateInput, input } from "../../type";

export interface InputChangeType {
  key1: input;
  key2: input;
}
export interface radio {
  label: string;
  value: string;
}
export interface PopupObj {
  popUp: boolean;
  data: any;
}
