import { Request, Response } from "express";
import SPC0002Model from "../models/SPC0002Model";
import { ResponceData } from "../utils";

export const getData02 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    if (req.body.data === 0) {
      result1 = await SPC0002Model.prototype.getProcLineData02(req.body);
    }
    if (req.body.data === 1) {
      result2 = await SPC0002Model.prototype.getProcPath02(req.body);
    }
    varData = {
      ...{ procLine: await ResponceData(result1) },
      ...{ procPath: await ResponceData(result2) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    console.log("error", error);
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
