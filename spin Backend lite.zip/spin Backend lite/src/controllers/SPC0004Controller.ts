import { Request, Response } from "express";
import SPC0004Model from "../models/SPC0004Model";
import { ResponceData } from "../utils";

export const SPC0004getData04 = async (req: Request, res: Response) => {
  try {
    let varData: any = [];
    let result1;
    let result2;
    if (req.body.data === 0) {
      result1 = await SPC0004Model.prototype.upcomingpageCode04(req.body);
    }
    if (req.body.data === 1) {
      result2 = await SPC0004Model.prototype.upcomingpage_02_Code04(req.body);
    }
    varData = {
      ...{ X: await ResponceData(result1) },
      ...{ Y: await ResponceData(result2) },
    };
    return res.status(200).json(varData);
  } catch (error: any) {
    return res
      .status(400)
      .json({ error: error?.message ? error?.message?.toString() : "Error" });
  }
};
