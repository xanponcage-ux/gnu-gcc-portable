
import * as repository from "../repository/TTSM047Query";

export default class  TTSM047 {
  static getFinalcampaignData(Plant: any) {
    return repository.getFinalcampaignData(Plant);
  };
  
}







