import query from "../infrastructure/database/querys";
import Error from "../models/errors";
import oracledb from "oracledb";

//In-transit Details Tab
export const getData01 = async (data: any) => {
  try {
    // console.log("data - getData01: ", data);
    let binds: any = {
      epaCode: data?.code,
    };
    let sql: any = ` SELECT NVL (EIC_ID_COIL, '') COIL_ID, NVL (EIC_NO_INVOICE, 0) INVOICE_NO,
       TO_CHAR (EIC_DT_INVOICE, 'DD-MON-YYYY') INVOICE_DT,
       NVL (EIC_NO_DELIVERY, '') DELV_NO, NVL (EIC_CD_PROD, '') PROD_CD,
       NVL (EIC_CD_QLTY_ACTL, '') QLTY_CD, 
       NVL (EIC_SEC1, '') THICK, NVL (EIC_SEC2, '') WIDTH,
       NVL (EIC_TDC_ACTL, '') TDC, NVL (EIC_NO_MATNR, '') MATERIAL_NO,
       NVL (EIC_NO_CAST, '') CAST_NO, NVL (EIC_CD_EDGE, '') EDGE,
       NVL (EIC_MS_PIECE_ACTL, 0) INVOICE_WEIGHT,
       (EIC_MS_PIECE_ACTL - NVL (EIC_MS_SCRAP, 0)) RESIDUAL_WEIGHT,
       NVL (EIC_ID_LOC_X, '') LOC_X, NVL (EIC_ID_LOC_Y, '') LOC_Y,
       NVL (EIC_ID_POS, '') POS, NVL (EIC_CD_YRD, '') YARD,
       NVL (EIC_REMARKS, ' ') REMARKS, NVL (EIC_MS_PIECE_ACTL, 0) SPC_WT,
       NVL (EIC_CD_STATUS, '') STATUS, NVL (EIC_CD_EPA, '') PLANT,
       NVL (EIC_ID_OP_SCRAP, '') OPERATOR_ID,
       NVL (EIC_MARK_CUST, '') CUSTOMER_CODE, 
       NVL (EIC_PASSED_PROC, '') MILL_PASSED_PROCESS,
       ROUND ((SYSDATE - EIC_DT_INVOICE)) INVOICE_AGE,
       ROUND ((SYSDATE - NVL (EIC_DT_LOADING, SYSDATE))) AGE_AT_SPC,
       TO_CHAR (EIC_DT_LOADING, 'DD-MON-YYYY') ARRIVAL_DT,
       ROUND (NVL (EIC_DT_LOADING, SYSDATE) - NVL (EIC_DT_INVOICE, SYSDATE)
             ) TRANSIT_LEAD_TIME_DAYS
       ,NULL AS INDENT_DATE
       ,NULL AS INDENT_BY
       ,EIC_MK_CUSTOMER MARK_CUST_NAME
       ,EIC_WO_NO CUST_ORD_NO
       ,EIC_ITEM_NO CUST_ITEM_NO
      FROM V_INPUT_COIL
      WHERE EIC_CD_EPA = :epaCode
      AND EIC_CD_STATUS = 'VA'`;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EIC_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EIC_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EIC_ID_COIL = '${data?.batchId}'`; //:batchId`;
      // binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EIC_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EIC_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EIC_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EIC_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr) {
      sql += ` AND EIC_DT_LOADING BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }
    if (data?.indentDateFrm || data?.indentDateTo) {
      sql += ` AND EIC_DT_INVOICE BETWEEN NVL('${data?.indentDateFrm}','01-JAN-1900') AND NVL('${data?.indentDateTo}','31-DEC-9999')`;
    }
    // if (data?.processDateFr) {
    //   sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:processDateFr,'01-JAN-1900') AND NVL(:processDateTo,'31-DEC-9999')`
    //   binds.processDateFr = data?.processDateFr;
    //   binds.processDateTo = data?.processDateTo;
    // }
    sql += " UNION ALL ";
    sql += ` SELECT NVL (EOM_ID_BATCH, '') COIL_ID, NVL(EOM_NO_INVOICE, '') INVOICE_NO,
       TO_CHAR(EOM_DT_INVOICE,'DD-MON-YYYY') INVOICE_DT,
       NULL DELV_NO, NVL (EOM_CD_PROD, '') PROD_CD,
       NVL (EOM_CD_QLTY_ACTL, '') QLTY_CD, 
       NVL (EOM_SEC1, '') THICK, NVL (EOM_SEC2, '') WIDTH,
       NVL (EOM_TDC_ACTL, '') TDC, NVL (EOM_NO_MATNR, '') MATERIAL_NO,
       NVL (EOM_NO_CAST, '') CAST_NO, NVL (EIC_CD_EDGE, '') EDGE,
       NVL (EOM_MS_PIECE_ACTL, 0) INVOICE_WEIGHT,
       0 RESIDUAL_WEIGHT, 
       NVL (EOM_ID_LOC_X, '') LOC_X, NVL (EOM_ID_LOC_Y, '') LOC_Y,
       NVL (EOM_ID_POS, '') POS, NVL (EOM_CD_YRD, '') YARD,
       NVL ('', ' ') REMARKS, NVL (EOM_MS_PIECE_ACTL, 0) SPC_WT,
       NVL (EOM_CD_STATUS, '') STATUS, NVL (EOM_CD_EPA, '') PLANT,
       NVL (EOM_ID_OP_SCRAP, '') OPERATOR_ID,
       NVL ('', '') CUSTOMER_CODE,
       NULL MILL_PASSED_PROCESS,
       0 INVOICE_AGE,
       0 AGE_AT_SPC,
       NULL ARRIVAL_DT,
       ROUND (SYSDATE - EOM_TS_CREATION) TRANSIT_LEAD_TIME_DAYS
       ,TO_CHAR(EOM_OTH_DEST_SEND_DT, 'DD-MM-YYYY HH24:MM:SS') AS INDENT_DATE
       ,EOM_OTH_CEN_SEND_BY AS INDENT_BY
       ,EIC_MK_CUSTOMER MARK_CUST_NAME
       ,EIC_WO_NO CUST_ORD_NO
       ,EIC_ITEM_NO CUST_ITEM_NO
      FROM V_EPA_PRODN A , V_INPUT_COIL B
      WHERE EOM_CD_EPA = :epaCode
      AND A.EOM_CD_EPA = B.EIC_CD_EPA
      AND A.EOM_ID_BATCH = B.EIC_ID_COIL
      AND EOM_CD_STATUS = 'VI' `;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EOM_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EOM_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EOM_ID_BATCH = '${data?.batchId}'`; //:batchId`;
      // binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EOM_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EOM_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EOM_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EOM_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EOM_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr) {
      sql += ` AND EOM_TS_CREATION BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }
    if (data?.indentDateFrm || data?.indentDateTo) {
      sql += ` AND EOM_OTH_DEST_SEND_DT BETWEEN NVL('${data?.indentDateFrm}','01-JAN-1900') AND NVL('${data?.indentDateTo}','31-DEC-9999')`;
    }
    // console.log("sql-tab1: ", sql);
    return await query(sql, binds);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

//Rec Raw Mat Tab
export const getData02 = async (data: any) => {
  try {
    let binds: any = {
      epaCode: data?.code,
    };

    let sql: any = ` 
    SELECT NVL(EIC_ID_COIL, '') AS COIL_ID
    ,NVL(EIC_CD_STATUS, '') AS STATUS
    ,NVL(EIC_SEC1, '') AS THICK
    ,NVL(EIC_SEC2, '') AS WIDTH
    ,NVL(EIC_LENGTH, '') AS LENGTH
    ,NVL(EIC_TDC_ACTL, '') AS TDC
    ,NVL(EIC_NO_INVOICE, '') AS INV_NO
    ,TO_CHAR(EIC_DT_INVOICE,'DD-MON-YYYY') AS INV_DT
    ,NVL(EIC_NO_DELIVERY, '') AS DELV_NO
    ,NVL(EIC_CD_PROD, '') AS PROD_CD
    ,NVL(EIC_CD_QLTY_ACTL, '') AS QLTY_CD
    ,NVL(EIC_NO_MATNR, '') AS MAT_NO
    ,NVL(EIC_NO_CAST, '') AS CAST_NO
    ,NVL(EIC_MS_PIECE_ACTL, '') AS NET_WT
    ,NVL(EIC_ID_LOC_X, '') AS LOC_X
    ,NVL(EIC_ID_LOC_Y, '') AS LOC_Y
    ,NVL(EIC_ID_POS, 0) AS POS
    ,NVL(EIC_CD_YRD, '') AS YRD
    ,NVL(EIC_CD_EPA, '') AS PLANT 
    ,TO_CHAR(EIC_DT_LOADING, 'DD-MM-YYYY HH24:MI:SS') AS CREATE_DT
    ,NULL AS INDENT_DATE
    FROM V_INPUT_COIL
    WHERE EIC_CD_EPA = :epacode
    AND EIC_CD_STATUS =  'VA' `;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EIC_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EIC_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EIC_ID_COIL = :batchId`;
      binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EIC_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EIC_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EIC_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EIC_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr) {
      sql += ` AND EIC_DT_LOADING BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }
    // This is added for rec location for VI, VG coils
    sql += ` UNION ALL `;
    sql += ` SELECT NVL(EOM_ID_BATCH, '') AS COIL_ID
    ,NVL(EOM_CD_STATUS, '') AS STATUS
    ,NVL(EOM_SEC1, '') AS THICK
    ,NVL(EOM_SEC2, '') AS WIDTH
    ,NVL(EOM_LENGTH, '') AS LENGTH
    ,NVL(EOM_TDC_ACTL, '') AS TDC
    ,NVL(EOM_NO_INVOICE, '') AS INV_NO
    ,TO_CHAR(EOM_DT_INVOICE,'DD-MON-YYYY') AS INV_DT
    ,NVL('', 0) AS DELV_NO
    ,NVL(EOM_CD_PROD, '') AS PROD_CD
    ,NVL(EOM_CD_QLTY_ACTL, '') AS QLTY_CD
    ,NVL(EOM_NO_MATNR, '') AS MAT_NO
    ,NVL(EOM_NO_CAST, '') AS CAST_NO
    ,NVL(EOM_MS_PIECE_ACTL, 0) AS NET_WT
    ,NVL(EOM_ID_LOC_X, '') AS LOC_X
    ,NVL(EOM_ID_LOC_Y, '') AS LOC_Y
    ,NVL(EOM_ID_POS, '') AS POS
    ,NVL(EOM_CD_YRD, '') AS YRD
    ,NVL(EOM_CD_EPA, '') AS PLANT 
    ,TO_CHAR(EOM_TS_CREATION, 'DD-MM-YYYY HH24:MI:SS') AS CREATE_DT
    ,TO_CHAR(EOM_OTH_DEST_SEND_DT, 'DD-MM-YYYY HH24:MM:SS') AS INDENT_DATE
    FROM V_EPA_PRODN
    WHERE EOM_CD_EPA = :epacode
    AND EOM_CD_STATUS IN (SELECT CD_VALUE FROM V_CODES WHERE CD_TYPE = 'TK031')`;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EOM_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EOM_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EOM_ID_BATCH  = :batchId`;
      binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EOM_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EOM_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EOM_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EOM_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EOM_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr) {
      sql += ` AND EOM_TS_CREATION BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }

    sql += ` order by STATUS, INV_NO`;
    // console.log("sql - getData02: ", sql);
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

//Rec Raw Mat Report
export const getData03 = async (data: any) => {
  try {
    let binds: any = {
      epaCode: data?.code,
    };
    let sql: any = ` 
    SELECT NVL(EIC_ID_COIL, '') AS COIL_ID
    ,NVL(EIC_CD_STATUS, '') AS STATUS
    ,NVL(EIC_SEC1, '') AS THICK
    ,NVL(EIC_SEC2, '') AS WIDTH
    ,NVL(EIC_LENGTH, '') AS LENGTH
    ,NVL(EIC_TDC_ACTL, '') AS TDC
    ,NVL(EIC_NO_INVOICE, '') AS INV_NO
    ,TO_CHAR(EIC_DT_INVOICE,'DD-MON-YYYY') AS INV_DT
    ,NVL(EIC_NO_DELIVERY, '') AS DELV_NO
    ,NVL(EIC_CD_PROD, '') AS PROD_CD
    ,NVL(EIC_CD_QLTY_ACTL, '') AS QLTY_CD
    ,NVL(EIC_NO_MATNR, '') AS MAT_NO
    ,NVL(EIC_NO_CAST, '') AS CAST_NO
    ,NVL(EIC_MS_PIECE_ACTL, 0) AS NET_WT
    ,NVL(EIC_ID_LOC_X, '') AS LOC_X
    ,NVL(EIC_ID_LOC_Y, '') AS LOC_Y
    ,NVL(EIC_ID_POS, '') AS POS
    ,(SELECT EOM_CD_YRD FROM V_EPA_PRODN WHERE EOM_ID_BATCH = EIC_ID_COIL AND EOM_CD_EPA = EIC_CD_EPA) AS YRD
    ,NVL(EIC_CD_EPA, '') AS PLANT
    ,NVL(EIC_MK_CUSTOMER, '') AS MARK_CUST
    ,TO_CHAR(EIC_DT_LOADING, 'DD-MM-YYYY HH24:MI:SS') AS CREATE_DT
    ,EIC_IDIA COIL_IDIA
    ,EIC_ODIA COIL_ODIA
    FROM V_INPUT_COIL
    WHERE EIC_CD_EPA = :epacode 
    AND EIC_DT_LOADING is NOT null`;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EIC_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EIC_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EIC_ID_COIL = :batchId`;
      binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EIC_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EIC_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EIC_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EIC_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EIC_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr || data?.receivingDateTo) {
      sql += ` AND EIC_DT_LOADING BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }

    sql += ` ORDER BY EIC_DT_LOADING`;
    // console.log("sql - getData03: ", sql);
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

//Return Raw Material
export const getData04 = async (data: any) => {
  try {
    let binds: any = {
      epaCode: data?.code,
    };

    let sql = ` SELECT NVL(EOM_ID_BATCH, '') AS COIL_ID
    ,NVL(EOM_CD_STATUS, '') AS STATUS
    ,NVL(EOM_SEC1, '') AS THICK
    ,NVL(EOM_SEC2, '') AS WIDTH
    ,NVL(EOM_LENGTH, '') AS LENGTH
    ,NVL(EOM_TDC_ACTL, '') AS TDC
    ,NVL(EOM_CD_PROD, '') AS PROD_CD
    ,NVL(EOM_CD_QLTY_ACTL, '') AS QLTY_CD
    ,NVL(EOM_NO_MATNR, '') AS MAT_NO
    ,NVL(EOM_NO_CAST, '') AS CAST_NO
    ,NVL(EOM_MS_PIECE_ACTL, 0) AS NET_WT
    ,NVL(EOM_CD_EPA, '') AS PLANT 
    ,TO_CHAR(EOM_TS_CREATION, 'DD-MM-YYYY HH24:MI:SS') AS CREATE_DT
    ,TO_CHAR(EOM_OTH_DEST_SEND_DT, 'DD-MM-YYYY HH24:MM:SS') AS INDENT_DATE
    FROM V_EPA_PRODN
    WHERE EOM_CD_EPA = :epacode
    AND EOM_CD_STATUS = 'VG'`;

    if (data.process && data.process?.length > 0) {
      sql += ` AND EOM_CD_STATUS = :process`;
      binds["process"] = data?.process;
    }
    if (data.tdc && data.tdc?.length > 0) {
      sql += ` AND EOM_TDC_ACTL = :tdc`;
      binds["tdc"] = data?.tdc;
    }
    if (data.batchId && data.batchId?.length > 0) {
      sql += ` AND EOM_ID_BATCH  = :batchId`;
      binds["batchId"] = data?.batchId;
    }
    if (data.invoiceNo && data.invoiceNo?.length > 0) {
      sql += ` AND EOM_NO_INVOICE = :invoiceNo`;
      binds["invoiceNo"] = data?.invoiceNo;
    }
    if (data.materialNo && data.materialNo?.length > 0) {
      sql += ` AND EOM_NO_MATNR = :materialNo`;
      binds["materialNo"] = data?.materialNo;
    }
    if (data.prodCode && data.prodCode?.length > 0) {
      sql += ` AND EOM_CD_PROD = :prodCode`;
      binds["prodCode"] = data?.prodCode;
    }
    if (data.qltyCode && data.qltyCode?.length > 0) {
      sql += ` AND EOM_CD_QLTY_ACTL = :qltyCode`;
      binds["qltyCode"] = data?.qltyCode;
    }
    if (data?.invoiceDateFr) {
      sql += ` AND EOM_DT_INVOICE BETWEEN NVL(:invoiceDateFr,'01-JAN-1900') AND NVL(:invoiceDateTo,'31-DEC-9999')`;
      binds.invoiceDateFr = data?.invoiceDateFr;
      binds.invoiceDateTo = data?.invoiceDateTo;
    }
    if (data?.receivingDateFr) {
      sql += ` AND EOM_TS_CREATION BETWEEN NVL(:receivingDateFr,'01-JAN-1900') AND NVL(:receivingDateTo,'31-DEC-9999')`;
      binds.receivingDateFr = data?.receivingDateFr;
      binds.receivingDateTo = data?.receivingDateTo;
    }
    console.log("sql - getData04: ", sql);
    return await query(sql, binds);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getStatusCodeData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_CD_STATUS
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getInvoiceData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_NO_INVOICE
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getMaterialData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_NO_MATNR
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getProdData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_CD_PROD
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getQltyData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_CD_QLTY_ACTL
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getTdcData01 = async () => {
  try {
    const sql: any = `SELECT
      DISTINCT EIC_TDC_ACTL
    FROM
      V_INPUT_COIL`;
    return await query(sql);
  } catch (error: any) {
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const saveTableData = async (batchId: any, yard: any) => {
  try {
    const sql: any = `Insert into V_YMS_L3_COIL_RECV
       (REC_ID_SOR_APPL, REC_ID_DESTN_APPL, REC_ID_MESSAGE, REC_RESERVED_1, REC_RESERVED_2,
        REC_ID_COIL, REC_YARD, REC_HOLD_CODE)
     Values
       ('L3_SP_YMS', 'SPIN', f_nannow_second_telgrm(SYSDATE), 'N', 'N',
        '${batchId}', '${yard}', '00')`;

    // console.log("sql: ", sql);
    return await query(sql);
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const tabAccess = async () => {
  try {
    let sql: any = `select cd_value from v_codes where cd_type = 'TK023'`;

    const result = await query(sql);
    return result;
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const getYardValue = async () => {
  try {
    let sql: any = `select cd_value yard from v_codes where cd_type = 'TK032'`;

    const result = await query(sql);
    return result;
  } catch (error: any) {
    console.log(error);
    throw new Error.InternalServerErrorMsg(error);
  }
};

export const deleteCoil = async (batchId: any, plantCd: any) => {
  try {
    const sql: any = `call TDSB0009 (
    ls_coilid   => :ls_coilid,
    ls_plantcd    => :ls_plantcd,
    ls_out_flag   => :ls_out_flag
    )`;

    const binds = {
      ls_coilid: batchId ?? "",
      ls_plantcd: plantCd ?? "",
      ls_out_flag: {
        type: oracledb.STRING,
        dir: oracledb.BIND_OUT,
        maxSize: 500,
      },
    };

    // console.log("sql: ", sql);
    // console.log("binds: ", binds);

    let result = await query(sql, binds);
    // console.log("result: ", result);
    return result?.outBinds?.ls_out_flag;
  } catch (error: any) {
    console.log("SPCG001_deleteCoil-error: ", error);
    throw new Error.InternalServerErrorMsg(error);
  }
};
