export interface TableType {
    EGP_CD_EPA: string;
    CIR_ID_COIL: string;
    EIC_ID_COIL: string;
}

export interface PopupObj {
    open:boolean,
    id:string
}

export interface radio {
    label:string,
    value:string,
}