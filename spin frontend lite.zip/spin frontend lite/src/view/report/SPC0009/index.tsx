import React from "react";
import DashboardLayout from "../../../components/layout/dashboardLayout";
import Tabulator from "../../../components/table";
import TableContainer from "../../../components/tableContainer";
import { Input, RadioInput, SelectInput } from "../../../components/input";
import {
  Grid,
  IconButton,
  Tab,
  Tabs,
  Box,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  SPS0009GetYieldDataApi,
  // SPC0009GetPlantDataApi,
  GetPlantDataApi,
} from "../../../apiConfig/insideAuthApi";
import Loader from "../../../components/preloader";
import { DatePickerInput } from "../../../components/input";
import { GetAuthorization, DateFormat } from "../../../utils";
import { TokenType } from "../../../type";
import { CulmnType } from "../../../type";
import alertify from "../../../components/alert";
import ButtonElement from "../../../components/button";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import { SelectType } from "../../../components/input/type";
import { FormType } from "../../auth/type";
import { InputChangeType } from "./type";
import Auth from "../../../components/layout/dashboardLayout/auth";

const P_SPC0009 = () => {
  const [loading, setLoading] = React.useState<boolean>(false);
  const [plant, setPlant] = React.useState<Array<SelectType>>([]);
  const [selectedPlant, setSelectedPlant] = React.useState<string>("");

  const [yieldTable, setYieldTable] = React.useState<any>(null);
  const [yieldTableData, setYieldTableData] = React.useState<any>([]);

  const varInput: InputChangeType = {
    key1: {
      config: {
        type: "input",
        label: "From",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key1"),
    },
    key2: {
      config: {
        type: "input",
        label: "To",
      },
      value: "",
      onChange: (e: any) => onInputChange(e?.toString(), "key2"),
    },
  };

  const [inputObj, setInputObj] = React.useState<InputChangeType>(varInput);

  let formData: Array<FormType> = [];
  for (const i in inputObj) {
    formData.push({
      key: i.toString(),
      data: inputObj[i as keyof InputChangeType],
    });
  }

  const onInputChange = (value: string, obj: string) => {
    setInputObj((prevState: InputChangeType) => ({
      ...prevState,
      [obj]: {
        ...inputObj[obj as keyof InputChangeType],
        value: value?.toString(),
      },
    }));
  };

  React.useEffect(() => {
    // setLoading(true);
    fetchPlantData();
  }, []);

  const fetchPlantData = () => {
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      GetPlantDataApi(token)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data) {
            const varData: Array<SelectType> = [];
            res.data?.map((x: any, i: number) => (
              <React.Fragment key={i}>
                {varData.push({
                  value: x?.EPL_CD_EPA?.toString(),
                  label: x?.EPL_CD_EPA_DESC?.toString(),
                  id: i,
                })}
              </React.Fragment>
            ));
            setPlant(varData);
            setSelectedPlant(varData[0]?.value);
          }
        })
        .catch((e: any) => {
          console.log("e", e);
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const fetchTableData = () => {
    if (!(selectedPlant?.length > 0)) {
      alertify.error("Please select Plant!");
      return;
    }
    const data = {
      plant: selectedPlant,
      dateFr: DateFormat(inputObj.key1.value),
      dateTo: DateFormat(inputObj.key2.value),
    };
    setLoading(true);
    GetAuthorization().then((token: TokenType) => {
      SPS0009GetYieldDataApi(token, data)
        .then((res) => {
          if (res.statusText !== "" && res.statusText !== "OK") {
            alertify.error(res?.data?.err ? res.data.err : res?.toString());
          } else if (res?.data?.length === 0) {
            alertify.error("No Data Found!");
            setYieldTableData(res.data);
            return;
          } else {
            setYieldTableData(res.data);
          }
        })
        .catch((e) => {
          alertify.error(
            e?.error?.message ? e.error.message : "Something Wents wrong!"
          );
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const downloadExcel = () => {
    if (yieldTableData.length === 0) {
      alertify.error("No Data exists in table for Downloading");
      return;
    }
    var date = new Date();
    var fileName = "SPC0009_" + ".xlsx";
    yieldTable.download("xlsx", fileName, {
      sheetName: "Sheet1",
    });
  };

  const handleClearAll = () => {
    setSelectedPlant("");
    setYieldTableData([]);
    setInputObj(varInput);
  };

  React.useEffect(() => {
    if (yieldTableData?.length > 0) {
      setYieldTable(
        new Tabulator("#table", {
          data: yieldTableData,
          columns: yieldTableCol,
          height: 400,
          layout: "fitDataFill",
          movableRows: true,
          // pagination: true,
          // paginationSize: 20,
          // paginationSizeSelector: [10, 20, 40, 60],
          // paginationCounter: "rows",
        })
      );
    } else {
      setYieldTable(null);
    }
  }, [yieldTableData]);

  const yieldTableCol: Array<CulmnType> = [
    {
      title: "Month",
      field: "YEAR_MONTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Month",
      field: "YEAR_MONTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Approval No",
      field: "APPROVAL_NO",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Approval Raise Date",
      field: "APPROVAL_RAISED_ON",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "SPC",
      field: "PLANT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "MC Batch",
      field: "MC_BATCH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "MC Thick",
      field: "MC_THK",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "MC Width",
      field: "MC_WIDTH",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "MC TDC",
      field: "MC_TDC",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "MC Qty",
      field: "MC_QTY",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Status",
      field: "APPROVAL_TYPE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "FG Size",
      field: "FG_SIZE",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Plan Qty",
      field: "FG_TONN_PLAN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Customer",
      field: "FG_CUSTOMER",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Offcut Qty",
      field: "OFFCUT_TONN",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Planned Yield",
      field: "TYT_CAL_YIELD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Accepted Yield",
      field: "TYT_ACP_YIELD",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Planned Yield Loss",
      field: "YIELD_LOSS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
      formatter: function (cell: any, formatterParams: any) {
        var value = cell.getValue();
        if (value) {
          return value.toFixed(3);
        }
        return value;
      },
    },
    {
      title: "Actual Loss(Planning)",
      field: "ACTUAL_LOSS",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "SPC Mgr Remarks if Any",
      field: "SPC_MANAGER_REM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Approving Authority Remarks",
      field: "APPROVING_AUTH_REM",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
    {
      title: "Approval Arrived Date",
      field: "APPROVING_AUTH_APP_DT",
      headerFilter: "input",
      headerFilterPlaceholder: "search...",
      hozAlign: "right",
    },
  ];

  const [restricted, setRestricted] = React.useState(null);
  return (
    <DashboardLayout>
      <Auth isRestricted={restricted} setRestricted={setRestricted}>
        <Grid container spacing={0} sx={{ pl: 1 }}>
          <Grid item xs={12}>
            {loading ? <Loader /> : null}
          </Grid>

          <Grid container spacing={0} sx={{ pl: 1 }}>
            <Grid item xs={12}>
              <TableContainer
                title="Filter"
                headerContainer={
                  <Tooltip title="Clear All">
                    <IconButton onClick={handleClearAll}>
                      <ClearAllIcon sx={{ color: "#ffffff" }} />
                    </IconButton>
                  </Tooltip>
                }
              >
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={1.7}>
                        <SelectInput
                          label="Plant*"
                          data={plant}
                          id={"id"}
                          value={selectedPlant}
                          size={"small"}
                          onChange={(e: string) => {
                            setSelectedPlant(e);
                            //   fetchEpaData(e);
                            //   setTableData([]);
                          }}
                        />
                      </Grid>

                      <Grid item xs={3}>
                        <Box component="span">
                          {" "}
                          {/* Date */}
                          <Grid container spacing={2}>
                            {formData.map(
                              (x: FormType, i: number) =>
                                i >= 0 &&
                                i < 2 && (
                                  <Grid item key={x?.key} xs={6}>
                                    <DatePickerInput
                                      id={x?.key}
                                      value={
                                        x?.data?.value?.length > 0
                                          ? x?.data?.value
                                          : null
                                      }
                                      {...x?.data?.config}
                                      onChange={x?.data?.onChange}
                                    />
                                  </Grid>
                                )
                            )}
                          </Grid>
                        </Box>
                      </Grid>

                      <Grid item xs={2}>
                        <ButtonElement onClick={() => fetchTableData()}>
                          Search
                        </ButtonElement>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableContainer>
            </Grid>

            <Grid item xs={12}>
              <TableContainer
                title="Details"
                headerContainer={
                  <Grid container>
                    <Grid item>
                      <Tooltip title="Download">
                        <IconButton onClick={downloadExcel}>
                          <DownloadForOfflineIcon sx={{ color: "#ffffff" }} />
                        </IconButton>
                      </Tooltip>
                    </Grid>
                  </Grid>
                }
              >
                <Box sx={{ width: "100%" }}>
                  {yieldTableData?.length > 0 && (
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <div id="table"></div>
                        <br />
                        <p
                          color="black"
                          style={{
                            color: "black",
                            paddingLeft: "1rem",
                            marginTop: "-1rem",
                          }}
                        >
                          Showing 1 to {yieldTableData?.length} of{" "}
                          {yieldTableData?.length} entries
                        </p>
                      </Grid>
                    </Grid>
                  )}
                </Box>
              </TableContainer>
            </Grid>
          </Grid>
        </Grid>
      </Auth>
    </DashboardLayout>
  );
};

export default P_SPC0009;
